# Google Play / AdMob server integration foundation

These modules are NOT a deployed payment service. The public GitHub Pages game is an explicitly labeled local TEST market. It never launches real checkout, charges money, makes real ad requests or accepts client ad-completed events as verified real rewards.

The verifier checks Google Play product and subscription responses using an injected server-authenticated Android Publisher fetch. Products must exist in Play Console with the listed IDs. Obfuscated account ID must match a server-authenticated game account. Pending/canceled products, inactive/expired subscriptions and mismatched accounts are rejected. Price, stars amount, expiry and reward amount never come from client claims.

AdMob SSV validation uses Google's trusted public-key endpoint, exact raw signed query bytes, allowlisted ad unit, account, one-time server challenge, timestamp and exact reward. SQLite transactions and globally unique hashed purchase-token/ad-transaction IDs prevent duplicate delivery grants. Challenges are single-use, server reward cap is3/day. Subscription expiry can be refreshed or revoked.

Live launch still needs account/recovery and authoritative ownership/save migration, server hosting/HTTPS, Google service-account credentials/API permissions, consume/acknowledgement jobs, refund/voided-purchase reconciliation and authenticated RTDN, product/base-plan/ad IDs, consent/privacy/store configuration and a Play internal-track test. Google test ads must not credit production SSV rewards.

The ledger accepts only objects returned by trusted server verification. NEVER expose its apply methods directly as client JSON endpoints. Public web frontend does not call them. Never put service-account JSON into frontend code or chat.

This is a tested integration starting point, not production payment readiness. No live credentials are present.
