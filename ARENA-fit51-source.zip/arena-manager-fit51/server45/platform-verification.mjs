import{verify,createPublicKey}from'node:crypto';
export const PRODUCTS45=new Map([['stars50',{product:'arena_stars_50',type:'inapp',stars:50}],['stars180',{product:'arena_stars_180',type:'inapp',stars:180}],['stars450',{product:'arena_stars_450',type:'inapp',stars:450}],['club',{product:'arena_club_pass',type:'subs',daily:2}],['pro',{product:'arena_pro_pass',type:'subs',daily:5}]]);
const fail=m=>{throw Error(m)},safe=v=>typeof v==='string'&&/^[a-zA-Z0-9_.:-]{1,200}$/.test(v);
export async function verifyPlay45({packageName,skuId,purchaseToken,accountId,publisherFetch,now=Date.now()}){
 const item=PRODUCTS45.get(skuId);if(!item||!safe(packageName)||!safe(accountId)||typeof purchaseToken!=='string'||purchaseToken.length<8||purchaseToken.length>4096)fail('Invalid purchase request');
 if(typeof publisherFetch!=='function')fail('Google Play server credentials not configured');
 const base='https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'+encodeURIComponent(packageName)+'/purchases/',path=item.type==='subs'?'subscriptionsv2/tokens/'+encodeURIComponent(purchaseToken):'products/'+encodeURIComponent(item.product)+'/tokens/'+encodeURIComponent(purchaseToken),r=await publisherFetch(base+path);
 if(!r.ok)fail('Google Play verification failed');const data=await r.json();
 if(item.type==='inapp'){
  if(data.purchaseState!==0||data.obfuscatedExternalAccountId!==accountId||(data.quantity??1)!==1)fail('Purchase pending, canceled or bound to another account');
  if(typeof data.orderId!=='string'||!data.orderId)fail('Missing Play order');return{provider:'google-play',sku:skuId,product:item.product,type:'inapp',stars:item.stars,accountId,orderId:data.orderId,purchaseToken,acknowledged:data.acknowledgementState===1,consumed:data.consumptionState===1,consume:true};
 }
 if(data.externalAccountIdentifiers?.obfuscatedExternalAccountId!==accountId)fail('Subscription account mismatch');
 const line=data.lineItems?.find(v=>v.productId===item.product),expires=Date.parse(line?.expiryTime||'');
 if(!['SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD','SUBSCRIPTION_STATE_CANCELED'].includes(data.subscriptionState)||!Number.isFinite(expires)||expires<=now)fail('Subscription not entitled');
 return{provider:'google-play',sku:skuId,product:item.product,type:'subs',daily:item.daily,accountId,orderId:data.latestOrderId||data.latestSuccessfulOrderId||'',purchaseToken,expires,acknowledged:data.acknowledgementState==='ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED',consume:false};
}
export function verifyAdMob45({rawQuery,trustedKeys,allowedAdUnits,accountId,challenge,now=Date.now()}){
 // Signatures cover exact raw percent-encoded bytes BEFORE &signature=.
 if(typeof rawQuery!=='string'||rawQuery.length>16000)fail('Invalid callback');
 const at=rawQuery.indexOf('&signature=');if(at<1)fail('Missing ad signature');const signed=rawQuery.slice(0,at),params=new URLSearchParams(rawQuery),sig=params.get('signature'),keyId=params.get('key_id');
 for(const k of['signature','key_id','transaction_id','custom_data','user_id','timestamp','ad_unit','reward_amount','reward_item'])if(params.getAll(k).length!==1)fail('Duplicate or missing ad field');
 if(!/^&signature=[A-Za-z0-9_%=-]+&key_id=[0-9]+$/.test(rawQuery.slice(at)))fail('Unsigned callback fields');
 const signedParams=new URLSearchParams(signed);for(const k of['transaction_id','custom_data','user_id','timestamp','ad_unit','reward_amount','reward_item'])if(signedParams.getAll(k).length!==1)fail('Unsigned reward field');
 const pem=trustedKeys?.get(keyId);if(!pem||!sig||!/^[A-Za-z0-9_-]+={0,2}$/.test(sig))fail('Unknown trusted ad key');
 let valid=false;try{valid=verify('SHA256',Buffer.from(signed),createPublicKey(pem),Buffer.from(sig,'base64url'))}catch{}if(!valid)fail('Invalid ad signature');
 const timestamp=Number(params.get('timestamp')),transactionId=params.get('transaction_id');
 if(!safe(transactionId)||!Number.isSafeInteger(timestamp)||Math.abs(now-timestamp)>300000||params.get('user_id')!==accountId||params.get('custom_data')!==challenge||!allowedAdUnits.includes(params.get('ad_unit'))||params.get('reward_amount')!=='1'||params.get('reward_item')!=='ticket')fail('Ad callback context rejected');
 return{provider:'admob',transactionId,accountId,challenge,tickets:1,timestamp};
}
export async function loadAdMobKeys45(fetcher=fetch){const r=await fetcher('https://www.gstatic.com/admob/reward/verifier-keys.json');if(!r.ok)fail('AdMob key download failed');const data=await r.json(),keys=new Map();for(const k of data.keys||[])if(Number.isSafeInteger(k.keyId)&&typeof k.pem==='string')keys.set(String(k.keyId),k.pem);if(!keys.size)fail('No trusted AdMob keys');return keys;}
