# Android Google Play + AdMob library45

Compile-only integration library, not a new APK or a connected payment service. Billing8.0.0, MobileAds24.6.0, UMP3.2.0. Official Google sample app ID in manifest; production host must override it with its own app ID.

Host Activity must call APIs on the UI thread and provide authenticated HTTPS Backend and safe UI Sink implementations. Do not expose native purchase methods to foreign WebView pages or frames. Purchase tokens stay native/server-side, never return to JS. Play product details supply localized prices; monthly subscription base plans and obfuscated account IDs required.

Pending/canceled purchases never grant inventory. Purchased/restored items go to server verification; server must grant durably then consume/acknowledge. Ads require UMP consent and server challenge, and client reward callback only triggers pending status until server SSV confirms. Privacy form exposed. App audience, age/consent configuration, lifecycle integration and duplicate-ad launch guards remain host integration work.

The public45web preview is TEST ONLY. No live Backend, app accounts, real ad IDs, merchant credentials or receipt lifecycle jobs are configured. Internal Play testing, signed app/package, product/base-plan creation, backend hosting/auth/ownership migration, refunds/RTDN/ack and real AdMob setup are launch prerequisites. Never use localStorage as a real-money wallet.

Gradle :commerce:assembleDebug outputs an AAR for review. It does not replace the game APK or production bot. See server45 for verifier/ledger foundation and explicit remaining work.
