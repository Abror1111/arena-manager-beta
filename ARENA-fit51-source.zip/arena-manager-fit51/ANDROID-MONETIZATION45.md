# ARENA45 — Google Play + AdMob yo‘li

Hozir: sayt marketi faqat TEST. Haqiqiy pul yechilmaydi, AdMob reklama so‘rovi yuborilmaydi. Test obunalari30kun, avtomatik uzaymaydi. Test xaridi va video bonuslari offline klubni o‘zgartirishi mumkin, lekin pullik huquq yoki server hamyoni hisoblanmaydi.

Tayyor sinovlar: yulduz paketlari; yulduz yoki video chiptasiga oddiy market o‘yinchisini olish;3profil ramkasi; +24energiya; ClubPass/ProPass kunlik bonuslari;18soniyalik original namuna video;3ta/UTCkun test limit; bekor qilish, qayta xarid/replay, offline saqlash va mobil o‘lchamlar. Oddiy tanga transferi saqlangan.

Android45 papkasidagi kutubxona Billing8.0.0, MobileAds24.6.0 va UMP3.2.0 bilan AARga yig‘iladi. Bu APK emas. Haqiqiy account/HTTPS Backend va Activity integratsiyasi kerak; native callback o‘zi mukofot bermaydi. SDK mahsulot tafsilotlaridagi mahalliy narx ko‘rsatilishi kerak; saytdagi dollar narxlari namuna.

Play Console’da kerakli mahsulotlar:
- arena_stars_50 / arena_stars_180 / arena_stars_450 — bir martalik sarflanadigan mahsulotlar.
- arena_club_pass / arena_pro_pass — obuna, monthly bazaviy tarifi.
- Android package/signing va litsenziya test hisoblari bilan internal test track.
- Publisher API xizmat akkaunti ruxsatlari. Maxfiy JSON frontendda va chatda bo‘lmasin.

AdMob’da: app ID, rewarded ad unit, SSV callback va1ticket mukofot sozlamasi, consent/privacy/audience sozlamalari. Rasmiy test app/ad IDs faqat SDK sinovi uchun. Haqiqiy reklama bonusini clientdagi video-ended yoki SDK earned hodisasidan bermang; serverdagi tekshirilgan, bir martalik SSV transaction talab qilinadi.

Server45 papkasida Play holat/account/expiry tekshiruvi, raw AdMob ECDSA imzo tekshiruvi, SQLite atomic receipt/ad-challenge/idempotency va server limit poydevori bor. Bular hali HTTP servis sifatida joylanmagan. Live ishga tushirishdan oldin:
- login/account recovery, haqiqiy server hamyoni/ownership va offline save migratsiyasi;
- HTTPS hosting, xavfsiz credential binding;
- consume/ack jobs, refund/voided-purchase reconciliation, authenticated RTDN;
- subscription lifecycle va restore real Google test trackda;
- app/market UI bilan native/backend ulash, audience/privacy/store va mavjud aktivlar huquqini release tekshiruvi.

Test balanslarni haqiqiy server balansiga avtomatik aylantirmang. Kodning mavjudligi real pul qabul qilish yoqilganini anglatmaydi. Birinchi hisoblar tayyor bo‘lgach, hosting/account integratsiyasi va Play ichki sinovi alohida yakunlanadi.
