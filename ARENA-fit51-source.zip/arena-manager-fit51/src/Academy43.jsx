import{ScreenIdentity49}from'./Visual49.jsx';
import React,{useState}from'react';
import{AdaptiveDeck,card}from'./AdaptiveDeck.jsx';
import{Portrait}from'./ManagerScreens.jsx';
import{MAPS}from'./maps.js';
import*as C from'./career.js';
const titles=['Klubingizni yarating','Birinchi beshlik','Tarkibni tushunish','Birinchi mashg‘ulot','Energiya va dam','Jang rejasini tuzing','Mukofot va maosh','Klub do‘konini sinang','Birinchi 5v5 jang'];
export function Academy43({career:c,commit,setModal,start,resume,navigate}){
 const step=c.tutorial.step,[player,setPlayer]=useState(''),p=c.roster.find(p=>p.id===player)||c.roster[0],next=()=>commit(C.advanceTutorial),done=step===1?c.roster.length===5:step===3?c.finance.stats.training>0:step===4?c.day>=2:step===5?c.tutorial.planEdited:step===6?c.finance.claimed.includes('scout'):step===7?c.finance.stats.shopPurchases>0:step===8?c.history.some(h=>h.type==='practice'&&!h.forfeit):true;
 const nextButton=<button className="primary" disabled={!done||!!c.pending} onClick={next}>{step===8?'Qo‘llanmani tugatish · +400 XP':'Keyingi bosqich →'}</button>;
 const heading=<div className="screen-heading academy-heading"><ScreenIdentity49/><div><span className="eyebrow">BOSHLANG‘ICH QO‘LLANMA · {step+1}/9</span><h1>{titles[step]}</h1></div><span className="tag-badge">◈ {c.credits.toLocaleString('en-US')}</span></div>;
 if(step===1)return <>{heading}<div className="transfer-summary"><span><b>{c.roster.length}/5</b> o‘yinchi · 800–1 000 tanga</span>{nextButton}</div><div className="transfer-scroll" data-vertical-scroll="transfers"><p className="academy-tip">Beshta yangi iste’dodni tanlang. Har xarid tangadan yechiladi; dastlabki beshlik avtomatik faol tarkibga kiradi. Kuchli transferlar keyingi darajalarda ochiladi.</p><div className="player-grid market-grid academy-recruits">{C.market(c).filter(p=>p.starter).map(p=><article className="player-profile panel" key={p.id}><Portrait p={p}/><div className="profile-name"><h2>{p.name}</h2><span>{p.role} · yangi o‘yinchi</span></div><p>OVR {C.overall(p)} · Salohiyat {p.potential}<br/>Maosh ◈ {C.salary(p)} / uchrashuv</p><button className="primary" disabled={c.roster.length>=5||c.credits<p.price} onClick={()=>setModal({type:'buy',id:p.id})}>Tanlash · ◈ {p.price}</button></article>)}</div></div></>;
 const items=step===0?[
 card('welcome','Siz — menejer',<p className="deck-copy">Bo‘sh klubdan boshlaysiz. 12 000 tanga berilgan; tayyor o‘yinchilar yo‘q. Beshta oddiy o‘yinchini sotib olasiz, rivojlantirasiz va jonli 5v5 jangni taktika bilan boshqarasiz.</p>),
 card('learn','Amalda o‘rganamiz',<p className="deck-copy">Transfer → tarkib → mashg‘ulot → dam → taktika → mukofot → do‘kon → mashq jangi. Har bosqich saqlanadi. Haqiqiy pul talab qilinmaydi.</p>),card('next','Boshlaymiz',nextButton)
 ]:step===2?[
 ...c.roster.map(p=>card(p.id,p.name,<div className="person-summary"><Portrait p={p}/><p>{p.role}<br/>OVR {C.overall(p)} · Energiya {p.energy}%</p></div>)),
 card('lineup','Faol beshlik',<p className="deck-copy">Faol beshlik jangga tushadi. Keyin zaxira sotib olib, Tarkib bo‘limida almashtirasiz. Aniqlik, reaksiya, taktika va granata ko‘nikmalari jangga ta’sir qiladi.</p>),card('next','Tarkib tayyor',nextButton)
 ]:step===3?[
 card('select','O‘yinchini tanlang',<label className="deck-field">Mashg‘ulot<select aria-label="Qo‘llanma o‘yinchisi" value={p.id} onChange={e=>setPlayer(e.target.value)}>{c.roster.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>),
 card('train','Aniqlikni oshiring',<><p className="deck-copy">◈ 400 evaziga aniqlik +{C.trainingQuote(c,p.id,'aim').gain}, energiya −12. Har o‘yinchi kuniga bir marta mashq qiladi.</p><button className="primary" disabled={!C.trainingQuote(c,p.id,'aim').canTrain||done} onClick={()=>commit(x=>C.trainPlayer(x,p.id,'aim'))}>Mashq qilish · ◈ 400</button></>),card('next',done?'Mashq saqlandi':'Mashqni bajaring',nextButton)
 ]:step===4?[
 card('rest','Tiklanish kuni',<><p className="deck-copy">Mashq va jang energiya sarflaydi. Dam olish jamoaga +24 energiya, +2 ruhiyat beradi va yangi kunni boshlaydi. Buning uchun maosh olinmaydi.</p><button className="primary" disabled={done} onClick={()=>commit(C.restDay)}>Bir kun dam olish</button></>),card('next',done?'Jamoa tiklandi':'Keyingi kun',nextButton)
 ]:step===5?[
 card('map','Xarita',<label className="deck-field">Maydon<select aria-label="Qo‘llanma xaritasi" value={c.settings.map} onChange={e=>commit(x=>C.updatePlan(x,{map:e.target.value}))}>{MAPS.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label>),
 card('plan','Buyruqni tanlang',<div className="deck-buttons">{[['a','A nuqtaga hujum'],['b','B nuqtaga hujum'],['balanced','Muvozanatli reja'],['hold','Himoya va kutish']].map(([id,name])=><button key={id} aria-pressed={c.settings.strategy===id} onClick={()=>commit(x=>C.updatePlan(x,{strategy:id}))}>{name}</button>)}</div>),
 card('explain','Raundning maqsadi',<p className="deck-copy">Hujumda C4 ni A yoki B nuqtaga qo‘ying va himoya qiling. Himoyada bunga yo‘l qo‘ymang yoki qo‘yilgan C4 ni zararsizlantiring. Raund dollarlari klub tangalaridan alohida.</p>),card('next','Rejani saqlash',nextButton)
 ]:step===6?[
 card('budget','Klub byudjeti',<p className="deck-copy">Transfer, mashg‘ulot va bezak klub tangasidan olinadi. Rasmiy uchrashuvdan so‘ng homiy va mukofot tushadi, butun tarkib maoshi hamda klub xizmati ayriladi. Hammasi Moliya tarixida yoziladi. Homiy shartnomasi 3 rasmiy uchrashuvga; tugagach Moliya bo‘limida yangilang.</p>),
 card('reward','Yangi iste’dod mukofoti',<><p className="deck-copy">Birinchi transfer uchun bir martalik 500 tangani oling. Vazifani qayta olish mumkin emas.</p><button className="primary" disabled={done} onClick={()=>commit(x=>C.claimObjective(x,'scout'))}>{done?'Mukofot olingan':'Mukofotni olish · ◈ 500'}</button></>),card('next','Byudjet tayyor',nextButton)
 ]:step===7?[
 card('shop','Storm Mark emblemasi',<><p className="deck-copy">Narx ◈ 1 200. Hamyon: {c.credits.toLocaleString('en-US')} → {(c.credits-(done?0:1200)).toLocaleString('en-US')}. Bezak jamoa kuchini oshirmaydi. Bir marta sotib olasiz, keyin bepul qo‘llaysiz.</p><button className="primary" disabled={done||c.credits<1200} onClick={()=>commit(x=>C.buyClubItem(x,'crest-bolt'))}>{done?'Emblema qo‘llanildi':'Sotib olish · ◈ 1 200'}</button></>),card('next','Kolleksiya saqlandi',nextButton)
 ]:[
 card('controls','Jangni kuzatish',<p className="deck-copy">▶ / Ⅱ — boshlash va pauza. Avto kamera jangni kuzatadi; yon paneldagi o‘yinchini bosib, alohida kamerada ko‘rasiz. Taktika buyruqlarini jang paytida ham o‘zgartirish mumkin. Menyuga qaytsangiz, jang saqlanadi.</p>),
 card('practice','Bosimsiz mashq',<><p className="deck-copy">G‘alaba shart emas — mashq uchrashuvini oxirigacha o‘ynang. Taslim bo‘lish qo‘llanmani tugatmaydi. Keyin liga va barcha bo‘limlar ochiladi.</p><button className="primary" disabled={done} onClick={()=>c.pending?resume():start(true)}>{c.pending?'Mashqni davom ettirish':'Mashq jangini boshlash'}</button></>),card('next',done?'Birinchi jang yakunlandi':'Mashq natijasini kutamiz',nextButton)
 ];
 return <>{heading}<AdaptiveDeck key={step} label="Qo‘llanma" items={items}/></>;
}
