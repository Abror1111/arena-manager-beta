import React,{useEffect,useState}from'react';
import manifest from'./art49.json'with{type:'json'};
import{loadAsset}from'./asset-cache.js';
const ready=new Map(),pending=new Map();
export function loadVisual49(kind){if(ready.has(kind))return Promise.resolve(ready.get(kind));if(pending.has(kind))return pending.get(kind);const job=loadAsset(manifest[kind]).then(({bytes})=>{const url=URL.createObjectURL(new Blob([bytes],{type:'image/webp'}));ready.set(kind,url);return url}).finally(()=>pending.delete(kind));pending.set(kind,job);return job;}
export function useVisualImage49(kind,enabled=true){const[url,setURL]=useState(()=>enabled?ready.get(kind):null);useEffect(()=>{let live=true;if(!enabled){setURL(null);return()=>{live=false}}setURL(ready.get(kind));loadVisual49(kind).then(u=>{if(live)setURL(u)}).catch(()=>{});return()=>{live=false}},[kind,enabled]);return url;}
export function Art49({kind='sections',cell=0,className='',style={}}){const url=useVisualImage49(kind),e=manifest[kind],n=Math.max(0,Math.min(e.rects.length-1,cell)),r=e.rects[n];return <span className={'art49 '+className} style={style} data-visual-art={kind+'-'+n} data-visual-quality={url?'full':'pending'} aria-hidden="true">{url&&<svg viewBox={r.join(' ')} preserveAspectRatio="xMidYMid slice" width="100%" height="100%"><image href={url} width={e.width} height={e.height}/></svg>}</span>}
