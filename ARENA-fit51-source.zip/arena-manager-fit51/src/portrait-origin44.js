export const PORTRAIT44_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/4fc1c9fbe933dec9f82ca605c9aebf82e32da346/portraits44/";
