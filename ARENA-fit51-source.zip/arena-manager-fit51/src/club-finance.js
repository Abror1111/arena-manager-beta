// Offline club coins are earned in play; match round dollars are a separate wallet.
export const COIN_LIMIT=100000000;
export const PRACTICE_ALLOWANCE=3;
export const SPONSORS=[
 {id:'local',name:'Mahalla Gaming',tag:'BOSHLANG‘ICH',fans:0,reputation:0,fee:450,bonus:200,length:3,color:'#d9bc83'},
 {id:'tech',name:'VECTOR Tech',tag:'HUDUDIY',fans:800,reputation:0,fee:750,bonus:350,length:3,color:'#81bcd8'},
 {id:'arena',name:'NOVA Hardware',tag:'PROFESSIONAL',fans:1800,reputation:8,fee:1150,bonus:550,length:3,color:'#ba9cde'},
];
export const SHOP=[
 {id:'theme-gold',kind:'theme',value:'gold',name:'Classic Gold',price:0,color:'#e2bf80',description:'Oltin turnir muhiti, nafis panel va zarhal aksentlar.'},
 {id:'theme-azure',kind:'theme',value:'azure',name:'Arctic Blue',price:1600,color:'#7bc9ed',description:'Muzli shisha muhiti, texnik to‘r va titan panellar.'},
 {id:'theme-crimson',kind:'theme',value:'crimson',name:'Crimson Five',price:2200,color:'#ec8b99',description:'Uglerod naqshi, qiya kesimlar va qizil neon ustaxona.'},
 {id:'theme-jade',kind:'theme',value:'jade',name:'Jade Circuit',price:2800,color:'#85d7b1',description:'Bog‘li klub muhiti, yumaloq tosh panel va jade bezaklar.'},
 {id:'theme-violet',kind:'theme',value:'violet',name:'Neon Violet',price:3600,color:'#b7a0ef',description:'Orbital muhit, yulduzli naqsh va binafsha shisha panellar.'},
 {id:'crest-arena',kind:'crest',value:'arena',name:'ARENA Shield',price:0,color:'#e2bf80',description:'Klubning boshlang‘ich emblemasi.'},
 {id:'crest-bolt',kind:'crest',value:'bolt',name:'Storm Mark',price:1200,color:'#99cfe6',description:'Chaqmoq belgili klub emblemasi.'},
 {id:'crest-wings',kind:'crest',value:'wings',name:'Falcon Wings',price:3500,color:'#dcb67e',description:'Qanotli turnir emblemasi.'},
 {id:'crest-crown',kind:'crest',value:'crown',name:'Crown Five',price:6500,color:'#e4c77d',description:'Chempion uslubidagi toj emblemasi.'},
 {id:'crest-orbit',kind:'crest',value:'orbit',name:'Orbital Club',price:4200,color:'#8ad9dc',description:'Orbita chiziqlari bilan original klub belgisi.'},
 {id:'crest-hex',kind:'crest',value:'hex',name:'Hex Division',price:5400,color:'#bda0ee',description:'Geometrik olti qirrali klub emblemasi.'},
 {id:'crest-flare',kind:'crest',value:'flare',name:'Rising Flare',price:7800,color:'#ed9b91',description:'Yuksalish va yangi mavsum timsoli.'},
 {id:'crest-fox',kind:'crest',value:'fox',name:'Moonveil Kitsune',price:9800,color:'#d0adef',description:'Kumush niqob, ametist va bezakli dumlar bilan original klub belgisi.'},
 {id:'crest-dragon',kind:'crest',value:'dragon',name:'Jade Sovereign',price:12000,color:'#8ed8be',description:'Jade ajdaho, marvarid va zarhal o‘ymakorlikli original klub belgisi.'},
];
export const OBJECTIVES=[
 {id:'debut',name:'Katta sahnaga qadam',description:'Bitta rasmiy uchrashuvni oxirigacha o‘ynang.',stat:'officialMatches',target:1,reward:400},
 {id:'winner',name:'Birinchi g‘alaba',description:'Rasmiy uchrashuvda g‘alaba qozoning.',stat:'officialWins',target:1,reward:600},
 {id:'coach',name:'Tajriba va mehnat',description:'Uchta shaxsiy mashg‘ulotni bajaring.',stat:'training',target:3,reward:350},
 {id:'scout',name:'Yangi iste’dod',description:'Transferdan bitta o‘yinchi oling.',stat:'recruits',target:1,reward:500},
 {id:'champion',name:'ARENA chempioni',description:'Bir mavsumda chempion bo‘ling.',stat:'championships',target:1,reward:2000},
 {id:'collector',name:'Klub kolleksiyasi',description:'Uchta pullik klub uslubi yoki emblema oling.',stat:'shopPurchases',target:3,reward:500},
];
const categories=new Set(['opening','match','sponsor','fans','salary','operations','support','season','training','facility','transfer-buy','transfer-sell','shop','objective']);
const int=(n,max=COIN_LIMIT)=>Number.isSafeInteger(n)&&n>=0&&n<=max;
const marketId=(id,season)=>typeof id==='string'&&new RegExp('^market-'+season+'-(?:[0-9]|[12][0-9]|3[0-5])$').test(id);
function knownPurchases(c){return [...new Set([...(c.roster||[]).map(p=>p.id),...(c.history||[]).filter(h=>h.type==='transfer').map(h=>h.playerId)].filter(id=>marketId(id,c.seasonNumber)))];}
export function ensureFinance(c){
 if(!c.finance){
  const official=(c.history||[]).filter(h=>h.type==='season'&&!h.forfeit),current=official.filter(h=>h.season===c.seasonNumber);
  c.finance={version:1,sequence:0,anchor:c.credits,income:0,expenses:0,ledger:[],sponsor:{id:'local',remaining:3},practicePaid:0,seasonCompleted:current.length,stats:{officialMatches:official.length,officialWins:official.filter(h=>h.win).length,training:0,recruits:(c.history||[]).filter(h=>h.type==='transfer').length,championships:c.season?.completed&&c.season.placement===1?1:0},claimed:[],owned:['theme-gold','crest-arena'],theme:'gold',crest:'arena'};
 }
 const f=c.finance;if(f.version===1){
  f.opening=c.credits-f.income+f.expenses;
  f.market={season:c.seasonNumber,acquired:knownPurchases(c)};
  if(f.stats&&Array.isArray(f.owned))f.stats.shopPurchases=f.owned.filter(id=>SHOP.some(s=>s.id===id&&s.price>0)).length;
  f.version=2;
 }
 return f;
}
export function post(c,category,amount,label,key){
 if(!categories.has(category)||!Number.isSafeInteger(amount)||Math.abs(amount)>COIN_LIMIT||typeof label!=='string'||label.length>100||key!==undefined&&(typeof key!=='string'||!key.length||key.length>100)||!int(c.credits))throw Error('Moliyaviy amal noto‘g‘ri.');
 const f=ensureFinance(c);if(key&&f.ledger.some(e=>e.key===key))throw Error('Bu to‘lov avval hisoblangan.');
 if(amount<0&&c.credits< -amount)throw Error('Klub tangasi yetarli emas.');
 if(amount>0&&c.credits+amount>COIN_LIMIT)throw Error('Hamyon chegarasiga yetdingiz. Avval tanga sarflang, keyin to‘liq summani oling.');
 if(!amount)return 0;
 const balance=c.credits+amount,income=f.income+Math.max(0,amount),expenses=f.expenses+Math.max(0,-amount),sequence=f.sequence+1;
 if(!int(income,1e15)||!int(expenses,1e15)||!int(sequence,1e12))throw Error('Hamyon hisob chegarasiga yetdi.');
 c.credits=balance;Object.assign(f,{sequence,income,expenses});f.ledger.push({id:sequence,key:key||'tx-'+sequence,day:c.day,category,label,amount,balance});
 while(f.ledger.length>120)f.anchor=f.ledger.shift().balance;
 return amount;
}
export function salary(p){const o=Math.round(p.aim*.45+p.reaction*.2+p.tactics*.2+p.utility*.15);return 60+Math.max(0,o-50)*3;}
export function clubCosts(c){return{salary:c.roster.reduce((n,p)=>n+salary(p),0),operations:40+c.trainingLevel*35};}
export function sponsorOffers(c){return SPONSORS.map(s=>({...s,available:c.fans>=s.fans&&c.reputation>=s.reputation}));}
export function activeSponsor(c){const f=c.finance;if(!f||f.sponsor.remaining<=0)return null;return SPONSORS.find(s=>s.id===f.sponsor.id)||null;}
const payoutRows=[['prize','match'],['sponsor','sponsor'],['fans','fans'],['support','support'],['salary','salary'],['operations','operations']];
export function matchQuote(c,win=false,practice=false){
 let planned;
 if(practice){const paid=(c.finance?.practicePaid||0)<PRACTICE_ALLOWANCE;planned={prize:paid?(win?350:180):0,sponsor:0,fans:0,salary:0,operations:0,support:0};}
 else{const costs=clubCosts(c),s=activeSponsor(c),prize=win?2200:900,sponsor=s?(s.fee+(win?s.bonus:0)):0,fans=Math.min(600,180+Math.floor(c.fans/30)*10),support=Math.max(0,costs.salary+costs.operations+200-prize-sponsor-fans);planned={prize,sponsor,fans,support,...costs};}
 const offeredGross=planned.prize+planned.sponsor+planned.fans+planned.support,expensesFirst=c.credits+offeredGross>COIN_LIMIT,rows=[...payoutRows];if(expensesFirst)rows.sort((a,b)=>Number(['salary','operations'].includes(b[0]))-Number(['salary','operations'].includes(a[0])));
 const q={...planned};let balance=c.credits,gross=0;for(const[k]of rows){const debit=k==='salary'||k==='operations',amount=debit?planned[k]:Math.min(planned[k],COIN_LIMIT-balance);balance+=debit?-amount:amount;q[k]=amount;if(!debit)gross+=amount;}
 return{...q,gross,net:balance-c.credits,offeredGross,cappedAmount:offeredGross-gross,expensesFirst,accountingRevision:2};
}
export function settleFinance(c,pending,won,forfeit){
 const f=ensureFinance(c),before=c.credits,practice=pending.type==='practice',eligible=!forfeit&&(!practice||f.practicePaid<PRACTICE_ALLOWANCE);
 if(forfeit)return{prize:0,sponsor:0,fans:0,support:0,salary:0,operations:0,gross:0,net:0,offeredGross:0,cappedAmount:0,eligible:false,accountingRevision:2,balanceBefore:before,balanceAfter:before};
 const q=matchQuote(c,won,practice),rows=[...payoutRows];if(q.expensesFirst)rows.sort((a,b)=>Number(['salary','operations'].includes(b[0]))-Number(['salary','operations'].includes(a[0])));
 const labels={prize:practice?'Mashq mukofoti':'Uchrashuv mukofoti',sponsor:'Homiy to‘lovi',fans:'Muxlislar va klub savdosi',support:'Liga ishtirok yordami',salary:'Tarkib maoshi',operations:'Klub xizmat xarajati'};
 for(const[k,category]of rows)post(c,category,q[k]*(k==='salary'||k==='operations'?-1:1),labels[k],pending.id+':'+k);
 if(practice){if(eligible)f.practicePaid++;}else{f.stats.officialMatches++;f.stats.officialWins+=won?1:0;f.seasonCompleted++;f.practicePaid=0;if(f.sponsor.remaining>0)f.sponsor.remaining--;}
 return{...q,net:c.credits-before,eligible,balanceBefore:before,balanceAfter:c.credits};
}
export function validateFinance(c){
 const f=ensureFinance(c),fail=()=>{throw Error('Klub moliyasi yoki hamyon tarixi noto‘g‘ri.');};
 if(!f||f.version!==2||!int(f.sequence,1e12)||!int(f.opening)||!int(f.anchor)||!int(f.income,1e15)||!int(f.expenses,1e15)||f.opening+f.income-f.expenses!==c.credits||!Array.isArray(f.ledger)||f.ledger.length>120)fail();
 if(!f.sponsor||!SPONSORS.some(s=>s.id===f.sponsor.id)||!int(f.sponsor.remaining,3)||!int(f.practicePaid,3)||!int(f.seasonCompleted,7))fail();
 if(!f.stats||['officialMatches','officialWins','training','recruits','championships','shopPurchases'].some(k=>!int(f.stats[k],1e9))||f.stats.officialWins>f.stats.officialMatches)fail();
 if(!f.market||f.market.season!==c.seasonNumber||!Array.isArray(f.market.acquired)||f.market.acquired.length>36||new Set(f.market.acquired).size!==f.market.acquired.length||f.market.acquired.some(id=>!marketId(id,c.seasonNumber)))fail();
 if(!Array.isArray(f.claimed)||new Set(f.claimed).size!==f.claimed.length||f.claimed.some(id=>!OBJECTIVES.some(q=>q.id===id)))fail();
 if(!Array.isArray(f.owned)||f.owned.length>SHOP.length||new Set(f.owned).size!==f.owned.length||f.owned.some(id=>!SHOP.some(s=>s.id===id))||!f.owned.includes('theme-gold')||!f.owned.includes('crest-arena')||f.stats.shopPurchases!==f.owned.filter(id=>SHOP.some(s=>s.id===id&&s.price>0)).length)fail();
 for(const kind of['theme','crest'])if(!SHOP.some(s=>s.kind===kind&&s.value===f[kind]&&f.owned.includes(s.id)))fail();
 let balance=f.anchor,last=0,income=0,expenses=0;const keys=new Set();for(const e of f.ledger){if(!e||!int(e.id,1e12)||e.id<=last||e.id>f.sequence||typeof e.key!=='string'||e.key.length>100||keys.has(e.key)||!int(e.day)||e.day<1||e.day>c.day||!categories.has(e.category)||typeof e.label!=='string'||e.label.length>100||!Number.isSafeInteger(e.amount)||!e.amount||Math.abs(e.amount)>COIN_LIMIT||!int(e.balance))fail();balance+=e.amount;if(balance!==e.balance)fail();income+=Math.max(0,e.amount);expenses+=Math.max(0,-e.amount);keys.add(e.key);last=e.id;}
 if(balance!==c.credits||f.ledger.length&&last!==f.sequence||income>f.income||expenses>f.expenses)fail();return f;
}
