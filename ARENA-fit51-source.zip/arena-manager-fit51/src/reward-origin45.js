export const REWARD45_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/53ed9a93bb03a840d09fb9c62dc4f37fef4ec797/media45/";
