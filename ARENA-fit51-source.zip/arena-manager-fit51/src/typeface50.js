import font from'./font50.json'with{type:'json'};
import{loadAsset}from'./asset-cache.js';
let started;
export function loadTypeface50(){if(started)return started;started=loadAsset(font).then(async({bytes})=>{const face=new FontFace('Arena Manrope',bytes,{weight:'200 800',display:'swap'});await face.load();document.fonts.add(face);document.documentElement.dataset.typeface50='ready';return face}).catch(()=>{document.documentElement.dataset.typeface50='fallback'});return started}
