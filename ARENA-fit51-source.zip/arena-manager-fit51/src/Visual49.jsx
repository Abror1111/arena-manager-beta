import{MarketArt47}from'./MarketArt47.jsx';
import React,{createContext,useContext,useLayoutEffect}from'react';
import styles from'./interface49.css?raw';
import polish from'./interface50.css?raw';
import fit from'./fit51.css?raw';
import{loadTypeface50}from'./typeface50.js';
import{Art49}from'./Art49.jsx';
import{THEMES49,SECTIONS49}from'./VisualCatalog49.js';
const Context49=createContext({screen:'home',theme:'gold'});
export const VisualProvider49=({screen,theme,children})=><Context49.Provider value={{screen,theme}}>{children}</Context49.Provider>;
export function installVisual49(){if(document.getElementById('arena-visual49-style'))return;const el=document.createElement('style');el.id='arena-visual49-style';el.textContent=styles+"\n"+polish+"\n"+fit;document.head.append(el);loadTypeface50()}
export function useVisual49(theme,screen){useLayoutEffect(()=>{document.documentElement.dataset.visualTheme=THEMES49[theme]?theme:'gold';document.documentElement.dataset.visualSection=screen;return()=>{}},[theme,screen])}
export function ScreenIdentity49(){const{screen}=useContext(Context49);if(screen==='shop')return <span className="screen-identity49 shop-identity49" aria-hidden="true"><MarketArt47 kind="pack" variant={2}/></span>;return <Art49 kind="sections" cell={SECTIONS49[screen]??0} className="screen-identity49"/>}
export function DeckStamp49({index,cardKey}){const{screen}=useContext(Context49);if(index>2||cardKey.startsWith('dialog-'))return null;return <Art49 kind="sections" cell={SECTIONS49[screen]??0} className={'deck-stamp49 '+(index===0?'deck-lead49':'')}/>}
export function ThemePreview49({theme='gold'}){const t=THEMES49[theme]||THEMES49.gold;return <div className={'theme-preview49 theme-'+theme} data-theme-preview={theme}><Art49 kind="themes" cell={t.cell}/><div className="theme-preview-overlay49"><span>{t.label}</span><div><i/><i/><i/></div><strong>ARENA <small>MANAGER</small></strong><b>KLUBGA KIRISH →</b><small>{t.caption}</small></div></div>}
