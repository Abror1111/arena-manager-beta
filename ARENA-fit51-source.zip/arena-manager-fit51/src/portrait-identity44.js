// Slots0..46 are club/transfer faces;47..71 are the25 named opposition players.
export const PORTRAIT_COUNT44=72,CLUB_PORTRAITS44=47;
const starters=['ACE','NOVA','SHADOW','REX','ECHO','PIXEL'];
const enemies=['FROST','VIPER','GHOST','BLAZE','STORM','STEPPE','QUM','BO‘RON','JET','MIRAGE','DELTA','AXIS','ZERO','ARC','NODE','VEGA','RIGEL','NOVA-X','LUNA','COMET','BEAT','SPARK','VOLTA','AMP','SURGE'];
const valid=n=>Number.isInteger(n)&&n>=0&&n<CLUB_PORTRAITS44;
export function portraitIndex44(identity,name,index=0){
 const text=String(identity??name??''),display=String(name||identity||'').toUpperCase(),starter=text.match(/^starter-(\d+)$/),market=text.match(/^market-\d+-(\d+)$/),e=enemies.indexOf(display);
 if(starter)return Number(starter[1])%6;if(market)return 6+Number(market[1])%36;if(e>=0)return 47+e;const s=starters.indexOf(display);if(s>=0)return s;
 let h=2166136261;for(const c of text||String(index))h=Math.imul(h^c.charCodeAt(0),16777619);return 42+(h>>>0)%5;
}
export function ensurePortraits44(c){
 const used=new Set();for(const p of c.roster){if(p.portrait44!==undefined&&!valid(p.portrait44))throw Error('O‘yinchi portreti yaroqsiz.');let n=p.portrait44??portraitIndex44(p.id,p.name);if(!valid(n))n=42;if(used.has(n)){if(p.portrait44!==undefined)throw Error('Jamoada takroriy portret bor.');n=[42,43,44,45,46,...Array.from({length:42},(_,i)=>i)].find(i=>!used.has(i));}p.portrait44=n;used.add(n);}
 const market=c.finance.market,own=new Map(c.roster.map(p=>[p.id,p.portrait44]));
 if(market.portraits44!==undefined){const a=market.portraits44;if(!Array.isArray(a)||a.length!==36||a.some(n=>!valid(n))||new Set(a).size!==36)throw Error('Transfer portretlari yaroqsiz.');for(let i=0;i<36;i++){const n=a[i],id=`market-${c.seasonNumber}-${i}`;if(own.has(id)?own.get(id)!==n:used.has(n))throw Error('Transfer va jamoa portretlari mos emas.');}return c;}
 const a=Array(36).fill(null),taken=new Set(used);for(let i=0;i<36;i++){const id=`market-${c.seasonNumber}-${i}`;if(own.has(id))a[i]=own.get(id);}
 for(let i=0;i<36;i++)if(a[i]===null){const preferred=6+i,n=!taken.has(preferred)?preferred:Array.from({length:47},(_,j)=>j).find(j=>!taken.has(j));a[i]=n;taken.add(n);}
 market.portraits44=a;return c;
}
