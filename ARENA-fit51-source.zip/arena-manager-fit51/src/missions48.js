// Operation progress is updated by completed official series and real training actions.
export const NORMAL48=[
{id:'scout48',name:'Talent Network',text:'Transfer yoki klub marketidan 3 o‘yinchi oling.',stat:'recruits',target:3,stars:3,tickets:1,art:2},
{id:'academy48',name:'Training Academy',text:'10 ta shaxsiy mashg‘ulotni bajaring.',stat:'training',target:10,stars:5,tickets:2,art:5},
{id:'league48',name:'League Veteran',text:'15 ta rasmiy uchrashuvni yakunlang.',stat:'officialMatches',target:15,stars:8,tickets:3,art:3},
{id:'victory48',name:'Winning Culture',text:'10 ta rasmiy uchrashuvda g‘alaba qozoning.',stat:'officialWins',target:10,stars:8,tickets:3,art:0},
{id:'style48',name:'Club Identity',text:'5 ta pullik klub uslubi yoki emblema oling.',stat:'shopPurchases',target:5,stars:5,tickets:2,art:6},
{id:'dynasty48',name:'Championship Legacy',text:'3 ta mavsumda chempion bo‘ling.',stat:'championships',target:3,stars:15,tickets:5,art:3},
];
export const PREMIUM48=[
{id:'entry48',name:'Operation Debut',text:'Ushbu pass davomida 1 ta rasmiy uchrashuvni yakunlang.',stat:'played',target:1,stars:2,tickets:1,art:0},
{id:'triple48',name:'Triple Commitment',text:'Ushbu pass davomida 3 ta rasmiy uchrashuvni yakunlang.',stat:'played',target:3,stars:3,tickets:2,art:4},
{id:'tactical48',name:'Tactical Momentum',text:'Ushbu pass davomida 3 ta rasmiy uchrashuvda yuting.',stat:'wins',target:3,stars:4,tickets:2,art:2},
{id:'workshop48',name:'Elite Workshop',text:'Ushbu pass davomida 5 ta shaxsiy mashg‘ulotni bajaring.',stat:'training',target:5,stars:3,tickets:2,art:5},
{id:'halfway48',name:'Halfway to Glory',text:'Ushbu pass davomida 5 ta rasmiy uchrashuvni yakunlang.',stat:'played',target:5,stars:5,tickets:3,art:7},
{id:'finale48',name:'Operation Complete',text:'Ushbu passning 10 ta rasmiy uchrashuvini yakunlang.',stat:'played',target:10,stars:8,tickets:4,art:8},
];
export const LEGACY48={five:{target:5,art:2},debut:{stat:'officialMatches',target:1,art:0},winner:{stat:'officialWins',target:1,art:3},coach:{stat:'training',target:3,art:5},regular:{stat:'officialMatches',target:5,art:4},champion:{stat:'championships',target:1,art:3}};
export function ensureMissions48(c){if(c.missions48!==undefined)return c.missions48;const pass=c.store46?.pass;return c.missions48={version:1,serial:pass?1:0,normalClaims:[],operation:pass?{id:1,plan:pass.id,played:10-pass.remaining,wins:0,training:0,claimed:[],closed:false}:null};}
export const readMissions48=c=>c.missions48||{version:1,serial:0,normalClaims:[],operation:null};
const int=(n,max)=>Number.isSafeInteger(n)&&n>=0&&n<=max;
export function validateMissions48(c){const m=ensureMissions48(c),bad=()=>{throw Error('Vazifalar tarixi yaroqsiz.');};if(!m||m.version!==1||!int(m.serial,1e6)||!Array.isArray(m.normalClaims)||new Set(m.normalClaims).size!==m.normalClaims.length||m.normalClaims.some(id=>!NORMAL48.some(g=>g.id===id)))bad();const o=m.operation;if(o!==null){if(!o||!int(o.id,1e6)||o.id<1||o.id!==m.serial||!['club','pro'].includes(o.plan)||!int(o.played,10)||!int(o.wins,o.played)||!int(o.training,1000)||typeof o.closed!=='boolean'||!Array.isArray(o.claimed)||new Set(o.claimed).size!==o.claimed.length||o.claimed.some(id=>!PREMIUM48.some(g=>g.id===id)))bad();}else if(m.serial!==0)bad();const pass=c.store46?.pass;if(pass){if(!o||o.closed||o.plan!==pass.id||o.played+pass.remaining!==10)bad();}else if(o&&!o.closed)bad();return m;}
export function missionProgress48(c,g,tier='normal'){const o=readMissions48(c).operation;const raw=tier==='premium'?o?.[g.stat]||0:g.id==='five'?(!c.tutorial||c.tutorial.complete?c.lineup.length:0):c.finance?.stats?.[g.stat]||0;return{current:Math.min(g.target,Math.max(0,raw)),target:g.target,ready:raw>=g.target&&(tier!=='premium'||!!o)};}
export function pendingPremium48(c){const o=readMissions48(c).operation;return o?PREMIUM48.filter(g=>!o.claimed.includes(g.id)&&missionProgress48(c,g,'premium').ready):[];}
export function startOperation48(c,plan){const m=ensureMissions48(c);if(pendingPremium48(c).length)throw Error('Avval premium vazifalarning tayyor mukofotlarini oling.');if(m.serial>=1e6)throw Error('Operatsiyalar chegarasiga yetildi.');m.serial++;m.operation={id:m.serial,plan,played:0,wins:0,training:0,claimed:[],closed:false};}
export function recordOperation48(c,type,win=false){if(!c.store46?.pass)return;const o=ensureMissions48(c).operation;if(!o||o.closed)throw Error('Faol operatsiya topilmadi.');if(type==='official'){o.played=Math.min(10,o.played+1);if(win)o.wins=Math.min(o.played,o.wins+1);}else if(type==='training')o.training=Math.min(1000,o.training+1);}
export function closeOperation48(c){const o=ensureMissions48(c).operation;if(o)o.closed=true;}
