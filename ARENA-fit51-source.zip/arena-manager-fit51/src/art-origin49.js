export const ART49_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/0b755c593226be24810d3f2608cdbd8814fccf2b/art49/";
