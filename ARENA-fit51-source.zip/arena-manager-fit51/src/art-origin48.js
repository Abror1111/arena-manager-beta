export const ART48_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/5c89ad30d021a7a7a6b6ab4bb097d67e734b3e79/art48/";
