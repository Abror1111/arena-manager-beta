# ARENA Manager1.51 — Text containment fix

Fix text escaping visible UI boxes introduced/exposed by1.50typography. Headings now use a sufficient linebox and content-driven height; long titles/wrapping badge use shrinkable flexcolumns. Fixed narrow badge nowrap/maxwidth conflict. Narrow tablet/landscape navigation labels get appropriate type/padding and may wrap inside their buttons.

Buttons and selectors stay within parent width with border-box sizing, normal wrapping and content-driven height. Flex/grid children have zero minwidth where text must shrink/wrap. Monetary rows, price/reward rows and wallet labels wrap as complete layout items; forecast tracks use minmax(0,1fr). Theme preview artwork is200px high so enlarged captions remain inside it. OVR chip moved inside avatar edge.

No blanket text-clipping/overflow-hidden solution or forced Android textZoom override added. Adaptive horizontal pages retained; only shop/transfers use vertical list scroll. Existing Manropefont/5palettes/72faceidentities/8frameart/36weaponicons remain. Coremap/combat/audio/economy/saves unchanged; engine label1.51 only.

235text states pass with0text escapes:120normal across8viewports;75at125%browser-font enlargement across5viewports;40launch/purchase/navigation/battle/commandpanel combinations at100/125% across4sizes. DOMRange bounds checked against nearest visible button/badge/card/textpanel, including off-page adaptive cards and all6shop tabs. Baseline50reported48normal and140enlarged text escapes in the initial audit. This is a browser layout test, not physical-device accessibility certification.

71existing Node tests pass with node --test tests/*.test.mjs (the unrelated long custom simulation chain was not repeated for this CSSfix). Whole-app browser51still checks50viewport fits,5themes/8frames/equips/36icons/actual3Dbattle/offline. Fresh9step tutorial and actual50SW21→51SW22 firstnavigation/offline upgrade pass. Focused panel audit uses2D to isolate text; actual3D is tested separately. Initial headless3Dscreenshot timeout/stale-size diagnostic retained; final40panel audit has0oversized cards.

Android151sameID/certificate as150;100bundledassets including fontOFL. ZIPCRC/signature/package/assetSHA and actual extractedAPKoffline font/portrait/market/missions/Sandrift3D/checkpointresume pass. No physicalAPKinstall/FPSclaim. Source ZIP excludes generatedAPKassets/caches/privatekeys and includes verified restorehelper. Other3Dworlds needinitialdownload/cache. No livebilling/ads or maprights-clearanceclaim.

Workingcasebot,28protectedpublished and209parent sourcefiles preserved. Changes publish only to remix31 and original18redirect; fullhistory/evidence stored in sourcebranch/archive/receipt.

Build with Node22+/Python3 and exact package.jsondependencies: `node --test tests/*.test.mjs`; `ARENA_MANAGER_OUT=/tmp/arena51-web npm run build`; `python pack-web31.py /tmp/arena51-web`. Serve under /arena-manager-beta/remix31/ with retained sharedrootassets. Verification51contains scripts/screenshots/results; RAMpaths in scripts need local adaptation. Native instructions androidGame51/README.md. Prior history: https://github.com/Abror1111/arena-manager-beta/tree/arena-polish50-source .
