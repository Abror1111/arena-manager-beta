from pathlib import Path
import json,hashlib,shutil,subprocess,urllib.parse
p=Path('/dev/shm/arena-manager-fit51');r=p/'androidGame51';app=r/'app';root=app/'src/main/assets/public';base=root/'arena-manager-beta';web=Path('/dev/shm/arena-manager-fit51-web');repo=Path('/dev/shm/arena-pages32');old=Path('/workspace/arena-rebuilt-beta/android')
(app/'src/main/java/uz/arena/preview').mkdir(parents=True,exist_ok=True);root.mkdir(parents=True,exist_ok=True)
shutil.copytree(old/'app/src/main/res',app/'src/main/res',dirs_exist_ok=True)
shutil.copytree(web,base/'remix31',dirs_exist_ok=True)
(base/'original20/assets').mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'original20/assets/index-CVBt3UIp.css',base/'original20/assets/index-CVBt3UIp.css')
(base/'ui15').mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'ui15/anime-player-portraits.png',base/'ui15/anime-player-portraits.png')
report=json.loads(Path('/dev/shm/arena-career46-tests/browser46.json').read_text());aliases={};files={}
def putLocal(path):
 rel=path.lstrip('/');target=root/rel
 if target.exists():return
 source=repo/rel.removeprefix('arena-manager-beta/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
def putRemote(url):
 url=urllib.parse.urldefrag(url)[0];url=urllib.parse.urlsplit(url)._replace(query='').geturl()
 if url in aliases:return
 cache=Path('/dev/shm/arena-tactics32-remote')/hashlib.sha256(url.encode()).hexdigest()
 data=cache.read_bytes()if cache.exists()else subprocess.check_output(['curl','-fLsS','--connect-timeout','20','--max-time','90',url])
 ext=Path(urllib.parse.urlsplit(url).path).suffix;ext='.dat'if ext=='.gz'else ext;name='embedded/'+hashlib.sha256(data).hexdigest()+ext;target=root/name;target.parent.mkdir(exist_ok=True);target.write_bytes(data);aliases[url]=name
for obsolete in (root/'embedded').glob('*.gz'):obsolete.unlink()
for url in sorted(set(report['requests'])):
 u=urllib.parse.urlsplit(url)
 if u.scheme=='https'and u.netloc=='raw.githubusercontent.com':putRemote(url)
 elif u.scheme=='http'and u.path.startswith('/arena-manager-beta/')and'/remix31/'not in u.path:putLocal(u.path)
# Bundle all simulation collisions, menu covers and runtime audio; other 3D worlds download/cache on demand.
for f in(repo/'cs2').glob('*.cmesh'):putLocal('/arena-manager-beta/cs2/'+f.name)
audio=json.loads((p/'src/bundled-audio.json').read_text())['clips']
musicPrefix='https://raw.githubusercontent.com/Abror1111/arena-manager-beta/503ddf64917c741af47d83842b624baa9a819fa2/music40/'
for e in audio:
 if e.get('pack')=='arena-music40':putRemote(musicPrefix+e['url'])
 else:putLocal('/arena-manager-beta/'+e['url'])
for e in json.loads((p/'src/previews39.json').read_text()).values():putRemote(e['url'])
video=json.loads((p/'src/reward-video45.json').read_text());putRemote(video['url'])
for entry in json.loads((p/'src/art48.json').read_text()).values():putRemote(entry['url'])
for entry in json.loads((p/'src/art49.json').read_text()).values():putRemote(entry['url'])
putRemote(json.loads((p/'src/font50.json').read_text())['url'])
licenseDir=root/'licenses';licenseDir.mkdir(exist_ok=True);shutil.copy2(p/'art50/OFL.txt',licenseDir/'Manrope-OFL.txt')
(root/'remote-aliases51.json').write_text(json.dumps(aliases,indent=2)+'\n')
for f in root.rglob('*'):
 if f.is_file():files[str(f.relative_to(root))]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
meta={'applicationId':'uz.arena.manager.preview','versionCode':151,'versionName':'1.51-beta','virtualOrigin':'https://arena.local/','entry':'/arena-manager-beta/remix31/?v=51','bundledFirst3DMap':'dust2','all11NavigationAndCollisionsBundled':True,'other3DMapsDownloadOnDemand':True,'fullOfflineAPK':False,'assets':files,'remoteAliases':aliases,'bytes':sum(v['bytes']for v in files.values())}
Path('/dev/shm/arena-fit51-tests/android-assets51.json').write_text(json.dumps(meta,indent=2)+'\n');print('Bundled files',len(files),'bytes',meta['bytes'],'aliases',len(aliases))
(r/'settings.gradle').write_text("pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name='ArenaCareer46'\ninclude ':app'\n")
(r/'build.gradle').write_text("plugins { id 'com.android.application' version '8.7.2' apply false }\n")
(r/'gradle.properties').write_text('org.gradle.jvmargs=-Xmx1536m -Dfile.encoding=UTF-8\norg.gradle.workers.max=2\n')
(r/'local.properties').write_text('sdk.dir=/workspace/.arena-tools/android-sdk\n')
(app/'build.gradle').write_text("""plugins { id 'com.android.application' }
android {
 namespace 'uz.arena.preview'
 compileSdk 35
 defaultConfig { applicationId 'uz.arena.manager.preview'; minSdk 26; targetSdk 35; versionCode 151; versionName '1.51-beta' }
 compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
 signingConfigs { debug { storeFile file(project.findProperty('previewKey51') ?: '../preview51.keystore'); storePassword 'android'; keyAlias 'androiddebugkey'; keyPassword 'android' } }
 buildTypes { debug { signingConfig signingConfigs.debug }; release { minifyEnabled false } }
}
""")
(app/'src/main/AndroidManifest.xml').write_text("""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
 <uses-permission android:name="android.permission.INTERNET"/>
 <uses-feature android:glEsVersion="0x00030000" android:required="false"/>
 <application android:label="ARENA Preview 1.51" android:icon="@drawable/icon" android:theme="@style/ArenaTheme" android:hardwareAccelerated="true" android:allowBackup="false" android:usesCleartextTraffic="false">
  <activity android:name=".MainActivity" android:screenOrientation="sensorLandscape" android:configChanges="orientation|screenSize|smallestScreenSize|keyboardHidden|uiMode|screenLayout" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity>
 </application>
</manifest>
""")
