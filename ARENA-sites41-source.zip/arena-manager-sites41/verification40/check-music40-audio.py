from pathlib import Path
import subprocess,json,re,concurrent.futures,hashlib
p=Path('/dev/shm/arena-music40-assets');manifest=json.loads((p/'music-manifest40.json').read_text());log=Path('/dev/shm/arena-music40-tests')
def check(e):
 f=p/e['url'];probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(f)]));stream=next(s for s in probe['streams']if s['codec_type']=='audio');assert stream['codec_name']=='mp3' and stream['channels']==2 and int(stream['sample_rate'])==44100
 assert abs(float(probe['format']['duration'])-e['duration'])<.1
 r=subprocess.run(['ffmpeg','-hide_banner','-i',str(f),'-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True,check=True);t=r.stderr.rsplit('Summary:',1)[-1];lufs=float(re.search(r'I:\s*([-0-9.]+) LUFS',t)[1]);tp=float(re.search(r'Peak:\s*([-0-9.]+) dBFS',t)[1]);assert -25<lufs<-12 and tp<-.5,(e['key'],lufs,tp)
 b=subprocess.check_output(['curl','-fLsS','--connect-timeout','15','--max-time','90',json.loads((log/'music-publication.json').read_text())['prefix']+e['url']]);assert hashlib.sha256(b).hexdigest()==e['sha256']
 return {'key':e['key'],'title':e['title'],'duration':e['duration'],'encodedDuration':float(probe['format']['duration']),'codec':'mp3','sampleRate':44100,'channels':2,'integratedLUFS':lufs,'truePeakDBFS':tp,'remoteSHA256Verified':True,'sha256':e['sha256']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:rows=list(ex.map(check,manifest['clips']))
(log/'audio-quality.json').write_text(json.dumps({'result':'passed','tracks':rows,'externalSampleInputs':[],'externalMelodyInputs':[]},indent=2)+'\n');print(json.dumps(rows,indent=2))
