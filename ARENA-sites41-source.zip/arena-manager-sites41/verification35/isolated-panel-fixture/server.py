from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  p=urlsplit(path).path
  for prefix,root in [('/src/','/dev/shm/arena-manager-holo35/src'),('/three/','/workspace/arena-rebuilt-beta/node_modules/three/build'),('/addons/','/workspace/arena-rebuilt-beta/node_modules/three/examples/jsm')]:
   if p.startswith(prefix):return str(Path(root)/p[len(prefix):])
  return '/dev/shm/holo35-panel-test/index.html'
ThreadingHTTPServer(('0.0.0.0',8244),H).serve_forever()
