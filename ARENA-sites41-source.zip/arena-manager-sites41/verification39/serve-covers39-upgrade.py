from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote,urlsplit
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  path=unquote(urlsplit(path).path);prefix='/arena-manager-beta/remix31/'
  if path.startswith(prefix):
   version=Path('/dev/shm/arena-covers39-tests/upgrade-version.txt').read_text().strip()
   root=Path('/dev/shm/arena-manager-holo38-web') if version=='38' else Path('/dev/shm/arena-manager-covers39-web')
   return str(root/path[len(prefix):])
  if path.startswith('/arena-manager-beta/'):return str(Path('/dev/shm/arena-pages32')/path[len('/arena-manager-beta/'):])
  return str(Path('/dev/shm/arena-manager-holo35-web')/path.lstrip('/'))
ThreadingHTTPServer(('0.0.0.0',8250),H).serve_forever()
