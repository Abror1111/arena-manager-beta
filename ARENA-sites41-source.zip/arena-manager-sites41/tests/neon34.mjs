import assert from 'node:assert/strict';
import * as T from 'three';
import {CYBER34} from '../src/cyber-profiles34.js';
import {roofAnchors34} from '../src/cyber-roofs34.js';
import {createCyberMaterials34} from '../src/cyber-materials34.js';
assert.equal(Object.keys(CYBER34).length,11);assert.equal(new Set(Object.values(CYBER34).map(p=>p.wall)).size,11);
function fixture(id,{walkY=0,site={x:1,z:1},tilt=0}={}){const root=new T.Group(),geo=new T.PlaneGeometry(10,10),mesh=new T.Mesh(geo,new T.MeshStandardMaterial());mesh.rotation.x=-Math.PI/2+tilt;mesh.position.y=5;root.add(mesh);const map={id,playerScale:1,width:40,height:40,nav:{rows:[[0,[15,15,walkY,25,15,walkY,25,25,walkY,15,25,walkY],[],[20,20,walkY]]]},sites:[site],review:{visual:{sha256:'fixture'}}};return{root,map,dispose(){geo.dispose();mesh.material.dispose();}};}
const flat=fixture('flat-roof-test'),result=roofAnchors34(flat.root,flat.map);assert(result.anchors.length>0);for(const a of result.anchors){assert(Math.abs(a.y-5)<1e-8);assert(a.ny>.999);assert(a.radius>=.6);assert(Math.abs(a.x)<5&&Math.abs(a.z)<5);const maxFootprint=a.radius*.67*Math.hypot(2.5/2,1.48/2);assert(maxFootprint<a.radius,'Full plinth footprint must fit the support circle');}flat.dispose();
const occupied=fixture('walkable-roof-test',{walkY:5});assert.equal(roofAnchors34(occupied.root,occupied.map).anchors.length,0,'No kits on walkable floor');occupied.dispose();
const plant=fixture('plant-clearance-test',{site:{x:20,z:20}});assert.equal(roofAnchors34(plant.root,plant.map).anchors.length,0,'No kits near plant markers');plant.dispose();
const slope=fixture('steep-roof-test',{tilt:.2});assert.equal(roofAnchors34(slope.root,slope.map).anchors.length,0,'No unsupported level kits on sloped roofs');slope.dispose();
// Source-derived surroundings can clone a material's compile hook. Running a
// cloned hook chain must never inject the cel-shading declarations twice.
const priorDocument=globalThis.document,context=new Proxy({getImageData:()=>({data:new Uint8ClampedArray(256*256*4)}),createImageData:()=>({data:new Uint8ClampedArray(256*256*4)})},{get:(o,k)=>o[k]||(()=>{})});
globalThis.document={createElement:()=>({width:0,height:0,getContext:()=>context})};
try{const skin=createCyberMaterials34('dust2',{capabilities:{getMaxAnisotropy:()=>8}}),first=new T.MeshStandardMaterial({name:'wall'});skin.apply(first);const copy=first.clone();copy.onBeforeCompile=first.onBeforeCompile;skin.apply(copy);const shader={fragmentShader:'#include <opaque_fragment>',vertexShader:'',uniforms:{}};copy.onBeforeCompile(shader,{});assert.equal(shader.fragmentShader.split('float animeLum34=').length-1,1,'Cloned hooks must compile a single cel layer');first.dispose();copy.dispose();skin.dispose();}finally{if(priorDocument===undefined)delete globalThis.document;else globalThis.document=priorDocument;}
console.log(JSON.stringify({result:'passed',profiles:11,groundedSupportCircle:true,walkableFloorClear:true,plantClearance:true,slopedRoofRejected:true,clonedShaderHookIdempotent:true}));
