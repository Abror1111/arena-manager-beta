import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {setNative31} from '../src/native-data31.js';
import {readSource31} from './source-assets31.mjs';
import {registerCollision,collisionRay,collisionBlocks} from '../src/world-collision.js';
import {createOperator} from '../src/operators.js';

import * as T from 'three';
setNative31(JSON.parse(gunzipSync(await readFile(new URL('../data/native-data31.json.gz',import.meta.url)))));
const [{Match},{prepareApprovedCollision}]=await Promise.all([import('../src/engine.js'),import('../src/approved-collision.js')]);
const {batchOriginalUnits}=await import('../src/units.js');
let seed=3601,queries=0;const random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
function parity(map,a,b){const hit=collisionRay(map,a,b,{ignoreStart:.06});assert.equal(collisionBlocks(map,a,b),!!hit&&hit.t<.99,JSON.stringify({map:map.id,a,b,hit}));queries++;}
for(const id of ['dust2','inferno','nuke']){
 const g=new Match({map:id,strategy:'a',seed:22});await prepareApprovedCollision(g.map,undefined,{load:readSource31});
 for(let i=0;i<1500;i++){const p=g.map.nav.rows[Math.floor(random()*g.map.nav.rows.length)][3],q=g.map.nav.rows[Math.floor(random()*g.map.nav.rows.length)][3],a={x:p[0]+(random()-.5)*.08,z:p[1],y:p[2]+.05+random()*2},b={x:q[0],z:q[1],y:q[2]+.05+random()*2};if(i%10===0){b.x=a.x;b.z=a.z;}parity(g.map,a,b);}
}
const propStates={},map={nav:{},rebuilt:true,props:[{id:'box',x:5,y:0,z:0,size:[2,2,2]}],getPropStates:()=>propStates};registerCollision(map,new Float32Array([0,0,-2,0,3,0,0,0,2]),new Uint32Array([0,1,2]));
for(const state of [null,{x:1,y:1,z:0},{x:1,y:1,z:0,broken:true}]){if(state)propStates.box=state;else delete propStates.box;for(let i=0;i<200;i++)parity(map,{x:-2+random()*10,y:random()*4,z:-2+random()*4},{x:-2+random()*10,y:random()*4,z:-2+random()*4});}
for(const x of [0,.059999,.06,.060001,1])parity(map,{x,y:1,z:0},{x:-2,y:1,z:0});parity(map,{x:1,y:1,z:1},{x:1,y:1,z:1});
delete propStates.box;registerCollision({nav:map.nav},new Float32Array(),new Uint32Array(),{replace:true});assert.equal(collisionBlocks(map,{x:0,y:1,z:0},{x:10,y:1,z:0}),true,'Empty triangle tree still checks props');
const oldDocument=globalThis.document;globalThis.document={createElement:()=>({getContext:()=>({createImageData:(w,h)=>({data:new Uint8Array(w*h*4)}),putImageData(){}})})};
try{
 const full=createOperator(0,0),low=createOperator(0,0,1),a=[],b=[];full.root.traverse(o=>{if(o.isMesh)a.push(o)});low.root.traverse(o=>{if(o.isMesh)b.push(o)});assert.equal(a.length,b.length);assert.equal(full.jointCount,low.jointCount);assert(low.stats.triangles<full.stats.triangles*.6);
 const scene=new T.Scene(),g=new T.Group();scene.add(g);g.add(full.root);g.userData.actorAlive=true;a.forEach((m,i)=>m.userData.distanceGeometry36=b[i].geometry);const units=[{g,parts:a,team:0}],batch=batchOriginalUnits(scene,units);
 batch.update(200);assert.equal(batch.detail,'full');const high=scene.children.filter(o=>o.isInstancedMesh&&o.visible),triangles=()=>scene.children.filter(o=>o.isInstancedMesh&&o.visible).reduce((n,o)=>n+(o.geometry.index?.count||o.geometry.attributes.position.count)/3*o.count,0),hi=triangles();assert(hi>0);
 batch.update(20);assert.equal(batch.detail,'screen-space');const lo=triangles();assert(lo<hi*.6);batch.update(105);assert.equal(batch.detail,'screen-space');batch.update(120);assert.equal(batch.detail,'full');assert.equal(triangles(),hi);
 full.gun.scale.setScalar(0);batch.update(200);assert(triangles()<hi,'Scale-zero weapons excluded');g.userData.actorAlive=false;batch.update(200);assert(!scene.children.some(o=>o.isInstancedMesh&&o.renderOrder===32&&o.visible));batch.dispose();assert(!scene.children.some(o=>o.isInstancedMesh));
 console.log(JSON.stringify({result:'passed',exactCollisionParityQueries:queries,realMaps:['dust2','inferno','nuke'],movedBrokenProps:true,verticalAndZeroLength:true,fullOperatorTriangles:full.stats.triangles,distantOperatorTriangles:low.stats.triangles,fullBatchTriangles:hi,distantBatchTriangles:lo,sameRigAndMaterials:true,detailHysteresis:true,hiddenWeaponsNotSubmitted:true,deadGhostsNotSubmitted:true,cleanup:true}));
}finally{globalThis.document=oldDocument;}
