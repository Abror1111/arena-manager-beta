import assert from 'node:assert/strict';
import * as T from 'three';
import {holoState35} from '../src/holo-state35.js';
import {scoreFaceGeometry35,addHolograms35} from '../src/holograms35.js';
import {humanGeometry35} from '../src/holo-human35.js';
import {citySites35,facadeAnchors35} from '../src/cyber-facades35.js';

const game={map:{name:'Dust II'},score:[7,5],teamNames:['UZB FIVE','IRON FIVE'],round:13,clock:89.9,phase:'live',bomb:{state:'carried'}};
assert.deepEqual(holoState35(game),{source:'match',home:'UZB FIVE',away:'IRON FIVE',score:'7 : 5',round:'RAUND 13',clock:'1:29',phase:'JONLI JANG'});
game.bomb={state:'planted',timer:12.8};assert.equal(holoState35(game).clock,'0:12');assert.equal(holoState35(game).phase,'C4 FAOL');assert.equal(holoState35({map:{name:'Mirage'}}).source,'preview');assert.equal(holoState35({map:{name:'Mirage'}}).score,'— : —');
for(let side=0;side<4;side++){const g=scoreFaceGeometry35(side,.492125),n=new T.Vector3().fromBufferAttribute(g.attributes.normal,0),out=new T.Vector3(Math.sin(side*Math.PI/2),0,Math.cos(side*Math.PI/2));assert(n.y>.3);assert(n.dot(out)>.8);assert.equal(g.index.count,6);g.dispose();}
const map={id:'fixture-holo35',width:40,height:40,playerScale:1,sites:[{x:1,z:1}],nav:{rows:[[0,[15,15,0,25,15,0,25,25,0,15,25,0],[],[20,20,0]]]},review:{visual:{sha256:'unit'}}},root=new T.Group(),roof=new T.Mesh(new T.PlaneGeometry(12,12),new T.MeshStandardMaterial());roof.rotation.x=-Math.PI/2;roof.position.y=5;root.add(roof);
const sites=citySites35(map,(x,z)=>x*.15+z*.07);assert.equal(sites.length,12);for(const a of sites){assert(Math.abs(a.x)-a.r>20||Math.abs(a.z)-a.r>20);for(const dx of[-a.r,0,a.r])for(const dz of[-a.r,0,a.r]){const y=(a.x+dx)*.15+(a.z+dz)*.07;assert(a.bottom<y&&a.top>y);}}
const wallRoot=new T.Group(),wall=new T.Mesh(new T.PlaneGeometry(12,10),new T.MeshStandardMaterial());wall.position.set(0,5,10);wallRoot.add(wall);const walls=facadeAnchors35(wallRoot,{...map,id:'wall-holo35'});assert(walls.length>0);for(const a of walls){assert(Math.abs(a.z-10)<1e-8);assert(Math.abs(a.ny)<.08);assert(a.radius>.55);}wall.geometry.dispose();wall.material.dispose();
const body=humanGeometry35();assert(body.attributes.position.count>1000);for(let i=0;i<body.attributes.skinWeight.count;i++){assert.equal(body.attributes.skinWeight.getX(i),1);assert(Number.isFinite(body.attributes.position.getY(i)));}body.dispose();
const canvases=[],oldDocument=globalThis.document;globalThis.document={createElement(){const texts=[],context=new Proxy({fillText:(s)=>texts.push(s)},{get:(o,k)=>o[k]||(()=>{})}),canvas={width:0,height:0,getContext:()=>context,texts};canvases.push(canvas);return canvas;}};
try{const dynamic=new T.Scene(),staticScene=new T.Scene(),h=addHolograms35(dynamic,root,map,{staticScene});assert.equal(h.faces,4);assert.equal(h.people,4);h.update(game,1);assert.equal(h.textureUpdates,1);assert.equal(h.state.score,'7 : 5');assert(canvases[0].texts.includes('7 : 5'));h.update(game,2);assert.equal(h.textureUpdates,1,'Do not repaint the score texture every frame');game.score=[8,5];h.update(game,3);assert.equal(h.textureUpdates,2);assert(canvases[0].texts.includes('8 : 5'));h.dispose();assert.equal(dynamic.children.length,0);assert.equal(staticScene.children.length,0);}finally{if(oldDocument===undefined)delete globalThis.document;else globalThis.document=oldDocument;}
roof.geometry.dispose();roof.material.dispose();
console.log(JSON.stringify({result:'passed',fourOutwardUpwardFaces:true,actualMatchScoreClockC4:true,previewHasNoFakeScore:true,textureRepaintOnlyOnChange:true,skinnedHumanGeometry:true,groundedTowersOutsidePlay:true,surfaceMountedFacades:true,cleanup:true}));
