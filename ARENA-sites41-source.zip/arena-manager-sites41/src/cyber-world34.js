import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {roofAnchors34} from './cyber-roofs34.js';
import {cyberProfile34} from './cyber-profiles34.js';

export function bevelBlock(w,h,d){const c=Math.min(.12,w*.1,h*.1),shape=new T.Shape(),pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];pts.forEach(([x,y],i)=>shape[i?'lineTo':'moveTo'](x,y));shape.closePath();const g=new T.ExtrudeGeometry(shape,{depth:d,steps:1,bevelEnabled:true,bevelSegments:1,bevelSize:.025,bevelThickness:.025,curveSegments:1});g.translate(0,0,-d/2);return g;}
function signTexture(p,id){const c=document.createElement('canvas');c.width=512;c.height=256;const g=c.getContext('2d');g.fillStyle=p.yellow;g.fillRect(0,0,512,256);g.strokeStyle=p.ink;g.lineWidth=9;g.strokeRect(12,12,488,232);g.fillStyle=p.ink;g.font='900 84px sans-serif';g.fillText('ARENA',37,112);g.fillStyle=p.accent;g.font='bold 23px monospace';g.fillText('NEON / '+id.toUpperCase().replace('-NIGHT',' N'),40,157);g.fillStyle=p.ink;g.font='19px monospace';g.fillText('SECTOR 34   //   ONLINE',40,206);for(let i=0;i<8;i++)g.fillRect(413+i*7,180,3,38);const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.anisotropy=4;return t;}

export function addCyberWorld34(scene,root,map,placements){
 const p=cyberProfile34(map.id),s=map.playerScale||1,support={anchors:placements?.kits||roofAnchors34(root,map).anchors},group=new T.Group();group.name='arena-neon-rooftops34';const buckets=[[],[],[],[],[]],geometries=new Set(),materials=[],matrix=new T.Matrix4(),local=new T.Matrix4(),rotation=new T.Quaternion(),q=new T.Quaternion(),up=new T.Vector3(0,1,0),position=new T.Vector3(),scale=new T.Vector3(),euler=new T.Euler();
 const atlas=signTexture(p,map.id);materials.push(new T.MeshStandardMaterial({color:p.panel,roughness:.6,metalness:.25}),new T.MeshStandardMaterial({color:p.ink,roughness:.78}),new T.MeshStandardMaterial({color:p.neon,emissive:p.neon,emissiveIntensity:1.15,roughness:.4}),new T.MeshStandardMaterial({color:p.accent,emissive:p.accent,emissiveIntensity:.9,roughness:.45}),new T.MeshBasicMaterial({map:atlas,side:T.DoubleSide,toneMapped:false}));
 const prototypes=new Map();function shape(key,create){if(!prototypes.has(key))prototypes.set(key,create());return prototypes.get(key);}
 function part(geo,mat,x,y,z,rx=0,ry=0,rz=0){local.compose(position.set(x,y,z),q.setFromEuler(euler.set(rx,ry,rz)),scale.set(1,1,1));const g=geo.clone().applyMatrix4(local).applyMatrix4(matrix);buckets[mat].push(g);}
 function block(mat,x,y,z,w,h,d){part(shape('b'+[w,h,d],()=>bevelBlock(w,h,d)),mat,x,y,z);}
 const body=shape('body',()=>bevelBlock(2.0,.55,1.35)),fan=shape('fan',()=>new T.CylinderGeometry(.34,.34,.1,16)),ring=shape('ring',()=>new T.TorusGeometry(.36,.035,5,20)),rod=shape('rod',()=>new T.CylinderGeometry(.025,.025,1.3,6));
 let signs=0;
 support.anchors.forEach((a,i)=>{
  const k=Math.min(1.45*s,a.radius*.67),yaw=(i%4)*Math.PI/2;rotation.setFromUnitVectors(up,new T.Vector3(a.nx,a.ny,a.nz));rotation.multiply(q.setFromAxisAngle(up,yaw));matrix.compose(position.set(a.x,a.y+.008*s,a.z),rotation,scale.set(k,k,k));
  if(Number.isFinite(a.bottom)){const h=(a.y-a.bottom)/k;block(1,0,-h/2,0,2.2,h,1.48);}
  // A layered plinth, chamfered housing, cooling grilles and exposed conduits.
  block(1,0,.08,0,2.2,.11,1.48);part(body,0,0,.40,0);block(2,-.96,.42,0,.045,.32,1.08);block(3,.96,.42,0,.045,.32,.62);
  for(let j=0;j<7;j++)block(1,-.72+j*.24,.40,.697,.13,.25,.04);
  for(const x of[-.48,.48]){part(fan,1,x,.75,0);part(ring,2,x,.81,0,Math.PI/2);for(let j=0;j<5;j++)part(shape('blade',()=>bevelBlock(.53,.025,.06)),0,x,.815,0,0,j*Math.PI/5);}
  // Raised ribs and coaxial ducts have their own silhouette from angled views.
  for(let j=0;j<4;j++)block(0,-.72+j*.48,.75,-.5,.08,.18,.22);
  part(shape('duct',()=>new T.TorusGeometry(.32,.055,6,12,Math.PI)),3,.65,.75,.37,0,Math.PI/2);
  if(i%3===0){
   signs++;for(const x of[-.88,.88]){part(rod,1,x,1.35,-.2);block(2,x,1.85,-.2,.07,.18,.1);}block(1,0,2.1,-.2,2.5,1.25,.17);block(3,0,2.1,-.08,2.34,1.1,.06);part(shape('screen',()=>new T.PlaneGeometry(2.24,1.02)),4,0,2.1,-.033);part(shape('screen-back',()=>new T.PlaneGeometry(2.24,1.02)),4,0,2.1,-.303,0,Math.PI);
  }else{
   // A telemetry mast with stacked isolators and two angled receiver vanes.
   part(rod,1,.63,1.29,-.37);for(const y of[1.1,1.4,1.7])block(3,.63,y,-.37,.18,.07,.18);block(0,.63,1.87,-.37,.36,.24,.11);part(shape('receiver',()=>new T.ConeGeometry(.22,.27,8)),2,.63,2.08,-.37,0,0,Math.PI/3);
  }
 });
 let triangles=0;for(let i=0;i<buckets.length;i++){const parts=buckets[i];if(!parts.length)continue;const geo=mergeGeometries(parts.map(g=>g.index?g.toNonIndexed():g));parts.forEach(g=>g.dispose());if(!geo)throw Error('Neon geometry merge failed');geometries.add(geo);triangles+=geo.attributes.position.count/3;const mesh=new T.Mesh(geo,materials[i]);mesh.name='arena-neon-batch34-'+i;mesh.castShadow=i<2;mesh.receiveShadow=i<2;group.add(mesh);}
 prototypes.forEach(g=>g.dispose());scene.add(group);
 return{group,kits:support.anchors.length,signs,triangles,batches:group.children.length,profile:'anime-neon34',support:support.anchors.map(a=>({x:a.x,y:a.y,z:a.z,radius:a.radius})),dispose(){group.removeFromParent();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());atlas.dispose();}};
}
