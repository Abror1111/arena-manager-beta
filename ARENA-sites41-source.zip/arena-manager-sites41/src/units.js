import{visualFloor31}from'./visual-floor31.js';
import*as T from'three';import{createOperator,poseOperator}from'./operators.js';import{createObserverSilhouette}from'./observer-silhouette.js';import{WEAPONS}from'./weapons.js';import{heightAt}from'./maps.js';import{createEquipment}from'./equipment-models.js';
export function createUnit(parent,p,kit){
 const g=new T.Group();parent.add(g);let op=createOperator(p.side==='CT'?1:0,p.id);g.add(op.root);const ring=new T.Mesh(new T.RingGeometry(.38,.47,28),new T.MeshBasicMaterial({color:p.team?'#4fa9ed':'#f2a64e',transparent:true,opacity:.6,depthWrite:false,depthTest:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.03;ring.renderOrder=20;g.add(ring);const shadow=new T.Mesh(new T.CircleGeometry(.3,16),new T.MeshBasicMaterial({color:'#172420',transparent:true,opacity:.25,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.012;g.add(shadow);
 const held=createEquipment('c4');held.root.visible=false;g.add(held.root);
 let previous=null,heading=p.angle||0,turn=0,lastAmmo=p.ammo,lastWeapon=p.weapon,wasAlive=p.alive,side=p.side,equipTime=1;const parts=[];op.root.traverse(o=>{if(o.isMesh)parts.push(o)});
 // Both tiers use the identical articulated rig, clothing, materials and props.
 // Distant subpixel bevels need fewer vertices; close views keep the full model.
 const distant=createOperator(p.side==='CT'?1:0,p.id,1),low=[];distant.root.traverse(o=>{if(o.isMesh)low.push(o)});
 if(low.length!==parts.length)throw Error('Operator detail rig differs');
 parts.forEach((part,i)=>{part.userData.distanceGeometry36=low[i].geometry});
 function update(p,game,time,dt,follow){
  const x=p.x-game.map.width/2,z=p.z-game.map.height/2;let vx=0,vz=0;if(previous&&dt>0&&Math.hypot(x-previous.x,z-previous.z)<2){vx=(x-previous.x)/dt;vz=(z-previous.z)/dt}previous={x,z};const visualY=visualFloor31(game.map,p.x,p.z,p.y||0);g.position.set(x,visualY,z);
  if(!wasAlive&&p.alive){heading=p.angle;turn=0;op.anchors=[];op.lastYaw=null;op.dead=0}wasAlive=p.alive;
  if(p.weapon!==lastWeapon)equipTime=0;equipTime=Math.min(1,equipTime+dt/.42);const moving=Math.hypot(vx,vz)>.06,target=game.players[p.targetId],aim=!!target?.alive,aimAngle=aim?Math.atan2(target.x-p.x,target.z-p.z):p.angle,desired=aim?aimAngle:moving?Math.atan2(vx,vz):(p.angle??heading),diff=Math.atan2(Math.sin(desired-heading),Math.cos(desired-heading));turn+=(T.MathUtils.clamp(diff*6,-4.2,4.2)-turn)*(1-Math.exp(-dt*10));heading+=turn*dt;g.rotation.y=heading;
  const local=new T.Vector3(vx,0,vz).applyAxisAngle(new T.Vector3(0,1,0),-heading),throwEvent=game.effects.find(e=>e.kind==='grenade'&&e.owner===p.id&&e.age<.7),plant=p.alive&&game.phase==='live'&&game.bomb.state==='carried'&&game.bomb.carrier===p.id&&game.bomb.actor===p.id&&p.plant>0,reload=p.reload>0?1-p.reload/WEAPONS[p.weapon].reload:-1,shot=p.alive&&p.weapon===lastWeapon&&p.ammo<lastAmmo&&!p.reload;
  const s=game.map.playerScale||1;const pose=poseOperator(op,{time,equip:equipTime,groundAt:(wx,wz)=>(heightAt(game.map,wx*s+game.map.width/2,wz*s+game.map.height/2,p.y)+visualY-(p.y||0))/s,vx:local.x/s,vz:local.z/s,world:{x:x/s,z:z/s,y:visualY/s,yaw:heading},aim,aimYaw:Math.atan2(Math.sin(aimAngle-heading),Math.cos(aimAngle-heading)),crouch:plant?1:!moving&&['cover','anchor','postplant','defuse'].includes(p.brain?.state)?.65:0,dead:!p.alive,reload,shot,sidearm:['pistol','special'].includes(WEAPONS[p.weapon]?.family),knife:p.weapon==='knife',sniper:WEAPONS[p.weapon]?.family==='sniper',throw:throwEvent?Math.min(.99,.66+throwEvent.age/.7*.34):-1,plant:plant?Math.min(.99,(p.plant||1)/3.2):-1},dt);
  held.root.visible=plant;g.userData.heldC4=plant;held.root.position.set(0,.24,.35);held.update(40,false,p.plant);g.userData.actorAlive=p.alive;lastAmmo=p.ammo;lastWeapon=p.weapon;ring.visible=p.alive;ring.scale.setScalar(follow===p.id?1.3:1);ring.material.opacity=follow===p.id?1:.55;shadow.visible=p.alive;op.root.userData.animation=pose.action;g.userData.originalMotion=pose;g.userData.originalOperator=true;
 }
 return{g,ring,parts,team:p.team,update,setSourceLibrary(){},get sourceName(){return null},dispose(){held.dispose();ring.geometry.dispose();ring.material.dispose();shadow.geometry.dispose();shadow.material.dispose();g.removeFromParent()}};
}

export function batchOriginalUnits(scene,units){
 const bins=new Map(),ghostMaterials=[0,1].map(team=>new T.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.65,depthWrite:false,depthTest:true,depthFunc:T.GreaterDepth,side:T.DoubleSide,toneMapped:false,stencilWrite:true,stencilRef:1,stencilFunc:T.NotEqualStencilFunc,stencilFail:T.KeepStencilOp,stencilZFail:T.KeepStencilOp,stencilZPass:T.KeepStencilOp}));
 for(const unit of units)for(const source of unit.parts){const key=source.geometry.uuid+source.material.uuid;if(!bins.has(key))bins.set(key,[]);bins.get(key).push({source,unit});source.visible=false;Object.assign(source.material,{stencilWrite:true,stencilRef:1,stencilFunc:T.AlwaysStencilFunc,stencilWriteMask:255,stencilFuncMask:255,stencilFail:T.KeepStencilOp,stencilZFail:T.KeepStencilOp,stencilZPass:T.ReplaceStencilOp})}
 const batches=[];for(const originals of bins.values()){
  const first=originals[0],tiers=[first.source.geometry,first.source.userData.distanceGeometry36].map(geometry=>{
   const mesh=new T.InstancedMesh(geometry,first.source.material,originals.length),ghost=new T.InstancedMesh(geometry,ghostMaterials[0],originals.length);
   for(const m of[mesh,ghost]){m.frustumCulled=false;m.instanceMatrix.setUsage(T.DynamicDrawUsage);scene.add(m)}
   mesh.renderOrder=10;mesh.receiveShadow=true;ghost.renderOrder=32;return{mesh,ghost};
  });batches.push({tiers,originals});
 }
 const color=new T.Color();let lastDetail=-1;
 return{count:batches.length,get detail(){return lastDetail?'screen-space':'full';},update(projectedHeight=200){
  // Hysteresis prevents switching tiers around the boundary during camera moves.
  if(lastDetail<0)lastDetail=projectedHeight<100?1:0;
  else if(lastDetail&&projectedHeight>112)lastDetail=0;else if(!lastDetail&&projectedHeight<88)lastDetail=1;
  units.forEach(u=>u.g.updateMatrixWorld(true));
  for(const b of batches){for(let tier=0;tier<2;tier++){
   const {mesh,ghost}=b.tiers[tier];let visible=0,occluded=0;
   if(tier===lastDetail)for(const {source,unit}of b.originals){
    const e=source.matrixWorld.elements;
    // Holstered/switched props are scale-zero in the action rig. Do not submit
    // their triangles (or their invisible x-ray copies) to the GPU at all.
    if(!unit.g.visible||e[0]*e[0]+e[1]*e[1]+e[2]*e[2]<1e-12)continue;
    mesh.setMatrixAt(visible++,source.matrixWorld);
    if(unit.g.userData.actorAlive){ghost.setMatrixAt(occluded,source.matrixWorld);ghost.setColorAt(occluded++,color.set(unit.team?'#55c5ff':'#ffb53f'));}
   }
   mesh.count=visible;ghost.count=occluded;mesh.visible=visible>0;ghost.visible=occluded>0;
   if(visible)mesh.instanceMatrix.needsUpdate=true;
   if(occluded){ghost.instanceMatrix.needsUpdate=true;ghost.instanceColor.needsUpdate=true;}
  }}
 },dispose(){for(const b of batches)for(const t of b.tiers){t.mesh.removeFromParent();t.ghost.removeFromParent();t.mesh.dispose();t.ghost.dispose();}ghostMaterials.forEach(m=>m.dispose())}};
}
