// Only objective names/order change. Physical site coordinates and the world stay intact.
export const SITE_REVISION41='arena-sites41';
export function swappedSites41(sites){return[{...sites[1],label:'A'},{...sites[0],label:'B'}];}
const flip=i=>i===0?1:i===1?0:i;
const strategy=s=>s==='a'?'b':s==='b'?'a':s;
export function migrateSiteNames41(game){
 // Keep an old unfinished match attacking/defending the same physical places.
 // Positions, paths, actors, C4 progress/timer, money, score and random state stay intact.
 game.strategy=strategy(game.strategy);game.enemyStrategy=strategy(game.enemyStrategy);
 for(const plan of game.tactics?.teams||[])plan.site=flip(plan.site);
 for(const history of game.tactics?.history||[]){history.attempts.reverse();history.wins.reverse();}
 for(const learning of game.tactics?.learning||[])learning.lastSite=flip(learning.lastSite);
 for(const p of game.players)if(p.brain&&p.brain.defendSite!==undefined)p.brain.defendSite=flip(p.brain.defendSite);
 game.note('A/B nomlari almashdi; davom etayotgan reja saqlandi.');
}
