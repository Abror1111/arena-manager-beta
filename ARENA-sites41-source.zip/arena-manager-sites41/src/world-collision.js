import{buildCollisionBVH36,collisionAny36,propsBlock36}from'./collision-bvh36.js';
// Source collision triangles, indexed in a bounded X/Z grid. Coordinates remain
// in simulation space; no render-origin translation enters gameplay queries.
const sources=new WeakMap(),order=[];
const key=(x,z)=>x+','+z,gridSize=2;
export function registerCollision(map,positions,indices,{replace=false}={}){
 const prior=sources.get(map.nav);if(prior&&!replace)return prior;
 const bins=new Map(),count=indices.length/3;
 for(let t=0;t<count;t++){
  const a=indices[t*3]*3,b=indices[t*3+1]*3,c=indices[t*3+2]*3;
  const minX=Math.floor(Math.min(positions[a],positions[b],positions[c])/gridSize),maxX=Math.floor(Math.max(positions[a],positions[b],positions[c])/gridSize),minZ=Math.floor(Math.min(positions[a+2],positions[b+2],positions[c+2])/gridSize),maxZ=Math.floor(Math.max(positions[a+2],positions[b+2],positions[c+2])/gridSize);
  if((maxX-minX+1)*(maxZ-minZ+1)>20000)continue;
  for(let x=minX;x<=maxX;x++)for(let z=minZ;z<=maxZ;z++){const k=key(x,z);if(!bins.has(k))bins.set(k,[]);bins.get(k).push(t);}
 }
 const data={positions,indices,bins,count,bvh36:buildCollisionBVH36(positions,indices)};sources.set(map.nav,data);const old=order.indexOf(map.nav);if(old>=0)order.splice(old,1);order.push(map.nav);while(order.length>2)sources.delete(order.shift());return data;
}
export function hasCollision(map){if(map.nav&&!sources.has(map.nav))map.ensureCollision?.();return !!(map.nav&&sources.has(map.nav));}
export function collisionRay(map,a,b,{ignoreStart=.015,ignoreProp=null}={}){
 if(map.nav&&!sources.has(map.nav))map.ensureCollision?.();const data=map.nav&&sources.get(map.nav);if(!data)return null;
 const {positions:p,indices:ix,bins}=data,dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,length=Math.hypot(dx,dy,dz);if(length<1e-8)return null;
 const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/gridSize*2)),candidates=new Set();
 for(let i=0;i<=steps;i++){const t=i/steps,x=Math.floor((a.x+dx*t)/gridSize),z=Math.floor((a.z+dz*t)/gridSize);for(const id of bins.get(key(x,z))||[])candidates.add(id);}
 let best=1.000001,result=null;
 for(const id of candidates){
  const ai=ix[id*3]*3,bi=ix[id*3+1]*3,ci=ix[id*3+2]*3,ex=p[bi]-p[ai],ey=p[bi+1]-p[ai+1],ez=p[bi+2]-p[ai+2],fx=p[ci]-p[ai],fy=p[ci+1]-p[ai+1],fz=p[ci+2]-p[ai+2];
  const hx=dy*fz-dz*fy,hy=dz*fx-dx*fz,hz=dx*fy-dy*fx,det=ex*hx+ey*hy+ez*hz;if(Math.abs(det)<1e-10)continue;
  const inv=1/det,sx=a.x-p[ai],sy=a.y-p[ai+1],sz=a.z-p[ai+2],u=(sx*hx+sy*hy+sz*hz)*inv;if(u<-.00001||u>1.00001)continue;
  const qx=sy*ez-sz*ey,qy=sz*ex-sx*ez,qz=sx*ey-sy*ex,v=(dx*qx+dy*qy+dz*qz)*inv;if(v<-.00001||u+v>1.00001)continue;
  const t=(fx*qx+fy*qy+fz*qz)*inv;if(t*length<ignoreStart||t>best||t>1)continue;
  let nx=ey*fz-ez*fy,ny=ez*fx-ex*fz,nz=ex*fy-ey*fx;const n=Math.hypot(nx,ny,nz);if(!n)continue;nx/=n;ny/=n;nz/=n;if(nx*dx+ny*dy+nz*dz>0){nx=-nx;ny=-ny;nz=-nz;}
  best=t;result={x:a.x+dx*t,y:a.y+dy*t,z:a.z+dz*t,nx,ny,nz,t,triangle:id};
 }
 if(map.rebuilt){const states=map.getPropStates?.()||{};for(const prop of map.props||[]){if(prop.id===ignoreProp)continue;const s=states[prop.id],center={x:s?.x??prop.x,y:(s?.y??prop.y)+prop.size[1]/2,z:s?.z??prop.z},factor=s?.broken?.76:1,half={x:prop.size[0]*factor/2,y:prop.size[1]*factor/2,z:prop.size[2]*factor/2};let lo=0,hi=1,normal={x:0,y:0,z:0};for(const axis of ['x','y','z']){const d=b[axis]-a[axis],v=a[axis]-center[axis];if(Math.abs(d)<1e-9){if(Math.abs(v)>half[axis]){lo=2;break;}continue;}let t0=(-half[axis]-v)/d,t1=(half[axis]-v)/d,n=-1;if(t0>t1){[t0,t1]=[t1,t0];n=1;}if(t0>lo){lo=t0;normal={x:0,y:0,z:0};normal[axis]=n;}hi=Math.min(hi,t1);if(lo>hi)break;}if(lo<=hi&&lo>=0&&lo<=1&&lo<best&&lo*length>=ignoreStart){best=lo;result={x:a.x+dx*lo,y:a.y+dy*lo,z:a.z+dz*lo,nx:normal.x,ny:normal.y,nz:normal.z,t:lo,prop:prop.id};}}}
 return result;
}
export function collisionBlocks(map,a,b){if(map.nav&&!sources.has(map.nav))map.ensureCollision?.();const data=map.nav&&sources.get(map.nav);return !!data&&(collisionAny36(data,a,b)||propsBlock36(map,a,b));}

export function registerDecorCollision(map,positions,indices,owner,{trimBaseBelow=null}={}){
 const current=sources.get(map.nav);if(!current)throw Error('Base collision must be ready first');if(current.decorOwner===owner)return current;const base=current.base||current;let baseIndices=base.indices;if(trimBaseBelow!==null){const selected=[];for(let i=0;i<base.indices.length;i+=3){const a=base.indices[i],b=base.indices[i+1],c=base.indices[i+2];if(Math.max(base.positions[a*3+1],base.positions[b*3+1],base.positions[c*3+1])>trimBaseBelow)selected.push(a,b,c);}baseIndices=new Uint32Array(selected);}const p=new Float32Array(base.positions.length+positions.length),ix=new Uint32Array(baseIndices.length+indices.length);p.set(base.positions);p.set(positions,base.positions.length);ix.set(baseIndices);const offset=base.positions.length/3;for(let i=0;i<indices.length;i++)ix[baseIndices.length+i]=indices[i]+offset;const result=registerCollision(map,p,ix,{replace:true});result.base=base;result.decorOwner=owner;return result;
}
export function releaseDecorCollision(map,owner){const current=sources.get(map.nav);if(current?.decorOwner===owner)sources.set(map.nav,current.base);}
export function hasPreparedCollision(map,version,sha256){const data=sources.get(map.nav);return data?.decorOwner?.version===version&&(!sha256||data.decorOwner.sha256===sha256);}
