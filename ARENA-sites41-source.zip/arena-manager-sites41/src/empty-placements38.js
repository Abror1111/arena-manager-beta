import{visualOccupancy38}from'./visual-occupancy38.js';
import{collisionBlocks}from'./world-collision.js';
import districts from'./approved/surroundings-layouts.json'with{type:'json'};
import dust from'./approved/dust2-context-plan.json'with{type:'json'};
import{mapContextPlan}from'./approved/map-context-data.js';
// Grounded models occupy measured empty volumes, never guessed roof points.
export function emptyPlacements38(map,heightAt,root){
 const visual=visualOccupancy38(root,map),s=map.playerScale||1,reserved=[],obstacles=[],layout=districts[map.id],plan=mapContextPlan(map.id);
 const add=(footprint,bottom,top)=>{if(!footprint?.length)return;obstacles.push({minX:Math.min(...footprint.map(p=>p[0])),maxX:Math.max(...footprint.map(p=>p[0])),minZ:Math.min(...footprint.map(p=>p[1])),maxZ:Math.max(...footprint.map(p=>p[1])),bottom,top});};
 for(const q of layout?.buildings||[])add(q.footprint,-Infinity,heightAt(q.x,q.z)+q.h+2*s);
 for(const q of plan?.rooms||[])add(q.footprint,q.bottom??-Infinity,q.top);
 if(map.id==='dust2'){for(const q of dust.perimeterRooms)add(q.footprint,-Infinity,q.sourceMaxY);for(const q of dust.sourcePlinths)add(q.footprint,-Infinity,q.top);}
 let tested=0,rejected=0;
 function clear(x,z,r,y,h){tested++;if(visual.blocked(x,z,r,y-4*s,y+h)||obstacles.some(o=>y+h>o.bottom&&y<o.top+.15*s&&x+r>o.minX&&x-r<o.maxX&&z+r>o.minZ&&z-r<o.maxZ)||reserved.some(q=>Math.hypot(q.x-x,q.z-z)<q.r+r+.4*s)){rejected++;return false;}
  const point=(a,b,c)=>({x:a+map.width/2,y:b,z:c+map.height/2}),bottom=y+.12*s,top=y+h;
  for(const dx of[-r,0,r])for(const dz of[-r,0,r])if(collisionBlocks(map,point(x+dx,bottom,z+dz),point(x+dx,top,z+dz))){rejected++;return false;}
  for(const level of[.25,.5,.85]){const yy=bottom+(top-bottom)*level;for(const [dx,dz]of[[r,0],[0,r],[r*.707,r*.707],[r*.707,-r*.707]])if(collisionBlocks(map,point(x-dx,yy,z-dz),point(x+dx,yy,z+dz))){rejected++;return false;}}
  return true;
 }
 function find(x,z,r,h,label){const candidates=[];for(let ring=0;ring<9;ring++){const n=ring?ring*8:1;for(let j=0;j<n;j++){const angle=j/n*Math.PI*2;candidates.push({x:x+Math.cos(angle)*ring*3*s,z:z+Math.sin(angle)*ring*3*s});}}for(const q of candidates){if(Math.abs(q.x)-r<map.width/2+1.5*s&&Math.abs(q.z)-r<map.height/2+1.5*s)continue;const values=[];for(const dx of[-r,0,r])for(const dz of[-r,0,r])values.push(heightAt(q.x+dx,q.z+dz));if(!values.every(Number.isFinite)||Math.max(...values)-Math.min(...values)>3*s)continue;const bottom=Math.min(...values)-.55*s,y=Math.max(...values)+.10*s;if(!clear(q.x,q.z,r,y,h))continue;const out={...q,r,bottom,top:y,y,height:h,label,radius:r,nx:0,ny:1,nz:0};reserved.push(out);return out;}return null;}
 const towers=[],kits=[],terminals=[],people=[];
 for(let side=0;side<4;side++)for(let j=0;j<3;j++){const r=(4.2+j*.3)*s,x=side%2?(j-1)*.29*map.width:(side===0?1:-1)*(map.width/2+10*s),z=side%2?(side===1?1:-1)*(map.height/2+10*s):(j-1)*.29*map.height,h=(24+(side+j)%4*4)*s,q=find(x,z,r*1.20,h+4*s,'tower');if(q)towers.push({...q,r});}
 for(const [list,count,r,h,label]of[[kits,16,2.3*s,7.8*s,'service'],[terminals,6,1.9*s,9*s,'terminal'],[people,4,2.6*s,13*s,'hologram']])for(let i=0;i<count;i++){const angle=(i+.4)*Math.PI*2/count,x=Math.cos(angle)*(map.width/2+7*s),z=Math.sin(angle)*(map.height/2+7*s),q=find(x,z,r,h,label);if(q)list.push(q);}
 return{towers,kits,terminals,people,reserved,obstacles,tested,rejected,visualCells:visual.cells,visualTriangles:visual.triangles,clear};
}
