import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

function bones35(){const bones=[],ids={};function bone(name,parent,x,y,z){const b=new T.Bone();b.name=name;b.position.set(x,y,z);ids[name]=bones.length;bones.push(b);if(parent)bones[ids[parent]].add(b);return b;}bone('root',null,0,0,0);bone('hips','root',0,.95,0);bone('spine','hips',0,.22,0);bone('chest','spine',0,.30,0);bone('neck','chest',0,.22,0);bone('head','neck',0,.12,0);for(const [side,sign] of[['L',1],['R',-1]]){bone(side+'Shoulder','chest',sign*.28,.10,0);bone(side+'Elbow',side+'Shoulder',sign*.17,-.32,0);bone(side+'Hand',side+'Elbow',sign*.05,-.30,.02);bone(side+'Hip','hips',sign*.14,-.05,0);bone(side+'Knee',side+'Hip',sign*.02,-.43,.025);bone(side+'Ankle',side+'Knee',-sign*.015,-.42,-.02);}bones[0].updateMatrixWorld(true);return{bones,ids};}

export function humanGeometry35(){
 const {bones,ids}=bones35(),parts=[],q=new T.Quaternion(),up=new T.Vector3(0,1,0),v=new T.Vector3();
 function add(geo,name,position=[0,0,0],scale=[1,1,1],rotation=null){const matrix=new T.Matrix4().compose(new T.Vector3(...position),rotation||new T.Quaternion(),new T.Vector3(...scale));geo.applyMatrix4(matrix).applyMatrix4(bones[ids[name]].matrixWorld);if(geo.index){const next=geo.toNonIndexed();geo.dispose();geo=next;}const n=geo.attributes.position.count,index=new Uint16Array(n*4),weight=new Float32Array(n*4);for(let i=0;i<n;i++){index[i*4]=ids[name];weight[i*4]=1;}geo.setAttribute('skinIndex',new T.Uint16BufferAttribute(index,4));geo.setAttribute('skinWeight',new T.Float32BufferAttribute(weight,4));parts.push(geo);}
 function link(parent,child,r){const delta=bones[ids[child]].position,length=delta.length();q.setFromUnitVectors(up,v.copy(delta).normalize());add(new T.CapsuleGeometry(r,Math.max(.001,length-r*2),3,8),parent,delta.clone().multiplyScalar(.5).toArray(),[1,1,1],q.clone());}
 add(new T.LatheGeometry([new T.Vector2(.15,-.1),new T.Vector2(.19,0),new T.Vector2(.25,.16),new T.Vector2(.29,.31),new T.Vector2(.22,.38)],12),'spine',[0,0,0],[1,1,.69]);
 add(new T.SphereGeometry(.22,12,8),'hips',[0,-.015,0],[1,.62,.70]);add(new T.CylinderGeometry(.078,.09,.15,10),'neck',[0,-.04,0]);
 add(new T.SphereGeometry(.17,16,12),'head',[0,0,0],[.88,1.08,.92]);add(new T.SphereGeometry(.116,10,8),'head',[0,-.065,.035],[.9,.72,1]);add(new T.ConeGeometry(.033,.085,6),'head',[0,-.005,.16],[1,1,1],new T.Quaternion().setFromAxisAngle(new T.Vector3(1,0,0),Math.PI/2));
 add(new T.SphereGeometry(.177,14,8,0,Math.PI*2,0,Math.PI*.49),'head',[0,.012,-.009],[.94,1.06,1]);
 for(const [side,sign] of[['L',1],['R',-1]]){link(side+'Shoulder',side+'Elbow',.087);link(side+'Elbow',side+'Hand',.061);link(side+'Hip',side+'Knee',.112);link(side+'Knee',side+'Ankle',.075);add(new T.SphereGeometry(.095,10,8),side+'Shoulder');add(new T.SphereGeometry(.065,8,6),side+'Elbow');add(new T.SphereGeometry(.06,8,6),side+'Hand',[0,-.035,.005],[.75,1.15,.6]);for(let j=0;j<4;j++)add(new T.CapsuleGeometry(.009,.055,2,5),side+'Hand',[sign*(j-1.5)*.019,-.105,.008]);add(new T.SphereGeometry(.10,10,6),side+'Ankle',[0,-.015,.08],[.95,.55,1.65]);add(new T.SphereGeometry(.035,8,6),'head',[sign*.157,-.005,0],[.48,1,.7]);}
 const geometry=mergeGeometries(parts);parts.forEach(g=>g.dispose());geometry.computeBoundingSphere();return geometry;
}

export function holoBodyMaterial35(color,time,scale){return new T.ShaderMaterial({transparent:true,depthWrite:false,side:T.DoubleSide,blending:T.AdditiveBlending,toneMapped:false,uniforms:{holoTime:time,holoColor:{value:new T.Color(color)},holoScale:{value:scale}},vertexShader:`
 #include <common>
 #include <skinning_pars_vertex>
 varying vec3 vHoloWorld;varying vec3 vHoloNormal;
 void main(){
 #include <beginnormal_vertex>
 #include <skinbase_vertex>
 #include <skinnormal_vertex>
 #include <begin_vertex>
 #include <skinning_vertex>
 vec4 world=modelMatrix*vec4(transformed,1.);vHoloWorld=world.xyz;vHoloNormal=normalize(mat3(modelMatrix)*objectNormal);gl_Position=projectionMatrix*viewMatrix*world;
 }`,fragmentShader:`uniform float holoTime,holoScale;uniform vec3 holoColor;varying vec3 vHoloWorld,vHoloNormal;void main(){float rim=pow(1.-abs(dot(normalize(cameraPosition-vHoloWorld),normalize(vHoloNormal))),1.5);float scan=.62+.38*smoothstep(.25,.72,fract(vHoloWorld.y/max(.01,holoScale)*28.-holoTime*.7));float sweep=pow(max(0.,sin(vHoloWorld.y/max(.01,holoScale)*1.7-holoTime*1.2)),18.);gl_FragColor=vec4(holoColor*(.75+rim+sweep*.5),(.18+rim*.44+sweep*.13)*scan);}`});}

export function holoPerson35(geometry,material){const rig=bones35(),mesh=new T.SkinnedMesh(geometry,material);mesh.name='arena-3d-human-hologram';mesh.add(rig.bones[0]);mesh.bind(new T.Skeleton(rig.bones));mesh.frustumCulled=false;return{mesh,update(t,index,reduced=false){const phase=reduced?0:t*.7+index*1.7,b=n=>rig.bones[rig.ids[n]];b('hips').position.y=.95+(reduced?0:Math.sin(phase)*.017);b('spine').rotation.z=Math.sin(phase*.5)*.025;b('head').rotation.y=Math.sin(phase*.55)*.22;b('LShoulder').rotation.z=.95+Math.sin(phase)*.12;b('LElbow').rotation.z=1.25+Math.sin(phase*1.4)*.2;b('LHand').rotation.z=Math.sin(phase*2)*.2;b('RShoulder').rotation.x=-.12+Math.sin(phase+.5)*.08;b('RElbow').rotation.x=-.14;b('LKnee').rotation.x=Math.sin(phase)*.025;b('RKnee').rotation.x=-Math.sin(phase)*.025;mesh.updateMatrixWorld(true);},dispose(){mesh.skeleton.dispose();mesh.removeFromParent();}};}
