import maps from './approved/maps.json' with {type:'json'};
import originals from './map-assets.json' with {type:'json'};
import pbr from './approved/pbr128-manifest.json' with {type:'json'};
import masks from './approved/route-mask-manifest.json' with {type:'json'};
import structures from './approved/structure-manifest.json' with {type:'json'};
import palm from './approved/context-palm.json' with {type:'json'};
import shared from './shared-assets.json' with {type:'json'};
import {resolveApprovedEntry} from './approved/asset-cache.js';
function entries(value,out=[]){if(Array.isArray(value))for(const v of value)entries(v,out);else if(value&&typeof value==='object'){if(value.url&&value.sha256&&value.bytes)out.push(value);else for(const v of Object.values(value))entries(v,out);}return out;}
export function approvedAssets(id){
 const base=id==='ancient-night'?'ancient':id,values=entries([maps[id].visual,originals[base].mesh,originals[id].radar,masks[id],structures[id],pbr.maps[id]||[],id==='dust2'?palm:null]);
 values.push(...shared.filter(e=>e.url.endsWith('/'+id+'_lower.png')));
 return [...new Map(values.map(e=>[e.url+'#'+e.sha256,e])).values()];
}
export const approvedDownloadMaps=Object.keys(maps).map(id=>{const list=approvedAssets(id);return{id,entries:list,bytes:list.reduce((n,e)=>n+e.bytes,0)};});
export const approvedEntry=resolveApprovedEntry;
