import * as T from 'three';
const cache=new Map();
// Every attachment has an inscribed support circle on an actual flat triangle.
// Keep clear of walkable nav floors and plant zones; never synthesize a floor.
export function roofAnchors34(root,map){
 const key=map.id+':'+map.review?.visual?.sha256;if(cache.has(key))return cache.get(key);
 const s=map.playerScale||1,step=2*s,bins=new Map(),cells=new Map();
 for(const row of map.nav?.rows||[]){const q=row[3],flat=Array.isArray(row[1])?row[1]:[],xs=[],zs=[],ys=[];for(let i=0;i<flat.length;i+=3){xs.push(flat[i]);zs.push(flat[i+1]);ys.push(flat[i+2]);}if(!xs.length){xs.push(q[0]);zs.push(q[1]);ys.push(q[2]);}const area={minX:Math.min(...xs)-2.7*s,maxX:Math.max(...xs)+2.7*s,minZ:Math.min(...zs)-2.7*s,maxZ:Math.max(...zs)+2.7*s,minY:Math.min(...ys)-2.4*s,maxY:Math.max(...ys)+2.4*s};for(let x=Math.floor(area.minX/step);x<=Math.floor(area.maxX/step);x++)for(let z=Math.floor(area.minZ/step);z<=Math.floor(area.maxZ/step);z++){const k=x+','+z;if(!bins.has(k))bins.set(k,[]);bins.get(k).push(area);}}
 const a=new T.Vector3(),b=new T.Vector3(),c=new T.Vector3(),ab=new T.Vector3(),ac=new T.Vector3(),normal=new T.Vector3(),p=new T.Vector3();let examined=0;
 root.updateMatrixWorld(true);root.traverse(o=>{
  if(!o.isMesh||!o.visible||!o.geometry?.attributes.position)return;
  const mats=Array.isArray(o.material)?o.material:[o.material];if(mats.every(m=>!m.visible||m.transparent||m.alphaTest>0))return;
  const pos=o.geometry.attributes.position,index=o.geometry.index,n=index?.count||pos.count;
  for(let i=0;i<n;i+=3){examined++;a.fromBufferAttribute(pos,index?index.getX(i):i).applyMatrix4(o.matrixWorld);b.fromBufferAttribute(pos,index?index.getX(i+1):i+1).applyMatrix4(o.matrixWorld);c.fromBufferAttribute(pos,index?index.getX(i+2):i+2).applyMatrix4(o.matrixWorld);ab.subVectors(b,a);ac.subVectors(c,a);normal.crossVectors(ab,ac);const cross=normal.length();if(cross<.1*s*s||Math.abs(normal.y)/cross<.995)continue;
   const la=b.distanceTo(c),lb=a.distanceTo(c),lc=a.distanceTo(b),perimeter=la+lb+lc,radius=cross/perimeter;if(radius<.6*s)continue;p.copy(a).multiplyScalar(la).addScaledVector(b,lb).addScaledVector(c,lc).divideScalar(perimeter);
   if(p.y<1.5*s||Math.abs(p.x)>map.width/2+7*s||Math.abs(p.z)>map.height/2+7*s)continue;
   const x=p.x+map.width/2,z=p.z+map.height/2,bx=Math.floor(x/step),bz=Math.floor(z/step);let walkable=false;
   for(const area of bins.get(bx+','+bz)||[])if(x>=area.minX&&x<=area.maxX&&z>=area.minZ&&z<=area.maxZ&&p.y>=area.minY&&p.y<=area.maxY){walkable=true;break;}
   if(walkable||map.sites.some(q=>Math.hypot(q.x-x,q.z-z)<4*s))continue;
   const cell=Math.floor(p.x/(6*s))+','+Math.floor(p.z/(6*s)),old=cells.get(cell);if(old&&old.y>=p.y)continue;
   if(normal.y<0)normal.negate();normal.divideScalar(cross);cells.set(cell,{x:p.x,y:p.y,z:p.z,radius,nx:normal.x,ny:normal.y,nz:normal.z});
  }
 });
 const hash=q=>{let h=34;for(const c of map.id+':'+Math.round(q.x/s)+':'+Math.round(q.z/s))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;},candidates=[...cells.values()].sort((a,b)=>hash(a)-hash(b)),anchors=[];
 for(const q of candidates){if(anchors.every(a=>Math.hypot(q.x-a.x,q.z-a.z)>7*s))anchors.push(q);if(anchors.length>=32)break;}
 const result={anchors,candidates:cells.size,trianglesExamined:examined};cache.set(key,result);return result;
}
