import{streetInside38,streetCross38}from'./street-layout38.js';
// Runtime queries over Valve nav polygons. All coordinates are converted with
// one uniform scale; radar and collision geometry use the same transform.
const caches=new WeakMap(),cacheOrder=[];
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z,(a.y??0)-(b.y??0));
function runtime(map){
 const data=map.nav;if(caches.has(data))return caches.get(data);
 const bins=new Map(),areas=data.rows.map((row,index)=>{const [id,flat,links,c]=row,points=[];for(let i=0;i<flat.length;i+=3)points.push({x:flat[i],z:flat[i+1],y:flat[i+2]});return{id,index,points,links,center:{x:c[0],z:c[1],y:c[2]}};});
 for(const area of areas){const xs=area.points.map(p=>p.x),zs=area.points.map(p=>p.z);area.bounds=[Math.min(...xs)-.07,Math.min(...zs)-.07,Math.max(...xs)+.07,Math.max(...zs)+.07];for(let x=Math.floor(area.bounds[0]);x<=Math.floor(area.bounds[2]);x++)for(let z=Math.floor(area.bounds[1]);z<=Math.floor(area.bounds[3]);z++){const key=x+','+z;if(!bins.has(key))bins.set(key,[]);bins.get(key).push(area);}}
 const decoded=atob(data.visibility),visibility=Uint8Array.from(decoded,c=>c.charCodeAt(0)),value={areas,bins,visibility,stride:Math.ceil(areas.length/8),portals:new Map(),bridges:new Map()};
 if(map.street38?.length)for(const area of areas)area.links=area.links.filter(j=>{const g=portal(value,area.index,j),pad=.08*(map.playerScale||1);return g&&!streetCross38(map,area.center,g.from,pad)&&!streetCross38(map,g.from,g.to,pad)&&!streetCross38(map,g.to,areas[j].center,pad);});
 for(const area of areas)for(const j of area.links){const gate=portal(value,area.index,j);if(!gate||distance(gate.from,gate.to)<.02)continue;const [a,b]=[gate.from,gate.to],points=gate.points||[a,b],xs=points.map(p=>p.x),zs=points.map(p=>p.z);for(let x=Math.floor(Math.min(...xs)-.08);x<=Math.floor(Math.max(...xs)+.08);x++)for(let z=Math.floor(Math.min(...zs)-.08);z<=Math.floor(Math.max(...zs)+.08);z++){const key=x+','+z;if(!value.bridges.has(key))value.bridges.set(key,[]);value.bridges.get(key).push({a,b,points:gate.points,index:area.index,toIndex:j,center:{y:(a.y+b.y)/2}});}}
 const reverse=Array.from(value.areas,()=>[]);for(const a of value.areas)for(const j of a.links)reverse[j].push(a.index);value.reverse=reverse;value.reachable=new Map();
 caches.set(data,value);cacheOrder.push(data);while(cacheOrder.length>3)caches.delete(cacheOrder.shift());return value;
}
function floorIn(area,x,z,tolerance=.065){
 let sign=0;const points=area.points;for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length],cross=(b.x-a.x)*(z-a.z)-(b.z-a.z)*(x-a.x),length=Math.hypot(b.x-a.x,b.z-a.z);if(Math.abs(cross)<=tolerance*length)continue;const s=Math.sign(cross);if(sign&&sign!==s)return null;sign=s;}
 for(let i=1;i<points.length-1;i++){const a=points[0],b=points[i],c=points[i+1],den=(b.z-c.z)*(a.x-c.x)+(c.x-b.x)*(a.z-c.z);if(Math.abs(den)<1e-9)continue;const u=((b.z-c.z)*(x-c.x)+(c.x-b.x)*(z-c.z))/den,v=((c.z-a.z)*(x-c.x)+(a.x-c.x)*(z-c.z))/den,w=1-u-v;if(u>=-.3&&v>=-.3&&w>=-.3)return a.y*u+b.y*v+c.y*w;}
 return area.center.y;
}
export function navLocation(map,p,nearest=false,allowed=null){
 if(streetInside38(map,p,.06*(map.playerScale||1))){if(!nearest)return null;let best=null,score=Infinity;for(const area of runtime(map).areas){if(allowed&&!allowed[area.index]||streetInside38(map,area.center,.06*(map.playerScale||1)))continue;const d=distance(p,area.center);if(d<score){score=d;best={index:area.index,...area.center};}}return best;}
 const {areas,bins,bridges}=runtime(map),candidates=bins.get(Math.floor(p.x)+','+Math.floor(p.z))||[];let result=null,score=Infinity;const hint=Number.isFinite(p.y)?p.y:map.spawns[1].y;
 for(const area of candidates){if(allowed&&!allowed[area.index])continue;if(p.x<area.bounds[0]||p.x>area.bounds[2]||p.z<area.bounds[1]||p.z>area.bounds[3])continue;const y=floorIn(area,p.x,p.z);if(y===null)continue;const delta=Math.abs(y-hint);if(delta<score){score=delta;result={index:area.index,x:p.x,z:p.z,y};}}
 for(const bridge of bridges.get(Math.floor(p.x)+','+Math.floor(p.z))||[]){if(allowed&&!allowed[bridge.toIndex])continue;let y;if(bridge.points)y=floorIn(bridge,p.x,p.z);else{const q=closestOn(p,bridge.a,bridge.b);if(Math.hypot(q.x-p.x,q.z-p.z)>.08)continue;y=q.y;}if(y===null)continue;const delta=Math.abs(y-hint);if(delta<score){score=delta;result={index:bridge.index,x:p.x,z:p.z,y,bridge:{a:bridge.a,b:bridge.b}};}}
 if(result||!nearest)return result;
 for(const area of areas){const c=area.center,d=(c.x-p.x)**2+(c.z-p.z)**2+((Number.isFinite(p.y)?c.y-p.y:0)**2)*2;if(d<score){score=d;result={index:area.index,...c};}}return result;
}
export function navUseful(map,point){const r=runtime(map);if(!r.useful){r.useful=new Uint8Array(r.areas.length);const queue=[];for(const p of [...map.sites,...map.spawns]){const q=navLocation(map,p,true);if(q&&!r.useful[q.index]){r.useful[q.index]=1;queue.push(q.index);}}for(let i=0;i<queue.length;i++)for(const j of r.reverse[queue[i]])if(!r.useful[j]){r.useful[j]=1;queue.push(j);}}const q=navLocation(map,point);return !!(q&&r.useful[q.index]);}
export function navStepLocation(map,from,to,goal=null){
 if(streetCross38(map,from,to,.08*(map.playerScale||1)))return null;
 const end=navLocation(map,goal||from,true);if(!end)return null;const r=runtime(map);let allowed=r.reachable.get(end.index);
 if(!allowed){allowed=new Uint8Array(r.areas.length);allowed[end.index]=1;const queue=[end.index];for(let i=0;i<queue.length;i++)for(const j of r.reverse[queue[i]])if(!allowed[j]){allowed[j]=1;queue.push(j);}r.reachable.set(end.index,allowed);if(r.reachable.size>16)r.reachable.delete(r.reachable.keys().next().value);}
 return navLocation(map,to,false,allowed);
}
export function navHeight(map,x,z,hint){return navLocation(map,{x,z,y:hint},true)?.y??0;}
export function navBlocked(map,x,z,y){return !navLocation(map,{x,z,y});}
export function navVisible(map,a,b){if(map.nav.authoredVisibility)return true;const ra=navLocation(map,a,true),rb=navLocation(map,b,true);if(!ra||!rb)return false;const r=runtime(map);return !!(r.visibility[ra.index*r.stride+(rb.index>>3)]&(1<<(rb.index&7)));}
function segmentInterval(points,a,b){
 if(points.length<3)return null;let orientation=0;for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length];orientation+=p.x*q.z-q.x*p.z;}if(Math.abs(orientation)<1e-7)return null;orientation=Math.sign(orientation);let lo=0,hi=1;
 for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length],dx=q.x-p.x,dz=q.z-p.z,base=orientation*(dx*(a.z-p.z)-dz*(a.x-p.x))+.060*Math.hypot(dx,dz),slope=orientation*(dx*(b.z-a.z)-dz*(b.x-a.x));if(Math.abs(slope)<1e-10){if(base<0)return null;}else if(slope>0)lo=Math.max(lo,-base/slope);else hi=Math.min(hi,-base/slope);if(lo>hi)return null;}
 return [lo,hi];
}
export function navWalkLine(map,a,b){
 if(streetCross38(map,a,b,.08*(map.playerScale||1)))return false;
 const start=navLocation(map,a),end=navLocation(map,b);if(!start||!end)return false;const r=runtime(map),length=Math.hypot(b.x-a.x,b.z-a.z),steps=Math.max(1,Math.ceil(length/.4)),candidates=new Set(),bridges=new Map();
 for(let i=0;i<=steps;i++){const t=i/steps,x=Math.floor(a.x+(b.x-a.x)*t),z=Math.floor(a.z+(b.z-a.z)*t);for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++){const key=(x+dx)+','+(z+dz);for(const area of r.bins.get(key)||[])candidates.add(area);for(const bridge of r.bridges.get(key)||[])bridges.set(bridge.index+':'+bridge.a.x+':'+bridge.a.z+':'+bridge.b.x+':'+bridge.b.z,bridge);}}
 const intervals=[];const add=(points,center)=>{const interval=segmentInterval(points,a,b);if(!interval)return;const t=(interval[0]+interval[1])/2,y=start.y+(end.y-start.y)*t,sample=floorIn({points,center},a.x+(b.x-a.x)*t,a.z+(b.z-a.z)*t),floor=Number.isFinite(sample)?sample:center.y;if(Math.abs(floor-y)>.42)return;intervals.push(interval);};
 for(const area of candidates)add(area.points,area.center);
 for(const bridge of bridges.values()){if(bridge.points)add(bridge.points,bridge.center);else{const dx=bridge.b.x-bridge.a.x,dz=bridge.b.z-bridge.a.z,len=Math.hypot(dx,dz)||1,nx=-dz/len*.075,nz=dx/len*.075;add([{x:bridge.a.x+nx,z:bridge.a.z+nz},{x:bridge.a.x-nx,z:bridge.a.z-nz},{x:bridge.b.x-nx,z:bridge.b.z-nz},{x:bridge.b.x+nx,z:bridge.b.z+nz}],bridge.center);}}
 intervals.sort((p,q)=>p[0]-q[0]);let until=0;for(const [lo,hi]of intervals){if(lo>until+1e-6)return false;until=Math.max(until,hi);if(until>=1-1e-6)return true;}return false;
}
class Heap{items=[];push(id,cost){const a=this.items;let i=a.length;a.push({id,cost});while(i){const p=(i-1)>>1;if(a[p].cost<=cost)break;a[i]=a[p];i=p;}a[i]={id,cost};}pop(){const a=this.items,top=a[0],last=a.pop();if(a.length){let i=0;while(i*2+1<a.length){let child=i*2+1;if(child+1<a.length&&a[child+1].cost<a[child].cost)child++;if(a[child].cost>=last.cost)break;a[i]=a[child];i=child;}a[i]=last;}return top.id;}get length(){return this.items.length;}}
function closestOn(p,a,b){const dx=b.x-a.x,dz=b.z-a.z,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.z-a.z)*dz)/(dx*dx+dz*dz||1)));return{x:a.x+dx*t,z:a.z+dz*t,y:a.y+(b.y-a.y)*t};}
function portal(r,i,j){
 const key=i+':'+j;if(r.portals.has(key))return r.portals.get(key);const a=r.areas[i],b=r.areas[j];let best=null,score=Infinity;
 const offer=(p,q,prefer=0,points=null)=>{const s=Math.hypot(p.x-q.x,p.z-q.z)+Math.abs(p.y-q.y)*.05+prefer;if(s<score){score=s;if(points){let area=0;for(let k=0;k<points.length;k++){const a=points[k],b=points[(k+1)%points.length];area+=a.x*b.z-b.x*a.z;}if(Math.abs(area)<1e-7)points=null;}best={from:p,to:q,points};}};
 for(let k=0;k<a.points.length;k++)for(let l=0;l<b.points.length;l++){
  const x=a.points[k],xx=a.points[(k+1)%a.points.length],y=b.points[l],yy=b.points[(l+1)%b.points.length],dx=xx.x-x.x,dz=xx.z-x.z,len=Math.hypot(dx,dz),ex=yy.x-y.x,ez=yy.z-y.z;
  if(len&&Math.abs(dx*ez-dz*ex)<.015*len*Math.hypot(ex,ez)){
   const ux=dx/len,uz=dz/len,p=(y.x-x.x)*ux+(y.z-x.z)*uz,q=(yy.x-x.x)*ux+(yy.z-x.z)*uz,lo=Math.max(0,Math.min(p,q)),hi=Math.min(len,Math.max(p,q));
   if(hi>lo){const at=t=>({x:x.x+ux*t,z:x.z+uz*t,y:x.y+(xx.y-x.y)*t/len}),point=at((lo+hi)/2),a0=at(lo),a1=at(hi);offer(point,closestOn(point,y,yy),-.0001,[a0,a1,closestOn(a1,y,yy),closestOn(a0,y,yy)]);}
  }
  for(const [p,q]of[[x,closestOn(x,y,yy)],[xx,closestOn(xx,y,yy)],[closestOn(y,x,xx),y],[closestOn(yy,x,xx),yy]])offer(p,q);
 }
 r.portals.set(key,best);return best;
}
export function navPath(map,a,b,smooth=true,penalty=null){
 const start=navLocation(map,a,true),end=navLocation(map,b,true);if(!start||!end)return[];if(start.index===end.index&&Math.abs(start.y-end.y)<.35)return[{x:end.x,z:end.z,y:end.y}];
 if(start.bridge){const points=[start.bridge.a,start.bridge.b].filter(q=>{const loc=navLocation(map,q);return loc&&!loc.bridge&&navWalkLine(map,start,loc);}).sort((p,q)=>distance(start,p)-distance(start,q));if(points[0]){const q=navLocation(map,points[0]);return[{x:q.x,y:q.y,z:q.z},...navPath(map,q,b,smooth,penalty)];}}
 const r=runtime(map),n=r.areas.length,cost=new Float64Array(n).fill(Infinity),came=new Int32Array(n).fill(-1),done=new Uint8Array(n),heap=new Heap();cost[start.index]=0;heap.push(start.index,0);
 while(heap.length){const i=heap.pop();if(done[i])continue;done[i]=1;if(i===end.index)break;for(const j of r.areas[i].links){if(done[j])continue;const next=cost[i]+distance(r.areas[i].center,r.areas[j].center)*(1+(penalty?Math.max(0,penalty(r.areas[j].center,j)):0));if(next<cost[j]){cost[j]=next;came[j]=i;heap.push(j,next+distance(r.areas[j].center,r.areas[end.index].center));}}}
 if(!done[end.index])return[];const route=[end.index];while(route[0]!==start.index){route.unshift(came[route[0]]);if(route[0]<0)return[];}
 const points=[];for(let k=1;k<route.length;k++){const gate=portal(r,route[k-1],route[k]);if(gate)points.push(gate.from,gate.to);points.push(r.areas[route[k]].center);}points.push({x:end.x,z:end.z,y:end.y});
 const result=[];for(const point of points){const previous=result.at(-1)||start;if(distance(previous,point)>.008)result.push({...point});if(result.length>=95)break;}if(!smooth)return result;
 // Short, almost level shortcuts only. Keep portal points for stairs, jumps and
 // stacked floors; long greedy shortcuts used to select a different floor.
 const reduced=[];let origin=start,i=0;
 while(i<result.length){let best=i;
  for(let j=Math.min(result.length-1,i+7);j>i;j--){const q=result[j];if(distance(origin,q)>3||Math.abs(origin.y-q.y)>.22)continue;
   // Portal-to-portal shortcuts repeat across C4 destinations and agents.
   // Cache only immutable nav geometry queries, never player/prop decisions.
   const valid=navShortcut36(map,origin,q);
   if(valid){best=j;break;}
  }
  origin=result[best];reduced.push(origin);i=best+1;
 }
 return reduced;
}

function navShortcut36(map,a,b){
 const r=runtime(map);r.shortcuts36??=new Map();
 const key=[a.x,a.y,a.z,b.x,b.y,b.z].join(',');
 if(r.shortcuts36.has(key))return r.shortcuts36.get(key);
 const length=distance(a,b),steps=Math.max(1,Math.ceil(length/.1));let valid=navWalkLine(map,a,b);
 for(let k=1;valid&&k<=steps;k++){const t=k/steps,expected=a.y+(b.y-a.y)*t,location=navLocation(map,{x:a.x+(b.x-a.x)*t,z:a.z+(b.z-a.z)*t,y:expected});if(!location||Math.abs(location.y-expected)>.18){valid=false;break;}}
 r.shortcuts36.set(key,valid);if(r.shortcuts36.size>8192)r.shortcuts36.delete(r.shortcuts36.keys().next().value);return valid;
}
