import{streetCollision38}from'./street-layout38.js';
import {gunzipSync} from 'three/addons/libs/fflate.module.js';
import {registerCollision,hasPreparedCollision} from './world-collision.js';
import {loadAsset} from './approved/asset-cache.js';
const decoded=new Map();
function register(map,data){const geometry=streetCollision38(map,data),out=registerCollision(map,geometry.positions,geometry.indices,{replace:true});out.decorOwner={version:14,sha256:map.assets.collision.sha256};return true;}
export function ensureApprovedCollision(map){
 if(hasPreparedCollision(map,14,map.assets.collision.sha256))return true;
 const data=decoded.get(map.assets.collision.sha256);return data?register(map,data):false;
}
export async function prepareApprovedCollision(map,signal,{load=loadAsset}={}){
 if(ensureApprovedCollision(map))return;
 const entry=map.assets.collision,{bytes}=await load(entry,{signal});
 if(signal?.aborted)throw new DOMException('Aborted','AbortError');
 const raw=gunzipSync(new Uint8Array(bytes)),view=new DataView(raw.buffer,raw.byteOffset,raw.byteLength);
 const n=view.getUint32(4,true),count=view.getUint32(8,true);
 if(String.fromCharCode(...raw.subarray(0,4))!=='ACM1'||raw.byteLength!==12+n*12+count*12)throw Error('Asl xarita to‘qnashuv geometriyasi mos emas.');
 if(hasPreparedCollision(map,14,entry.sha256))return;
 const data={positions:new Float32Array(raw.buffer.slice(raw.byteOffset+12,raw.byteOffset+12+n*12)),indices:new Uint32Array(raw.buffer.slice(raw.byteOffset+12+n*12))};
 decoded.set(entry.sha256,data);while(decoded.size>2)decoded.delete(decoded.keys().next().value);
 register(map,data);
}
