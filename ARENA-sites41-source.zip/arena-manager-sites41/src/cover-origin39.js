export const COVER39_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/a396b2f8aca9a467bcc2bc93e623f42fba01a67c/covers39/";
