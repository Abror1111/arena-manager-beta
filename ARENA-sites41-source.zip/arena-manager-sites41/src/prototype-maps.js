// Hand-authored, playable interpretations. These are not extracted Valve assets.
const block=(x,z,w,d,h=4,style='house')=>({x,z,w,d,h,style});
const site=(label,x,z)=>({label,x,z});
const area=(name,x,z)=>({name,x,z});
const themes={
 desert:{ground:'#cbbb96',roof:'#b9835c',wall:'#e6d1a5',style:'desert'},
 town:{ground:'#b9b2a0',roof:'#aa5945',wall:'#e1c99d',style:'town'},
 jungle:{ground:'#78876a',roof:'#78805c',wall:'#a1a283',style:'jungle'},
 industry:{ground:'#a1a8aa',roof:'#547c8c',wall:'#ccd4ce',style:'industry'},
 park:{ground:'#8c9981',roof:'#737f7c',wall:'#a9b5ae',style:'park'},
 warehouse:{ground:'#a9a89b',roof:'#718472',wall:'#c6c7b2',style:'warehouse'}
};
function map(id,name,theme,region,blocks,sites,spawns,areas,extra={}){return {id,name,...themes[theme],region,blocks,sites,spawns,areas,water:false,...extra};}
const b=block;
export const MAPS=[
 map('dust2','Sandrift','desert','LONG · MID · TUNNELS',[
  b(7,21,8,12,4),b(19,20,8,6,5),b(21,9,8,6,4),b(37,8,10,6,3),b(38,21,10,12,5),b(49,22,5,16,4),b(56,12,3,10,5),b(19,33,12,5,4),b(38,34,9,5,4),b(3,6,4,6,4),b(55,35,6,5,4),b(28,15,2,4,3),b(28,26,2,6,3),b(11,3,10,2,2.5),b(48,3,12,2,2.5)
 ],[site('A',49,9),site('B',11,9)],[{x:30,z:36},{x:31,z:4}],[area('LONG A',54,21),area('MID',31,20),area('TUNNELS',12,28),area('SHORT',42,14)],{terraces:[{x:47,z:8,w:17,d:12,h:1.5,ramp:5}],landmarks:[{type:'palm',x:4,z:20},{type:'dome',x:19,z:20},{type:'car',x:53,z:32}]}),
 map('mirage','Sunveil','desert','PALACE · CONNECTOR · APARTMENTS',[
  b(48,31,9,8,5),b(52,18,7,8,4),b(41,8,10,5,5),b(39,21,7,10,4),b(23,21,9,6,4),b(15,30,14,5,4),b(10,18,5,10,5),b(19,7,13,4,4),b(31,5,6,6,5),b(4,6,5,5,4),b(57,6,4,5,4),b(5,34,4,7,4),b(57,33,3,10,4),b(27,32,3,7,2),b(21,13,3,4,3)
 ],[site('A',44,15),site('B',14,12)],[{x:34,z:36},{x:30,z:10}],[area('PALACE',47,26),area('MID',31,20),area('CONNECTOR',33,14),area('APARTMENTS',13,25)],{landmarks:[{type:'palm',x:52,z:18},{type:'dome',x:31,z:5},{type:'arch',x:31,z:14}]}),
 map('inferno','Ember Quarter','town','BANANA · MID · APARTMENTS',[
  b(7,22,8,13,5),b(18,20,7,6,5),b(21,9,7,8,4),b(31,8,7,8,5),b(40,23,8,10,5),b(50,29,7,7,4),b(53,17,8,6,5),b(22,32,10,7,5),b(39,35,7,4,4),b(7,4,8,4,4),b(56,5,4,6,5),b(29,22,3,5,3),b(48,4,6,3,5),b(4,36,4,5,4),b(14,11,2,4,2)
 ],[site('A',47,11),site('B',11,10)],[{x:30,z:37},{x:40,z:4}],[area('BANANA',13,24),area('MID',30,27),area('APARTMENTS',44,26),area('ARCH',37,14)],{landmarks:[{type:'fountain',x:11,z:10},{type:'bell',x:31,z:8},{type:'car',x:53,z:30}],terraces:[{x:12,z:9,w:20,d:16,h:1,ramp:5}]}),
 map('nuke','Reactor','industry','YARD · RAMP · REACTORS',[
  b(9,9,12,8,7,'factory'),b(29,10,12,7,7,'factory'),b(47,6,17,5,5,'factory'),b(20,21,7,10,6,'factory'),b(40,20,8,10,5,'factory'),b(48,32,13,6,4,'container'),b(9,30,10,7,4,'factory'),b(29,31,8,6,5,'factory'),b(56,20,4,12,5,'factory'),b(5,20,4,5,4,'tank'),b(51,16,3,4,4,'container'),b(56,35,3,4,3,'container')
 ],[site('A',29,20),site('B',48,23)],[{x:23,z:37},{x:21,z:4}],[area('YARD',12,20),area('A · UPPER',29,16),area('B · CUTAWAY',48,26),area('RAMP',44,14)],{terraces:[{x:29,z:19,w:17,d:14,h:2.2,ramp:6}],landmarks:[{type:'reactor',x:29,z:20},{type:'reactor',x:48,z:23},{type:'stack',x:9,z:9}]}),
 map('train','Railworks','industry','A YARD · IVY · B HALL',[
  b(5,20,6,22,6,'factory'),b(24,7,21,5,5,'factory'),b(52,9,9,8,5,'factory'),b(38,31,22,6,5,'factory'),b(14,30,8,5,5,'factory'),b(57,29,3,16,5,'factory'),b(20,19,3,13,2.4,'train'),b(28,21,3,12,2.5,'train'),b(37,18,3,12,2.4,'train'),b(47,22,3,12,2.5,'train'),b(15,5,4,4,4,'factory'),b(18,36,7,3,4,'factory')
 ],[site('A',33,11),site('B',51,32)],[{x:10,z:36},{x:40,z:4}],[area('A YARD',32,15),area('IVY',52,18),area('B HALL',45,34),area('LADDER',14,22)],{landmarks:[{type:'gantry',x:32,z:7},{type:'stack',x:5,z:20}]}),
 map('ancient','Relic Grove','jungle','TEMPLE · DONUT · CAVE',[
  b(6,19,8,14,4,'temple'),b(18,10,8,6,5,'temple'),b(31,8,8,6,6,'temple'),b(40,21,9,8,4,'temple'),b(20,23,7,8,4,'temple'),b(24,34,12,4,4,'temple'),b(51,11,9,5,4,'temple'),b(52,32,9,5,4,'temple'),b(57,23,3,9,3,'temple'),b(7,4,9,4,4,'temple'),b(35,32,3,7,3,'temple'),b(29,20,3,4,3,'temple'),b(45,4,8,3,3,'temple')
 ],[site('A',12,11),site('B',48,24)],[{x:13,z:35},{x:41,z:8}],[area('DONUT',23,15),area('MID',30,26),area('CAVE',43,30),area('TEMPLE',12,5)],{terraces:[{x:12,z:10,w:18,d:14,h:1.6,ramp:6},{x:48,z:24,w:17,d:16,h:1,ramp:6}],landmarks:[{type:'tree',x:6,z:19},{type:'temple',x:31,z:8},{type:'tree',x:52,z:32}]}),
 // The night edition intentionally shares Ancient's actual layout, not a fake new layout.
 null,
 map('anubis','Sunken Court','desert','CANAL · BRIDGE · TEMPLE',[
  b(6,20,8,14,4,'temple'),b(18,11,8,5,5,'temple'),b(20,25,8,7,4,'temple'),b(31,7,9,5,5,'temple'),b(41,11,7,5,4,'temple'),b(42,27,9,7,5,'temple'),b(54,22,5,14,5,'temple'),b(14,34,9,4,4,'temple'),b(30,34,7,5,4,'temple'),b(53,5,8,4,5,'temple'),b(5,5,6,6,4,'temple'),b(31,22,3,5,2,'temple')
 ],[site('A',48,18),site('B',13,17)],[{x:40,z:36},{x:31,z:13}],[area('CANAL',30,29),area('BRIDGE',31,18),area('TEMPLE',47,7),area('MID',29,15)],{terraces:[{x:31,z:16,w:19,d:18,h:1.8,ramp:7}],water:true,landmarks:[{type:'obelisk',x:31,z:7},{type:'palm',x:6,z:20},{type:'canal',x:30,z:29}]}),
 map('overpass','Canal Crossing','park','FOUNTAIN · CONNECTOR · WATER',[
  b(7,11,10,10,5),b(21,9,8,5,4),b(21,23,8,7,5),b(37,10,9,7,4),b(38,25,8,7,5),b(53,8,8,8,5),b(55,25,4,10,5),b(11,33,12,4,4),b(29,34,8,4,4),b(46,35,11,3,4),b(6,23,3,7,3),b(29,20,3,5,3)
 ],[site('A',13,22),site('B',47,26)],[{x:19,z:37},{x:32,z:4}],[area('PARK',14,16),area('CONNECTOR',31,20),area('WATER',48,19),area('MONSTER',48,31)],{terraces:[{x:15,z:15,w:29,d:28,h:2.8,ramp:9}],landmarks:[{type:'fountain',x:14,z:16},{type:'tree',x:7,z:11},{type:'bridge',x:47,z:26}]}),
 map('vertigo','Skyline','industry','A RAMP · MID · SCAFFOLD',[
  b(7,20,8,16,5,'concrete'),b(23,10,10,6,4,'concrete'),b(24,25,8,7,4,'concrete'),b(40,10,10,6,4,'concrete'),b(41,27,8,7,3,'concrete'),b(54,21,4,12,4,'concrete'),b(12,5,8,3,3,'concrete'),b(15,34,10,5,4,'concrete'),b(37,36,15,3,4,'concrete'),b(30,18,3,4,3,'container'),b(51,5,7,4,4,'concrete')
 ],[site('A',46,18),site('B',15,16)],[{x:25,z:37},{x:33,z:5}],[area('A RAMP',47,28),area('MID',32,24),area('SCAFFOLD',49,13),area('B STAIRS',14,26)],{terraces:[{x:44,z:16,w:25,d:26,h:2.5,ramp:9},{x:15,z:14,w:21,d:19,h:1.6,ramp:7}],landmarks:[{type:'crane',x:41,z:27},{type:'scaffold',x:7,z:20}]}),
 map('cache','Iron Depot','warehouse','A MAIN · MID · CHECKERS',[
  b(6,18,7,14,5,'factory'),b(20,9,10,6,5,'factory'),b(20,25,8,8,4,'factory'),b(40,8,12,5,5,'factory'),b(40,22,8,8,5,'factory'),b(53,13,7,7,5,'factory'),b(51,32,9,5,5,'factory'),b(16,35,9,4,5,'factory'),b(31,33,6,6,4,'factory'),b(31,18,3,5,2,'container'),b(57,24,3,8,4,'factory'),b(6,5,6,4,4,'factory')
 ],[site('A',14,16),site('B',49,24)],[{x:26,z:37},{x:31,z:5}],[area('A MAIN',13,26),area('MID',31,25),area('CHECKERS',47,16),area('GARAGE',26,30)],{landmarks:[{type:'gantry',x:20,z:9},{type:'vent',x:40,z:22},{type:'car',x:51,z:32}]})
];
MAPS[6]={...MAPS[5],id:'ancient-night',name:'Relic Afterdark',region:'RELIC GROVE · TUNGI MUHIT',night:true,ground:'#586b61',roof:'#5c6c5c'};
export const LEGACY_MAPS=[{id:'courtyard',name:'Dust Courtyard · 1.02',ground:'#c7b18a',roof:'#c48b68',wall:'#e7d6b1'},{id:'ruins',name:'Ancient Garden · 1.02',ground:'#84907b',roof:'#67796a',wall:'#a7ac88'},{id:'harbor',name:'Harbor District · 1.02',ground:'#75828a',roof:'#41798b',wall:'#a9bac2',water:true}];
export const ALL_MAPS=[...MAPS,...LEGACY_MAPS];
export const mapMeta=id=>ALL_MAPS.find(m=>m.id===id)||MAPS[0];
export const modernMapId=id=>({courtyard:'dust2',ruins:'ancient',harbor:'train'}[id]||id);
export function makeMap(id='dust2'){
 const theme=mapMeta(id);if(theme.blocks)return structuredClone(theme);
 const blocks=[b(29,20,10,6,4),b(13,20,13,4,5),b(31,7,13,6,4),b(47,18,12,4,4),b(32,33,12,6,3.4),b(5,8,4,10,3),b(57,33,4,10,3)];
 if(id==='ruins'){blocks[0]=b(28,20,6,10,5);blocks.push(b(20,30,4,4,3));}if(id==='harbor'){blocks[1]=b(14,20,14,4,3);blocks.push(b(43,8,3,8,3));}
 return {...theme,legacy:true,blocks,sites:[site('A',13,8),site('B',47,30)],spawns:[{x:8,z:33},{x:51,z:7}],areas:[],landmarks:[]};
}
export function heightAt(map,x,z){
 if(map.legacy)return map.id==='ruins'?Math.max(0,1-Math.abs(x-47)/6)*Math.max(0,1-Math.abs(z-30)/8)*1.6:0;
 let h=0;for(const t of map.terraces||[]){const dx=Math.max(0,Math.abs(x-t.x)-(t.w/2-t.ramp)),dz=Math.max(0,Math.abs(z-t.z)-(t.d/2-t.ramp));h=Math.max(h,t.h*Math.max(0,1-Math.max(dx,dz)/t.ramp));}return h;
}
