import * as T from 'three';
import {finishExteriorMaterial}from'./facade-finish.js';
// The backdrop is a connected, grounded district, not isolated props at far
// anchors. Its complete solids are batched and cached with the source city.
export function buildContextDistricts({b,plan,profile,ground,sourceByTexture,materials,ownedMaterials,textures}){
 const layout=plan.districts,kind=layout.kind,{box,tube,quad,tri,lathe,arch}=b;let details=0,baseMaxGap=-Infinity;const bindings=[];
 function source(key,pattern,fallback,finish='stone'){
  const entries=[...sourceByTexture.entries()].filter(([name])=>pattern.test(name)&&!/overlay|decal|prop|crate|barrel|door|sign|window|ceiling|trim|vent|ac_|dish|cluster/i.test(name));const m=entries[0]?.[1]?.clone()||materials.get(fallback).clone();m.vertexColors=false;m.clippingPlanes=[];m.clipShadows=false;m.side=T.DoubleSide;m.shadowSide=T.FrontSide;m.alphaTest=0;m.transparent=false;m.opacity=1;m.onBeforeCompile=()=>{};m.customProgramCacheKey=()=> 'district-'+key;for(const k of['map','normalMap','roughnessMap','metalnessMap','aoMap'])if(m[k]){const t=m[k].clone();t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(1,1);t.offset.set(0,0);t.rotation=0;t.needsUpdate=true;textures.add(t);m[k]=t;}finishExteriorMaterial(m,finish);m.name=key;materials.set(key,m);ownedMaterials.add(m);bindings.push(m.map?.name||fallback);return key;
 }
 source('district-wall',kind==='village'?/plaster.*(?:yellow|tan|wall)|stucco|brick_wall/i:kind==='medina'?/plaster|brick_ver|stone_wall/i:kind==='nile'||kind==='jungle'?/sandstone|stone_wall|ancient.*wall|block/i:/brick.*wall|concrete.*wall|brick.*color|siding/i,'wall');
 source('district-wall-alt',/brick.*color|plaster.*color|stone_wall/i,'wall');source('district-roof',kind==='village'?/shingles|terracotta/i:kind==='medina'||kind==='nile'||kind==='jungle'?/roof_stone|rooftop01|rooftop_01|concrete_roof/i:/roof_metal|corrugated.*roof|concrete_roof|shifer/i,'roof');source('district-stone',/stone.*wall|stone.*block|concrete.*wall|brick.*wall/i,'trim');source('district-road',/asphalt.*color|cobble.*color|pavement/i,'ballast');
 // Volumetric crowns are used where the supplied tree is a billboard.
 // Layered branch clusters stay three-dimensional in the steep observer view.
 let authoredTrees=0,treeTriangles=0;
 if(['village','campus','park','warehouse','rail'].includes(kind)){
  source('district-tree-bark',/bark|trunk/i,'wood','wood');
  for(const [key,mult]of[['district-leaf',1],['district-leaf-light',1.12]]){const m=new T.MeshStandardMaterial({color:new T.Color(profile.leaf).multiplyScalar(mult),roughness:.96,side:T.DoubleSide});finishExteriorMaterial(m,'canvas');m.name=key;materials.set(key,m);ownedMaterials.add(m);}
  const before=b.triangles;
  for(let i=0;i<layout.plants.length;i++){const[x,z,scale]=layout.plants[i],slender=(kind==='village'&&i%4!==0)||kind==='warehouse',base=ground.minimum([[x-.22,z-.22],[x+.22,z+.22]],.05),h=(slender?6.1:5.2)*scale;lathe('district-tree-bark',x,base,z,[[.18*scale,0],[.15*scale,h*.5],[.065*scale,h*.91],[0,h*.98]],9);
   const rings=slender?[[.23,.8],[.57,1.2],[.70,2.0],[.61,3.1],[.49,4.1],[.32,5.1],[.06,6.2],[0,6.35]]:[[.25,1.2],[1.20,1.7],[1.65,2.7],[1.60,3.6],[1.15,4.4],[.35,5.0],[0,5.15]];
   lathe('district-leaf',x,base,z,rings.map(([r,y])=>[r*scale,y*scale]),14);
   for(let j=0;j<9;j++){const angle=j*2.39996+i*.8,level=slender?1.6+j*.40:2.0+(j%3)*.78,radius=(slender?.42:1.0)*scale*(1-j*.035),xx=x+Math.cos(angle)*radius,zz=z+Math.sin(angle)*radius,r=(slender?.34:.74)*scale,yy=base+level*scale;lathe(j%3?'district-leaf':'district-leaf-light',xx,yy,zz,[[r*.45,0],[r,.20*scale],[r*.94,.55*scale],[r*.61,.92*scale],[0,1.1*scale]],8);}
   authoredTrees++;
  }
  treeTriangles=b.triangles-before;
 }
 function frame(x,z,angle){const c=Math.cos(angle),s=Math.sin(angle);return(a,y,d)=>[x+c*a+s*d,y,z-s*a+c*d];}
 function grounded(x,z,w,d,angle){const at=frame(x,z,angle),corners=[[-w/2-.35,-d/2-.35],[w/2+.35,-d/2-.35],[w/2+.35,d/2+.35],[-w/2-.35,d/2+.35]].map(([a,c])=>{const p=at(a,0,c);return[p[0],p[2]];}),bottom=ground.minimum(corners,.12),base=Math.max(...corners.map(p=>ground.height(...p)))+.06;for(const p of corners)baseMaxGap=Math.max(baseMaxGap,bottom-ground.height(...p));return{at,bottom,base,corners};}
 function local(at,key,x,y,z,w,h,d,angle){box(key,at(x,y,z),[w,h,d],angle);}
 function windows(at,w,d,base,h,angle,variant){for(let side=0;side<4;side++){
  const a=angle+side*Math.PI/2,width=side%2?d:w,depth=side%2?w:d,origin=at(Math.sin(side*Math.PI/2)*w/2,0,Math.cos(side*Math.PI/2)*d/2),f=frame(origin[0],origin[2],a),floors=Math.max(1,Math.floor(h/2.65));
  for(let row=0;row<floors;row++)for(let j=0;j<Math.max(2,Math.floor(width/1.7));j++){const count=Math.max(2,Math.floor(width/1.7)),x=-width/2+(j+.5)*width/count,y=base+1.6+row*2.65;if(y>base+h-.5)continue;local(f,'recess',x,y,.045,.62,.94,.055,a);local(f,kind==='skyline'?'glass':'accent',x,y,.08,.53,.80,.035,a);for(const s of[-1,1]){local(f,'trim',x+s*.36,y,.11,.075,1.1,.10,a);local(f,'trim',x,y+s*.52,.11,.85,.075,.16,a);}if(kind==='village'||kind==='medina'){for(const s of[-1,1]){local(f,'wood',x+s*.48,y,.15,.22,.95,.07,a);for(let k=0;k<6;k++)local(f,'accent',x+s*.48,y-.37+k*.145,.205,.19,.035,.025,a);}}details++;}
  for(const y of[base+.18,base+h-.16])local(f,'trim',0,y,.12,width,.13,.20,a);
  if((variant+side)%3===0&&h>5){const y=base+2.75;local(f,'trim',0,y,.34,1.8,.14,.78,a);for(let k=0;k<8;k++)local(f,'metal',-.78+k*.22,y+.40,.67,.025,.68,.025,a);local(f,'metal',0,y+.76,.67,1.9,.035,.035,a);}
 }}
 function tileRoof(at,w,d,y,angle){const rise=Math.min(1.45,d*.3);for(const sign of[-1,1]){quad('district-roof',at(-w/2-.2,y,sign*(d/2+.2)),at(w/2+.2,y,sign*(d/2+.2)),at(w/2+.2,y+rise,0),at(-w/2-.2,y+rise,0),.6);for(let x=-w/2;x<w/2;x+=.43)tube('district-roof',[at(x,y+.03,sign*(d/2+.2)),at(x,y+rise+.03,0)],.035,.035,5);}for(const sign of[-1,1])tri('district-wall',at(sign*w/2,y,-d/2),at(sign*w/2,y,d/2),at(sign*w/2,y+rise,0));tube('trim',[at(-w/2-.2,y+rise,0),at(w/2+.2,y+rise,0)],.07,.07,6);}
 for(const item of layout.buildings){const{x,z,w,d,angle,variant}=item;let h=item.h;const f=grounded(x,z,w,d,angle),{at,bottom}=f,base=kind==='skyline'?plan.sourceBounds[1]-.65:f.base,top=base+h;box('district-stone',at(0,(bottom+f.base+.2)/2,0),[w+.55,f.base+.2-bottom,d+.55],angle);box(variant%3?'district-wall':'district-wall-alt',at(0,base+h/2,0),[w,h,d],angle);
  if(kind==='skyline'){
   for(let y=base+2;y<top-.6;y+=3.0){for(const side of[-1,1]){local(at,'glass',0,y,side*(d/2+.035),w-.3,2.2,.055,angle);local(at,'metal',0,y+1.25,side*(d/2+.06),w,.13,.08,angle);local(at,'glass',side*(w/2+.035),y,0,.055,2.2,d-.3,angle);}for(let x=-w/2+.8;x<w/2;x+=1.45)for(const side of[-1,1])local(at,'trim',x,y,side*(d/2+.08),.055,2.4,.06,angle);}
   local(at,'district-roof',0,top+.1,0,w+.3,.3,d+.3,angle);local(at,'metal',0,top+.6,0,w*.45,1.1,d*.36,angle);continue;
  }
  if(kind==='village')tileRoof(at,w,d,top,angle);else{local(at,'district-roof',0,top+.10,0,w+.12,.20,d+.12,angle);for(const side of[-1,1]){local(at,'trim',0,top+.35,side*d/2,w,.52,.16,angle);local(at,'trim',side*w/2,top+.35,0,.16,.52,d,angle);}}
  if(kind==='jungle'||kind==='nile'){
   // Stepped cornices, carved recesses and fluted columns make complete ruins.
   for(let i=0;i<3;i++)local(at,'district-stone',0,top-.22+i*.20,0,w+.25+i*.22,.15,d+.25+i*.22,angle);
   for(let x=-w/2+.65;x<w/2;x+=1.7){const p=at(x,base,d/2+.40);lathe('district-stone',p[0],base,p[2],[[.43,0],[.43,.22],[.31,.32],[.25,h-.5],[.39,h-.35],[.44,h-.1],[0,h-.1]],12);for(let k=0;k<4;k++)local(at,'recess',x,base+1+k*.6,d/2+.06,.50,.30,.07,angle);details+=5;}
   for(let i=0;i<5;i++)local(at,'district-stone',0,base-.05+i*.13,d/2+.7-i*.13,w*.7-i*.15,.16,1.4-i*.18,angle);
  }else windows(at,w,d,base,h,angle,variant);
  if(kind==='medina'){
   const width=Math.min(w-1,4.8),a=frame(x,z,angle);for(let i=0;i<16;i++){const x0=-width/2+i*width/16,x1=x0+width/16;quad(i%2?'wood':'accent',a(x0,base+2.6,d/2+.12),a(x1,base+2.6,d/2+.12),a(x1,base+2.25,d/2+1.2),a(x0,base+2.25,d/2+1.2));}for(const xx of[-width/2,width/2])tube('wood',[a(xx,base,d/2+1.1),a(xx,base+2.3,d/2+1.1)],.045,.045,6);
  }
  if(kind==='campus'||kind==='warehouse'||kind==='rail'){
   const doorW=Math.min(3.1,w*.4);local(at,'recess',0,base+1.3,d/2+.04,doorW,2.6,.04,angle);for(let i=0;i<12;i++)local(at,'metal',0,base+.12+i*.21,d/2+.09,doorW-.08,.13,.045,angle);for(let k=0;k<2;k++){local(at,'metal',-w*.25+k*w*.5,top+.55,0,1.45,.90,1.3,angle);for(let j=0;j<6;j++)local(at,'recess',-w*.25+k*w*.5,top+.28+j*.1,.66,1.3,.035,.025,angle);}const x=w/2-.4;tube('metal',[at(x,base+.2,d/2+.25),at(x,top+.7,d/2+.25),at(x-1.2,top+.7,d/2+.25)],.075,.075,8);for(let j=0;j<Math.floor(h/.36);j++)tube('accent',[at(x-.18,base+.2+j*.36,d/2+.29),at(x+.18,base+.2+j*.36,d/2+.29)],.025,.025,5);details+=16;
   if(kind==='campus'&&variant%2===0){const p=at(-w/2-1.7,base,0),y=ground.minimum([[p[0]-1.12,p[2]-1.12],[p[0]+1.12,p[2]+1.12]],.05);lathe('metal',p[0],y-.15,p[2],[[0,0],[1.1,0],[1.1,.2],[.95,.35],[.95,4.8],[.7,5.3],[0,5.6]],20);for(const yy of[1.0,3.5,4.7])lathe('trim',p[0],y,p[2],[[.96,yy],[1.01,yy],[1.01,yy+.09],[.96,yy+.09]],20);tube('metal',[[p[0],y+4.5,p[2]],at(-w/2,base+4.5,0)],.13,.13,8);}
  }
 }
 // Irregular layered outcrops; no repeated cubes or floating rock plates.
 for(let i=0;i<layout.rocks.length;i++){const[x,z,r,angle]=layout.rocks[i],corners=Array.from({length:9},(_,k)=>[x+Math.cos(k/9*6.283)*r,z+Math.sin(k/9*6.283)*r]),base=ground.minimum(corners,.12),rings=[];for(let j=0;j<5;j++){const radius=[.78,1,.94,.64,.23][j],yy=[0,.35,.9,1.4,1.65][j]*r;const ring=[];for(let k=0;k<9;k++){const a=k/9*6.283+angle,rr=r*radius*(.86+.14*Math.sin(k*7+i*3+j*.4));ring.push([x+Math.cos(a)*rr,base+yy+.09*r*Math.sin(k*5+j+i),z+Math.sin(a)*rr]);}rings.push(ring);}for(let j=0;j<4;j++)for(let k=0;k<9;k++)quad(j>2&&kind==='jungle'?'vine':'district-stone',rings[j][k],rings[j][(k+1)%9],rings[j+1][(k+1)%9],rings[j+1][k]);for(let k=1;k<8;k++){tri('district-stone',rings[0][0],rings[0][k+1],rings[0][k]);tri('district-stone',rings[4][0],rings[4][k],rings[4][k+1]);}details+=5;}
 function inBuilding(x,z,pad){return layout.buildings.some(q=>{const c=Math.cos(q.angle),s=Math.sin(q.angle),dx=x-q.x,dz=z-q.z;return Math.abs(c*dx-s*dz)<q.w/2+pad&&Math.abs(s*dx+c*dz)<q.d/2+pad;});}
 function ribbon(a,c,width,key='district-road',rail=false){const L=Math.hypot(c[0]-a[0],c[1]-a[1]),n=[-(c[1]-a[1])/L,(c[0]-a[0])/L],steps=Math.ceil(L/1.8);for(let i=0;i<steps;i++){const t=i/steps,v=(i+1)/steps,p=[a[0]+(c[0]-a[0])*t,a[1]+(c[1]-a[1])*t],q=[a[0]+(c[0]-a[0])*v,a[1]+(c[1]-a[1])*v],mid=[(p[0]+q[0])/2,(p[1]+q[1])/2];if(inBuilding(...mid,width/2+.4))continue;const points=[p,q].map(p=>[-1,1].map(sign=>{const x=p[0]+n[0]*width/2*sign,z=p[1]+n[1]*width/2*sign;return[x,ground.height(x,z)+.035,z];}));quad(key,points[0][0],points[1][0],points[1][1],points[0][1],.35);if(rail){for(const sign of[-1,1]){const ends=[p,q].map(p=>{const x=p[0]+n[0]*.68*sign,z=p[1]+n[1]*.68*sign;return[x,ground.height(x,z)+.20,z];});tube('metal',ends,.055,.055,5);}for(let k=0;k<3;k++){const f=(i+(k+.5)/3)/steps,x=a[0]+(c[0]-a[0])*f,z=a[1]+(c[1]-a[1])*f;box('wood',[x,ground.height(x,z)+.10,z],[2.0,.11,.15],Math.atan2(-(c[1]-a[1]),c[0]-a[0])+Math.PI/2);}}else for(const sign of[-1,1]){const x=mid[0]+n[0]*width/2*sign,z=mid[1]+n[1]*width/2*sign;box('trim',[x,ground.height(x,z)+.09,z],[L/steps+.04,.16,.12],Math.atan2(-(q[1]-p[1]),q[0]-p[0]));}}}
 const q=layout.navBounds;
 if(kind!=='jungle'&&kind!=='nile'&&kind!=='skyline'){
  const corners=[[q[0]-13,q[1]-13],[q[2]+13,q[1]-13],[q[2]+13,q[3]+13],[q[0]-13,q[3]+13]];for(let i=0;i<4;i++)ribbon(corners[i],corners[(i+1)%4],kind==='park'?2.4:4.3);
 }
 if(kind==='village'){
  // Terraced vineyard rows give the open Tuscan side a recognizable land use.
  // Their low canopy and trellises stay well outside the playable rectangle.
  const earth=new T.MeshStandardMaterial({color:'#806d4c',roughness:1,side:T.DoubleSide});finishExteriorMaterial(earth,'stone');materials.set('district-earth',earth);ownedMaterials.add(earth);
  for(let row=0;row<5;row++){const x=q[0]-16-row*3.2,z0=q[1]-18,z1=q[3]+18;ribbon([x,z0],[x,z1],1.05,'district-earth');for(let z=z0;z<z1;z+=2.2){if(inBuilding(x,z,1.4))continue;const y=ground.minimum([[x-.25,z-.25],[x+.25,z+.25]],.04);b.lathe('district-leaf',x,y+.20,z,[[.15,0],[.43,.30],[.36,.68],[.18,.95],[0,1.02]],8);b.tube('wood',[[x,y,z],[x,y+.55,z]],.025,.018,5);if(Math.round((z-z0)/2.2)%2===0){b.tube('wood',[[x,y,z],[x,y+1.05,z]],.035,.035,5);b.tube('metal',[[x,y+.84,z-.95],[x,y+.84,z+.95]],.012,.012,4);}}}
 }
 if(kind==='rail')for(let k=0;k<3;k++)ribbon([q[0]-12-k*3.8,q[1]-27],[q[0]-12-k*3.8,q[3]+27],2.65,'ballast',true);
 if(kind==='park')for(let k=0;k<6;k++){const p=layout.plants[k*5];if(!p)continue;const[x,z]=p,y=ground.height(x+1.9,z);for(const a of[-.7,.7])box('metal',[x+1.9+a,y+.27,z],[.08,.55,.40]);for(let i=0;i<4;i++)box('wood',[x+1.9,y+.55,z-.24+i*.15],[1.8,.07,.10]);tube('metal',[[x+1.05,y+.55,z+.28],[x+1.05,y+1.0,z+.28],[x+2.75,y+1.0,z+.28],[x+2.75,y+.55,z+.28]],.035,.035,6);}
 return{authoredTrees,treeTriangles,buildings:layout.buildings.length,rocks:layout.rocks.length,details,materialBindings:bindings,baseMaxGap:Number.isFinite(baseMaxGap)?baseMaxGap:0};
}
