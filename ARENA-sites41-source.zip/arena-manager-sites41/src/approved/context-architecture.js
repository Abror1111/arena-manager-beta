import {add,sub,mul,unit} from './context-geometry.js';
// Facades are measured roof rims; freestanding architecture has a complete
// footprint, rear, side returns, roof, foundation and purpose-specific details.
export function buildArchitecture({b,profile,plan,height,random}){
 const {box,tube,lathe,arch,quad,tri}=b;let props=0,facades=0,details=0,rooms=0,foundationMaxGap=-Infinity;
 function frame(x,z,yaw=0){const u=[Math.cos(yaw),0,-Math.sin(yaw)],n=[Math.sin(yaw),0,Math.cos(yaw)],base=height(x,z);return{base,at:(a,y,d)=>[x+u[0]*a+n[0]*d,y,z+u[2]*a+n[2]*d],yaw};}
 function localBox(f,key,x,y,d,w,h,depth){box(key,f.at(x,y,d),[w,h,depth],f.yaw);}
 function window(f,x,y,kind='shutters',w=.72){
  localBox(f,'recess',x,y,.08,w,1.08,.07);for(const s of [-1,1]){localBox(f,'trim',x+s*(w/2+.065),y,.17,.10,1.28,.14);localBox(f,'trim',x,y+s*.58,.17,w+.24,.10,.16);}
  if(kind==='shutters'){for(const s of [-1,1]){localBox(f,'wood',x+s*(w/2+.25),y,.23,.34,1.08,.07);for(let j=0;j<8;j++)localBox(f,'accent',x+s*(w/2+.25),y-.43+j*.12,.285,.29,.045,.04);}}
  else if(kind==='lattice'){for(let i=0;i<6;i++){const xx=x-w*.43+i*w*.172;tube('wood',[f.at(xx,y-.49,.21),f.at(xx,y+.49,.21)],.014);}for(let i=0;i<7;i++)tube('wood',[f.at(x-w/2,y-.45+i*.15,.21),f.at(x+w/2,y-.45+i*.15,.21)],.014);arch('trim',f.at,x,y+.14,w*.54,.11,.23);}
  else{for(let j=0;j<4;j++)localBox(f,'metal',x,y-.39+j*.26,.21,w,.038,.035);localBox(f,'metal',x,y,.21,.045,1.08,.035);localBox(f,'glass',x,y,.13,w-.10,1,.025);}
  localBox(f,'trim',x,y-.66,.15,w+.38,.10,.36);details++;
 }
 function carvedBand(f,width,y,temple=false){for(let x=-width/2+.20;x<width/2-.12;x+=.45){localBox(f,'trim',x,y,.18,.36,.34,.16);if(temple){for(let j=0;j<3;j++)localBox(f,'accent',x-.105+j*.105,y+((j%2)*.10-.05),.28,.035,.20,.035);}else{const path=[];for(let j=0;j<=8;j++){const a=j/8*Math.PI*2;path.push(f.at(x+Math.cos(a)*.1,y+Math.sin(a)*.1,.28));}tube('accent',path,.018,.018,5);}details++;}}
 function service(f,w,base,top){
  for(const x of [-w/2+.25,w/2-.25])tube('metal',[f.at(x,base+.2,.25),f.at(x,top-.3,.25),f.at(x-.35,top-.3,.25)],.06);
  const yy=Math.min(top-1.1,base+2);localBox(f,'metal',0,yy,.20,1.5,.88,.4);for(let k=0;k<8;k++)localBox(f,'recess',0,yy-.35+k*.10,.415,1.34,.035,.035);for(const s of [-1,1])localBox(f,'trim',s*.75,yy,.44,.06,.98,.055);
  for(let j=0;j<Math.floor(w/1.8);j++)window(f,-w/2+.9+j*1.8,Math.min(top-1,base+3.6),'industrial',.95);details+=3;
 }
 function dress(f,w,base,top,type){
  if(top-base<2)return;const industrial=['plant','warehouse','depot','park','skyline'].includes(type);
  for(const y of [base+.20,top-.15])localBox(f,'trim',0,y,.20,w+.20,.16,.28);
  if(industrial){service(f,w,base,top);if(type==='warehouse'||type==='depot')for(let x=-w/2+.15;x<w/2;x+=1.8){localBox(f,'trim',x,(base+top)/2,.12,.16,top-base,.24);localBox(f,'trim',x,top-.4,.16,.32,.28,.30);}return;}
  const isTemple=type==='temple'||type==='ruin';
  if(isTemple){carvedBand(f,w,top-.62,true);for(let x=-w/2+.55;x<w/2;x+=1.65){const yy=(top+base)*.5;localBox(f,'recess',x,yy,.12,.75,1.2,.05);for(let k=0;k<3;k++){localBox(f,'trim',x+(.21-k*.21),yy,.2,.105,.72-(k%2)*.2,.10);localBox(f,'trim',x,yy-.42+k*.4,.21,.66,.09,.10);}if(type==='ruin'){const path=[];for(let k=0;k<14;k++)path.push(f.at(x+.13*Math.sin(k*.9),top-k*(top-base)*.055,.29));tube('vine',path,.025,.012,5);}details++;}return;}
  const count=Math.max(1,Math.floor(w/2.1));for(let row=base+2;row<top-1.2;row+=2.35)for(let j=0;j<count;j++)window(f,-w/2+(j+.5)*w/count,row,type==='riad'?'lattice':'shutters');
  carvedBand(f,w,top-.5,false);
  for(const sign of [-1,1])for(let y=base+.35;y<top-.5;y+=.43)localBox(f,'trim',sign*(w/2-.10),y,.18,.29+(Math.floor(y/.43)%2)*.14,.18,.16);
  if(top-base>4&&w>4){localBox(f,'trim',0,base+2.9,.23,2.25,.15,.72);for(let j=0;j<10;j++)tube('metal',[f.at(-1+j*.222,base+3,.56),f.at(-1+j*.222,base+3.65,.56)],.018);tube('metal',[f.at(-1.1,base+3.66,.56),f.at(1.1,base+3.66,.56)],.027);}
 }
 // Dress only the measured rims whose full outward detail depth is outside
 // the protected navigation mesh (checked independently by plan generation).
 for(const p of plan.structure?[]:plan.facades){const mid=[(p.a[0]+p.b[0])/2,(p.a[1]+p.b[1])/2],d=unit([p.b[0]-p.a[0],0,p.b[1]-p.a[1]]),n=[p.normal[0],0,p.normal[1]],base=height(...mid);const f={base,yaw:Math.atan2(-d[2],d[0]),at:(x,y,z)=>[mid[0]+d[0]*x+n[0]*(z+.17),y,mid[1]+d[2]*x+n[2]*(z+.17)]};dress(f,p.length,base,p.top,profile.architecture);facades++;}

 // Short room returns measured from exposed source wall planes. Their depth
 // and all decorative overhangs have been excluded from the nav guard offline.
 for(const r of plan.structure?[]:plan.rooms||[]){const d=unit([r.b[0]-r.a[0],0,r.b[1]-r.a[1]]),n=[r.normal[0],0,r.normal[1]],mid=[(r.a[0]+r.b[0])/2,(r.a[1]+r.b[1])/2],length=Math.hypot(r.b[0]-r.a[0],r.b[1]-r.a[1]),base=Math.min(...r.footprint.map(p=>height(...p)))-.32,center=[mid[0]+n[0]*r.depth/2,mid[1]+n[2]*r.depth/2],yaw=Math.atan2(-d[2],d[0]);box('wall',[center[0],(base+r.top)/2,center[1]],[length,r.top-base,r.depth],yaw);box('roof',[center[0],r.top+.04,center[1]],[length+.05,.10,r.depth+.05],yaw);
  const at=(x,y,z)=>[mid[0]+d[0]*x+n[0]*(r.depth+z),y,mid[1]+d[2]*x+n[2]*(r.depth+z)];dress({at,yaw},length,base,r.top,profile.architecture);facades++;
  for(const sign of [-1,1]){const origin=add([mid[0],0,mid[1]],mul(d,sign*length/2)),f={yaw:yaw+Math.PI/2,at:(x,y,z)=>add(origin,add(mul(n,x+r.depth/2),add([0,y,0],mul(d,sign*z))))};dress(f,r.depth,base,r.top,profile.architecture);facades++;}
  for(const p of r.footprint)foundationMaxGap=Math.max(foundationMaxGap,base-height(...p));rooms++;
 }
 function roof(f,w,d,y,pitched){if(!pitched){localBox(f,'roof',0,y,0,w+.20,.22,d+.20);for(const sign of [-1,1])localBox(f,'trim',0,y+.25,sign*d/2,w,.40,.18);return;}const ridge=y+1.35;
  for(const sign of [-1,1]){quad('roof',f.at(-w/2-.15,y,sign*(d/2+.17)),f.at(w/2+.15,y,sign*(d/2+.17)),f.at(w/2+.15,ridge,0),f.at(-w/2-.15,ridge,0));for(let i=0;i<=Math.ceil(w/.3);i++)tube('roof',[f.at(-w/2+i*.3,y+.025,sign*(d/2+.17)),f.at(-w/2+i*.3,ridge+.025,0)],.035,.035,5);}
  for(const sign of [-1,1])tri('wall',f.at(sign*w/2,y,-d/2),f.at(sign*w/2,y,d/2),f.at(sign*w/2,ridge,0));tube('trim',[f.at(-w/2-.2,ridge+.05,0),f.at(w/2+.2,ridge+.05,0)],.07);
 }
 function building(x,z,yaw,type,index){const f=frame(x,z,yaw),w=type==='depot'?6.2:type==='villa'?4.5:4,d=type==='plant'?4.8:3.6,h=['temple','ruin'].includes(type)?4.0:4.0+(index%2)*1.7,base=Math.max(...[-1,1].flatMap(a=>[-1,1].map(c=>{const p=f.at(a*(w/2+.2),0,c*(d/2+.2));return height(p[0],p[2]);})))+.06,top=base+h;
  // Every new structure has thickness and a closed rear, not a stage flat.
  const corners=[[-w/2-.2,-d/2-.2],[w/2+.2,-d/2-.2],[w/2+.2,d/2+.2],[-w/2-.2,d/2+.2]].map(([x,z])=>f.at(x,0,z)),bottom=Math.min(...corners.map(p=>height(p[0],p[2])))-.18,foundationTop=base+.32;localBox(f,'trim',0,(bottom+foundationTop)/2,0,w+.40,foundationTop-bottom,d+.40);for(const p of corners)foundationMaxGap=Math.max(foundationMaxGap,bottom-height(p[0],p[2]));localBox(f,'wall',0,base+h/2,0,w,h,d);roof(f,w,d,top,['villa','depot','warehouse'].includes(type));
  for(let side=0;side<4;side++){const angle=yaw+side*Math.PI/2,u=side%2?d:w,xx=x+Math.sin(angle)*(side%2?w:d)/2,zz=z+Math.cos(angle)*(side%2?w:d)/2;dress(frame(xx,zz,angle),u,base,top,type);facades++;}
  if(['temple','ruin'].includes(type)){for(const sign of [-1,1]){const q=f.at(sign*(w/2+.4),base,d*.4);lathe('trim',q[0],base,q[2],[[.55,0],[.55,.25],[.38,.32],[.29,2.6],[.43,2.72],[.5,3.0],[0,3.0]],16);}for(let k=0;k<3;k++)localBox(f,'trim',0,base+.12+k*.13,d/2+.25+k*.3,w-1-k*.4,.16,.4);}
  if(['plant','warehouse','depot'].includes(type)){for(let k=0;k<2;k++){const p=f.at(-1+k*2,top+.12,0);box('metal',[p[0],top+.38,p[2]],[1.15,.60,1.0],yaw);for(let j=0;j<9;j++)localBox(f,'recess',-1+k*2,top+.38,-.52,.95,.035,.04);}tube('metal',[f.at(w/2-.3,base+.3,d/2+.25),f.at(w/2-.3,top+.7,d/2+.25),f.at(w/2-.9,top+.7,d/2+.25)],.10);}
  if(type==='villa'){const p=f.at(-1,top+.65,-.6);box('wall',[p[0],top+1.2,p[2]],[.55,1.4,.6],yaw);box('trim',[p[0],top+1.92,p[2]],[.72,.18,.75],yaw);}
  if(profile.family==='temple')for(let k=0;k<6;k++){const q=f.at(-w/2+.4+k*.6,top+.1,0);box('trim',q,[.38,.35,.65],yaw);}
  props++;
 }

 if(plan.structure?.decor){for(const p of plan.structure.decor){const d=unit([p.b[0]-p.a[0],0,p.b[1]-p.a[1]]),n=p.normal,L=p.length,mid=[(p.a[0]+p.b[0])/2,(p.a[1]+p.b[1])/2],base=p.bottom,f={yaw:Math.atan2(-d[2],d[0]),at:(x,y,z)=>[mid[0]+d[0]*x+n[0]*z,y,mid[1]+d[2]*x+n[1]*z]};dress(f,L,base,p.top,profile.architecture);facades++;}}
 const anchors=plan.anchors;
 if(!plan.districts){
 if(profile.architecture==='skyline'){
  // The supplied tower already contains the high-rise base. Additional city
  // blocks sit far below the playable floors; no invented slab crosses them.
  for(let i=0;i<12;i++){const a=i*Math.PI/6,r=48+(i%3)*13,x=Math.cos(a)*r,z=Math.sin(a)*r,base=plan.sourceBounds[1]-.65,h=35+(i*19%65),w=6+i%3*2,d=7;const f=frame(x,z,a*.3);localBox(f,'wall',0,base+h/2,0,w,h,d);roof(f,w,d,base+h,false);for(let y=base+3;y<base+h-1;y+=2.5){for(const s of [-1,1]){localBox(f,'glass',0,y,s*(d/2+.025),w-.6,1.55,.035);localBox(f,'metal',0,y+.92,s*(d/2+.06),w,.13,.06);}for(let j=1;j<5;j++)localBox(f,'metal',-w/2+j*w/5,(base+base+h)/2,d/2+.07,.11,h,.06);}props++;facades+=4;}
  // One trussed service crane outside the nav bounds, anchored to city grade.
  const [x,z]=anchors[2],base=plan.sourceBounds[1]-.7,top=10;for(const s of [-1,1])tube('accent',[[x+s*.65,base,z-.65],[x+s*.65,top,z-.65],[x+s*.65,top,z+.65],[x+s*.65,base,z+.65]],.10);for(let y=base;y<top-1;y+=3.3)for(const s of [-1,1]){tube('accent',[[x-.65,y,z+s*.65],[x+.65,y+3.3,z+s*.65]],.065);tube('metal',[[x-.65,y+3.3,z+s*.65],[x+.65,y,z+s*.65]],.04);}for(const dz of [-.5,.5])tube('accent',[[x-9,top,z+dz],[x+11,top,z+dz]],.10);for(let j=-9;j<11;j+=1)tube('metal',[[x+j,top-.45,z-.5],[x+j+1,top+.5,z+.5]],.04);props++;
 }else{
  const indices={riad:[2,7,12],villa:[1,8,15],temple:[1,9,17],ruin:[3,8,17],plant:[2,9,16],warehouse:[1,10,19],depot:[0,7,14],park:[3,10,17]}[profile.architecture];
  for(let j=0;j<(plan.structure?0:indices.length);j++){const i=indices[j],[x,z]=anchors[i],yaw=(i%4===0?-Math.PI/2:i%4===1?Math.PI/2:i%4===2?Math.PI:0);building(x,z,yaw,profile.architecture,j);}
  if(profile.architecture==='plant'){
   for(let k=0;k<2;k++){const [x,z]=anchors[20+k],y=height(x,z);lathe('metal',x,y,z,[[0,0],[1.8,0],[1.8,.2],[1.55,.35],[1.55,4.8],[1.1,5.6],[.35,5.9],[0,5.9]],24);for(const h of [.7,2.8,4.6])lathe('trim',x,y,z,[[1.56,h],[1.63,h],[1.63,h+.12],[1.56,h+.12]],24);tube('metal',[[x+1.55,y+.2,z],[x+1.55,y+5.1,z]],.06);for(let j=0;j<13;j++)tube('accent',[[x+1.5,y+.4+j*.35,z-.25],[x+1.5,y+.4+j*.35,z+.25]],.025);props++;}
  }
  if(profile.architecture==='depot'){
   for(let k=0;k<2;k++){const [x,z]=anchors[18+k],y=height(x,z)+.12;box('ballast',[x,y-.06,z],[3.1,.30,10]);for(const s of [-1,1])box('metal',[x+s*.65,y+.15,z],[.09,.11,10]);for(let t=-4.8;t<5;t+=.48)box('wood',[x,y+.02,z+t],[1.95,.12,.16]);for(const s of [-1,1])tube('metal',[[x+s*2,y,z-4],[x+s*2,y+4,z-4],[x-s*2,y+4,z-4]],.07);props++;}
  }
  if(profile.architecture==='park'){
   const [x,z]=anchors[21],y=height(x,z);for(const s of [-1,1]){box('wall',[x+s*2.5,y+1.6,z],[.65,3.4,3.0]);box('trim',[x+s*2.5,y+3.2,z],[1.3,.45,3.6]);}box('wall',[x,y+3.4,z],[6.6,.35,3.5]);for(const s of [-1,1])tube('metal',[[x-3,y+3.65,z+s*1.55],[x+3,y+3.65,z+s*1.55]],.05);for(let i=0;i<18;i++)for(const s of [-1,1])tube('metal',[[x-2.8+i*.33,y+3.55,z+s*1.55],[x-2.8+i*.33,y+4.25,z+s*1.55]],.025);props++;
  }
 }
 }
 return{props,facades,details,rooms,foundationMaxGap:Number.isFinite(foundationMaxGap)?foundationMaxGap:0};
}
export function buildVegetation({b,profile,plan,height,random}){
 const {tube,tri,quad,lathe}=b;let trees=0,leaves=0;
 function leaf(p,a,len,width,key='holo-leaf38'){const d=[Math.cos(a),.13,Math.sin(a)],side=[-Math.sin(a),0,Math.cos(a)],tip=add(p,mul(d,len)),mid=add(add(p,mul(d,len*.48)),[0,.11,0]);tri(key,p,add(mid,mul(side,width)),tip);tri(key,p,tip,add(mid,mul(side,-width)));leaves++;}
 const reserved={riad:[2,7,12],villa:[1,8,15],temple:[1,9,17],ruin:[3,8,17],plant:[2,9,16,20,21],warehouse:[1,10,19],depot:[0,7,14,18,19],park:[3,10,17,21],skyline:[]}[profile.architecture];const treeIndices=plan.anchors.map((_,i)=>i).filter(i=>!reserved.includes(i)&&(profile.family==='nile'?i%4===1:i%3!==1)&&(!profile.water||height(...plan.anchors[i])>-1.0));const placements=profile.architecture==='skyline'?[]:treeIndices.map(i=>plan.anchors[i]);
 for(let index=0;index<placements.length;index++){
  const [x,z]=placements[index],y=height(x,z)-.12,scale=.80+random()*.42,h=(profile.tree==='cypress'?5.5:profile.tree==='palm'?5.7:4.8)*scale,type=profile.tree;
  if(type==='palm'){
   const trunk=[];for(let j=0;j<=14;j++){const t=j/14;trunk.push([x+Math.sin(t*1.4)*.34,y+t*h,z+t*t*.2]);}tube('holo-bark38',trunk,.18,.075,10);for(let k=0;k<25;k++){const yy=y+k*h/25;lathe('holo-bark38',x+Math.sin(k/25*1.4)*.34,yy,z+(k/25)**2*.2,[[.15,0],[.18,.025],[.14,.065]],8);}
   const crown=trunk.at(-1);for(let k=0;k<11;k++){const a=k/11*Math.PI*2+.2,spine=[];for(let j=0;j<=12;j++){const t=j/12,rr=t*2.35*scale;spine.push([crown[0]+Math.cos(a)*rr,crown[1]+Math.sin(t*Math.PI)*.42-t*t*.62,crown[2]+Math.sin(a)*rr]);}tube('holo-branch38',spine,.027,.006,5);for(let j=1;j<12;j++)for(const sign of [-1,1])leaf(spine[j],a+sign*1.15,(.12+Math.sin(j/12*Math.PI)*.5)*scale,.07*scale,(j+k)%3?'holo-leaf38':'holo-leaf-light38');}
  }else{
   const trunk=[[x,y,z],[x+.08,y+h*.45,z-.05],[x-.1,y+h*.88,z+.03]];tube(type==='birch'?'holo-bark38':'holo-bark38',trunk,.22,.045,9);
   const branches=type==='cypress'||type==='pine'?12:15;
   for(let j=0;j<branches;j++){const t=j/branches,a=j*2.399963,spread=type==='cypress'?.5*(1-t)+.16:type==='pine'?1.8*(1-t)+.18:1.2+Math.sin(t*Math.PI)*.75,yy=y+h*(.32+t*.6),tip=[x+Math.cos(a)*spread,yy+.4,z+Math.sin(a)*spread];tube('holo-bark38',[[x,yy-.3,z],tip],.047,.012,6);for(let k=0;k<(type==='jungle'?22:15);k++){const aa=a+k*2.399963,rr=Math.sqrt(random())*(type==='cypress'?.4:.9),p=[tip[0]+Math.cos(aa)*rr,tip[1]+(random()-.4)*.8,tip[2]+Math.sin(aa)*rr];leaf(p,aa,type==='pine'?.32:type==='jungle'?.48:.35,type==='jungle'?.20:.14,k%4?'holo-leaf38':'holo-leaf-light38');}}
   if(type==='birch')for(let k=0;k<12;k++)tube('holo-bark38',[[x-.1,y+k*h/14,z+.16],[x+.13,y+k*h/14+.07,z+.17]],.025,.02,5);
   if(type==='jungle')for(let j=0;j<4;j++){const a=j/4*Math.PI*2;tube('holo-bark38',[[x+Math.cos(a)*.7,y+.05,z+Math.sin(a)*.7],[x,y+.9,z]],.12,.10,6);}
  }
  // Grounded ferns and grasses around the tree, not floating foliage discs.
  if(type!=='cypress')for(let j=0;j<3;j++){const a=j*2.4,xx=x+Math.cos(a)*1.2,zz=z+Math.sin(a)*1.2,base=height(xx,zz);for(let k=0;k<7;k++)leaf([xx,base+.02,zz],k/7*Math.PI*2,.55,.055);}
  trees++;
 }
 return{trees,leaves,treeIndices:profile.architecture==='skyline'?[]:treeIndices,reservedAnchors:reserved};
}
