import React,{useEffect,useState}from'react';
import previews from'./previews39.json'with{type:'json'};
import thumbs from'./cover-thumbs39.json'with{type:'json'};
import{loadAsset}from'./asset-cache.js';
import{modernMapId}from'./maps.js';
const ready=new Map(),pending=new Map();
const coverId=id=>{const key=modernMapId(id);return Object.hasOwn(previews,key)?key:'dust2'};
export function mapAssetsPreview(id){const key=coverId(id);return ready.get(key)||thumbs[key];}
export function ensureCover39(id){const key=coverId(id);if(ready.has(key))return Promise.resolve(ready.get(key));if(pending.has(key))return pending.get(key);const job=loadAsset(previews[key]).then(({bytes})=>{const url=URL.createObjectURL(new Blob([bytes],{type:'image/jpeg'}));ready.set(key,url);return url;}).finally(()=>pending.delete(key));pending.set(key,job);return job;}
export function MapCover39({mapId,onError,...props}){const key=coverId(mapId),[image,setImage]=useState(()=>({key,url:mapAssetsPreview(key)}));useEffect(()=>{let mounted=true;const local=mapAssetsPreview(key);setImage({key,url:local});ensureCover39(key).then(url=>{if(mounted)setImage({key,url});}).catch(()=>{/* The embedded current-map preview stays visible offline or on failure. */});return()=>{mounted=false};},[key]);const src=image.key===key?image.url:mapAssetsPreview(key),full=ready.get(key)===src;return <img {...props} src={src} data-map-cover={key} data-cover-version="39" data-cover-quality={full?'full':'preview'} onError={e=>{if(src!==thumbs[key])setImage({key,url:thumbs[key]});onError?.(e);}}/>;}
