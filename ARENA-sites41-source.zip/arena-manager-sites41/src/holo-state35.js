const clock=n=>{n=Math.max(0,Math.floor(Number(n)||0));return Math.floor(n/60)+':'+String(n%60).padStart(2,'0');};
export function holoState35(game){
 const live=Array.isArray(game.score)&&game.score.length===2;
 if(!live)return{source:'preview',home:'ARENA',away:game.map?.name||'NEON CITY',score:'— : —',round:'XARITA KO‘RINISHI',clock:'--:--',phase:'HOLO PREVIEW'};
 const planted=game.bomb?.state==='planted';
 return{source:'match',home:String(game.teamNames?.[0]||'HOME').slice(0,18),away:String(game.teamNames?.[1]||'AWAY').slice(0,18),score:game.score[0]+' : '+game.score[1],round:'RAUND '+game.round,clock:clock(planted?game.bomb.timer:game.phase==='freeze'?game.freeze:game.clock),phase:planted?'C4 FAOL':game.phase==='roundend'?'RAUND YAKUNI':game.phase==='matchend'?'UCHRASHUV YAKUNI':game.phase==='freeze'?'TAYYORLANISH':'JONLI JANG'};
}
