import{addCyberDistrict35}from'./cyber-district35.js';
import{addHolograms35}from'./holograms35.js';
import{createCyberMaterials34}from'./cyber-materials34.js';
import{addCyberWorld34}from'./cyber-world34.js';
import{cyberProfile34}from'./cyber-profiles34.js';
import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {MeshoptDecoder} from 'three/addons/libs/meshopt_decoder.module.js';
import {loadVisualData} from './approved/visual-data.js';
import {configureSourceMaterial,configureMobileSourceMaterial} from './approved/source-materials.js';
import {enhanceSourcePBR} from './approved/source-pbr.js';
import {finishNativeVegetation} from './approved/source-vegetation-finish.js';
import {loadRouteCutaway} from './approved/route-cutaway.js';
import {addDust2Context} from './approved/dust2-context.js';
import {addMapContext} from './approved/map-context.js';
import {mapLightingFrame,mapContextFrame} from './approved/map-context-data.js';
import {fitContextSun} from './approved/context-lighting.js';
import {createCachedWorld} from './approved/cached-world.js';
import {bindMapProps} from './map-prop-renderer.js';
import {prepareApprovedCollision} from './approved-collision.js';
import {observerClipHeight} from './observer-camera.js';

// The accepted review geometry and its authored district, in the same source
// coordinate system as the simulation. Actors/VFX remain in the match scene.
export function addApprovedWorld(overlay,map,renderer,{inspect=false}={}){
 const review=map.review,scene=new T.Scene(),profile=cyberProfile34(map.id),remix=createCyberMaterials34(map.id,renderer);scene.background=new T.Color(profile.sky);
 scene.add(new T.HemisphereLight('#cbdcfa',profile.ink,1.65));
 const sun=new T.DirectionalLight(profile.sun,review.night?1.7:2.25);sun.position.set(-30,60,20);sun.castShadow=true;sun.shadow.mapSize.setScalar(matchMedia('(pointer:coarse)').matches?1024:2048);sun.shadow.camera.left=sun.shadow.camera.bottom=-45;sun.shadow.camera.right=sun.shadow.camera.top=45;sun.shadow.camera.far=200;sun.shadow.normalBias=.025;sun.shadow.bias=-.00005;sun.shadow.radius=2;scene.add(sun,sun.target);if(map.id!=='dust2')fitContextSun(sun,mapLightingFrame(map.id));
 renderer.localClippingEnabled=true;overlay.background=null;
 // Battle cameras must preserve the whole map. Route/floor cuts are only an
 // explicit explorer tool; following an actor must never remove architecture.
 const controller=new AbortController(),cutoff=new T.Plane(new T.Vector3(0,-1,0),1000),cutUniform={value:false};
 const geometries=new Set(),materials=new Set(),textures=new Set();let root,pbr,mask,environment,compositor,props,cyber,district,holos,holoGame,ready=false,error=null,progress=0,disposed=false,signature='',cameraKey='',sourceTriangles=0,sourceMeshes=0;
 const promise=(async()=>{try{
  await prepareApprovedCollision(map,controller.signal);progress=.04;
  const bytes=await loadVisualData(review,controller.signal,p=>progress=.04+p*.5);
  const gltf=await new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).parseAsync(bytes,'');root=gltf.scene;
  const t=review.transform;root.scale.setScalar(1/(.0254*80));root.rotation.y=Math.PI/2;root.position.set(-t.pos_x/80-map.width/2,-t.z_base/80,t.pos_y/80-map.height/2);
  root.traverse(o=>{if(o.isLight||o.isCamera){o.visible=false;return;}if(!o.isMesh)return;geometries.add(o.geometry);const mats=Array.isArray(o.material)?o.material:[o.material];o.visible=mats.map(configureSourceMaterial).some(Boolean);for(const m of mats){for(const v of Object.values(m))if(v?.isTexture)textures.add(v);remix.apply(m);}o.visible&&=mats.some(m=>m.visible);o.castShadow=mats.some(m=>!m.transparent||m.alphaTest>0);o.receiveShadow=true;for(const m of mats){materials.add(m);if(!m.transparent&&!m.alphaTest){m.side=T.DoubleSide;m.shadowSide=T.FrontSide;}for(const v of Object.values(m))if(v?.isTexture){textures.add(v);v.anisotropy=Math.min(16,renderer.capabilities.getMaxAnisotropy());}m.clippingPlanes=inspect?[cutoff]:[];m.clipShadows=inspect;}});
  if(disposed){disposeRoot();return;}progress=.65;pbr=null;progress=.76;
  if(inspect)mask=await loadRouteCutaway({...review,nav:{transform:review.transform}},cutoff,controller.signal);const applied=new Set();
  function routes(material,key){if(!mask||applied.has(material))return;applied.add(material);mask.apply(material);const before=material.onBeforeCompile;material.onBeforeCompile=function(shader,r){before.call(this,shader,r);shader.uniforms.arenaObserveRoutes=cutUniform;shader.fragmentShader=shader.fragmentShader.replace('uniform sampler2D arenaRouteMask;','uniform bool arenaObserveRoutes;uniform sampler2D arenaRouteMask;').replace('if(route.r>.5&&vArenaCutPosition.y>min(arenaRouteClip,localClip))discard;','if(arenaObserveRoutes&&route.r>.5&&vArenaCutPosition.y>min(arenaRouteClip,localClip))discard;');};material.customProgramCacheKey=()=>key;}
  root.traverse(o=>{if(!o.isMesh||!o.visible)return;const mats=Array.isArray(o.material)?o.material:[o.material];for(const m of mats)routes(m,'arena-reviewed-match-route-14');const m=mats[0],depth=new T.MeshDepthMaterial({depthPacking:T.RGBADepthPacking,map:m.map,alphaMap:m.alphaMap,alphaTest:m.alphaTest,clippingPlanes:inspect?[cutoff]:[],clipShadows:inspect});routes(depth,'arena-reviewed-match-depth-14');o.customDepthMaterial=depth;materials.add(depth);sourceMeshes++;sourceTriangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;});
  if(disposed){disposeRoot();return;}scene.add(root);root.updateMatrixWorld(true);progress=.82;
  environment=map.id==='dust2'?await addDust2Context(scene,root,review,renderer,controller.signal):await addMapContext(scene,root,review,renderer,controller.signal,m=>gltf.parser.associations.get(m)?.materials,o=>gltf.parser.associations.get(o));
  if(disposed){disposeRoot();return;}scene.traverse(o=>{if(o.isMesh)for(const m of(Array.isArray(o.material)?o.material:[o.material]))if(m.isMeshStandardMaterial){if(/continuous-.*(?:ground|relief)|terrain-ground/.test(o.name))m.userData.cyberGround34=true;remix.apply(m);}});scene.background.set(profile.sky);props=bindMapProps(gltf,map,overlay);cyber=addCyberWorld34(scene,root,map);district=addCyberDistrict35(scene,root,map,environment,remix);holos=addHolograms35(environment.dynamicScene,root,map,{staticScene:scene,reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches});ready=true;progress=1;renderer.shadowMap.needsUpdate=true;
 }catch(e){if(e.name!=='AbortError'){error=e.message||String(e);disposeRoot();}}})();
 function disposeRoot(){holos?.dispose();district?.dispose();cyber?.dispose();remix.dispose();props?.dispose();compositor?.dispose();environment?.dispose();root?.removeFromParent();mask?.dispose();pbr?.dispose();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>{t.dispose();t.source?.data?.close?.();});}
 return{promise,get ready(){return ready;},get error(){return error;},get progress(){return progress;},get root(){return root;},get environment(){return environment;},get clipHeight(){return cutoff.constant;},get pbrMaps(){return remix.textureCount;},get holoFaces(){return holos?.faces||0;},get holoPeople(){return holos?.people||0;},get holoAds(){return holos?.ads||0;},get holoState(){return holos?.state||null;},get holoTextureUpdates(){return holos?.textureUpdates||0;},get cityTowers(){return district?.towers||0;},get cityFacades(){return district?.facades||0;},get cityTerminals(){return district?.terminals||0;},get cityTriangles(){return district?.triangles||0;},get cyberKits(){return cyber?.kits||0;},get cyberSigns(){return cyber?.signs||0;},get cyberTriangles(){return cyber?.triangles||0;},get cyberBatches(){return cyber?.batches||0;},get cyberProfile(){return remix.profile;},get remixedMaterials(){return remix.changed;},get replacedTextures(){return remix.textureCount;},get hiddenSourceSigns(){return remix.hidden;},get pbrBytes(){return pbr?.bytes||0;},get propCount(){return props?.count||0;},get activeProps(){return props?.active||0;},get sourceTriangles(){return sourceTriangles;},get sourceMeshes(){return sourceMeshes;},get sourceHash(){return review.visual.sha256;},get cacheMode(){return compositor?.mode||'loading';},get sourceCaptures(){return compositor?.captures||0;},get districtCount(){return environment?.districtBuildings||0;},get wallSolids(){return environment?.sourceRoomCount||environment?.perimeterRooms||0;},seamlessGround:true,groundSource:'accepted-source-review-worlds11',
  invalidate(){cameraKey='';compositor?.invalidate();},
  get roofMode(){return cutUniform.value?'source-route-cutaway':'full-source';},
  setRoofMode(value){const enabled=inspect&&value==='routes';if(cutUniform.value!==enabled){cutUniform.value=enabled;signature='';renderer.shadowMap.needsUpdate=true;}for(const g of[cyber?.group,district?.group,holos?.group,holos?.staticGroup])if(g)g.visible=!enabled&&cutoff.constant===1000;},
  setLevel(level,actor){const h=inspect?observerClipHeight(map,level,actor):1000;if(cutoff.constant!==h){cutoff.constant=h;signature='';renderer.shadowMap.needsUpdate=true;}for(const g of[cyber?.group,district?.group,holos?.group,holos?.staticGroup])if(g)g.visible=!cutUniform.value&&h===1000;},
  updateProps(game){holoGame=game;props?.update(game);const next=game.round+':'+Object.keys(game.propStates||{}).sort().join(',');if(signature!==next){signature=next;compositor?.invalidate();}},
  render(camera,now){if(!ready){renderer.render(overlay,camera);return;}compositor??=createCachedWorld(renderer,scene,camera,environment.dynamicScene);const next=[...camera.matrixWorld.elements,...camera.projectionMatrix.elements,cutoff.constant,Number(cutUniform.value)].map(n=>n.toFixed(6)).join(',');const dirty=next!==cameraKey;cameraKey=next;environment.update(now/1000);holos?.update(holoGame||{map},now/1000);environment.beforeRender?.(camera,dirty);compositor.resize();compositor.render(dirty);const clear=renderer.autoClear;renderer.autoClear=false;renderer.render(overlay,camera);renderer.autoClear=clear;},
  dispose(){disposed=true;controller.abort();disposeRoot();sun.shadow.dispose();scene.clear();}
 };
}

export function approvedInspectionFrame(map,aspect,tilt,yaw,target){
 const frame=mapContextFrame(map.id),min=map.id==='dust2'?[-54,-1,-45]:frame?.min,max=map.id==='dust2'?[43,16,45]:frame?.max;if(!min||!max)return null;
 const offset=new T.Vector3(Math.sin(yaw)*Math.sin(tilt),Math.cos(tilt),Math.cos(yaw)*Math.sin(tilt)),matrix=new T.Matrix4().lookAt(offset,new T.Vector3(),new T.Vector3(0,1,0)),inverse=new T.Quaternion().setFromRotationMatrix(matrix).invert();let mx=0,my=0;
 for(const x of[min[0],max[0]])for(const y of[min[1],max[1]])for(const z of[min[2],max[2]]){const p=new T.Vector3(x,y,z).sub(target).applyQuaternion(inverse);mx=Math.max(mx,Math.abs(p.x));my=Math.max(my,Math.abs(p.y));}return Math.max(my,mx/Math.max(.1,aspect))*(map.id==='dust2'?1.16:1.08);
}
