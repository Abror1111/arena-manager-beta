# ARENA Manager1.52 — Compact mobile UI and guided first play

Compact responsive shell for phones, landscape phones, coarse-pointer tablets, iPad, folded covers, unfolded Fold and split-screen. Five primary phone tabs, full static menu, tablet rail, safe areas, live reflow and viewport-segment hinge-aware controls. AdaptiveDeck retains one live DOM instance and horizontal pages; only shop and transfers have vertical lists.

Replace text-only onboarding presentation with a spotlight over actual controls, an original SVG hand and a brief contextual explanation. Real paid starter recruits, skills inspection, paid training, rest, chosen map and strategy, objective claim, confirmed cosmetic and practice all use existing career actions. Selection confirmation avoids moving native pickers while open. Actual pause, auto camera, individual follow, orders, speed and play are taught with held simulation.

Persist optional phase-scoped guide52 actions and pause state inside existing tutorial version1. Existing completed clubs are not forced into onboarding. Help offers an isolated memory-only practice club. Guided beginner financial guards prevent spending the starter budget on unrelated upgrades; normal and legacy clubs retain existing rules.

Tabbed battle roster exposes five full player cards per team on narrow screens; compact HUD and selectors retain real weapons, ammo and status. Simulation geometry, map art, combat, audio, currencies, billing state, portraits and themes remain from51; engine version label becomes1.52.

An immutable separately published compressed runtime keeps the main GitHub Pages tree under1GiB. Loader verifies SHA256, repairs corrupt runtime cache and supports cached offline launch. Android bundles the pinned runtime. Previous loader aliases are retained for service-worker upgrades.

Android preview152 keeps the existing package and signing certificate; fullUser orientation and adjustResize support portrait/landscape and keyboard. Browser viewport and extracted-asset checks do not claim physical-device installation, measured FPS or every hardware/browser combination. Other3Dmaps need their first download; no live billing, ads or legal-clearance claim.

Build: `node --test tests/*.test.mjs`; `ARENA_MANAGER_OUT=/tmp/arena52-web npm run build`; `python pack-web31.py /tmp/arena52-web`. runtime52.json pins the exact compressed runtime; the packer verifies reproducibility. Serve at /arena-manager-beta/remix31/ with retained shared assets. Verification52 contains evidence and scripts; adapt RAM paths locally. Android instructions in androidGame52/README.md. Prior source/history: https://github.com/Abror1111/arena-manager-beta/tree/arena-fit51-source .
