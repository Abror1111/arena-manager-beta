ARENA - yangi xaritalarni eksport qilish v4

1. Ushbu ZIPni alohida yangi papkaga toliq oching (Извлечь все).
2. Export-Mirage.cmd ni ikki marta bosing. ZIP ichidan ishga tushirmang.
3. Dastur CS2ni E:\Steam Game\steamapps\common\Counter-Strike Global Offensive manzilidan oladi. Manzil ozgargan bolsa, yangi manzilni soraydi.
4. Asl model va teksturalar eksport qilinadi. Keyin ZIP va taxminan 24 MiB bolaklar avtomatik yaratiladi. TAYYOR yozuvini kuting; bu bir necha daqiqa olishi mumkin.
5. ARENA-CS2-exports ichidagi ARENA-mirage-CS2-visuals-upload-parts papkasini oching (qayta eksportda nomida -2 ham bolishi mumkin).
6. Shu chatga ARENA-upload-manifest.json va dastlabki 5 ta ARENA-part-...zip yuboring. Qolganlarini keyingi xabarlarda yuborasiz.
7. XATO chiqsa, ARENA-CS2-exports ichidagi eng yangi ARENA-diagnostics-*.txt faylini yuboring. Qora oyna tugma bosmaguncha yopilmaydi.

Boshqa xaritalarni bittadan tayyorlash: Choose-Map.cmd ni oching va raqamini kiriting. Avval Mirage, keyin boshqa xaritalar. Faqat ornatilgan de_*.vpk xaritalari eksport qilinadi. Cache va Ancient Night sizning CS2 versiyangizda bolmasligi mumkin.

Python 3 va ornatilgan CS2 kerak. Source2Viewer-CLI20.1 rasmiy GitHub sahifasidan yuklanadi, SHA256 tekshiriladi. Eski eksport va CS2 fayllari saqlanadi. Avvalgi Dust II fayllarini qayta yuborish kerak emas. Eksport tarkibi faqat ushbu xaritaning GLB/teksturalari va nav/radar malumotlari.

Agar eksportga joy yetmasa, dastur XATO yozadi; asl oyin fayllarini ochirmaydi. Har bir xarita uchun bir necha GB bosh joy kerak bolishi mumkin.
