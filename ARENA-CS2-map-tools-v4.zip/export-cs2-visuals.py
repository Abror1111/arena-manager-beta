"""Export actual CS2 scenes on the user's PC with Source2Viewer-CLI20.1.
No game files are downloaded, changed or deleted. Python3 standard library only.
"""
import argparse,hashlib,json,re,struct,subprocess,sys,zipfile,platform,urllib.request,posixpath,os,datetime
from urllib.parse import unquote,urlsplit
from pathlib import Path
MAPS=['dust2','mirage','inferno','nuke','train','ancient','ancient-night','anubis','overpass','vertigo','cache']
RUN_LOG=None

def normalize_game(value):
 path=Path(str(value).strip().strip('"').strip("'")).expanduser().resolve()
 if path.name.lower()=='gameinfo.gi':path=path.parent
 for candidate in [path,path/'game/csgo',path/'csgo']:
  if (candidate/'gameinfo.gi').is_file():return candidate
 raise ValueError('CS2 gameinfo.gi topilmadi. Oyin papkasi yoki uning game\\csgo papkasini kiriting: '+str(path))

def run_cli(command,capture=False):
 if RUN_LOG:RUN_LOG.write('COMMAND: '+subprocess.list2cmdline([str(a) for a in command])+'\n');RUN_LOG.flush()
 lines=[]
 with subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace') as process:
  for line in process.stdout:
   lines.append(line)
   if RUN_LOG:RUN_LOG.write(line);RUN_LOG.flush()
   if not capture:print(line,end='',flush=True)
  code=process.wait()
 if code:raise ValueError('Source2Viewer xato kodi '+str(code)+'. Oxirgi yozuv: '+''.join(lines[-6:]).strip())
 return ''.join(lines)

def resource_paths(text):
 text=text.replace('\\','/')
 return list(dict.fromkeys(re.findall(r'(?i)(?:^|[\s\]])((?:[a-z0-9_.-]+/)*[a-z0-9_.-]+\.(?:vmap_c|vwrld_c))(?=\s|$)',text)))

def free_target(output,slug):
 target=output/slug;number=1
 while target.exists() and any(p.is_file() for p in target.rglob('*')):
  number+=1;target=output/(slug+'-'+str(number))
 return target

def official_viewer():
 system=platform.system();kind='windows' if system=='Windows' else 'linux' if system=='Linux' else None
 if kind is None or platform.machine().lower() not in ['amd64','x86_64']:raise ValueError('Use --viewer for this platform.')
 hashes={'windows':'67aaf8a67a85ca60fd09ff343e62103a4cdf3a2d177fc656231d7d734c5b3aa3','linux':'29d25a6d6b62377fc5386c3e5145b0a2180a401a50041afe9494b3f503deaef5'}
 folder=Path.home()/'.arena-cs2-tools'/'20.1';exe=folder/('Source2Viewer-CLI.exe' if kind=='windows' else 'Source2Viewer-CLI');archive=folder/('cli-'+kind+'-x64.zip');folder.mkdir(parents=True,exist_ok=True)
 if not archive.exists():
  print('Official Source2Viewer20.1 yuklanmoqda...',flush=True)
  with urllib.request.urlopen('https://github.com/ValveResourceFormat/ValveResourceFormat/releases/download/20.1/'+archive.name,timeout=90) as response,archive.open('wb') as output:
   import shutil;shutil.copyfileobj(response,output)
 if file_hash(archive)!=hashes[kind]:raise ValueError('Source2Viewer SHA256 mismatch; tool will not be used.')
 with zipfile.ZipFile(archive) as z:
  for item in z.infolist():
   if Path(item.filename).name!=item.filename:raise ValueError('Unexpected tool archive path')
  z.extractall(folder)
 if kind=='linux':exe.chmod(0o755)
 return exe

def glb_json(path):
 with path.open('rb') as f:
  magic,version,size=struct.unpack('<4sII',f.read(12));assert magic==b'glTF' and version==2 and size==path.stat().st_size,'Invalid GLB'
  length,kind=struct.unpack('<II',f.read(8));assert kind==0x4E4F534A;return json.loads(f.read(length))
def world_resource(viewer,map_vpk,pak,source):
 for archive in [map_vpk,pak]:
  if not archive.exists():continue
  print('Xarita resurslari tekshirilmoqda:',archive.name,flush=True)
  listing=run_cli([str(viewer),'--input',str(archive),'--vpk_list','--vpk_extensions','vmap_c,vwrld_c'],capture=True)
  paths=resource_paths(listing);preferred=['maps/'+source+'.vmap_c','maps/'+source+'/world.vwrld_c']
  for path in preferred:
   for found in paths:
    if found.lower()==path:return archive,found
  # The per-map archive may use an internal folder different from its filename.
  if archive==map_vpk:
   maps=[p for p in paths if p.lower().endswith('.vmap_c')]
   worlds=[p for p in paths if p.lower().endswith('/world.vwrld_c') or p.lower()=='world.vwrld_c']
   if len(maps)==1:return archive,maps[0]
   if not maps and len(worlds)==1:return archive,worlds[0]
 raise ValueError('Full world/vmap topilmadi: '+source+'. Diagnostika faylini yuboring; world_physics bilan almashtirilmaydi.')

def file_hash(path):
 digest=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
 return digest.hexdigest()

def select_model(target,source):
 candidates=sorted(p for p in target.rglob('*.glb') if not p.name.lower().endswith('_physics.glb') and p.stem.lower()!='world_physics')
 for expected in [target/'maps'/(source+'.glb'),target/(source+'.glb'),target/'maps'/source/'world.glb']:
  if expected in candidates:return expected
 named=[p for p in candidates if p.stem.lower()==source]
 if len(named)==1:return named[0]
 if len(candidates)==1:return candidates[0]
 raise ValueError('Asosiy vizual GLB aniq topilmadi. Nomzodlar: '+', '.join(str(p.relative_to(target)) for p in candidates))

def client_version(game):
 steam=(game/'steam.inf').read_text(encoding='utf-8-sig') if (game/'steam.inf').exists() else ''
 match=re.search(r'^ClientVersion\s*=\s*(\d+)',steam,re.M)
 return match.group(1) if match else None

def add_reference(game,viewer,source,target):
 reference=target/'reference';reference.mkdir(exist_ok=True)
 vpk=game/'maps'/(source+'.vpk')
 if not list(reference.rglob('*.nav')):
  run_cli([str(viewer),'--input',str(vpk),'--vpk_filepath','maps/'+source+'.nav','--output',str(reference)+os.sep])
 pak=game/'pak01_dir.vpk'
 if pak.exists():
  paths=[('resource/overviews/'+source+'.txt',False),('panorama/images/overheadmaps/'+source+'_radar_psd.vtex_c',True)]
  if source in ['de_nuke','de_train','de_vertigo']:paths.append(('panorama/images/overheadmaps/'+source+'_lower_radar_psd.vtex_c',True))
  for resource_path,decompile in paths:
   command=[str(viewer),'--input',str(pak),'--vpk_filepath',resource_path,'--output',str(reference)+os.sep]
   if decompile:command+=['--decompile']
   run_cli(command)

def pack_existing(game,viewer,slug,target,output):
 game=normalize_game(game);target=Path(target).expanduser().resolve();output=Path(output).expanduser().resolve();source='de_'+slug.replace('-','_')
 if target==game or game in target.parents or output==game or game in output.parents:raise ValueError('Eksport CS2 papkasidan tashqarida bolishi kerak.')
 model=select_model(target,source);data=glb_json(model)
 if not data.get('meshes') or not data.get('materials') or not data.get('images'):raise ValueError('Asosiy model/material/teksturalar toliq emas: '+str(model))
 print('Asosiy model:',model,flush=True)
 selected={model.relative_to(target).as_posix():model}
 for entry in data.get('images',[])+data.get('buffers',[]):
  if 'uri' not in entry:continue
  uri=entry['uri'];decoded=unquote(uri)
  if urlsplit(uri).scheme or decoded.startswith('/') or '\\' in decoded or ':' in decoded:raise ValueError('Tashqi/yaroqsiz model resursi: '+uri)
  rel=posixpath.normpath(posixpath.join(model.parent.relative_to(target).as_posix(),decoded));path=target/rel
  if rel.startswith('../') or not path.is_file() or target not in path.resolve().parents:raise ValueError('Tekstura/buffer topilmadi: '+uri)
  selected[rel]=path
 session=target/'ARENA-session.json';client=client_version(game)
 if not client:raise ValueError('steam.inf ichidan CS2 ClientVersion topilmadi. Diagnostika faylini yuboring.')
 if session.exists():
  prior=json.loads(session.read_text())
  if prior.get('clientVersion')!=client:raise ValueError('CS2 versiyasi eksportdan keyin ozgargan. Mos xarita/nav versiyasini tanlang.')
 print('Model tayyor. Mavjud fayllar qayta render eksport qilinmaydi.',flush=True)
 add_reference(game,viewer,source,target)
 for path in (target/'reference').rglob('*'):
  if path.is_file():selected[path.relative_to(target).as_posix()]=path
 total=sum(p.stat().st_size for p in selected.values());files={}
 print('Tekshirish:',len(selected),'fayl,',round(total/1024/1024,1),'MiB',flush=True)
 for i,(name,path) in enumerate(sorted(selected.items()),1):
  files[name]=file_hash(path)
  if i==1 or i==len(selected) or i%max(1,len(selected)//20)==0:print('Tekshiruv:',i,'/',len(selected),flush=True)
 manifest={'schema':1,'map':slug,'sourceMap':source,'clientVersion':client,'versionEvidence':'export session metadata' if session.exists() else 'installed steam.inf at recovery time; original v2 had no session sidecar','exporter':'Source2Viewer-CLI20.1','coordinateSystem':'source2viewer-y-up-meters','model':model.relative_to(target).as_posix(),'files':files,'rights':'Original CS2/Valve or other map-owner assets; not MIT.','note':'Main visual scene; separate physics GLBs excluded. Source2 shaders/lighting may differ in glTF.'}
 output.mkdir(parents=True,exist_ok=True);base=output/('ARENA-'+target.name+'-CS2-visuals.zip');archive=base;number=1
 while archive.exists():number+=1;archive=base.with_name(base.stem+'-'+str(number)+'.zip')
 partial=archive.with_name(archive.name+'.'+datetime.datetime.now().strftime('%H%M%S%f')+'.part')
 with zipfile.ZipFile(partial,'w',zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
  for i,(name,path) in enumerate(sorted(selected.items()),1):
   z.write(path,name)
   if i==1 or i==len(selected) or i%max(1,len(selected)//20)==0:print('ZIP:',i,'/',len(selected),flush=True)
  z.writestr('ARENA-export.json',json.dumps(manifest,indent=2))
 print('ZIP yaxlitligi tekshirilmoqda...',flush=True)
 with zipfile.ZipFile(partial) as z:
  bad=z.testzip()
  if bad:raise ValueError('ZIP yaxlitligi xatosi: '+bad)
 partial.rename(archive)
 print('TAYYOR:',archive,flush=True);print('ZIP hajmi:',round(archive.stat().st_size/1024/1024,1),'MiB',flush=True)
 return archive

def export(game,viewer,maps,output,dry_run=False):
 game=normalize_game(game);viewer=Path(viewer).expanduser().resolve();output=Path(output).expanduser().resolve()
 if not viewer.is_file():raise ValueError('Source2Viewer-CLI fayli topilmadi: '+str(viewer))
 if output==game or game in output.parents:raise ValueError('Eksportni CS2 papkasidan tashqariga saqlang.')
 completed=[]
 for slug in maps:
  source='de_'+slug.replace('-','_');vpk=game/'maps'/(source+'.vpk')
  if not vpk.exists():print('Topilmadi, otkazildi:',vpk.name);continue
  target=free_target(output,slug)
  archive,resource=(vpk,'maps/'+source+'.vmap_c') if dry_run else world_resource(viewer,vpk,game/'pak01_dir.vpk',source)
  args=[str(viewer),'--input',str(archive),'--vpk_filepath',resource,'--decompile','--gltf_export_format','glb','--gltf_export_materials','--gltf_textures_adapt','--game',str(game/'gameinfo.gi'),'--output',str(target)+os.sep]
  print('Eksport:',slug,flush=True)
  if dry_run:print(subprocess.list2cmdline(args));completed.append(slug);continue
  target.mkdir(parents=True,exist_ok=True)
  (target/'ARENA-session.json').write_text(json.dumps({'schema':1,'map':slug,'clientVersion':client_version(game),'resource':resource}),encoding='utf-8')
  run_cli(args);pack_existing(game,viewer,slug,target,output);completed.append(slug)
 if not completed:raise ValueError('Tanlangan xaritalarning hech biri topilmadi.')
 return completed
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--game',required=True);parser.add_argument('--viewer');parser.add_argument('--maps',nargs='+',choices=MAPS,default=['dust2']);parser.add_argument('--output');parser.add_argument('--pack-existing');parser.add_argument('--dry-run',action='store_true');a=parser.parse_args()
 output=Path(a.output or (Path(a.pack_existing).expanduser().resolve().parent if a.pack_existing else Path(__file__).resolve().parent/'ARENA-CS2-exports')).expanduser().resolve();log_path=None
 try:
  game=normalize_game(a.game)
  if output==game or game in output.parents:raise ValueError('Eksportni CS2 papkasidan tashqariga saqlang.')
  output.mkdir(parents=True,exist_ok=True)
  stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');log_path=output/('ARENA-diagnostics-'+stamp+'.txt')
  with log_path.open('w',encoding='utf-8') as log:
   RUN_LOG=log;log.write('ARENA exporter v3 | Python '+sys.version+' | '+platform.platform()+'\nGAME: '+str(game)+'\nOUTPUT: '+str(output)+'\n')
   try:
    viewer=a.viewer or official_viewer()
    if a.pack_existing:
     if len(a.maps)!=1:raise ValueError('Mavjud papka uchun bitta xarita tanlang.')
     pack_existing(game,viewer,a.maps[0],a.pack_existing,output)
    else:export(game,viewer,a.maps,output,a.dry_run)
   except Exception as error:
    log.write('ERROR: '+str(error)+'\n');raise
   finally:RUN_LOG=None
  print('Yakunlandi. Diagnostika:',log_path,flush=True)
 except (ValueError,AssertionError,subprocess.CalledProcessError,OSError,zipfile.BadZipFile) as error:
  print('\nXATO:',error,flush=True)
  if log_path:print('Shu matn faylini yuboring:',log_path,flush=True)
  sys.exit(1)
