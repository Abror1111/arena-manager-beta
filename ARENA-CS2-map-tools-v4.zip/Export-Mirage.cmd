@echo off
cd /d "%~dp0"
echo ARENA - export one installed CS2 map and prepare upload parts
py -3 prepare-map-upload.py --map mirage
if errorlevel 1 echo XATO - See the message above and keep the diagnostics file.
echo.
pause
