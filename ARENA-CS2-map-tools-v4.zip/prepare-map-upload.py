"""Export one installed CS2 map and prepare chat-sized attachments. Python 3 only."""
import argparse
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
DEFAULT_GAME = r'E:\Steam Game\steamapps\common\Counter-Strike Global Offensive'
MAPS = ['mirage', 'inferno', 'nuke', 'train', 'ancient', 'anubis', 'overpass', 'vertigo', 'cache', 'ancient-night', 'dust2']


def prepare(game, slug, output, runner=subprocess.run):
    if slug not in MAPS:
        raise ValueError('Xarita nomi yaroqsiz.')
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    before = set(output.glob('ARENA-*-CS2-visuals*.zip'))
    result = runner([sys.executable, str(ROOT / 'export-cs2-visuals.py'), '--game', str(game), '--maps', slug, '--output', str(output)])
    if result.returncode:
        raise ValueError('Eksport tugamadi. ARENA-diagnostics-*.txt faylini chatga yuboring.')
    created = set(output.glob('ARENA-*-CS2-visuals*.zip')) - before
    if len(created) != 1:
        raise ValueError('Yangi tayyor ZIP aniq topilmadi. Diagnostika faylini yuboring.')
    archive = created.pop()
    spec = importlib.util.spec_from_file_location('arena_transfer', ROOT / 'cs2-transfer.py')
    transfer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transfer)
    transfer.split(archive, chunk_size=24 * 1024 * 1024)
    return archive.parent / (archive.stem + '-upload-parts')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--map', choices=MAPS)
    parser.add_argument('--game', default=DEFAULT_GAME)
    parser.add_argument('--output', type=Path, default=ROOT / 'ARENA-CS2-exports')
    args = parser.parse_args()
    slug = args.map
    if slug is None:
        for i, name in enumerate(MAPS, 1):
            print(str(i) + '. ' + name)
        number = int(input('Xarita raqamini kiriting: ').strip())
        if not 1 <= number <= len(MAPS):
            raise ValueError('Royxatdagi xarita raqamini kiriting.')
        slug = MAPS[number - 1]
    print('ARENA: ' + slug + ' eksporti va 24 MiB bolaklar', flush=True)
    print('CS2 papkasi: ' + args.game, flush=True)
    if not Path(args.game).exists():
        args.game = input('CS2 papkasining toliq yolini kiriting: ').strip().strip('"')
    parts = prepare(args.game, slug, args.output)
    print('\nTAYYOR: ' + str(parts), flush=True)
    print('Chatga ARENA-upload-manifest.json va dastlabki 5 ta ZIP bolakni yuboring.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, IndexError, KeyboardInterrupt) as error:
        print('\nXATO: ' + str(error), flush=True)
        sys.exit(1)
