"""Lossless CS2 ZIP transfer in small, valid ZIP attachments. Python3 stdlib."""
from pathlib import Path
import argparse,hashlib,json,math,os,struct,sys,tempfile,zipfile
BLOCK=1024*1024;MAX_CHUNK=30*BLOCK

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(BLOCK),b''):h.update(b)
 return h.hexdigest()

def atomic_json(path,value):
 path=Path(path)
 with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=path.parent,delete=False) as f:
  tmp=Path(f.name);json.dump(value,f,indent=2)
 try:os.replace(tmp,path)
 finally:tmp.unlink(missing_ok=True)

def metadata_valid(m):
 if m.get('schema')!=1 or m.get('format')!='arena-chunk-zip-v1':raise ValueError('Unknown transfer format')
 for key in ['sourceSHA256','chunkSHA256']:
  if not isinstance(m.get(key),str) or len(m[key])!=64 or any(c not in '0123456789abcdef' for c in m[key]):raise ValueError('Invalid hash')
 for key in ['index','count','sourceBytes','chunkBytes','chunkSize']:
  if type(m.get(key)) is not int or m[key]<=0:raise ValueError('Invalid size/index')
 if m['chunkSize']>MAX_CHUNK or m['count']!=math.ceil(m['sourceBytes']/m['chunkSize']) or not 1<=m['index']<=m['count']:raise ValueError('Invalid chunk layout')
 expected=min(m['chunkSize'],m['sourceBytes']-(m['index']-1)*m['chunkSize'])
 if m['chunkBytes']!=expected:raise ValueError('Chunk length mismatch')
 if m['count']>10000 or m['sourceBytes']>100*1024**3:raise ValueError('Transfer too large')
 name=m.get('sourceName')
 if not isinstance(name,str) or len(name)>180 or '/' in name or '\\' in name or ':' in name or not name.lower().endswith('.zip'):raise ValueError('Invalid archive name')
 return m

def split(source,output=None,chunk_size=24*BLOCK):
 source=Path(source).expanduser().resolve()
 if not source.is_file() or not source.name.lower().endswith('.zip'):raise ValueError('Asl ZIP topilmadi: '+str(source))
 if not 1<=chunk_size<=MAX_CHUNK:raise ValueError('Chunk size must be1..30MiB')
 size=source.stat().st_size
 if not size:raise ValueError('ZIP bosh')
 output=Path(output).expanduser().resolve() if output else source.parent/(source.stem+'-upload-parts')
 output.mkdir(parents=True,exist_ok=True)
 print('1/2 Asl ZIP tekshirilmoqda:',round(size/BLOCK,1),'MiB',flush=True);whole=digest(source);count=math.ceil(size/chunk_size);parts=[]
 print('2/2 Bolaklar yozilmoqda:',count,'ta. Asl ZIP saqlanadi.',flush=True)
 with source.open('rb') as f:
  for index in range(1,count+1):
   name=f'ARENA-part-{index:03d}-of-{count:03d}.zip';dest=output/name;need=min(chunk_size,size-(index-1)*chunk_size);h=hashlib.sha256()
   with tempfile.NamedTemporaryFile(dir=output,suffix='.part',delete=False) as t:tmp=Path(t.name)
   try:
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
     with z.open('chunk.bin','w',force_zip64=True) as inner:
      left=need
      while left:
       b=f.read(min(BLOCK,left))
       if not b:raise ValueError('Asl ZIP hajmi jarayonda ozgardi')
       inner.write(b);h.update(b);left-=len(b)
     m={'schema':1,'format':'arena-chunk-zip-v1','sourceName':source.name,'sourceBytes':size,'sourceSHA256':whole,'chunkSize':chunk_size,'index':index,'count':count,'chunkBytes':need,'chunkSHA256':h.hexdigest()}
     z.writestr('part.json',json.dumps(m,sort_keys=True))
    if dest.exists():
     if digest(dest)!=digest(tmp):
      # ZIP metadata timestamps differ on retries; compare payload/metadata instead.
      with zipfile.ZipFile(dest) as old:
       if set(old.namelist())!={'chunk.bin','part.json'} or json.loads(old.read('part.json'))!=m:raise ValueError('Boshqa bolaklar bor. Yangi --output papkasini tanlang.')
       with old.open('chunk.bin') as stream:
        check=hashlib.sha256()
        for b in iter(lambda:stream.read(BLOCK),b''):check.update(b)
       if check.hexdigest()!=m['chunkSHA256']:raise ValueError('Oldingi bolak shikastlangan. Yangi --output papkasini tanlang.')
    else:tmp.rename(dest)
    if dest.stat().st_size>=32*BLOCK:raise ValueError('Attachment limit exceeded')
    parts.append({'file':name,'index':index,'bytes':need,'sha256':m['chunkSHA256']});print('Tayyor:',index,'/',count,name,flush=True)
   finally:tmp.unlink(missing_ok=True)
  if f.read(1):raise ValueError('Asl ZIP hajmi jarayonda ozgardi')
 if digest(source)!=whole:raise ValueError('Asl ZIP jarayonda ozgargan, bolaklarni yubormang.')
 manifest={'schema':1,'format':'arena-chunk-zip-v1','sourceName':source.name,'sourceBytes':size,'sourceSHA256':whole,'chunkSize':chunk_size,'count':count,'parts':parts}
 atomic_json(output/'ARENA-upload-manifest.json',manifest)
 print('YAKUNLANDI:',output,flush=True);print('Avval ARENA-upload-manifest.json va1-5 ZIP bolaklarni yuboring.',flush=True)
 return manifest

def receive(parts,cache):
 cache=Path(cache).resolve();cache.mkdir(parents=True,exist_ok=True);touched=set()
 for archive in parts:
  with zipfile.ZipFile(archive) as z:
   names=z.namelist()
   if len(names)!=2 or set(names)!={'chunk.bin','part.json'}:raise ValueError('Unexpected wrapper files')
   if z.getinfo('part.json').file_size>16000:raise ValueError('Metadata too large')
   m=metadata_valid(json.loads(z.read('part.json')))
   if z.getinfo('chunk.bin').file_size!=m['chunkBytes']:raise ValueError('Payload length mismatch')
   folder=cache/m['sourceSHA256'];folder.mkdir(exist_ok=True);meta=folder/'transfer.json'
   base={k:m[k] for k in ['schema','format','sourceName','sourceBytes','sourceSHA256','chunkSize','count']}
   if meta.exists() and json.loads(meta.read_text())!=base:raise ValueError('Mixed transfer metadata')
   target=folder/f'chunk-{m["index"]:05d}.bin';h=hashlib.sha256();length=0
   with tempfile.NamedTemporaryFile(dir=folder,delete=False) as t:tmp=Path(t.name)
   try:
    with z.open('chunk.bin') as inp,tmp.open('wb') as out:
     for b in iter(lambda:inp.read(BLOCK),b''):
      length+=len(b)
      if length>m['chunkBytes']:raise ValueError('Payload exceeds declared size')
      h.update(b);out.write(b)
    if length!=m['chunkBytes'] or h.hexdigest()!=m['chunkSHA256']:raise ValueError('Corrupt chunk')
    if target.exists():
     if digest(target)!=m['chunkSHA256']:raise ValueError('Conflicting cached chunk')
    else:tmp.rename(target)
    atomic_json(meta,base);atomic_json(folder/f'chunk-{m["index"]:05d}.json',m);touched.add(folder)
   finally:tmp.unlink(missing_ok=True)
 result=[]
 for folder in sorted(touched):
  m=json.loads((folder/'transfer.json').read_text());missing=[i for i in range(1,m['count']+1) if not (folder/f'chunk-{i:05d}.bin').is_file()];record={'sha256':m['sourceSHA256'],'received':m['count']-len(missing),'count':m['count'],'missing':missing}
  if not missing:
   dest=folder/m['sourceName']
   if not dest.exists():
    with tempfile.NamedTemporaryFile(dir=folder,delete=False) as t:tmp=Path(t.name)
    try:
     h=hashlib.sha256();size=0
     with tmp.open('wb') as out:
      for index in range(1,m['count']+1):
       part=folder/f'chunk-{index:05d}.bin';expected=json.loads((folder/f'chunk-{index:05d}.json').read_text())['chunkSHA256'];chunk_hash=hashlib.sha256()
       with part.open('rb') as inp:
        for b in iter(lambda:inp.read(BLOCK),b''):out.write(b);h.update(b);chunk_hash.update(b);size+=len(b)
       if chunk_hash.hexdigest()!=expected:raise ValueError('Cached part changed')
     if size!=m['sourceBytes'] or h.hexdigest()!=m['sourceSHA256']:raise ValueError('Reassembled ZIP hash mismatch')
     with zipfile.ZipFile(tmp) as z:
      if len(z.infolist())>12000 or sum(i.file_size for i in z.infolist())>2*1024**3:raise ValueError('CS2 archive exceeds import limits')
      if z.testzip():raise ValueError('Original archive CRC failure')
     tmp.rename(dest)
    finally:tmp.unlink(missing_ok=True)
   elif digest(dest)!=m['sourceSHA256']:raise ValueError('Existing assembled archive mismatch')
   record['archive']=str(dest);record['verified']=True
  result.append(record)
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True);a=sub.add_parser('split');a.add_argument('--input',required=True);a.add_argument('--output');a.add_argument('--chunk-mib',type=int,default=24);a=sub.add_parser('receive');a.add_argument('--cache',required=True);a.add_argument('parts',nargs='+');args=p.parse_args()
 try:
  if args.command=='split':split(args.input,args.output,args.chunk_mib*BLOCK)
  else:print(json.dumps(receive(args.parts,args.cache),indent=2))
 except (ValueError,OSError,zipfile.BadZipFile) as error:print('XATO:',error,flush=True);sys.exit(1)
