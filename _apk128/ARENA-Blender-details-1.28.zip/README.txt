ARENA1.28 — Blender architectural modules

Open ARENA-CS2-detail128.blend in Blender4.3 or later.
The catalog contains44 editable modules in11 setting columns and four type rows.
These are the new architectural detail models. The game retains its supplied
CS2 base scenes and assigns their textures to the modules at runtime.
The included preview demonstrates that runtime material assignment.
Source CS2 map geometry/textures are not embedded in this Blender catalog.
Run scripts/build-detail-kit128.py to regenerate the editable library.
