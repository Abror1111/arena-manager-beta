import collision from './environment132-collisions.json' with {type:'json'};
import images from './environment132-images.json' with {type:'json'};
import kit from './environment132-kit.json' with {type:'json'};
import textures from './environment132-textures.json' with {type:'json'};
import {environmentProfile} from './environment-profiles132.js';
export function environmentAssets(map){const family=environmentProfile(typeof map==='string'?{id:map}:map).family;const id=typeof map==='string'?map:map.id;return[collision.maps[id],images.maps[id],kit.library,...Object.values(textures.families[family]).flatMap(role=>Object.values(role))];}
