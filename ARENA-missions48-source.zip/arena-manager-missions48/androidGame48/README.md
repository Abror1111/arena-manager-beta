# ARENA Preview 1.48 — Android game host

Application ID `uz.arena.manager.preview`, versionCode148, minSDK26, targetSDK35. Debug-signed test APK; the same preview app and signing certificate as1.47; it can update that version. Only Internet permission; no ad or billing SDK in this host. Source android45 remains an inactive integration foundation. Physical Android installation has not been tested here.

Sandrift 3D plus all 11 navigation/collision maps, runtime audio/music, original portraits and covers are bundled. Other 3D worlds download into the verified game cache on first access. If a 3D world cannot load, 2D remains available. Secure virtual HTTPS origin and native resource routing support web crypto/cache without file-URL access. Restricted navigation, CSP, no cleartext or third-party cookies. Back/pause/cutout handling and Android document export/import bridge are included.

To build: Java17+, Android SDK35/build-tools35.0.0, Gradle8.11.1. Set ANDROID_HOME or local.properties. Obtain the published preview asset bundle with `python tools/restore-apk-assets48.py` from the repository root; its reference and SHA are in androidGame48/preview-apk48.json. This verifies the APK archive and extracts only assets/public. Alternatively prepare the same paths from android-assets48.json and pinned web assets. Native compressed-data aliases deliberately use `.dat`: AAPT rewrites `.gz` assets otherwise. Build the web using root README and copy it to app/src/main/assets/public/arena-manager-beta/remix31 when changing JS.

Generate your own development key (private, never commit) and pass its path with `gradle :app:assembleDebug -PpreviewKey48=/absolute/path/preview48.keystore`. The configured debug alias/password match standard Android debug keys. This key cannot update the distributed preview signed with another key; uninstalling loses local data, so export backup first. Production Play signing is intentionally unconfigured.

The source archive omits generated assets, Gradle caches/build output, SDK path configuration and private keys. assets48.json records exact bundled hashes. Verification includes APK ZIP CRC, per-asset byte hashes, aapt package/permissions, apksigner signature, plus browser simulation of extracted actual assets. No physical device or frame-rate claim.

Both original product/emblem art atlases are bundled and tested offline. Premium missions use earned stars/pass and local game events; no real billing SDK activated.
