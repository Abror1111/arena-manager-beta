import React,{useState}from'react';
import{Commerce45,ShopTabs45}from'./Commerce45.jsx';
import{PortraitProvider44}from'./Portrait44.jsx';
import*as C from'./career.js';
export function StoreLab46({onExit}){
 const[c,setC]=useState(()=>{const c=C.enableSandbox45(C.createCareer());c.roster[0].energy=70;return c}),[kind,setKind]=useState('market'),[notice,setNotice]=useState('');
 const commit=f=>{try{const n=f(c);setC(n);setNotice('');return n}catch(e){setNotice(e.message);return null}};
 return <PortraitProvider44 roster={c.roster} frame={c.commerce45?.frame}><div className="career-app store-lab46" data-theme="violet"><header className="career-header"><strong>ARENA · SINOV LABORATORIYASI</strong><button onClick={onExit}>Asosiy klubga qaytish</button></header><main className="career-content" style={{gridColumn:'1 / -1'}}><div className="screen-heading"><div><span className="eyebrow">ALOHIDA VAQTINCHALIK KLUB</span><h1>Market sinovi</h1></div></div><p className="economy-note">Bu yerdagi xaridlar asosiy jamoa, hamyon yoki saqlangan o‘yinga yozilmaydi. Chiqilganda sinov holati tozalanadi.</p><ShopTabs45 kind={kind} setKind={setKind}/>{notice&&<p role="alert">{notice}</p>}<Commerce45 career={c} commit={commit} locked={false} kind={['theme','crest'].includes(kind)?'market':kind}/></main><footer className="career-footer"><span>PUL YECHILMAYDI · FAQAT NAMUNA</span><span>1.48 BETA</span></footer></div></PortraitProvider44>;
}
