import{ART48_PREFIX}from'./art-origin48.js';
import{REWARD45_PREFIX}from'./reward-origin45.js';
import{PORTRAIT44_PREFIX}from'./portrait-origin44.js';
import{MUSIC40_PREFIX}from'./music-origin40.js';
import{COVER39_PREFIX}from'./cover-origin39.js';
import {CONTEXT_ASSET_PREFIX} from './approved/context-origin.js';
import {HD_ASSET_PREFIX} from './approved/hd-origin.js';
import {ENVIRONMENT_ASSET_PREFIX} from './environment-origin132.js';
import {REBUILT_ASSET_PREFIX} from './rebuilt-asset-origin.js';
import {createAssetStore} from './asset-store.js';
export const packaged=!!globalThis.window?.ArenaAndroid;
let store;
export function assetStore(){
 if(!store){let storage;try{storage=globalThis.caches;}catch{}
  store=createAssetStore({baseURL:location.href,fetcher:fetch.bind(globalThis),storage,packaged,memoryLimit:16*1024**2,externalPrefixes:[ART48_PREFIX,REWARD45_PREFIX,PORTRAIT44_PREFIX,MUSIC40_PREFIX,COVER39_PREFIX,REBUILT_ASSET_PREFIX,ENVIRONMENT_ASSET_PREFIX,CONTEXT_ASSET_PREFIX,HD_ASSET_PREFIX].filter(Boolean),hash:async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('')});
 }
 return store;
}
export const loadAsset=(entry,options)=>assetStore().get(packaged&&entry.localUrl?{...entry,url:entry.localUrl}:entry,options);
