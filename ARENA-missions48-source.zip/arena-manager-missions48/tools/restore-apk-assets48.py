"""Restore exact generated assets from the public signed preview; never extracts code/keys."""
from pathlib import Path
import json,urllib.request,hashlib,zipfile,io
root=Path(__file__).resolve().parents[1];meta=json.loads((root/'androidGame48/preview-apk48.json').read_text())
with urllib.request.urlopen(meta['url'],timeout=180)as response:data=response.read(100*1024**2)
assert len(data)==meta['bytes']and hashlib.sha256(data).hexdigest()==meta['sha256'],'APK hash mismatch'
expected=json.loads((root/'androidGame48/assets48.json').read_text())['assets'];dest=root/'androidGame48/app/src/main/assets/public'
with zipfile.ZipFile(io.BytesIO(data))as z:
 assert z.testzip()is None
 for name,entry in expected.items():
  assert not Path(name).is_absolute()and'..'not in Path(name).parts
  body=z.read('assets/public/'+name);assert len(body)==entry['bytes']and hashlib.sha256(body).hexdigest()==entry['sha256'],name
  f=dest/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(body)
print('Verified and restored',len(expected),'bundled assets; own development signing key still required')
