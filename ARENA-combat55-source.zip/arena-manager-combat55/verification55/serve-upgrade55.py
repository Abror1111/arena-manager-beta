from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote,urlsplit
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  path=unquote(urlsplit(path).path);prefix='/arena-manager-beta/remix31/'
  if path.startswith(prefix):
   old=Path('/dev/shm/arena-combat55-tests/upgrade-version.txt').read_text().strip()=='54'
   return str(Path('/dev/shm/arena-manager-newgame54-web' if old else '/dev/shm/arena-manager-combat55-web')/path[len(prefix):])
  if path.startswith('/arena-manager-beta/'):return str(Path('/dev/shm/arena-pages53')/path[len('/arena-manager-beta/'):])
  return '/dev/shm/no-such-file'
ThreadingHTTPServer(('0.0.0.0',8283),H).serve_forever()
