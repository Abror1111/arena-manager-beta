import*as C from'./career.js';
// Do not leave the completed match until its result really reaches persistent storage.
export function saveMatchResult55(storage,career,snapshot){if(!career.pending)throw Error('Saqlanadigan uchrashuv topilmadi. Klubga qayting.');const next=C.completeMap(career,snapshot);C.validateCareer(next);if(!C.saveCareer(storage,next))throw Error('Natija qurilmaga yozilmadi. Joy bo‘shating va qayta saqlang. Jang hali yopilmadi.');return next}
