# ARENA Preview1.50 Android host

ApplicationID uz.arena.manager.preview, versionCode150, minSDK26/targetSDK35. Same preview ID/certificate as1.49; update is supported. Debugsigned test APK, Internetpermission only. No billing/ad SDKactivation. Physical installation/FPS not measured here.

Sandrift3D, all11navigation/collisions, audio/music/portraits/covers, five illustrated art atlases and licensedManropefont bundled. Other3Dworlds download into verified cache on firstaccess.2D fallback remains. Secure virtualHTTPSorigin, restrictednative routing/CSP, no cleartext, native backupimport/export bridge and lifecycle/cutout support retained.

Build: Java17+, SDK35/buildtools35.0.0, Gradle8.11.1. Configure ANDROID_HOME or local.properties. From sourceroot run `python tools/restore-apk-assets50.py` to restore exact generated publicassets from SHA-verified publishedAPK (assets50.json/preview-apk50.json). Compresseddata uses .dat because AAPT rewrites .gz. Web build directions in rootREADME.

Use your private development key with `gradle :app:assembleDebug -PpreviewKey50=/absolute/path/preview50.keystore` (standard Android debugalias/password). Different key cannot update distributedpreview; export backup before uninstalling. Production Play signing unconfigured. No private keys/generated assets/build/caches/SDKpaths in sourcearchive. Verification includes package/signature,ZIPCRC,98assetSHA and browser simulation of extractedAPKofflinefont/portraits/market/missions/3Dbattle. This is not physicalAndroidtesting.
