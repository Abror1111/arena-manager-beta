# ARENA Manager1.50 — Portrait geometry and interface polish

Portret UI rebuilt around one normalized100x120SVGcomposition (round map markers use100x100). Square atlas cell is rendered into the actual frame aperture with proportional crop; outer frame preserves aspect ratio. Original49background-behind-a-clip magnification and aspect stretching removed. Cell edges inset1pixel avoid neighboring portraits. Transparent frame component embedded as SVGgroup, with silhouette mask on celestial frame to remove neighboring atlas ornament tips. Original72faces/identityslots/ownership retained.

Stable5:6portrait sizes: general transfer/tutorial80x96; squad/home75x90desktop and70x84phone,50x60shortlandscape; frame gallery110x132; actualbattle40x48desktop,30x36phone. Round3Dworldlabels show the same identity as clear headshots without tiny unreadable ornate frames. OVR chip sits beside the portrait; role text no longer covers the image. Actual collection/menu/battle share composition.

Licensed variable Manrope font (unmodified24836byteWOFF2, SILOpenFontLicense1.1 bundled) loaded using same SHA-verified asset store. Immutable font/art50provenance on arena-polish50-art; fallback systemfont remains usable on failure, cached font works offline and is bundled in APK. No external fontstylesheet/CDNcall at runtime.

Whole-app typography polished:750weight headings, restrained spacing,12pxbody/labels, tabular digits, clearer roles/playernames, consistent lineheights and numerical rhythm. Larger legible captions and touch targets, visible focus/disabled/pressed states. Semantic energy/dangercolors, calmer navigation, reduced illustrative overlay opacity and refined skillbars preserve5clubmaterialskins. Existing adaptive horizontal layout remains; shop/transfers remain the only vertical listscrollers.

71Node tests and prior custom regression chain complete. Whole-app browser50checks10screens×5viewports, all5themes/eightframes/free re-equip/36icons/real3Dbattle and offline. Dedicated details50checks loaded licensedfont, equal X/Yportraitscale and5:6proportions atfivewidths, proportional aperturecrop, and normaltext/secondarytext/primarybutton contrast >=4.5:1onall5palette basepanelcolors. This contrast test does not claim a complete accessibility audit of every overlaid map pixel.

Actual49ServiceWorker20→50ServiceWorker21 upgrade: new inline style/font/portraits usable on firstnavigation while oldworker controls; saved earnedwallet unchanged; then offline reload with cachedfont passes. Fresh tutorial/browser checks remain. Android150sameID/certificate as149:ZIPCRC/package/99bundledassetSHA and extractedAPKoffline browser test covernewfont/portraitcomposition/market/missions/actualSandrift3D/checkpointresume. No physicaldeviceinstallation or FPSclaim.

Coremaps/combat/audio/economy/missionbalances and priorclubownership retained. Protected28published+209parent sources+workingcasebot preserved. SourceZIP carries fullhistory, originalart and fontlicense/provenance; generatedAPKassets/caches/privatekeys omitted. Other3Dworlds needfirstdownload/cache. No livebilling/ads or maprights-clearance claim.

Build: Node22+/Python3; install exact package.jsondependencies; `npm test`; `ARENA_MANAGER_OUT=/tmp/arena50-web npm run build`; `python pack-web31.py /tmp/arena50-web`. Serve under /arena-manager-beta/remix31/ with existing sharedrootassets. Archive rebuild byte-identical. See verification50 for fullscripts/screenshots/proofs. ScriptRAMpaths need adapting locally.

Android: androidGame50/README.md, tools/restore-apk-assets50.py. Prior history/source: https://github.com/Abror1111/arena-manager-beta/tree/arena-visual49-source .
