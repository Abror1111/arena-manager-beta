from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote,urlsplit
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  path=unquote(urlsplit(path).path);prefix='/arena-manager-beta/remix31/'
  if path.startswith(prefix):
   root=Path('/dev/shm/arena-manager-polish50-web');return str(root/path[len(prefix):])
  if path.startswith('/arena-manager-beta/'):return str(Path('/dev/shm/arena-pages32')/path[len('/arena-manager-beta/'):])
  return '/dev/shm/no-such-file'
ThreadingHTTPServer(('0.0.0.0',8272),H).serve_forever()
