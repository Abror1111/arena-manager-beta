@echo off
setlocal
cd /d "%~dp0"
echo ARENA - Export CT and T agents with skins and available animations
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 "%~dp0export-cs2-agents.py"
goto done
:usepython
python "%~dp0export-cs2-agents.py"
:done
echo.
echo Keep the diagnostics file if an error appeared above.
pause
