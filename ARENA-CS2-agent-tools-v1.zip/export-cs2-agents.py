"""Export a CT/T pair, their skins and available animation clips from installed CS2."""
import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import posixpath
import re
import sys
from urllib.parse import unquote, urlsplit
import zipfile

ROOT = Path(__file__).resolve().parent


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


e = module('arena_map_exporter', 'export-cs2-visuals.py')
transfer = module('arena_transfer', 'cs2-transfer.py')


def agent_models(listing):
    paths = re.findall(r'(?im)(?:^|\s)((?:[a-z0-9_.-]+/)+[a-z0-9_.-]+\.vmdl_c)(?=\s|$)', listing.replace('\\', '/'))
    return sorted(set(p for p in paths if p.lower().startswith(('agents/models/', 'characters/models/'))
                      and re.fullmatch(r'(?:ctm|tm)_[a-z0-9_]+', Path(p).stem, re.I)
                      and not any(t in Path(p).stem.lower() for t in ['_arms', '_gloves', '_sleeves', '_legs', '_head'])))


def choose_pair(paths):
    result = []
    for side, prefix, preferred in [('CT', 'ctm_', ['ctm_sas', 'ctm_swat', 'ctm_st6']),
                                    ('T', 'tm_', ['tm_phoenix', 'tm_leet', 'tm_balkan'])]:
        candidates = [p for p in paths if Path(p).stem.lower().startswith(prefix)]
        if not candidates:
            raise ValueError(side + ' agent modeli topilmadi. Diagnostika faylini yuboring.')
        candidates.sort(key=lambda p: (preferred.index(Path(p).stem.lower()) if Path(p).stem.lower() in preferred else 99, len(p), p))
        result.append((side, candidates[0]))
    return result


def inspect_model(path, require_materials=True):
    data = e.glb_json(path)
    if not data.get('meshes') or not data.get('skins') or not any(s.get('joints') for s in data['skins']):
        raise ValueError('Skeletli agent modeli topilmadi: ' + str(path))
    if not any('JOINTS_0' in p.get('attributes', {}) and 'WEIGHTS_0' in p['attributes']
               for m in data['meshes'] for p in m.get('primitives', [])):
        raise ValueError('Agentning skelet ogirliklari topilmadi: ' + str(path))
    if require_materials and (not data.get('materials') or not data.get('images')):
        raise ValueError('Agent teksturalari toliq eksport qilinmadi: ' + str(path))
    return data


def dependencies(root, model, data):
    root, model = Path(root).resolve(), Path(model).resolve()
    selected = {model.relative_to(root).as_posix(): model}
    for entry in data.get('images', []) + data.get('buffers', []):
        if 'uri' not in entry:
            continue
        uri, decoded = entry['uri'], unquote(entry['uri'])
        if urlsplit(uri).scheme or decoded.startswith('/') or '\\' in decoded or ':' in decoded:
            raise ValueError('Yaroqsiz agent resursi: ' + uri)
        name = posixpath.normpath(posixpath.join(model.parent.relative_to(root).as_posix(), decoded))
        path = root / name
        if name.startswith('../') or not path.is_file() or root not in path.resolve().parents:
            raise ValueError('Agent teksturasi/bufferi topilmadi: ' + uri)
        selected[name] = path
    return selected


def pack_agents(root, models, client_version, archive):
    root, archive = Path(root).resolve(), Path(archive).resolve()
    if archive.exists():
        raise ValueError('Tayyor arxiv saqlanadi. Yangi fayl nomini tanlang.')
    selected, agents = {}, []
    for side, resource, model in models:
        data = inspect_model(model)
        selected.update(dependencies(root, model, data))
        agents.append({'side': side, 'sourceResource': resource, 'model': model.relative_to(root).as_posix(),
                       'skins': len(data['skins']), 'joints': max(len(s['joints']) for s in data['skins']),
                       'materials': len(data['materials']), 'images': len(data['images']),
                       'animationNames': [a.get('name', '') for a in data.get('animations', [])]})
    if len(agents) != 2 or {a['side'] for a in agents} != {'CT', 'T'}:
        raise ValueError('Bitta CT va bitta T agenti kerak.')
    manifest = {'schema': 1, 'assetType': 'agents', 'clientVersion': client_version,
                'coordinateSystem': 'source2viewer-y-up-meters', 'exporter': 'Source2Viewer-CLI20.1',
                'agents': agents, 'files': {name: e.file_hash(path) for name, path in sorted(selected.items())},
                'rights': 'Original CS2/Valve assets; not MIT.',
                'note': 'Available clips are retained. Missing animation graphs are reported in the diagnostics; no animation clips are fabricated.'}
    partial = archive.with_name(archive.name + '.partial')
    if partial.exists():
        raise ValueError('Oldingi vaqtincha arxiv saqlanadi. Yangi papka tanlang.')
    with zipfile.ZipFile(partial, 'w', zipfile.ZIP_DEFLATED, compresslevel=1, allowZip64=True) as z:
        for index, (name, path) in enumerate(sorted(selected.items()), 1):
            z.write(path, name)
            if index == 1 or index == len(selected) or index % 10 == 0:
                print('Agent ZIP:', index, '/', len(selected), flush=True)
        z.writestr('ARENA-agent-export.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(partial) as z:
        bad = z.testzip()
        if bad:
            raise ValueError('ZIP yaxlitligi xatosi: ' + bad)
    partial.rename(archive)
    return manifest


def export_agents(game, viewer, output):
    game, output = e.normalize_game(game), Path(output).resolve()
    if output == game or game in output.parents:
        raise ValueError('Eksport CS2 papkasidan tashqarida bolishi kerak.')
    client = e.client_version(game)
    if not client:
        raise ValueError('CS2 ClientVersion topilmadi.')
    pak = game / 'pak01_dir.vpk'
    if not pak.is_file():
        raise ValueError('pak01_dir.vpk topilmadi: ' + str(pak))
    listing = e.run_cli([str(viewer), '--input', str(pak), '--vpk_list', '--vpk_extensions', 'vmdl_c'], capture=True)
    paths = agent_models(listing)
    print('Topilgan agent modellari:', len(paths), flush=True)
    pair = choose_pair(paths)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    target = output / ('agents-' + stamp)
    target.mkdir(parents=True)
    models = []
    for side, resource in pair:
        dest = target / side.lower()
        dest.mkdir()
        print('Eksport:', side, resource, flush=True)
        e.run_cli([str(viewer), '--input', str(pak), '--vpk_filepath', resource, '--decompile',
                   '--gltf_export_format', 'glb', '--gltf_export_materials', '--gltf_textures_adapt',
                   '--gltf_export_animations', '--gltf_compose_additive', '--game', str(game / 'gameinfo.gi'),
                   '--output', str(dest) + os.sep])
        expected = Path(resource).stem
        candidates = [p for p in dest.rglob('*.glb') if p.stem.lower() == expected.lower()]
        if len(candidates) != 1:
            raise ValueError('Asosiy agent GLB aniq topilmadi: ' + resource)
        data = inspect_model(candidates[0])
        print(side, 'skeletlar:', len(data['skins']), 'animatsiyalar:', len(data.get('animations', [])), flush=True)
        if not data.get('animations'):
            print('ESLATMA: Bu modelda klip topilmadi. Skelet saqlanadi; diagnostikani ham yuboring.', flush=True)
        models.append((side, resource, candidates[0]))
    archive = output / ('ARENA-CS2-agents-' + stamp + '.zip')
    manifest = pack_agents(target, models, client, archive)
    upload = transfer.split(archive, chunk_size=24 * 1024 * 1024)
    parts = archive.parent / (archive.stem + '-upload-parts')
    upload.update({'assetType': 'agents', 'clientVersion': client, 'agents': manifest['agents']})
    transfer.atomic_json(parts / 'ARENA-upload-manifest.json', upload)
    print('TAYYOR:', parts, flush=True)
    print('Agentlar:', ', '.join(a['side'] + ': ' + str(len(a['animationNames'])) + ' klip' for a in manifest['agents']), flush=True)
    print('ARENA-upload-manifest.json va dastlabki 5 ZIP bolakni chatga yuboring.', flush=True)
    return archive


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--game', default=r'E:\Steam Game\steamapps\common\Counter-Strike Global Offensive')
    p.add_argument('--viewer')
    p.add_argument('--output', type=Path, default=ROOT / 'ARENA-CS2-exports')
    a = p.parse_args()
    if not Path(a.game.strip('"')).exists():
        a.game = input('CS2 papkasining toliq yolini kiriting: ').strip().strip('"')
    game, output = e.normalize_game(a.game), a.output.resolve()
    if output == game or game in output.parents:
        raise ValueError('Eksport CS2 papkasidan tashqarida bolishi kerak.')
    output.mkdir(parents=True, exist_ok=True)
    log_path = output / ('ARENA-agents-diagnostics-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '.txt')
    print('Diagnostika:', log_path, flush=True)
    with log_path.open('w', encoding='utf-8') as log:
        e.RUN_LOG = log
        log.write('ARENA agent exporter v1\nGAME: ' + str(game) + '\n')
        try:
            viewer = a.viewer or e.official_viewer()
            export_agents(game, viewer, output)
        except Exception as error:
            log.write('ERROR: ' + str(error) + '\n')
            print('Shu diagnostika faylini yuboring:', log_path, flush=True)
            raise
        finally:
            e.RUN_LOG = None


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, AssertionError, zipfile.BadZipFile, KeyboardInterrupt) as error:
        print('XATO:', error, flush=True)
        sys.exit(1)
