ARENA - asl CS2 CT/T agentlari v1

1. ZIPni yangi papkaga toliq oching (Извлечь все). ZIP ichidan ishga tushirmang.
2. Export-Agents.cmd ni ikki marta bosing.
3. Dastur CS2ni E:\Steam Game\steamapps\common\Counter-Strike Global Offensive manzilidan oladi. Manzil ozgargan bolsa yangisini soraydi.
4. Asl bitta CT va bitta T modeli avtomatik tanlanadi. Skelet, tekstura va mavjud animatsiyalar birga eksport qilinadi. Oynada har bir agent uchun animatsiyalar soni chiqadi. Klip topilmasa bu ham yoziladi, diagnostikani saqlang.
5. ZIP va 24 MiB bolaklar avtomatik tayyorlanadi. TAYYOR yozuvini kuting.
6. ARENA-CS2-exports ichidagi ARENA-CS2-agents-...-upload-parts papkasini oching.
7. Chatga ARENA-upload-manifest.json va dastlabki 5 ta ARENA-part-...zip yuboring. Jami 5 tadan kam bolsa barcha bolaklarni yuboring.
8. Qolgan bolaklarni keyingi xabarlarda yuboring. Agent va xarita bolaklarini alohida xabarlarda yuboring.
9. Xato bolsa ARENA-CS2-exports ichidagi eng yangi ARENA-agents-diagnostics-*.txt faylini yuboring. Qora oyna tugma bosmaguncha yopilmaydi.

Python3 va ornatilgan CS2 kerak. Rasmiy Source2Viewer-CLI20.1 yuklanadi va SHA256 tekshiriladi. Avvalgi eksport va CS2 oyin fayllari saqlanadi. Faqat tanlangan 2 agent va ularga bogliq tekstura/animatsiyalar olinadi; butun Steam papkasi yuklanmaydi.

Bu yordamchi faqat eksport tayyorlaydi. Agentlar hali ARENA ichiga qoshilmagan: fayllar yuborilgach, skelet va animatsiyalar moslanadi va telefonga optimallashtiriladi.

Xaritalar uchun alohida ARENA-CS2-map-tools-v4.zip yordamchisini ishlating. Export-Mirage.cmd - Mirage, Choose-Map.cmd - boshqa ornatilgan xaritani tanlash. Avvalgi Dust II tayyor, uni qayta yuborish kerak emas.
