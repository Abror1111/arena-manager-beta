"""ARENA-authored PBR surfaces from mathematical height fields, no source images."""
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image
import json,hashlib,io
R=Path(__file__).resolve().parents[1];OUT=R/'public/rebuilt131/textures';OUT.mkdir(parents=True,exist_ok=True)
N=1024;y,x=np.mgrid[:N,:N];records={}
roles=['wall','stone','brick','roof','metal','steel','wood','paving','soil','bark','leaf','glass']
for index,role in enumerate(roles):
 rng=np.random.default_rng(13100+index);fine=rng.normal(0,1,(N,N));broad=gaussian_filter(fine,24)*35;grain=gaussian_filter(fine,1.3)
 h=.5+.06*grain+.02*broad
 if role in ['stone','brick','paving']:
  tw,th=(256,128)if role=='stone'else(128,64)if role=='brick'else(128,128)
  xx=(x+(y//th%2)*tw/2)%tw;yy=y%th;edge=np.minimum.reduce([xx,tw-xx,yy,th-yy]);face=np.clip((edge-3)/6,0,1)
  tile=rng.uniform(-.08,.08,(N//th+1,N//tw+2));variation=tile[y//th,((x+(y//th%2)*tw/2)//tw).astype(int)]
  h=.2+face*(.6+variation)+grain*.025
 elif role=='roof':h=.45+.17*np.cos(x*np.pi/32)+.15*np.clip((y%160)/10,0,1)+grain*.012
 elif role=='metal':h=.5+.25*np.cos(x*np.pi/48)+grain*.004
 elif role=='steel':
  seams=(x%256<5)|(y%256<5);h=.55-seams*.25+grain*.01
  for xx in range(18,N,256):
   for yy in range(18,N,256):h+=np.exp(-((x-xx)**2+(y-yy)**2)/18)*.22
 elif role=='wood':h=.52+.08*np.sin(y*.11+broad*2+x*.017)+grain*.008-((x%128)<4)*.22
 elif role=='bark':h=.48+.14*np.sin(x*.11+gaussian_filter(fine,16)*30)+grain*.04
 elif role=='soil':h=.5+grain*.14+broad*.025
 elif role=='leaf':h=.5+grain*.03+np.sin(x*.05+y*.01)*.035
 elif role=='glass':h=np.full((N,N),.5)
 albedo=np.clip(.76+(h-.5)*.24+grain*.012,.28,.96)
 if role=='glass':albedo[:]=.82
 rgb=np.stack([albedo]*3,axis=-1);rgb=(rgb*255).astype('uint8')
 small=Image.fromarray((np.clip(h,0,1)*255).astype('uint8')).resize((512,512),Image.Resampling.LANCZOS);height=np.asarray(small,dtype=float)/255
 dy,dx=np.gradient(height);strength=4 if role in ['wall','soil','bark']else 2.5
 normal=np.stack([-dx*strength,-dy*strength,np.ones_like(dx)],axis=-1);normal/=np.linalg.norm(normal,axis=-1,keepdims=True);normal=((normal*.5+.5)*255).astype('uint8')
 rough=np.clip((.35 if role=='glass'else .66 if role in ['metal','steel']else .9)+grain*.025,.15,1);rough=Image.fromarray((rough*255).astype('uint8')).resize((256,256),Image.Resampling.LANCZOS).convert('RGB')
 rec={}
 for kind,im in [('color',Image.fromarray(rgb)),('normal',Image.fromarray(normal)),('roughness',rough)]:
  buf=io.BytesIO();im.save(buf,format='WEBP',quality=93,lossless=kind!='color',method=6);b=buf.getvalue();sha=hashlib.sha256(b).hexdigest();name=f'{role}-{kind}-{sha[:12]}.webp';(OUT/name).write_bytes(b)
  rec[kind]={'url':'/rebuilt131/textures/'+name,'localUrl':'/rebuilt131/textures/'+name,'sha256':sha,'bytes':len(b),'size':list(im.size)}
 records[role]=rec;print('TEXTURE',role,sum(e['bytes']for e in rec.values()),flush=True)
meta={'schema':1,'origin':'ARENA mathematical height-field PBR; no imported images','source':'scripts/make-rebuilt-textures131.py','sourceScriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'materials':records}
(R/'src/rebuilt131-textures.json').write_text(json.dumps(meta,indent=2)+'\n');(OUT/'PROVENANCE.json').write_text(json.dumps(meta,indent=2)+'\n')
