"""Eleven distinct edited architecture modules for the source map settings.
Uses the maintained Blender geometry helpers; no source scene is overwritten.
"""
from pathlib import Path
import os
helpers=Path(__file__).with_name('build-detail-kit128.py')
(helpers.parents[1]/'public').mkdir(parents=True,exist_ok=True)
exec(compile(helpers.read_text().split('STYLES=')[0],str(helpers),'exec'))
OUT=R/'public/landmarks130';OUT.mkdir(exist_ok=True)

def rotate_new(start,angle):
    tr=Matrix.Rotation(angle,4,'Z')
    for o in objects[start:]:o.matrix_world=tr@o.matrix_world

def dome(z,r=.65,h=.4,kind='stone'):
    verts=[]
    for row in range(7):
        a=row*math.pi/12
        for k in range(20):
            t=k*math.tau/20;verts.append((math.cos(t)*r*math.cos(a),math.sin(t)*r*math.cos(a),z+h*math.sin(a)))
    add_mesh('curved_dome',verts,[(i*20+k,i*20+(k+1)%20,(i+1)*20+(k+1)%20,(i+1)*20+k)for i in range(6)for k in range(20)],kind)

def platform():
    for k in range(3):box(0,0,.06+k*.08,3.05-k*.15,2.7-k*.15,.12,'stone',.04)

def courtyard(id):
    platform()
    if id=='dust2':
        cylinder(0,0,.65,.72,.85,'wall',8);cylinder(0,0,1.11,.84,.12,'stone',8)
        for k in range(4):
            s=len(objects);arch(0,-.64,1.17,.78,.55,'stone',.14);rotate_new(s,k*math.pi/2)
        dome(2.12,.76,.42);cylinder(0,0,2.6,.08,.22,'metal',10)
        for k in range(8):
            a=k*math.tau/8;tube([(.85*math.cos(a),.85*math.sin(a),.26),(.85*math.cos(a),.85*math.sin(a),1.0)],.035,'stone',6)
        planter(1.1,.83,.26,.75)
    elif id=='mirage':
        for x in [-.93,.93]:arch(x,-.65,.26,.7,.78,'stone',.17)
        for y in [-.68,.7]:box(0,y,1.55,2.75,.18,.14,'wood',.02)
        for k in range(8):box(-1.2+k*.34,.03,1.66,.07,1.75,.12,'wood',.015)
        cylinder(0,.1,.47,.54,.42,'stone',12);cylinder(0,.1,.69,.65,.1,'stone',12)
        tube([(-1.2,.8,.3),(-1.2,.8,1.6),(-.5,.8,1.7)],.04,'metal',8)
        for x in [-1.15,1.15]:planter(x,.82,.26,.7)
    elif id=='inferno':
        cylinder(0,0,.82,.76,1.18,'wall',8)
        for z in [.28,.8,1.42]:cylinder(0,0,z,.88,.12,'stone',8)
        for k in range(4):
            s=len(objects);arch(0,-.61,1.47,.72,.42,'stone',.15);rotate_new(s,k*math.pi/2)
        cylinder(0,0,1.77,.27,.4,'metal',12,r2=.15)
        roof_tiles(2.2,1.95,2.30)
        tube([(-1.02,-1,2.32),(-1.1,-1,.3)],.04,'metal',7)
    elif id in ['ancient','ancient-night']:
        for i in range(4):box(0,0,.33+i*.13,2.6-i*.32,2.2-i*.25,.17,'stone',.05)
        if id=='ancient':
            arch(0,0,.84,1.25,.7,'stone',.4)
            for k in range(5):box(-1+k*.5,.1,2.19,.44,.65,.18,'stone',.035)
            for x in [-1,1]:
                cylinder(x,-.3,1.15,.2,1.2,'stone',12);cylinder(x,-.3,1.8,.31,.12,'stone',12)
            for i in range(15):leaf(-1.3+i*.08,.65,.8+(i%3)*.35,i*2.39,.42)
        else:
            for k in range(6):
                a=k*math.tau/6;cylinder(math.cos(a)*.91,math.sin(a)*.91,1.29,.11,1.12,'stone',10)
            cylinder(0,0,1.9,1.13,.15,'stone',12);dome(1.98,1.02,.5)
            cylinder(0,0,1.11,.26,.7,'stone',6,r2=.16)
            for k in range(12):
                a=k*math.tau/12;box(math.cos(a)*1.15,math.sin(a)*1.15,.33,.12,.12,.18,'stone',.02)
    elif id=='anubis':
        for x in [-.82,.82]:
            cylinder(x,.08,1.05,.2,1.55,'stone',16,r2=.15)
            cylinder(x,.08,.34,.32,.14,'stone',12);cylinder(x,.08,1.88,.36,.16,'stone',12)
            for k in range(10):leaf(x,.08,1.91,k*math.tau/10,.32)
        arch(0,.05,.32,1.4,1.52,'stone',.25)
        cylinder(0,-.65,.47,.45,.32,'stone',12);cylinder(0,-.65,.65,.55,.1,'stone',12)
        for k in range(5):box(0,.5,.3+k*.085,1.5-k*.13,.65,.09,'stone',.02)
    elif id=='overpass':
        for x in [-.67,.67]:arch(x,0,.27,1.0,.72,'stone',.6)
        box(0,0,1.66,2.9,.95,.2,'wall',.04)
        for k in range(10):tube([(-1.25+k*.28,-.45,1.76),(-1.25+k*.28,-.45,2.13)],.025,'metal',6)
        tube([(-1.42,-.45,2.15),(1.42,-.45,2.15)],.04,'metal',7)
        tube([(-1.15,.7,.28),(-1.15,.7,1.5),(-.8,.7,1.72),(.4,.7,1.72),(.6,.7,.48)],.14,'metal',12)
    elif id=='nuke':
        cylinder(0,0,.45,.87,.28,'metal',16);cylinder(0,0,1.15,.61,1.15,'metal',20)
        dome(1.72,.61,.42,'metal')
        for k in range(8):
            a=k*math.tau/8;tube([(.79*math.cos(a),.79*math.sin(a),.3),(.79*math.cos(a),.79*math.sin(a),1.1)],.035,'metal',7)
        for x in [-1.13,1.13]:
            tube([(x,-.7,.3),(x,-.7,1.56),(x,-.3,1.86),(x,.6,1.86)],.12,'metal',12)
            for z in [.5,1,1.5]:cylinder(x,-.7,z,.19,.07,'metal',12)
        for k in range(7):box(-1.35,-.9+k*.19,.34+k*.1,.27,.2,.09,'metal',.012)
    elif id=='train':
        for x in [-1.16,1.16]:
            for y in [-.55,.55]:tube([(x,y,.27),(x,y,2.18)],.065,'metal',9)
            tube([(x,-.55,.6),(x,.55,1.75),(x,-.55,2.18)],.04,'metal',7)
        for z in [1.95,2.18]:tube([(-1.3,-.55,z),(1.3,-.55,z)],.055,'metal',8)
        for k in range(8):tube([(-1.25+k*.34,-.55,1.95),(-1.08+k*.34,-.55,2.18)],.025,'metal',6)
        for x in [-.8,.8]:
            for z in [1.4,1.65,1.9]:
                o=cylinder(x,-.68,z,.095,.08,'glass',12);o.rotation_euler[0]=math.pi/2
        for y in [-.35,.35]:tube([(-1.3,y,.31),(1.3,y,.31)],.04,'metal',8)
        for y in [.48,.82]:tube([(-1.3,y,.28),(-1.3,y,2.12)],.025,'metal',7)
        for k in range(10):tube([(-1.3,.48,.34+k*.18),(-1.3,.82,.34+k*.18)],.025,'metal',7)
    elif id=='vertigo':
        for x in [-.62,.62]:
            for y in [-.62,.62]:tube([(x,y,.27),(x*.7,y*.7,2.4)],.065,'metal',8)
        for z in [.55,1.2,1.85,2.4]:
            for y in [-.62,.62]:tube([(-.62,y,z),(.62,y,z+.55)],.035,'metal',6)
        for y in [-.35,.35]:tube([(-1.45,y,2.4),(1.45,y,2.4),(1.05,y,2.68),(-1.4,y,2.68)],.05,'metal',8)
        for k in range(8):tube([(-1.4+k*.36,-.35,2.4),(-1.22+k*.36,-.35,2.68)],.025,'metal',5)
        for x in [-.58,-.3]:tube([(x,.7,.32),(x,.7,2.28)],.025,'metal',7)
        for k in range(10):tube([(-.58,.7,.34+k*.19),(-.3,.7,.34+k*.19)],.025,'metal',7)
        drum=cylinder(.45,.65,.56,.22,.5,'metal',16);drum.rotation_euler[1]=math.pi/2
        for x in [.18,.72]:
            flange=cylinder(x,.65,.56,.29,.06,'metal',16);flange.rotation_euler[1]=math.pi/2
        box(-.93,0,2.25,.7,.75,.27,'stone',.05);tube([(1.2,0,2.45),(1.2,0,1.42),(1.08,0,1.3),(.98,0,1.43)],.035,'metal',7)
    elif id=='cache':
        box(0,0,.7,2.7,1.8,.9,'wall',.04)
        for k in range(3):
            x=-1.35+k*.9
            add_mesh('sawtooth_roof',[(x,-1,1.2),(x+.8,-1,1.65),(x+.8,1,1.65),(x,1,1.2)],[(0,1,2,3)],'roof')
            add_mesh('clerestory_glazing',[(x+.8,-1,1.2),(x+.8,-1,1.65),(x+.8,1,1.65),(x+.8,1,1.2)],[(0,1,2,3)],'glass')
        for k in range(12):box(.6,-.93,.35+k*.06,.8,.05,.045,'metal',.005)
        tube([(-1.1,.6,.27),(-1.1,.6,1.7),(-.9,.6,1.9),(-.55,.6,1.9)],.11,'metal',10)
        planter(1.04,.8,.25,.65)

ids=['dust2','mirage','inferno','nuke','train','ancient','ancient-night','anubis','overpass','vertigo','cache'];records=[]
for i,id in enumerate(ids):
    objects=[];courtyard(id)
    bpy.ops.object.select_all(action='DESELECT')
    for o in objects:o.select_set(True)
    bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();o=bpy.context.object;o.name=id.replace('-','_')+'__landmark'
    for v in o.data.vertices:v.co=o.matrix_world@v.co
    o.matrix_world.identity()
    while o.data.uv_layers:o.data.uv_layers.remove(o.data.uv_layers[0])
    uv=o.data.uv_layers.new(name='LandmarkUV')
    for p in o.data.polygons:
        dims=[a for a in range(3)if a!=max(range(3),key=lambda a:abs(p.normal[a]))]
        for li in p.loop_indices:
            v=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[dims[0]]*.7,v[dims[1]]*.7)
    xyz=[v.co.copy()for v in o.data.vertices];bounds=[min(v[a]for v in xyz)for a in range(3)]+[max(v[a]for v in xyz)for a in range(3)]
    assert max(abs(bounds[0]),abs(bounds[3]))<=1.8 and max(abs(bounds[1]),abs(bounds[4]))<=1.6,(id,bounds)
    o.location=(i*5,0,0);records.append({'map':id,'kind':'landmark','node':o.name,'catalog':[i*5,0],'bounds':bounds,'triangles':sum(len(p.vertices)-2 for p in o.data.polygons)})
    print('LANDMARK',id,records[-1]['triangles'],flush=True)
dest=Path(os.environ.get('ARENA_BLEND_OUTPUT',str(R/'generated/ARENA-landmarks130.blend')));dest.parent.mkdir(parents=True,exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(dest))
bpy.ops.export_scene.gltf(filepath=str(OUT/'landmarks.glb'),export_format='GLB',export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_apply=True)
p=OUT/'landmarks.glb';meta={'schema':1,'builder':'Blender4.3.2','source':'scripts/build-landmarks130.py','sourceMapGeometryModified':False,'geometryOrigin':'Eleven distinct ARENA architectural landmark meshes, fitted to source map settings and validated pockets','models':records,'library':{'url':'/landmarks130/landmarks.glb','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}
(OUT/'models.json').write_text(json.dumps(meta,indent=2)+'\n');(R/'src/landmarks130-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
