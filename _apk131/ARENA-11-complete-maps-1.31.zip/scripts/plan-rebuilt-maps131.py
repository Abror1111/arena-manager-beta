"""Create eleven new architectural plans, using only CS2 nav as a layout guide.
No exported GLB, VPK, collision mesh, radar image or source texture is consumed.
"""
from pathlib import Path
import json,math,hashlib,random
import numpy as np
from shapely import Polygon,box,union_all,LineString,shortest_line,constrained_delaunay_triangles,MultiPoint,delaunay_triangles,Point,set_precision
from shapely.strtree import STRtree
from scipy.spatial import cKDTree
R=Path(__file__).resolve().parents[1];OUT=Path('/workspace/.arena-tools/rebuilt131-plans');OUT.mkdir(exist_ok=True)
styles={'dust2':'desert','mirage':'arcade','inferno':'terracotta','nuke':'reactor','train':'rail','ancient':'temple','ancient-night':'moon','anubis':'river','overpass':'park','vertigo':'sky','cache':'workshop'}
def polygons(g):
 if g.is_empty:return[]
 if g.geom_type=='Polygon':return[g]
 return[p for child in getattr(g,'geoms',[])for p in polygons(child)]
def rings(p):return{'outer':[[round(x,5),round(z,5)]for x,z in list(p.exterior.coords)[:-1]],'holes':[[[round(x,5),round(z,5)]for x,z in list(r.coords)[:-1]]for r in p.interiors]}
def caps(poly,y=None):
 out=[]
 for t in constrained_delaunay_triangles(poly).geoms:
  q=list(t.exterior.coords)[:3]
  out.append([[float(x),float(z)]for x,z in q])
 return out
def floor_y(row,x,z):
 p=np.asarray(row[1]).reshape(-1,3);low=float(p[:,2].min());high=float(p[:,2].max());best=None;penalty=1e9
 for i in range(1,len(p)-1):
  a,b,c=p[0],p[i],p[i+1];den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(den)<1e-8:continue
  u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(z-c[1]))/den;v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(z-c[1]))/den;w=1-u-v
  value=float(a[2]*u+b[2]*v+c[2]*w);outside=max(0,-u,-v,-w)
  if outside<penalty:best=value;penalty=outside
  if outside<.0001:break
 return max(low,min(high,float(row[3][2])if best is None else best))
for index,(id,style)in enumerate(styles.items()):
 src=R/'src/reference'/f'{id}.json';m=json.loads(src.read_text());rng=random.Random(131+index);rows=m['rows'];shapes=[]
 for r in rows:
  xy=np.array(r[1]).reshape(-1,3)[:,:2];p=Polygon(xy).buffer(0)
  if p.is_empty:p=LineString(xy).buffer(.16)
  shapes.append(p)
 centers=np.array([r[3]for r in rows]);kd=cKDTree(centers[:,:2]);walk=union_all(shapes);connectors=[]
 # Recreate visible, closed ramps over guide portals rather than leaving gaps.
 for i,r in enumerate(rows):
  for j in r[2]:
   if j<=i:continue
   a,b=shapes[i],shapes[j];d=a.distance(b);dy=centers[j,2]-centers[i,2]
   if d<.08 or d>3.5 or abs(dy)>.15+d*.72:continue
   line=shortest_line(a,b);coords=list(line.coords)
   if len(coords)!=2:continue
   p,q=coords;dx=q[0]-p[0];dz=q[1]-p[1];length=math.hypot(dx,dz)
   if length<.02:continue
   nx=-dz/length*.29;nz=dx/length*.29
   coords3=[[p[0]+nx,float(centers[i,2]),p[1]+nz],[p[0]-nx,float(centers[i,2]),p[1]-nz],[q[0]-nx,float(centers[j,2]),q[1]-nz],[q[0]+nx,float(centers[j,2]),q[1]+nz]]
   footprint=Polygon([(p[0],p[2])for p in coords3]);connectors.append({'vertices':coords3,'footprint':rings(footprint),'stair':bool(abs(dy)>.35)})
 if connectors:walk=union_all([walk,*[Polygon(c['footprint']['outer'])for c in connectors]])
 domain=walk.convex_hull.buffer(3.5,quad_segs=3);buildable=domain.difference(walk.buffer(.18,join_style='mitre'));plots=[];small=[];grid=6.2 if style in ['desert','arcade','terracotta','park']else 8.5
 x0,z0,x1,z1=domain.bounds
 for z in np.arange(z0,z1,grid):
  for x in np.arange(x0,x1,grid):
   pieces=buildable.intersection(box(float(x+.055),float(z+.055),float(x+grid-.055),float(z+grid-.055)))
   for poly in polygons(pieces):
    poly=poly.simplify(.025,preserve_topology=True).difference(walk.buffer(.14))
    for p in polygons(poly):
     if p.area<.12:continue
     point=p.representative_point();near=centers[np.atleast_1d(kd.query([point.x,point.y],k=6)[1])];base=float(near[np.argmin(np.linalg.norm(near[:,:2]-[point.x,point.y],axis=1)),2])
     rect=list(p.minimum_rotated_rectangle.exterior.coords);lengths=[math.dist(rect[i],rect[i+1])for i in range(4)];width=min(lengths);kind='wall'if width<.72 or p.area<1.5 else'building'
     height=.68 if kind=='wall'else 1.3+rng.random()*1.4
     if m['lowerClip']is not None and base<m['lowerClip']-.1:height=min(height,max(.55,m['lowerClip']-.12-base))
     plots.append({**rings(p),'caps':caps(p),'area':round(p.area,4),'base':round(base,4),'height':round(height,4),'kind':kind,'variant':rng.random(),'center':[point.x,point.y]})
 # A complete, continuous owned foundation, with grounded perimeter dressing.
 trees=[]
 for _ in range(70):
  a=rng.random()*math.tau;r=2.5+rng.random()*4
  p=domain.exterior.interpolate(rng.random()*domain.exterior.length);c=domain.centroid;dx=p.x-c.x;dz=p.y-c.y;length=math.hypot(dx,dz)or 1
  x=p.x+dx/length*r;z=p.y+dz/length*r
  if math.hypot(x-m['sites'][0]['x'],z-m['sites'][0]['z'])<2:continue
  if len(trees)>=38:break
  trees.append({'x':x,'z':z,'y':float(np.min(centers[:,2]))-.12,'kind':'palm'if style in ['desert','arcade','river']else'tree','size':.8+rng.random()*.6,'rotation':a})
 water=[]
 if style in ['river','temple','moon','park']:
  candidates=sorted([p for p in plots if p['kind']=='building'and p['area']>6],key=lambda p:p['area'],reverse=True)
  if candidates:
   p=candidates[-1];poly=Polygon(p['outer'],p['holes']);c=poly.representative_point();radius=min(.8,c.distance(poly.boundary)*.7)
   if radius>.22:water=[{'x':c.x,'z':c.y,'y':p['base']+.02,'radius':radius}];p['pool']=True;p['kind']='garden'
 # Triangulate entirely new floor slabs around the layout guide.
 floors=[];tree=STRtree(shapes)
 for row,shape in zip(rows,shapes):
  poly=set_precision(shape,0.0001);center_y=float(row[3][2]);hits=tree.query(shape,predicate='intersects')
  deck=any(rows[j][3][2]<center_y-1.0 and shapes[j].intersection(shape).area>.01 for j in hits)
  # Flat areas are unioned before meshing; source nav cell borders are not architecture.
  levels=[v for tri in caps(poly) for x,z in tri for v in [floor_y(row,x,z)]]
  if not levels:continue
  if max(levels)-min(levels)<.065:
   level=round(center_y*10)/10+.014
   floors.append({'planar':True,'shape':poly,'level':level,'deck':bool(deck),'base':center_y,'layer':'upper'if m['lowerClip']is not None and center_y>m['lowerClip']else'lower'})
  else:
   floors.append({'rings':[[[float(x),floor_y(row,x,z)+.014,float(z)]for x,z in list(r.coords)[:-1]]for r in[poly.exterior,*poly.interiors]],'caps':[[[float(x),floor_y(row,x,z)+.014,float(z)]for x,z in t]for t in caps(poly)],'deck':bool(deck),'base':center_y,'layer':'upper'if m['lowerClip']is not None and center_y>m['lowerClip']else'lower'})
 grouped={};merged=[]
 for f in floors:
  if not f.get('planar'):merged.append(f);continue
  grouped.setdefault((f['level'],f['deck'],f['layer']),[]).append(f['shape'])
 for (level,deck,layer),pieces in grouped.items():
  for poly in polygons(set_precision(union_all(pieces).buffer(-.00012,join_style="mitre").buffer(.00012,join_style="mitre"),.0001)):
   if poly.area<.00001:continue
   merged.append({'rings':[[[float(x),level,float(z)]for x,z in list(r.coords)[:-1]]for r in[poly.exterior,*poly.interiors]],'caps':[[[float(x),level,float(z)]for x,z in t]for t in caps(poly)],'deck':deck,'base':level,'layer':layer})
 floors=merged
 # Real curved tiles supplement closed conforming roofs.
 for p in plots:
  poly=Polygon(p['outer'],p['holes']);x0,z0,x1,z1=poly.bounds;p['tiles']=[]
  if p['kind']!='building':continue
  if style=='terracotta':
   for zz in np.arange(z0+.14,z1-.14,.48):
    for xx in np.arange(x0+.14,x1-.14,.34):
     if poly.covers(box(float(xx-.13),float(zz),float(xx+.13),float(zz+.46))):p['tiles'].append([float(xx),float(zz),min(.62,Point(float(xx),float(zz)).distance(poly.boundary)*.48)])
 # Place full original buildings, sized inside real free plots, not source meshes.
 for p in plots:
  if p['kind']!='building':continue
  poly=Polygon(p['outer'],p['holes']);c=poly.representative_point()
  for scale in [1,.85,.7,.55]:
   if poly.covers(box(c.x-2.5*scale,c.y-2.65*scale,c.x+2.5*scale,c.y+2.65*scale)):
    p['assembly']={'x':c.x,'z':c.y,'scale':scale};break
 # Fit one entire distinct architectural landmark into a real building plot.
 landmark=None
 for p in sorted([p for p in plots if p['kind']=='building'],key=lambda p:-p['area']):
  poly=Polygon(p['outer'],p['holes']);c=poly.representative_point()
  for scale in [1,.8,.65,.5]:
   if poly.covers(box(c.x-1.6*scale,c.y-1.4*scale,c.x+1.6*scale,c.y+1.4*scale)):
    landmark={'plot':plots.index(p),'x':c.x,'z':c.y,'y':p['base'],'scale':scale};break
  if landmark:break
 assert landmark,id+' landmark fit'
 data={k:m[k]for k in ['width','height','playerScale','sites','spawns','spawnPoints','view','upperClip','lowerClip','rows']};data.update({'id':id,'style':style,'revision':'arena-rebuilt-131','guideNavSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'guideOrigin':'CS2 navigation layout/elevation reference; no source 3D geometry or images','domain':rings(domain),'groundY':min(v for r in rows for v in r[1][2::3])-.2,'plots':plots,'floors':floors,'landmark':landmark,'foundationCaps':caps(domain.buffer(8,quad_segs=3)),'foundation':rings(domain.buffer(8,quad_segs=3)),'connectors':connectors,'trees':trees,'water':water})
 tmp=OUT/(id+'.tmp');tmp.write_text(json.dumps(data,separators=(',',':'))+'\n');tmp.replace(OUT/(id+'.json'));print('PLAN',id,len(rows),'floors',len(plots),'plots',sum(p['kind']=='building'for p in plots),'buildings',len(connectors),'ramps',flush=True)
