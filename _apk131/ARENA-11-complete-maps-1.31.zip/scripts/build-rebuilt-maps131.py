"""Build complete new map scenes in Blender; never imports a source 3D asset.
The only source-game input is the documented 2D navigation/elevation guide.
"""
import bpy,bmesh,math,json,sys,os,ast,random,struct,gzip,hashlib,base64
from pathlib import Path
from mathutils import Vector,Matrix
from collections import defaultdict,Counter
R=Path(__file__).resolve().parents[1];PLANS=Path('/workspace/.arena-tools/rebuilt131-plans');OUT=R/'public/rebuilt131';OUT.mkdir(parents=True,exist_ok=True)
BLENDS=Path('/workspace/shared/arena-131-blender');BLENDS.mkdir(exist_ok=True)
texture_meta=json.loads((R/'src/rebuilt131-textures.json').read_text());ids=sys.argv[sys.argv.index('--')+1:]if'--'in sys.argv else['dust2','mirage','inferno','nuke','train','ancient','ancient-night','anubis','overpass','vertigo','cache']
palettes={
'dust2':{'wall':'#dfceb1','stone':'#cab997','roof':'#c4b299','paving':'#cfc4af','metal':'#879b9b','wood':'#8b6847','soil':'#b6a78b'},
'mirage':{'wall':'#e3d1b5','stone':'#c8ba9c','roof':'#b8c1c1','paving':'#cfc2a4','metal':'#76a9bd','wood':'#9d7750','soil':'#bcb092'},
'inferno':{'wall':'#e5d3ac','stone':'#c6c0ae','roof':'#c17a4b','paving':'#bfbcb0','metal':'#879493','wood':'#9a7047','soil':'#9da18b'},
'nuke':{'wall':'#e0e6df','stone':'#afb7b2','roof':'#b3c8cf','paving':'#acb4b1','metal':'#87aec0','wood':'#ad9270','soil':'#a2ad9a'},
'train':{'wall':'#b7b6a4','stone':'#aaa99e','roof':'#8b9b9d','paving':'#a6a39b','metal':'#a0795c','wood':'#957b5a','soil':'#a5a086'},
'ancient':{'wall':'#a9b19a','stone':'#a5b095','roof':'#869a78','paving':'#a5ab92','metal':'#718b7c','wood':'#847355','soil':'#81976d'},
'ancient-night':{'wall':'#899c94','stone':'#9eafa1','roof':'#6d9189','paving':'#95a89a','metal':'#679eaa','wood':'#827b65','soil':'#6e8e7b'},
'anubis':{'wall':'#e2cca3','stone':'#cbb991','roof':'#c9b792','paving':'#c7bea3','metal':'#77a6ac','wood':'#a08056','soil':'#b4ae8d'},
'overpass':{'wall':'#d4d9c6','stone':'#b4bcae','roof':'#a5b4af','paving':'#b3b8ae','metal':'#789e9e','wood':'#947653','soil':'#8fa27d'},
'vertigo':{'wall':'#d5ddd8','stone':'#b5c0ba','roof':'#a8bac1','paving':'#afb9b5','metal':'#c0ab78','wood':'#b69765','soil':'#8c9a8e'},
'cache':{'wall':'#c9d3ba','stone':'#b3b7a3','roof':'#9bad9e','paving':'#b0b3a3','metal':'#81a294','wood':'#a1875c','soil':'#8e9d7d'}}

def linear(v):return v/12.92 if v<=.04045 else((v+.055)/1.055)**2.4
def rgb(hex):return tuple(linear(int(hex[i:i+2],16)/255)for i in[1,3,5])+(1,)
def functions(path,ns):
 tree=ast.parse(path.read_text());tree.body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))];exec(compile(tree,str(path),'exec'),ns)
def own_namespace(mats):return{'bpy':bpy,'math':math,'Vector':Vector,'Matrix':Matrix,'random':random,'objects':[],'M':mats,'materials':mats}

for map_id in ids:
 print('START_COMPLETE',map_id,flush=True);plan=json.loads((PLANS/(map_id+'.json')).read_text());bpy.ops.wm.read_factory_settings(use_empty=True)
 mats={};style=plan['style'];palette=palettes[map_id];texture_nodes=[]
 for role in list(texture_meta['materials'])+['glow']:
  m=bpy.data.materials.new(role);m.use_nodes=True;nodes=m.node_tree.nodes;p=nodes.get('Principled BSDF');color=palette.get(role,'#aa8b70'if role in['wood','bark']else'#75935c'if role=='leaf'else'#b7b9a7'if role=='brick'else'#406276'if role=='glass'else'#bac3b8')
  p.inputs['Base Color'].default_value=rgb(color);p.inputs['Roughness'].default_value=.45 if role in['metal','steel','glass']else .86;m.diffuse_color=rgb(color);m['arenaRole']=role;m['arenaOrigin']='ARENA authored PBR'
  if role in texture_meta['materials']:
   for kind,socket in [('color','Base Color'),('roughness','Roughness')]:
    e=texture_meta['materials'][role][kind];im=bpy.data.images.load(str(R/'public'/e['localUrl'].lstrip('/')),check_existing=True);im.colorspace_settings.name='sRGB'if kind=='color'else'Non-Color';node=nodes.new('ShaderNodeTexImage');node.image=im;m.node_tree.links.new(node.outputs['Color'],p.inputs[socket]);texture_nodes.append(node)
   e=texture_meta['materials'][role]['normal'];im=bpy.data.images.load(str(R/'public'/e['localUrl'].lstrip('/')),check_existing=True);im.colorspace_settings.name='Non-Color';node=nodes.new('ShaderNodeTexImage');node.image=im;normal=nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.45;m.node_tree.links.new(node.outputs['Color'],normal.inputs['Color']);m.node_tree.links.new(normal.outputs['Normal'],p.inputs['Normal']);texture_nodes.append(node)
  if role=='glow':p.inputs['Emission Color'].default_value=rgb('#e7c77e');p.inputs['Emission Strength'].default_value=1.2
  mats[role]=m
 objects=[];audit=[];prop_roots=[];props=[];assembly_count=0;ground=plan['groundY'];lower=plan['lowerClip'];collision_objects=[]
 def layer_for(y):return 'upper'if lower is not None and y>lower else'lower'
 def make_mesh(name,vertices,faces,role='wall',collision=False,layer='lower',closed=False):
  mesh=bpy.data.meshes.new(name);mesh.from_pydata([(x,-z,y)for x,y,z in vertices],[],faces);mesh.materials.append(mats[role]);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);objects.append(o);o['arenaLayer']=layer;o['arenaRole']=role;o['arenaCore']=closed
  if closed:
   bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.remove_doubles(bm,verts=bm.verts,dist=.000003);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bad=sum(not e.is_manifold for e in bm.edges);bm.to_mesh(mesh);bm.free();audit.append({'name':name,'closed':bad==0,'nonManifoldEdges':bad,'faces':len(mesh.polygons)})
   if bad:raise RuntimeError(name+' is not a closed solid: '+str(bad))
  if collision:collision_objects.append(o)
  return o
 def bevel_mesh(o,width):
  bm=bmesh.new();bm.from_mesh(o.data);edges=[e for e in bm.edges if e.is_manifold and e.calc_face_angle(0)>.35]
  if edges:bmesh.ops.bevel(bm,geom=edges,offset=width,segments=2,affect='EDGES',clamp_overlap=True)
  bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(o.data);bm.free()
 def solid(name,rings,topcaps,bottomcaps,topfn,bottomfn,role,collision=True,layer='lower',bevel=0):
  verts=[];faces=[];lookup={}
  def vertex(x,z,top):
   x=round(x,5);z=round(z,5)
   y=topfn(x,z)if top else bottomfn(x,z);key=(round(x,6),round(y,6),round(z,6))
   if key not in lookup:lookup[key]=len(verts);verts.append((x,y,z))
   return lookup[key]
  for is_top,caps in[(True,topcaps),(False,bottomcaps)]:
   for tri in caps:
    pts=list(tri);area=sum(a[0]*b[1]-b[0]*a[1]for a,b in zip(pts,pts[1:]+pts[:1]))
    if(is_top and area>0)or(not is_top and area<0):pts.reverse()
    faces.append([vertex(x,z,is_top)for x,z in pts])
  for ring in rings:
   for a,b in zip(ring,ring[1:]+ring[:1]):faces.append([vertex(*a,False),vertex(*a,True),vertex(*b,True),vertex(*b,False)])
  try:o=make_mesh(name,verts,faces,role,collision,layer,True)
  except RuntimeError:
   # Point-touching floor islands have no valid shared shell. Split them into
   # their constrained triangular volumes, each independently closed.
   if not name.startswith('walk_floor_')or '_cell_'in name:raise
   bad=bpy.data.objects.get(name);data=bad.data;objects.remove(bad);audit.pop();bpy.data.objects.remove(bad,do_unlink=True);bpy.data.meshes.remove(data)
   print('REPAIR_FLOOR_CELLS',map_id,name,len(topcaps),flush=True)
   for k,tri in enumerate(topcaps):
    a,b,c=tri
    if abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))<1e-8:continue
    solid(name+'_cell_'+str(k),[tri],[tri],[tri],topfn,bottomfn,role,collision,layer,0)
   return None
  if bevel:bevel_mesh(o,bevel)
  return o
 def plate(name,rings,caps,base,top,role='stone',layer='lower',bevel=0):return solid(name,rings,caps,caps,lambda x,z:top,lambda x,z:base,role,True,layer,bevel)
 def box(name,x,y,z,w,h,d,role='wall',yaw=0,collision=False,layer='lower'):
  c=math.cos(yaw);s=math.sin(yaw);verts=[]
  for yy in[-h/2,h/2]:
   for xx,zz in[(-w/2,-d/2),(w/2,-d/2),(w/2,d/2),(-w/2,d/2)]:verts.append((x+c*xx+s*zz,y+yy,z-s*xx+c*zz))
  return make_mesh(name,verts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],role,collision,layer,False)
 # All architectural assemblies below are our own authored geometry functions.
 ns=own_namespace(mats);functions(R/'scripts/build-detail-kit128.py',ns);functions(R/'scripts/build-landmarks130.py',ns)
 def authored_box(x,y,z,w,d,h,kind='wall',bevel=.025):
  verts=[(sx*w/2,sy*d/2,sz*h/2)for sz in[-1,1]for sx,sy in[(-1,-1),(1,-1),(1,1),(-1,1)]]
  mesh=bpy.data.meshes.new('crafted_'+kind);mesh.from_pydata(verts,[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);mesh.materials.append(mats[kind]);mesh.update();o=bpy.data.objects.new('crafted_'+kind,mesh);bpy.context.collection.objects.link(o);o.location=(x,y,z)
  if bevel:bevel_mesh(o,min(bevel,min(w,d,h)*.18))
  ns['objects'].append(o);return o
 def authored_cylinder(x,y,z,r,h,kind='metal',segments=12,r2=None):
  mesh=bpy.data.meshes.new('turned_'+kind);bm=bmesh.new();bmesh.ops.create_cone(bm,cap_ends=True,cap_tris=False,segments=segments,radius1=r,radius2=r if r2 is None else r2,depth=h);bm.to_mesh(mesh);bm.free();mesh.materials.append(mats[kind]);o=bpy.data.objects.new('turned_'+kind,mesh);bpy.context.collection.objects.link(o);o.location=(x,y,z)
  for poly in mesh.polygons:poly.use_smooth=len(poly.vertices)==4
  ns['objects'].append(o);return o
 ns['box']=authored_box;ns['cylinder']=authored_cylinder
 def assembly(kind,x,y,z,scale=1,yaw=0):
  ns['objects']=[]
  if kind=='building':
   if style in ['temple','moon','river']:ns['ruins'](style)
   elif style in ['reactor','rail','sky','workshop']:ns['industrial']('energy'if style=='reactor'else'workshop'if style=='sky'else style)
   else:ns['civil'](style)
  else:ns[kind]()
  transform=Matrix.Translation((x,-z,y))@Matrix.Rotation(yaw,4,'Z')@Matrix.Scale(scale,4)
  for o in ns['objects']:
   o.matrix_world=transform@o.matrix_world;o['arenaLayer']=layer_for(y);o['arenaRole']=o.data.materials[0].name;objects.append(o)
   if kind=='building' and o.data.materials[0].name not in ['leaf','glass']:collision_objects.append(o)
 # The whole new map rests on its own closed, irregular foundation.
 f=plan['foundation'];plate('whole_map_foundation',[f['outer'],*f['holes']],plan['foundationCaps'],ground-3.5,ground-.025,'soil',bevel=.06)
 box('continuous_far_ground',plan['width']/2,ground-.16,plan['height']/2,400,.24,400,'soil',collision=False)
 # New closed floor slabs follow guide elevations; upper decks stay open below.
 for i,f in enumerate(plan['floors']):
  
  if i%700==0:print('FLOORS',map_id,i,len(plan['floors']),flush=True)
  ring3=f['rings'];top_lookup={(round(x,5),round(z,5)):y for ring in ring3 for x,y,z in ring}
  for tri in f['caps']:
   for x,y,z in tri:top_lookup[(round(x,5),round(z,5))]=y
  def top(x,z):return top_lookup[(round(x,5),round(z,5))]
  def bottom(x,z):return top(x,z)-.17 if f['deck']else ground-.12
  caps=[[[x,z]for x,y,z in tri]for tri in f['caps']];rings=[[[x,z]for x,y,z in ring]for ring in ring3]
  solid('walk_floor_'+str(i),rings,caps,caps,top,bottom,'paving',True,f['layer'])
 for i,c in enumerate(plan['connectors']):
  q=c['vertices'];ring=[[p[0],p[2]]for p in q];tri=[[ring[0],ring[1],ring[2]],[ring[0],ring[2],ring[3]]];a=q[0];b=q[3];dx=b[0]-a[0];dz=b[2]-a[2];den=dx*dx+dz*dz
  def h(x,z):return a[1]+((x-a[0])*dx+(z-a[2])*dz)/(den or 1)*(b[1]-a[1])+.014
  solid('portal_ramp_'+str(i),[ring],tri,tri,h,lambda x,z:h(x,z)-.18,'steel'if style in['reactor','rail','sky']else'paving',True,layer_for((a[1]+b[1])/2))
 # Fully new building volumes, with sealed backs, raised copings and shaped roofs.
 for i,p in enumerate(plan['plots']):
  
  if i%25==0:print('BUILDINGS',map_id,i,len(plan['plots']),flush=True)
  rings=[p['outer'],*p['holes']];base=p['base'];h=p['height'];layer=layer_for(base);role='stone'if style in['temple','moon','river']else'brick'if style in['rail','workshop']else'wall'
  if i==plan['landmark']['plot'] or p['kind']=='garden':
   plate('courtyard_plinth_'+str(i),rings,p['caps'],ground-.12,base+.12,'stone',layer,.02);continue
  if p.get('assembly'):
   a=p['assembly'];plate('assembly_foundation_'+str(i),rings,p['caps'],ground-.12,base+.035,'stone',layer,.02)
   assembly('building',a['x'],base+.04,a['z'],a['scale']);assembly_count+=1;continue
  body=plate('building_'+str(i),rings,p['caps'],ground-.12,base+h,role,layer,.025 if p['kind']=='building'else .012)
  if p['kind']=='wall':
   plate('molded_coping_'+str(i),rings,p['caps'],base+h,base+h+.075,'stone',layer,.015);continue
  # Two rounds of conforming subdivision create real hipped roof ridges.
  caps=[[[round(x,5),round(z,5)]for x,z in tri]for tri in p['caps']];refined_rings=rings
  roof_heights={(round(x,6),round(z,6)):0.0 for ring in rings for x,z in ring}
  # Distances are provided by the authored triangulation plan, not a source mesh.
  def distance_boundary(x,z):
   best=1e9
   for ring in rings:
    for a,b in zip(ring,ring[1:]+ring[:1]):
     dx=b[0]-a[0];dz=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz or 1)));best=min(best,math.hypot(x-a[0]-dx*t,z-a[1]-dz*t))
   return best
  for step in range(2):
   refined=[]
   for a,b,c in caps:
    ab=[(a[0]+b[0])/2,(a[1]+b[1])/2];bc=[(b[0]+c[0])/2,(b[1]+c[1])/2];ca=[(c[0]+a[0])/2,(c[1]+a[1])/2];refined.extend([[a,ab,ca],[b,bc,ab],[c,ca,bc],[ab,bc,ca]])
   caps=refined;refined_rings=[[v for a,b in zip(ring,ring[1:]+ring[:1])for v in[a,[(a[0]+b[0])/2,(a[1]+b[1])/2]]]for ring in refined_rings]
  pitched=style=='terracotta'
  def roof_y(x,z):return base+h+.075+(min(.62,distance_boundary(x,z)*.48)if pitched else 0)
  solid('sealed_roof_'+str(i),refined_rings,caps,caps,roof_y,lambda x,z:base+h+.015,('roof'if pitched or p['variant']<.4 else 'stone'if p['variant']<.75 else'metal'),True,layer)
  if p['area']>2:
   cx,cz=p['center'];assembly('roof_detail',cx,base+h+.09,cz,.6+p['variant']*.4)
  if pitched:
   for k,(x,z,offset)in enumerate(p.get('tiles',[])):
    verts=[]
    for along in[0,.47]:
     for j in range(5):
      a=j*math.pi/4;xx=x+math.cos(a)*.13;zz=z+along;verts.append((xx,roof_y(xx,zz)+math.sin(a)*.035+.012,zz))
    make_mesh('curved_roof_channel',verts,[(j,j+1,j+6,j+5)for j in range(4)],'roof',False,layer)
  # Frames, sills, beams and drain pipes articulate the actual polygon facades.
  for a,b in zip(p['outer'],p['outer'][1:]+p['outer'][:1]):
   dx=b[0]-a[0];dz=b[1]-a[1];length=math.hypot(dx,dz)
   if length<1.25:continue
   ux=dx/length;uz=dz/length;nx=uz;nz=-ux;yaw=math.atan2(-uz,ux)
   count=min(6,int(length/1.4))
   for j in range(count):
    t=(j+.5)/count;x=a[0]+dx*t;z=a[1]+dz*t;yy=base+min(h*.55,1.05)
    box('recessed_window',x+nx*.014,yy,z+nz*.014,.49,.62,.045,'glass',yaw,False,layer)
    for side in[-1,1]:box('window_jamb',x+ux*.29*side+nx*.04,yy,z+uz*.29*side+nz*.04,.065,.78,.09,'stone',yaw,False,layer)
    for dy in[-.37,.37]:box('window_lintel',x+nx*.04,yy+dy,z+nz*.04,.65,.07,.10,'stone',yaw,False,layer)
    box('window_sill',x+nx*.10,yy-.43,z+nz*.10,.72,.10,.25,'stone',yaw,False,layer)
   box('facade_cornice',(a[0]+b[0])/2+nx*.035,base+h-.13,(a[1]+b[1])/2+nz*.035,length,.105,.115,'stone',yaw,False,layer)
 # Distinct complete landmark assemblies, not overlays on an imported map.
 ns['objects']=[];ns['courtyard'](map_id);landmark=plan['landmark'];scale=landmark['scale'];transform=Matrix.Translation((landmark['x'],-landmark['z'],landmark['y']+.13))@Matrix.Scale(scale,4)
 for o in ns['objects']:
  o.matrix_world=transform@o.matrix_world;o['arenaLayer']=layer_for(landmark['y']);o['arenaRole']=o.data.materials[0].name;o['arenaCore']=False;objects.append(o)
 # Original branched vegetation and eroded rock geometry around the new foundation.
 green=own_namespace(mats);functions(R/'scripts/build-scenery129.py',green)
 for i,t in enumerate(plan['trees']):
  green['objects']=[];green['palm'if t['kind']=='palm'else'broadleaf'](style,random.Random(i));transform=Matrix.Translation((t['x'],-t['z'],ground))@Matrix.Rotation(t['rotation'],4,'Z')@Matrix.Scale(t['size'],4)
  for o in green['objects']:o.matrix_world=transform@o.matrix_world;o['arenaLayer']='lower';objects.append(o)
 # Site markings are newly modeled typography and inset court paint.
 for site in plan['sites']:
  bpy.ops.object.text_add(location=(site['x'],-site['z'],site['y']+.035));o=bpy.context.object;o.name='site_'+site['label'];o.data.body=site['label'];o.data.size=1.1;o.data.align_x='CENTER';o.data.align_y='CENTER';o.data.extrude=.002;o.data.materials.append(mats['glow']);bpy.ops.object.convert(target='MESH');objects.append(o);o['arenaLayer']=layer_for(site['y'])
 # Newly modeled court basins; water uses the same owned boundary at runtime.
 water_surfaces=[]
 for basin in plan['water']:
  x,z,y,r=basin['x'],basin['z'],basin['y'],basin['radius'];ring=[]
  for j in range(32):
   t=j*math.tau/32;ring.append([x+math.cos(t)*r,z+math.sin(t)*r])
  inner=[[x+(xx-x)*.86,z+(zz-z)*.86]for xx,zz in ring]
  rimcaps=[]
  for j in range(32):
   k=(j+1)%32;rimcaps.extend([[ring[j],ring[k],inner[j]],[inner[j],ring[k],inner[k]]])
  plate('carved_basin_rim',[ring,inner],rimcaps,y-.08,y+.1,'stone',layer_for(y))
  pos=[]
  for j in range(32):
   for xx,zz in [[x,z],inner[j],inner[(j+1)%32]]:pos.extend([xx,y+.055,zz])
  water_surfaces.append({'positions':pos,'color':'#468f9c'})
 # Physical, newly authored objects remain individual assemblies for explosions.
 chosen=[p for i,p in enumerate(plan['plots'])if p['kind']=='building'and not p.get('assembly')and i!=plan['landmark']['plot']and p['area']>3][:12]
 for k,p in enumerate(chosen):
  x,z=p['center'];y=p['base']+p['height']+.1;ns['objects']=[];kind='wood'if k%2==0 else'metal'
  if kind=='wood':
   for row in range(5):ns['box'](0,0,.075+row*.13,.68,.62,.12,'wood',.016)
   for xx in [-.28,.28]:
    for yy in [-.29,.29]:ns['box'](xx,yy,.34,.075,.075,.73,'metal',.008)
  else:
   ns['cylinder'](0,0,.35,.28,.7,'metal',20)
   for yy in [.06,.35,.65]:ns['cylinder'](0,0,yy,.3,.045,'steel',20)
   ns['cylinder'](.08,0,.718,.045,.025,'metal',12)
  group=bpy.data.objects.new('ARENA_prop_'+str(k),None);bpy.context.collection.objects.link(group);group['arenaProp']=k;group.location=(x,-z,y);transform=Matrix.Translation((x,-z,y))
  for o in ns['objects']:
   local=o.matrix_world.copy();o.parent=group;o.matrix_basis=local;o['arenaLayer']=layer_for(y);o['arenaDynamic']=True;objects.append(o)
  props.append({'id':k,'node':group.name,'x':x,'y':y,'z':z,'size':[.72,.74,.68],'kind':kind,'movable':True})
 # Consistent UVs for every newly authored surface, in physical world units.
 for o in objects:
  if o.type!='MESH':continue
  mesh=o.data
  if not mesh.uv_layers:
   uv=mesh.uv_layers.new(name='ARENA_world_uv')
   for poly in mesh.polygons:
    axis=max(range(3),key=lambda a:abs(poly.normal[a]));dims=[a for a in range(3)if a!=axis]
    for li in poly.loop_indices:
     v=mesh.vertices[mesh.loops[li].vertex_index].co;uv.data[li].uv=(v[dims[0]]*.65,v[dims[1]]*.65)
  if 'arenaLayer'not in o:o['arenaLayer']='lower'
  o['arenaOrigin']='ARENA authored'
 # Export the collision from these exact new solids, not a legacy source mesh.
 positions=[];indices=[]
 for o in collision_objects:
  o.data.calc_loop_triangles();matrix=o.matrix_world;start=len(positions)//3
  for v in o.data.vertices:
   p=matrix@v.co;positions.extend([p.x,p.z,-p.y])
  for tri in o.data.loop_triangles:indices.extend(start+i for i in tri.vertices)
 raw=b'ACM1'+struct.pack('<II',len(positions)//3,len(indices)//3)+struct.pack('<%sf'%len(positions),*positions)+struct.pack('<%sI'%len(indices),*indices);packed=gzip.compress(raw,mtime=0);sha=hashlib.sha256(packed).hexdigest();collision_name=f'{map_id}-collision-{sha[:12]}.cmesh';(OUT/collision_name).write_bytes(packed)
 # Save the complete editable scene, including original PBR image data.
 print('SAVE_EDITABLE',map_id,len(objects),flush=True);bpy.context.preferences.filepaths.save_version=0;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(BLENDS/(map_id+'.blend')),compress=True)
 # Runtime binds the shared, verified atlas, avoiding eleven embedded image copies.
 for m in mats.values():
  p=m.node_tree.nodes.get('Principled BSDF')
  for socket in['Base Color','Roughness','Normal']:
   for link in list(p.inputs[socket].links):m.node_tree.links.remove(link)
 facade_windows=sum(o.name.startswith('recessed_window')for o in objects)
 # Collapse static meshes by material and floor. The editable .blend stays unmerged.
 buckets=defaultdict(list)
 for o in objects:
  if o.type=='MESH'and not o.get('arenaDynamic'):buckets[(tuple(m.name for m in o.data.materials),o.get('arenaLayer','lower'))].append(o)
 for (roles,layer),items in buckets.items():
  vertices=[];faces=[];uvs=[];smooth=[]
  for o in items:
   mesh=o.data;mesh.calc_loop_triangles();start=len(vertices);matrix=o.matrix_world;vertices.extend(tuple(matrix@v.co)for v in mesh.vertices);uv=mesh.uv_layers.active.data
   for t in mesh.loop_triangles:
    faces.append(tuple(start+i for i in t.vertices));uvs.extend(tuple(uv[i].uv)for i in t.loops);smooth.append(mesh.polygons[t.polygon_index].use_smooth)
  mesh=bpy.data.meshes.new('batched_'+layer+'_'+'_'.join(roles));mesh.from_pydata(vertices,[],faces);mesh.update()
  for role in roles:mesh.materials.append(mats[role])
  uv=mesh.uv_layers.new(name='ARENA_world_uv')
  for i,v in enumerate(uvs):uv.data[i].uv=v
  for p,flag in zip(mesh.polygons,smooth):p.use_smooth=flag
  o=bpy.data.objects.new('ARENA_'+layer+'_'+'_'.join(roles),mesh);bpy.context.collection.objects.link(o);o['arenaLayer']=layer;o['arenaOrigin']='ARENA authored complete base'
  old_data={old.data for old in items};bpy.data.batch_remove(ids=set(items));bpy.data.batch_remove(ids={data for data in old_data if data.users==0})
  print('BATCH',map_id,layer,roles,len(faces),flush=True)
 glb=OUT/(map_id+'.glb');bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_extras=True,export_apply=True)
 info={'id':map_id,'revision':'arena-rebuilt-131','origin':'ARENA complete authored base; CS2 2D layout/elevation guide only','sourceImportedMeshes':0,'sourceImportedTextures':0,'guideNavSHA256':plan['guideNavSHA256'],'buildingPlots':len(plan['plots']),'completeArchitecturalAssemblies':assembly_count,'newFacadeWindows':facade_windows,'closedCoreSolids':len(audit),'nonManifoldCoreSolids':sum(not a['closed']for a in audit),'walkFloorSolids':len(plan['floors']),'newConnectors':len(plan['connectors']),'collisionTriangles':len(indices)//3,'collision':{'url':'/rebuilt131/'+collision_name,'localUrl':'/rebuilt131/'+collision_name,'bytes':len(packed),'sha256':sha},'visual':{'url':'/rebuilt131/'+map_id+'.glb','localUrl':'/rebuilt131/'+map_id+'.glb','bytes':glb.stat().st_size,'sha256':hashlib.sha256(glb.read_bytes()).hexdigest()},'blend':str(BLENDS/(map_id+'.blend')),'props':props,'waterSurfaces':water_surfaces,'audit':audit}
 (OUT/(map_id+'-build.json')).write_text(json.dumps(info,indent=2)+'\n')
 # A compact active guide contains no old collision mesh or source visibility.
 nav={k:plan[k]for k in['width','height','playerScale','sites','spawns','spawnPoints','view','upperClip','lowerClip','rows']};n=len(nav['rows']);nav['visibility']='';nav['authoredVisibility']=True;nav['collision']=base64.b64encode(packed).decode();nav['source']='ARENA rebuilt131 from CS2 layout guide';nav['guideNavSHA256']=plan['guideNavSHA256']
 navdir=R/'src/rebuilt131-nav';navdir.mkdir(exist_ok=True);(navdir/(map_id+'.json')).write_text(json.dumps(nav,separators=(',',':'))+'\n')
 print('BUILT_COMPLETE',map_id,len(plan['plots']),len(audit),glb.stat().st_size,len(packed),flush=True)
