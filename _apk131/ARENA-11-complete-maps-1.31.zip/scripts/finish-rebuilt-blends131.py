"""Complete editable scenes with packed, tinted PBR, lighting and observer camera."""
import bpy,math,json,sys
from mathutils import Vector
from pathlib import Path
r=Path(__file__).resolve().parents[1];directory=Path('/workspace/shared/arena-131-blender')
for file in sorted(directory.glob('*.blend')):
 id=file.stem;plan=json.loads((Path('/workspace/.arena-tools/rebuilt131-plans')/(id+'.json')).read_text());info=json.loads((r/'public/rebuilt131'/(id+'-build.json')).read_text());bpy.ops.wm.open_mainfile(filepath=str(file))
 for m in bpy.data.materials:
  if not m.use_nodes:continue
  p=m.node_tree.nodes.get('Principled BSDF')
  if not p:continue
  links=list(p.inputs['Base Color'].links)
  if links and links[0].from_node.type=='TEX_IMAGE':
   source=links[0].from_socket;tint=tuple(p.inputs['Base Color'].default_value);m.node_tree.links.remove(links[0]);mix=m.node_tree.nodes.new('ShaderNodeMixRGB');mix.name='ARENA tint × own PBR';mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=tint;m.node_tree.links.new(source,mix.inputs[1]);m.node_tree.links.new(mix.outputs[0],p.inputs['Base Color'])
 for p in info['props']:
  o=bpy.data.objects.get(p['node'])
  if o and o.location.length<1e-6:
   children=[(child,child.matrix_world.copy())for child in o.children];o.location=(p['x'],-p['z'],p['y']);bpy.context.view_layer.update()
   for child,matrix in children:child.matrix_world=matrix
 scene=bpy.context.scene;scene.render.engine='BLENDER_EEVEE_NEXT';scene.render.resolution_x=1400;scene.render.resolution_y=1000;scene.render.resolution_percentage=100;scene.world=scene.world or bpy.data.worlds.new('ARENA atmosphere');scene.world.use_nodes=True;bg=scene.world.node_tree.nodes.get('Background');bg.inputs[0].default_value=(.58,.66,.62,1);bg.inputs[1].default_value=.65
 v=plan['view'];target=Vector(((v['minX']+v['maxX'])/2,-(v['minZ']+v['maxZ'])/2,plan['groundY']+1));data=bpy.data.cameras.new('Observer 24 degrees');camera=bpy.data.objects.new('ARENA observer camera',data);scene.collection.objects.link(camera);camera.location=target+Vector((4,-30,68));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler();data.type='ORTHO';data.ortho_scale=max(v['maxX']-v['minX'],v['maxZ']-v['minZ'])*1.38;data.clip_end=500;scene.camera=camera
 sun=bpy.data.lights.new('ARENA warm daylight','SUN');sun.energy=2;sun.angle=.12;light=bpy.data.objects.new('ARENA daylight',sun);scene.collection.objects.link(light);light.rotation_euler=(.45,-.35,-.5)
 scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.filepath='//'+id+'-render.png';bpy.context.preferences.filepaths.save_version=0;bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(file),compress=True);print('COMPLETE_EDITABLE',id,len([o for o in scene.objects if o.type=='MESH']),flush=True)
