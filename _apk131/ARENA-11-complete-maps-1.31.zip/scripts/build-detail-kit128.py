"""Blender4.3 reproducible architecture library; mesh details, not cube placeholders.
Coordinates are validated local envelopes. Source maps/nav are not edited.
"""
import bpy,math,json,sys,hashlib,os
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parents[1];OUT=R/'public/detail128';OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
M={}
for name,color in {'wall':(.72,.69,.61,1),'stone':(.69,.68,.6,1),'roof':(.45,.34,.25,1),'wood':(.35,.25,.16,1),'metal':(.29,.35,.35,1),'glass':(.15,.25,.28,1),'leaf':(.29,.42,.25,1),'glow':(.8,.63,.3,1)}.items():
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=color;p.inputs['Roughness'].default_value=.55 if name=='metal'else .82
 if name=='metal':p.inputs['Metallic'].default_value=.28
 M[name]=m
objects=[];ROOTS=[]
def add_mesh(name,verts,faces,kind):
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.materials.append(M[kind]);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);objects.append(o);return o

def box(x,y,z,w,d,h,kind='wall',bevel=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(x,y,z));o=bpy.context.object;o.name=kind;o.scale=(w,d,h);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(M[kind]);objects.append(o)
 if bevel>0:
  m=o.modifiers.new('crafted_edges','BEVEL');m.width=min(bevel,min(w,d,h)*.18);m.segments=2;bpy.ops.object.modifier_apply(modifier=m.name)
 return o

def cylinder(x,y,z,r,h,kind='metal',segments=12,r2=None):
 bpy.ops.mesh.primitive_cone_add(vertices=segments,radius1=r,radius2=r if r2 is None else r2,depth=h,location=(x,y,z));o=bpy.context.object;o.name=kind;o.data.materials.append(M[kind]);objects.append(o)
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 return o

def tube(points,r=.04,kind='metal',segments=7):
 verts=[]
 for i,p in enumerate(points):
  tangent=Vector(points[min(i+1,len(points)-1)])-Vector(points[max(0,i-1)]);tangent.normalize();u=tangent.cross(Vector((0,0,1)))
  if u.length<.1:u=tangent.cross(Vector((0,1,0)))
  u.normalize();v=tangent.cross(u).normalized()
  for j in range(segments):verts.append(tuple(Vector(p)+r*(u*math.cos(j*math.tau/segments)+v*math.sin(j*math.tau/segments))))
 faces=[]
 for i in range(len(points)-1):
  for j in range(segments):faces.append((i*segments+j,i*segments+(j+1)%segments,(i+1)*segments+(j+1)%segments,(i+1)*segments+j))
 return add_mesh('bent_pipe',verts,faces,kind)

def arch(x,y,z,w,h,kind='stone',depth=.14):
 r=w/2;verts=[];steps=14
 for i in range(steps+1):
  a=i*math.pi/steps
  for radius in [r,r+.16]:
   for yy in [-depth/2,depth/2]:verts.append((x+math.cos(a)*radius,y+yy,z+h+math.sin(a)*radius))
 faces=[]
 for i in range(steps):
  a=i*4;b=(i+1)*4;faces.extend([(a,b,b+2,a+2),(a+1,a+3,b+3,b+1),(a,a+1,b+1,b),(a+2,b+2,b+3,a+3)])
 add_mesh('voussoir_arch',verts,faces,kind)
 for side in [-1,1]:box(x+side*(r+.08),y,z+h/2,.16,depth,h,kind)

def leaf(x,y,z,angle,l=.5):
 verts=[]
 for i in range(6):
  t=i/5;width=math.sin(t*math.pi)*.11;px=x+math.cos(angle)*l*t;py=y+math.sin(angle)*l*t;pz=z+.35*math.sin(t*2.1)
  for sign in [-1,1]:verts.append((px-math.sin(angle)*width*sign,py+math.cos(angle)*width*sign,pz))
 add_mesh('curved_leaf_blade',verts,[(i*2,i*2+1,i*2+3,i*2+2)for i in range(5)],'leaf')

def planter(x,y,z,s=1):
 cylinder(x,y,z+.2*s,.3*s,.4*s,'stone',12,r2=.39*s);cylinder(x,y,z+.42*s,.41*s,.07*s,'stone',12);cylinder(x,y,z+.456*s,.34*s,.012*s,'wood',12)
 for i in range(9):leaf(x,y,z+.46*s,i*2.399,.43*s)

def window(x,y,z,w=.65,h=.8):
 box(x,y,z,w,.06,h,'glass',.01)
 for dx in [-w/2,w/2]:box(x+dx,y-.04,z,.06,.1,h+.1,'stone',.015)
 for dz in [-h/2,h/2]:box(x,y-.04,z+dz,w+.1,.1,.06,'stone',.015)
 box(x,y-.08,z,.045,.08,h,'wood',.008);box(x,y-.08,z,w,.08,.035,'wood',.008);box(x,y-.13,z-h/2-.08,w+.2,.35,.13,'stone',.02)

def roof_tiles(w=4.65,d=4.2,z=2.65):
 # Gable with individually curved, overlapping terracotta channels.
 ridge=z+.65
 verts=[(-w/2,-d/2,z),(w/2,-d/2,z),(0,-d/2,ridge),(-w/2,d/2,z),(w/2,d/2,z),(0,d/2,ridge)]
 add_mesh('pitched_gable',verts,[(0,1,2),(3,5,4)],'wall');add_mesh('roof_underlayment',verts,[(0,2,5,3),(1,4,5,2)],'roof')
 for side in [-1,1]:
  for ix in range(7):
   x=side*(ix+.35)*w/14;zz=ridge-abs(x)*1.3/w
   for iy in range(12):
    yy=-d/2+(iy+.1)*d/12;v=[]
    for along in [0,.38]:
     for j in range(5):
      a=j*math.pi/4;vx=x+math.cos(a)*.17;v.append((vx,yy+along,ridge-abs(vx)*1.3/w+math.sin(a)*.07+.035))
    add_mesh('overlapping_roof_tile',v,[(j,j+1,j+6,j+5)for j in range(4)],'roof')
 tube([(0,-d/2-.02,ridge+.07),(0,d/2+.03,ridge+.07)],.085,'roof',9)

def civil(style):
 box(-.32,.13,1.25,3.7,3.7,2.5,'wall',.07);box(1.36,.35,.95,1.0,3.25,1.9,'wall',.06)
 for z in [.12,2.35]:box(-.25,.1,z,4.28,3.94,.16,'stone',.025)
 for x in [-1.4,.8]:window(x,-1.77,1.35)
 for sy in [-.75,.8]:
  start=len(objects);window(0,0,1.12,.65,.72)
  transform=Matrix.Translation(Vector((1.89,sy,0)))@Matrix.Rotation(math.pi/2,4,'Z')
  for o in objects[start:]:o.matrix_world=transform@o.matrix_world
 for i in range(5):box(-2.15,-1.76,.35+i*.4,.23,.17,.22,'stone',.025)
 arch(-.3,-1.85,.15,.9,1.0,'stone',.2);box(-.3,-1.78,.73,.86,.06,1.15,'wood',.03)
 if style=='terracotta':roof_tiles()
 else:
  box(-.22,.1,2.62,4.4,4.1,.18,'stone',.04)
  for x in [-2.3,1.92]:box(x,.1,2.85,.17,4.15,.42,'wall',.04)
  for y in [-1.95,2.15]:box(-.2,y,2.85,4.3,.17,.42,'wall',.04)
  for i in range(5):box(-1.65+i*.72,.1,3.05,.1,2.7,.12,'wood',.015)
 # Curved gutter, bracketed downpipe, shutter panels and a real balcony balustrade.
 tube([(-2.15,-1.9,2.62),(1.7,-1.9,2.62)],.055,'metal')
 tube([(1.7,-1.9,2.62),(1.85,-1.95,2.5),(1.85,-1.95,.25),(1.95,-2.1,.14)],.045,'metal')
 for x in [-1.4,.8]:
  for side in [-1,1]:box(x+side*.45,-1.87,1.35,.16,.1,.86,'wood',.012)
 box(-.3,-2.13,.95,1.75,.52,.12,'stone',.025)
 for i in range(8):tube([(-1.05+i*.22,-2.36,1.02),(-1.05+i*.22,-2.36,1.58)],.019,'metal',5)
 tube([(-1.13,-2.36,1.6),(.55,-2.36,1.6)],.025,'metal',6)
 box(-1.3,.6,3.0,.42,.5,.75,'wall',.04);box(-1.3,.6,3.42,.57,.65,.1,'stone',.025)
 planter(1.35,1.25,2.55,.7)

def industrial(style):
 length=4.7;depth=2.45 if style=='rail'else 3.9;height=2.05 if style=='rail'else 13.8 if style=='sky'else 2.65
 box(0,0,height/2,length,depth,height,'metal',.09);box(0,0,.16,length+.14,depth+.1,.24,'metal',.025)
 for x in [-2.12,-1.05,0,1.05,2.12]:
  box(x,-depth/2-.025,height/2,.065,.09,height-.2,'stone',.008)
  if abs(x)<2:
   if style=='sky':
    for row in range(7):box(x,-depth/2-.07,1.2+row*1.8,.7,.06,.72,'glass',0)
   else:window(x,-depth/2-.07,1.2,.7,.62)
 if style=='sky':
  for row in range(7):
   for sy in [-1.1,0,1.1]:box(length/2+.03,sy,1.2+row*1.8,.06,.72,.72,'glass',0)
   box(0,-depth/2-.08,.5+row*1.8,length,.1,.08,'stone',.008)
   box(length/2+.04,0,.5+row*1.8,.1,depth,.08,'stone',.008)
  for sy in [-1.7,-.55,.55,1.7]:box(length/2+.05,sy,height/2,.08,.06,height,'metal',.008)
 if style=='rail':
  # Curved wagon roof, bogies and flanged wheels, rather than a box railcar.
  for i in range(13):
   a=i*math.pi/12;box(0,math.cos(a)*depth*.49,height+math.sin(a)*.38,length,.19,.085,'roof',.015)
  for x in [-1.5,1.5]:
   box(x,0,.24,.75,depth+.12,.25,'metal')
   for y in [-depth/2,depth/2]:
    o=cylinder(x,y,.3,.29,.16,'metal',12);o.rotation_euler[0]=math.pi/2
 else:
  for i in range(18):box(-2.25+i*.265,0,height+.1,.06,depth+.18,.16,'roof',.015)
  box(-.8,.4,height+.33,1.1,1.0,.45,'metal',.06)
  for i in range(6):box(-1.22+i*.17,-.12,height+.34,.045,.04,.31,'glass',.005)
  cylinder(.9,.6,height+.35,.32,.7,'metal',16);cylinder(.9,.6,height+.73,.42,.08,'metal',16)
  tube([(.9,.6,height+.75),(.9,.6,height+1.04),(1.2,.6,height+1.18),(1.5,.6,height+1.18)],.095,'metal',9)
  # Roof solar/truss frame with split cells and ribbed doorway.
  panel=box(.25,-.75,height+.31,2.1,1.25,.08,'glass',.02);panel.rotation_euler[0]=.12
  for i in range(6):box(-.68+i*.37,-.75,height+.37,.025,1.25,.025,'metal',.003)
  for i in range(12):box(1.65,-depth/2-.055,.3+i*.12,.8,.06,.075,'metal',.01)

def ruins(style):
 # Layered, broken masonry with offset courses, fluted columns and true arch.
 for layer in range(3):box(0,0,.12+layer*.17,4.65-layer*.28,4.4-layer*.24,.22,'stone',.065)
 for side in [-1,1]:
  for course in range(6):
   for i in range(3):
    x=side*(1.02+i*.48);box(x,.7,.69+course*.29,.46,.75,.27,'stone',.035)
  for x in [side*1.72]:
   cylinder(x,-.95,1.28,.22,1.65,'stone',12);cylinder(x,-.95,.49,.34,.15,'stone',12);box(x,-.95,2.17,.65,.65,.17,'stone',.04)
 arch(0,.29,.52,1.55,1.12,'stone',.5)
 for i in range(4):box(-1.5+i*.85,.6,2.47,.78,.95,.22,'stone',.06)
 for i in range(8):leaf(-1.8+(i%3)*.2,.85,1.2+(i%4)*.2,i*1.2,.65)
 planter(1.35,1.5,.5,.9)
 if style=='river':
  for i in range(5):cylinder(-1.3+i*.65,1.5,1.06,.11,1.1,'stone',10)
  box(0,1.5,1.7,3.3,.45,.18,'stone',.03)

def pocket(style):
 box(0,0,.07,2.95,2.5,.14,'stone',.05)
 for x,y in [(-1,-.7),(1,.7)]:planter(x,y,.13,.85)
 for x in [-.8,.8]:
  for y in [-.45,.45]:cylinder(x,y,.9,.055,1.6,'metal',8)
 for i in range(5):box(-.9+i*.45,0,1.76,.075,1.4,.11,'wood',.014)
 for i in range(5):box(-.72+i*.35,.74,.48,.24,.35,.08,'wood',.014)
 for x in [-.65,.65]:tube([(x,.72,.43),(x,.72,.18),(x,.9,.14)],.035,'metal',7)
 if style in ['garden','moon','river']:
  cylinder(.2,-.45,.46,.34,.55,'stone',10,r2=.23);cylinder(.2,-.45,.78,.43,.1,'stone',12)
 else:arch(.0,-.8,.15,.82,.65,'stone',.12)

def roof_detail():
 box(0,0,.24,.72,.65,.48,'metal',.045)
 for i in range(6):box(-.29+i*.115,-.34,.24,.04,.04,.32,'glass',.005)
 cylinder(.12,.03,.55,.19,.17,'metal',12);tube([(.12,.03,.6),(.12,.03,.78),(.28,.03,.83)],.055,'metal',8)

STYLES={'dust2':'sandstone','mirage':'arcade','inferno':'terracotta','nuke':'energy','train':'rail','ancient':'garden','ancient-night':'moon','anubis':'river','overpass':'park','vertigo':'sky','cache':'workshop'}
records=[]
for mapIndex,(id,style) in enumerate(STYLES.items()):
 for kindIndex,kind in enumerate(['building','pocket','planter','roof']):
  objects=[]
  if kind=='building':
   if style in ['garden','moon','river']:ruins(style)
   elif style in ['energy','rail','sky','workshop']:industrial(style)
   else:civil(style)
  elif kind=='pocket':pocket(style)
  elif kind=='planter':planter(0,0,0,1.2)
  else:roof_detail()
  bpy.ops.object.select_all(action='DESELECT')
  for o in objects:o.select_set(True)
  bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();o=bpy.context.object;o.name=id.replace('-','_')+'__'+kind
  bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
  # Bake world transform into mesh and recenter model at its authored local origin.
  for v in o.data.vertices:v.co=o.matrix_world@v.co
  o.matrix_world.identity()
  # Box projection in real local units yields consistent tile frequency.
  while len(o.data.uv_layers):o.data.uv_layers.remove(o.data.uv_layers[0])
  uv=o.data.uv_layers.new(name='DetailUV')
  for poly in o.data.polygons:
   axis=max(range(3),key=lambda i:abs(poly.normal[i]));dims=[i for i in range(3)if i!=axis]
   for li in poly.loop_indices:
    v=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[dims[0]]*.5,v[dims[1]]*.5)
  o.data.uv_layers.active=uv
  o.location=(mapIndex*7,kindIndex*7,0);ROOTS.append(o);tri=sum(len(p.vertices)-2 for p in o.data.polygons);xs=[v.co.x for v in o.data.vertices];ys=[v.co.y for v in o.data.vertices];zs=[v.co.z for v in o.data.vertices]
  records.append({'map':id,'kind':kind,'node':o.name,'catalog':[mapIndex*7,kindIndex*7],'triangles':tri,'bounds':[min(xs),min(ys),min(zs),max(xs),max(ys),max(zs)]})
  print('MODELED',id,kind,tri,flush=True)
# Save an editable Blender source and a render-only GLB library.
blendOutput=Path(os.environ.get('ARENA_BLEND_OUTPUT',str(R/'generated/ARENA-CS2-detail128.blend')));blendOutput.parent.mkdir(parents=True,exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(blendOutput))
bpy.ops.export_scene.gltf(filepath=str(OUT/'architecture.glb'),export_format='GLB',export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_materials='EXPORT',export_extras=True,export_apply=True)
p=OUT/'architecture.glb';metadata={'schema':1,'builder':'Blender4.3.2','source':'scripts/build-detail-kit128.py','sourceMapGeometryModified':False,'geometryOrigin':'ARENA modeled architectural details inspired by source-map setting','runtimeTextures':'Matched to supplied CS2 map materials; fallback Blender material if no matching source texture','models':records,'library':{'url':'/detail128/architecture.glb','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}
(OUT/'models.json').write_text(json.dumps(metadata,indent=2)+'\n');(R/'src/detail128-manifest.json').write_text(json.dumps(metadata,indent=2)+'\n');print('LIBRARY',p.stat().st_size,flush=True)
