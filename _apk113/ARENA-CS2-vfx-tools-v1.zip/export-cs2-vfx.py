"""Read installed CS2 particle resources with the pinned Source2Viewer20.1.
Never writes to the game directory. No game assets are downloaded.
"""
import argparse,datetime,hashlib,importlib.util,json,os,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('arena_export_common',ROOT/'export-cs2-visuals.py');common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
RESOURCE=re.compile(r'(?i)(?<![a-z0-9_./-])((?:particles|materials)/(?:[a-z0-9_.-]+/)*[a-z0-9_.-]+\.(?:vpcf|vmat|vtex)(?:_c)?)')
KEYWORDS=re.compile(r'molotov|incendiary|smokegrenade|flashbang|hegrenade|grenade_explosion|explosion_c4|bomb_explosion|weapon_c4|c4_explosion',re.I)
MATERIALS=re.compile(r'fire|flame|smoke|flash|explos|ember|spark|dust|scorch',re.I)
MAX_FILES=768;MAX_BYTES=512*1024**2

def resources(text):
 result=set()
 for match in RESOURCE.findall(text.replace('\\','/')):
  path=match.lower()
  if any(p in ['.','..'] for p in path.split('/')):continue
  result.add(path if path.endswith('_c') else path+'_c')
 return result

def select_resources(listing):
 return sorted(p for p in resources(listing) if p.startswith('particles/') and KEYWORDS.search(p) or p.startswith(('materials/particles/','materials/particle/','materials/effects/')) and MATERIALS.search(p))

def export(game,viewer,output):
 game=common.normalize_game(game);output=Path(output).resolve()
 install=game.parent.parent if game.parent.name.lower()=='game' else game
 if output==install or install in output.parents:raise ValueError('Eksport papkasi CS2 papkasidan tashqarida bolishi kerak.')
 output.mkdir(parents=True,exist_ok=False);assets=output/'assets';assets.mkdir()
 log=(output/'diagnostics.txt').open('w',encoding='utf-8');common.RUN_LOG=log
 try:
  pak=game/'pak01_dir.vpk'
  if not pak.is_file():raise ValueError('pak01_dir.vpk topilmadi: '+str(game))
  listing=common.run_cli([str(viewer),'--input',str(pak),'--vpk_list','--vpk_extensions','vpcf_c,vmat_c,vtex_c'],capture=True)
  known=resources(listing);todo=set(select_resources(listing));done=set()
  if not any(p.startswith('particles/') for p in todo):raise ValueError('Granata zarracha resurslari topilmadi. diagnostics.txt faylini yuboring.')
  for depth in range(6):
   pending=sorted(todo-done)
   if not pending:break
   if len(done)+len(pending)>MAX_FILES:raise ValueError('VFX fayllari limiti oshdi; diagnostics.txt yuboring.')
   for start in range(0,len(pending),12):
    batch=pending[start:start+12];print('VFX:',len(done),'/',len(done)+len(pending),'qadam',depth+1,flush=True)
    common.run_cli([str(viewer),'--input',str(pak),'--vpk_filepath',','.join(batch),'--decompile','--threads','2','--output',str(assets)+os.sep]);done.update(batch)
    if sum(p.stat().st_size for p in assets.rglob('*') if p.is_file())>MAX_BYTES:raise ValueError('512 MiB chegarasi oshdi; mavjud fayllar saqlandi.')
   for p in assets.rglob('*'):
    if p.is_file() and p.suffix.lower() in ['.vpcf','.vmat','.vtex','.mks','.txt','.json'] and p.stat().st_size<2*1024**2:
     todo.update(resources(p.read_text(encoding='utf-8',errors='replace'))&known)
  files=sorted(p for p in assets.rglob('*') if p.is_file())
  if not any(p.suffix.lower()=='.png' for p in files):raise ValueError('PNG teksturalar chiqmadi. diagnostics.txt yuboring; bosh ZIP tayyor deb korsatilmaydi.')
  manifest={'schema':1,'assetType':'cs2-vfx','clientVersion':common.client_version(game),'exporter':'Source2Viewer-CLI20.1','resources':sorted(done),'unresolvedResources':sorted(todo-done),'files':{p.relative_to(output).as_posix():{'bytes':p.stat().st_size,'sha256':common.file_hash(p)} for p in files},'rights':'Original CS2/Valve assets; source particle definitions require adaptation to the Arena renderer.'}
  manifestPath=output/'ARENA-vfx-export.json';manifestPath.write_text(json.dumps(manifest,indent=2),encoding='utf-8');files.append(manifestPath)
  archive=output.with_suffix('.zip');partial=archive.with_suffix('.zip.partial')
  if archive.exists() or partial.exists():raise ValueError('Oldingi ZIP saqlanadi. Yangi papka tanlang.')
  with zipfile.ZipFile(partial,'w',zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
   for p in files:z.write(p,p.relative_to(output).as_posix())
  with zipfile.ZipFile(partial) as z:
   if z.testzip():raise ValueError('ZIP yaxlitlik tekshiruvi otmadi.')
  partial.rename(archive)
  if archive.stat().st_size>24*1024**2:
   spec=importlib.util.spec_from_file_location('arena_transfer',ROOT/'cs2-transfer.py');transfer=importlib.util.module_from_spec(spec);spec.loader.exec_module(transfer);transfer.split(archive)
  print('TAYYOR:',archive,flush=True);print('Shu ZIP faylini yuboring. Oyin fayllari ozgarmadi.',flush=True);return archive
 finally:log.close();common.RUN_LOG=None

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--game',default=r'E:\Steam Game\steamapps\common\Counter-Strike Global Offensive');parser.add_argument('--viewer');parser.add_argument('--output');args=parser.parse_args()
 output=Path(args.output or ('ARENA-CS2-VFX-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')))
 try:return export(args.game,Path(args.viewer).resolve() if args.viewer else common.official_viewer(),output)
 except Exception as error:
  diagnostic=Path.cwd()/('ARENA-VFX-diagnostics-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.txt');diagnostic.write_text(str(error),encoding='utf-8');print('XATO:',error,flush=True);print('Diagnostika:',diagnostic,flush=True);raise SystemExit(1)
if __name__=='__main__':main()
