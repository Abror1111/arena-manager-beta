ARENA: asl CS2 granata VFX eksporti

1. ZIPni yangi papkaga oching.
2. Export-VFX.cmd faylini ikki marta bosing. Python3 kerak (oldingi eksport vositasi bilan bir xil).
3. Siz bergan E:\Steam Game\steamapps\common\Counter-Strike Global Offensive manzili ishlatiladi.
4. Oxirida TAYYOR yozuvi va ARENA-CS2-VFX-....zip fayli chiqadi. Shu ZIPni yuboring.

Boshqa CS2 manzili uchun buyruq:
py -3 export-cs2-vfx.py --game "D:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive"

XATO bolsa diagnostics.txt faylini yuboring. Qisman eksportlar ochirilmaydi.
Asl oyinning VPK fayllari faqat oqiladi. Source2Viewer20.1 rasmiy GitHub relizidan yuklanadi va SHA256 tekshiriladi. Hech qanday Steam login/token kerak emas.

Bu yordamchi haqiqiy granata particle tariflari va ularga tegishli material/teksturalarni yigadi. Source2 particle tizimi Arena/WebGL ichida avtomatik1:1 ishlamaydi; uning materiallari va animatsiya parametrlari moslashtiriladi.

ZIP24MiB dan katta bolsa, avtomatik kichik bolaklar va ARENA-upload-manifest.json ham tayyorlanadi. Asl ZIP ham saqlanadi.
