@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 export-cs2-vfx.py %*
) else (
 python export-cs2-vfx.py %*
)
echo.
pause
