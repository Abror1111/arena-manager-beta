"""Editable bounded scenery for the existing CS2 scenes. No source assets edited.
Run in Blender 4.3: blender -b --python scripts/build-scenery129.py.
"""
import bpy, math, random, json, hashlib, os
from pathlib import Path
from mathutils import Vector

R = Path(__file__).resolve().parents[1]
OUT = R / 'public/detail129'
OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
materials = {}
for name, color in {'bark': (.24,.17,.10,1), 'leaf': (.30,.43,.20,1),
                    'wood': (.40,.30,.18,1), 'metal': (.22,.26,.25,1),
                    'stone': (.47,.47,.41,1)}.items():
    m = bpy.data.materials.new(name)
    m.diffuse_color = color
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = color
    p.inputs['Roughness'].default_value = .9
    materials[name] = m

objects = []
def mesh(name, verts, faces, kind):
    g = bpy.data.meshes.new(name)
    g.from_pydata(verts, [], faces)
    g.materials.append(materials[kind])
    g.update()
    o = bpy.data.objects.new(name, g)
    bpy.context.collection.objects.link(o)
    objects.append(o)
    return o

def tube(points, radius, kind='bark', sides=9):
    verts=[]
    for i, point in enumerate(points):
        p = Vector(point)
        axis = Vector(points[min(i+1,len(points)-1)])-Vector(points[max(0,i-1)])
        axis.normalize()
        u = axis.cross(Vector((0,1,0))).normalized()
        v = axis.cross(u).normalized()
        r = radius*(1-i/(len(points)-1)*.74)
        for k in range(sides):
            a = k*math.tau/sides
            verts.append(tuple(p + r*(u*math.cos(a)+v*math.sin(a))))
    faces=[tuple(range(sides-1,-1,-1)),tuple((len(points)-1)*sides+k for k in range(sides))]
    for i in range(len(points)-1):
        for k in range(sides):
            a=i*sides+k;b=i*sides+(k+1)%sides
            faces.append((a,b,b+sides,a+sides))
    return mesh('tapered_branch',verts,faces,kind)

def blade(point, angle, length, width, droop=0):
    # A curved six-sided leaf with a raised central vein; no crossed leaf cards.
    x,y,z=point;verts=[]
    for i in range(5):
        t=i/4; w=math.sin(math.pi*t)*width
        for side in [-1,0,1]:
            verts.append((x+math.cos(angle)*length*t-math.sin(angle)*w*side,
                          y+math.sin(angle)*length*t+math.cos(angle)*w*side,
                          z+math.sin(t*math.pi)*.06*(1-abs(side))-droop*t*t))
    faces=[]
    for i in range(4):
        for k in range(2):
            a=i*3+k;faces.append((a,a+1,a+4,a+3))
    return mesh('curved_veined_leaf',verts,faces,'leaf')

def broadleaf(style,rng):
    tube([(0,0,0),(.08,-.04,.8),(-.05,.06,1.7),(.13,.03,2.6),(.08,.05,3.35)],.17)
    for k in range(7):
        a=k*2.399;h=1.55+(k%3)*.5;r=.8+(k%2)*.12
        tip=(math.cos(a)*r,math.sin(a)*r,h+.7)
        tube([(.02,0,h),(math.cos(a)*r*.4,math.sin(a)*r*.4,h+.3),tip],.07,sides=7)
        for j in range(14):
            theta=j*2.399+a;dist=.05+(j%4)*.13
            point=(tip[0]+math.cos(theta)*dist,tip[1]+math.sin(theta)*dist,tip[2]+rng.uniform(-.14,.42))
            blade(point,theta,.32+rng.random()*.22,.10+rng.random()*.045,.12)
    for k in range(16):
        a=k*2.399;blade((math.cos(a)*.3,math.sin(a)*.3,3.28+(k%4)*.09),a,.45,.13,.1)
    # Visible root buttresses connect the trunk to the terrain.
    for k in range(5):
        a=k*math.tau/5;tube([(0,0,.24),(math.cos(a)*.28,math.sin(a)*.28,.04),(math.cos(a)*.43,math.sin(a)*.43,-.035)],.075,sides=6)

def palm(style,rng):
    points=[(.09*math.sin(i*.6),i*.016,i*.45)for i in range(9)]
    tube(points,.145,sides=12)
    # Diamond-shaped bark scars on a genuinely curved trunk.
    for i in range(15):
        z=.22+i*.22;a=i*2.399
        tube([(.10*math.cos(a),.10*math.sin(a),z),(.14*math.cos(a),.14*math.sin(a),z+.11),(.10*math.cos(a),.10*math.sin(a),z+.2)],.025,sides=5)
    for k in range(11):
        a=k*math.tau/11;r=1.40
        path=[(math.cos(a)*r*t, .13+math.sin(a)*r*t, 3.6+.42*math.sin(t*math.pi)-.55*t*t)for t in [0,.2,.4,.6,.8,1]]
        tube(path,.035,'bark',5)
        for j in range(1,8):
            t=j/8;p=(math.cos(a)*r*t,.13+math.sin(a)*r*t,3.6+.42*math.sin(t*math.pi)-.55*t*t)
            for sign in [-1,1]:blade(p,a+sign*1.05,.29*(1-t*.6),.045,.14)
    for k in range(5):
        a=k*2.4;tube([(.10*math.cos(a),.13+.10*math.sin(a),3.45),(.16*math.cos(a),.13+.16*math.sin(a),3.29)],.08,'wood',8)

def boulder(style,rng):
    # Irregular fractured high-valence rock surface, rather than a primitive.
    for k,(x,y,s) in enumerate([(0,0,1),(.92,.45,.42),(-.68,.55,.29)]):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1,location=(x,y,.28*s))
        o=bpy.context.object;o.name='eroded_fractured_rock';o.data.materials.append(materials['stone']);objects.append(o)
        for v in o.data.vertices:
            n=v.co.normalized();w=1+.12*math.sin(n.x*11+n.y*6)+rng.uniform(-.05,.05)
            v.co=(v.co.x*s*w,v.co.y*s*.73*w,max(-.31*s,v.co.z*s*.56*w))
        for p in o.data.polygons:p.use_smooth=True
    # Separated narrow chips, preserving the established footprint.
    tube([(-.5,-.3,.25),(-.34,-.36,.46),(-.1,-.34,.52)],.035,'stone',6)

def cuboid(x,y,z,w,d,h,kind='wood',bevel=.018):
    bpy.ops.mesh.primitive_cube_add(size=1,location=(x,y,z))
    o=bpy.context.object;o.name='crate_'+kind;o.scale=(w,d,h)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(materials[kind]);objects.append(o)
    mod=o.modifiers.new('worn_edges','BEVEL');mod.width=bevel;mod.segments=2
    bpy.ops.object.modifier_apply(modifier=mod.name)
    return o

def cargo(style,rng):
    # Pallet, separate planks, cross braces, steel bands and recessed handle.
    for j in range(4):cuboid(-.48+j*.32,0,.045,.22,1.2,.13)
    for i in range(6):
        z=.20+i*.14
        cuboid(0,-.49,z,1.2,.095,.13);cuboid(0,.49,z,1.2,.095,.13)
        cuboid(-.55,0,z,.10,.9,.13);cuboid(.55,0,z,.10,.9,.13)
    for j in range(6):cuboid(-.48+j*.19,0,1.04,.18,1.05,.10)
    for x in [-.42,.42]:
        for y in [-.55,.55]:cuboid(x,y,.59,.085,.06,.96,'metal',.008)
        cuboid(x,0,1.105,.085,1.10,.035,'metal',.006)
    for y in [-.555,.555]:
        brace=cuboid(0,y,.61,1.17,.065,.07);brace.rotation_euler[1]=.55
        tube([(-.14,y,.73),(-.14,y-.045,.68),(.14,y-.045,.68),(.14,y,.73)],.022,'metal',6)
    for x in [-.42,.42]:
        for z in [.2,.93]:tube([(x,-.61,z),(x,-.59,z)],.028,'metal',6)

styles={'dust2':'sandstone','mirage':'arcade','inferno':'terracotta','nuke':'energy','train':'rail','ancient':'garden','ancient-night':'moon','anubis':'river','overpass':'park','vertigo':'sky','cache':'workshop'}
models=[];canonical={}
for i,(map_id,style)in enumerate(styles.items()):
    for j,(kind,builder)in enumerate({'tree':broadleaf,'palm':palm,'rock':boulder,'crate':cargo}.items()):
        objects=[];builder(style,random.Random(j))
        bpy.ops.object.select_all(action='DESELECT')
        for o in objects:o.select_set(True)
        bpy.context.view_layer.objects.active=objects[0]
        bpy.ops.object.join();o=bpy.context.object;o.name=map_id.replace('-','_')+'__'+kind
        for v in o.data.vertices:v.co=o.matrix_world@v.co
        o.matrix_world.identity()
        while o.data.uv_layers:o.data.uv_layers.remove(o.data.uv_layers[0])
        uv=o.data.uv_layers.new(name='SceneryUV')
        for poly in o.data.polygons:
            axis=max(range(3),key=lambda a:abs(poly.normal[a]));dims=[a for a in range(3)if a!=axis]
            for k in poly.loop_indices:
                v=o.data.vertices[o.data.loops[k].vertex_index].co
                uv.data[k].uv=(v[dims[0]],v[dims[1]])
        # Authored subtle leaf variation, not foliage animation weights.
        colors=o.data.color_attributes.new(name='Pigment',type='FLOAT_COLOR',domain='CORNER')
        for poly in o.data.polygons:
            leaf=o.data.materials[poly.material_index].name=='leaf'
            factor=.86+.14*((poly.index*73%31)/30)
            for k in poly.loop_indices:
                p=o.data.vertices[o.data.loops[k].vertex_index].co
                color=(factor*.9,factor,factor*.87,1)if leaf else(1,1,1,1)
                colors.data[k].color=color
        xyz=[tuple(v.co)for v in o.data.vertices];bounds=[min(p[a]for p in xyz)for a in range(3)]+[max(p[a]for p in xyz)for a in range(3)]
        # Share the same authored mesh across map palettes and placements.
        # This keeps eleven catalog views from duplicating mobile GPU/download data.
        if kind in canonical:o.data=canonical[kind]
        else:canonical[kind]=o.data
        o.location=(i*5,j*6,0)
        models.append({'map':map_id,'kind':kind,'node':o.name,'catalog':[i*5,j*6],'bounds':bounds,'triangles':sum(len(p.vertices)-2 for p in o.data.polygons)})
        print('MODELED',map_id,kind,models[-1]['triangles'],flush=True)

dest=Path(os.environ.get('ARENA_BLEND_OUTPUT',str(R/'generated/ARENA-scenery129.blend')))
dest.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(dest))
bpy.ops.export_scene.gltf(filepath=str(OUT/'scenery.glb'),export_format='GLB',export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_materials='EXPORT',export_extras=True,export_apply=True)
b=(OUT/'scenery.glb').read_bytes()
manifest={'schema':1,'builder':'Blender4.3.2','source':'scripts/build-scenery129.py','sourceMapGeometryModified':False,'geometryOrigin':'ARENA authored foliage, eroded rocks and slatted cargo, placed outside existing playable routes','models':models,'library':{'url':'/detail129/scenery.glb','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}}
(OUT/'models.json').write_text(json.dumps(manifest,indent=2)+'\n')
(R/'src/scenery129-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
