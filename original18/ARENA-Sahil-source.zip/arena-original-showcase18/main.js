import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

// Original ARENA procedural architecture, materials, characters, animation,
// synthesized sound and effects. No imported game media or scene data.
const $=s=>document.querySelector(s),clamp=T.MathUtils.clamp,lerp=T.MathUtils.lerp;
let seed=1831029;function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}const range=(a,b)=>a+(b-a)*random();
const reduced=matchMedia('(prefers-reduced-motion:reduce)').matches;
const materials={},geos={},obstacles=[],roofParts=[],agents=[],effects=[],tracers=[],grenades=[],fires=[],ripples=[],birds=[],clouds=[],agentBatches=[];
let renderer,scene,camera,world,water,particles,particleGeo,sun,clock,sim=0,paused=false,quality='HD',cameraMode='overview',selected=0,cycle=0,flash=0,eventUntil=0,autoPoint=new T.Vector3(0,1,1),lastAction=0,focusUntil=0,frame=0,ready=false;
let yaw=.76,pitch=.84,zoom=1,cameraShake=0,c4=null,frames=0,fpsTime=0,lastFps=60;
const aim=new T.Vector3(0,0,1),camAim=new T.Vector3(0,1,0),camGoal=new T.Vector3(),viewPoint=new T.Vector3(),tempV=new T.Vector3();
const names=['KAI','MIRA','REN','SORA','RYO','AXEL','NOVA','LEO','YUNA','EZRA'];
const weapons=[['AR-7',30,30],['VX-4',25,25],['R-90',10,10],['SM-2',32,32],['AR-7',30,30]];
const sceneStats={originalMedia:true,sourceGameAssets:0,map:'Sahil',buildings:0,materialTextures:0,agentCount:10};

function texture(kind,color){
 const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d');g.fillStyle=color;g.fillRect(0,0,512,512);
 for(let i=0;i<16000;i++){const v=random()>.5?255:0;g.fillStyle=`rgba(${v},${v},${v},${range(.015,.075)})`;const s=range(.5,2.8);g.fillRect(random()*512,random()*512,s,s)}
 if(kind==='plaster'){
  for(let i=0;i<130;i++){g.fillStyle=`rgba(86,67,43,${range(.015,.065)})`;g.beginPath();g.ellipse(random()*512,random()*512,range(5,35),range(3,16),0,0,7);g.fill()}
  for(let i=0;i<18;i++){let x=random()*512,y=random()*512;g.strokeStyle='#3b302313';g.lineWidth=range(.5,1.4);g.beginPath();g.moveTo(x,y);for(let j=0;j<5;j++){x+=range(-9,9);y+=range(3,12);g.lineTo(x,y)}g.stroke()}
 }else if(kind==='stone'||kind==='paving'){
  const h=kind==='stone'?64:85,w=kind==='stone'?128:85;
  for(let r=0;r<512/h;r++)for(let col=-1;col<512/w+1;col++){let x=col*w+(r%2)*w*.5;g.fillStyle=`rgba(${random()>.5?'255,249,231':'74,64,50'},${range(.025,.13)})`;g.fillRect(x+2,r*h+2,w-4,h-4);g.strokeStyle='#4c4c3a29';g.lineWidth=2;g.strokeRect(x+1,r*h+1,w-2,h-2);g.strokeStyle='#fff8d635';g.strokeRect(x+3,r*h+3,w-6,h-6)}
 }else if(kind==='roof'){
  for(let y=0;y<512;y+=25)for(let x=-30;x<512;x+=50){const xx=x+(Math.floor(y/25)%2)*25;g.fillStyle=`rgba(75,30,15,${range(.1,.3)})`;g.fillRect(xx,y,48,23);const grad=g.createLinearGradient(xx,y,xx+48,y);grad.addColorStop(0,'#ea9c6722');grad.addColorStop(.5,'#ffd2a155');grad.addColorStop(1,'#52241066');g.fillStyle=grad;g.fillRect(xx+2,y+1,45,20)}
 }else if(kind==='wood'){
  for(let x=0;x<512;x+=45){g.strokeStyle='#20150c70';g.lineWidth=3;g.beginPath();g.moveTo(x,0);g.lineTo(x,512);g.stroke();for(let j=0;j<30;j++){g.strokeStyle='#d9aa6920';g.lineWidth=range(.5,2);g.beginPath();g.moveTo(x+random()*43,0);g.bezierCurveTo(x+range(0,45),170,x+range(0,45),330,x+range(0,45),512);g.stroke()}}
 }else if(kind==='tile'){
  g.fillStyle='#123e42';g.fillRect(0,0,512,512);for(let y=0;y<512;y+=64)for(let x=0;x<512;x+=64){g.strokeStyle='#d5c298';g.lineWidth=2;g.strokeRect(x+2,y+2,60,60);g.save();g.translate(x+32,y+32);g.rotate(Math.PI/4);g.strokeStyle='#7baba3';g.strokeRect(-16,-16,32,32);g.fillStyle='#d4ba7d';g.fillRect(-4,-4,8,8);g.restore()}
 }
 const tex=new T.CanvasTexture(c);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);tex.repeat.set(kind==='tile'?1:2,kind==='tile'?1:2);sceneStats.materialTextures++;return tex;
}
function mat(name,color,kind='plaster',extra={}){return materials[name]=new T.MeshStandardMaterial({color:0xffffff,map:texture(kind,color),roughness:.88,...extra})}
function solid(name,color,extra={}){return materials[name]=new T.MeshStandardMaterial({color,roughness:.72,...extra})}
function mesh(geo,ma,parent=world,x=0,y=0,z=0,rx=0,ry=0,rz=0){const m=new T.Mesh(geo,ma);m.position.set(x,y,z);m.rotation.set(rx,ry,rz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function box(parent,ma,x,y,z,w,h,d){const m=mesh(geos.box,ma,parent,x,y,z);m.scale.set(w,h,d);return m}
function capsule(parent,ma,x,y,z,w,h,d){const m=mesh(geos.capsule,ma,parent,x,y,z);m.scale.set(w*.5,h/3,d*.5);return m}
function cyl(parent,ma,x,y,z,r,h,segments=12,rTop=r){return mesh(new T.CylinderGeometry(rTop,r,h,segments),ma,parent,x,y,z)}
function sphere(parent,ma,x,y,z,r,sx=1,sy=1,sz=1){const m=mesh(geos.sphere,ma,parent,x,y,z);m.scale.set(r*sx,r*sy,r*sz);return m}
function beam(parent,ma,a,b,r=.05){const v=new T.Vector3().subVectors(b,a),m=mesh(new T.CylinderGeometry(r,r,v.length(),7),ma,parent);m.position.copy(a).add(b).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return m}
function archShape(w,h,border=.2){const sh=new T.Shape();sh.moveTo(-w/2,0);sh.lineTo(w/2,0);sh.lineTo(w/2,h-w*.5);sh.absarc(0,h-w*.5,w*.5,0,Math.PI,false);sh.lineTo(-w/2,0);if(border){const r=w/2-border,hole=new T.Path();hole.moveTo(-r,.02);hole.lineTo(-r,h-w*.5);hole.absarc(0,h-w*.5,r,Math.PI,0,true);hole.lineTo(r,.02);hole.closePath();sh.holes.push(hole)}return sh}
function arch(parent,ma,x,y,z,w,h,depth=.13,border=.17){return mesh(new T.ExtrudeGeometry(archShape(w,h,border),{depth,bevelEnabled:false,curveSegments:12}),ma,parent,x,y,z)}
function addObstacle(x,z,w,d,h=5){obstacles.push({minX:x-w/2-.45,maxX:x+w/2+.45,minZ:z-d/2-.45,maxZ:z+d/2+.45,h})}

function windowDetail(parent,x,y,z,w=1,h=1.5,fancy=false){
 box(parent,materials.dark,x,y+h/2,z,w,h,.045);box(parent,materials.wood,x-w*.27,y+h*.48,z+.045,w*.42,h*.88,.08);box(parent,materials.wood,x+w*.27,y+h*.48,z+.045,w*.42,h*.88,.08);
 for(const dx of [-1,1])box(parent,materials.trim,x+dx*(w/2+.07),y+h/2,z+.05,.11,h+.22,.13);
 box(parent,materials.trim,x,y+h+.055,z+.06,w+.25,.12,.18);box(parent,materials.trim,x,y-.03,z+.13,w+.35,.17,.37);
 for(let i=1;i<6;i++)box(parent,materials.woodLight,x,y+i*h/6,z+.11,w*.92,.025,.035);
 if(fancy){arch(parent,materials.trim,x,y-.05,z+.13,w+.4,h+.55,.12,.12);box(parent,materials.tile,x,y-.3,z+.15,w+.45,.24,.12)}
}
function facade(parent,width,height,depth,style=0){
 // Local +Z faces outward; all four facades are actually built.
 const floors=Math.max(1,Math.round(height/3));
 for(let f=0;f<floors;f++){
  let yy=f*2.75+1.05;const count=Math.floor(width/2.4);
  for(let i=0;i<count;i++){const xx=(i-(count-1)/2)*2.35;if(f===0&&i===Math.floor(count/2)&&style!==2){box(parent,materials.dark,xx,1.1,depth/2+.025,1.25,2.2,.08);arch(parent,materials.trim,xx,.02,depth/2+.12,1.65,2.75,.15,.2);box(parent,materials.wood,xx,1.03,depth/2+.08,1.05,2.05,.06);for(let k=0;k<5;k++)box(parent,materials.woodLight,xx-.42+k*.21,1.02,depth/2+.13,.025,2,.015);sphere(parent,materials.brass,xx+.31,1.03,depth/2+.2,.055)}else windowDetail(parent,xx,yy,depth/2+.04,style===2?1.25:.9,style===2?1.35:1.45,style===1&&f===floors-1)}
  if(f>0){box(parent,materials.trim,0,f*2.75+.3,depth/2+.15,width+.18,.15,.28);if(style===1){const ww=Math.min(width-1,5);box(parent,materials.trim,0,f*2.75+.52,depth/2+.65,ww,.2,1.25);for(let i=0;i<Math.ceil(ww/.22);i++)box(parent,materials.iron,-ww/2+i*.22,f*2.75+1.05,depth/2+1.15,.035,1,.035);box(parent,materials.iron,0,f*2.75+1.5,depth/2+1.15,ww,.045,.045)}}
 }
 box(parent,materials.trim,0,height-.18,depth/2+.08,width+.15,.2,.25);box(parent,materials.tile,0,.45,depth/2+.04,width,.24,.045);
 for(const xx of [-width/2+.13,width/2-.13]){box(parent,materials.trim,xx,height/2,depth/2+.09,.23,height,.16);for(let y=.5;y<height;y+=.6)box(parent,materials.stone,xx,y,depth/2+.16,.31,.24,.14)}
}
function building(x,z,w,d,h,style=0,color=materials.sand){
 sceneStats.buildings++;const g=new T.Group();world.add(g);g.position.set(x,0,z);addObstacle(x,z,w,d,h);
 // Four walls, floor and solid ceiling; never a single floating facade.
 box(g,materials.stone,0,.18,0,w+.36,.36,d+.36);box(g,color,0,h/2,-d/2+.13,w,h,.26);box(g,color,0,h/2,d/2-.13,w,h,.26);box(g,color,-w/2+.13,h/2,0,.26,h,d);box(g,color,w/2-.13,h/2,0,.26,h,d);
 box(g,materials.paving,0,h-.15,0,w,.3,d);
 for(let j=0;j<4;j++){const f=new T.Group();g.add(f);f.rotation.y=j*Math.PI/2;facade(f,j%2?d:w,h,j%2?w:d,style)}
 for(const sx of [-1,1])box(g,color,sx*(w/2-.08),h+.28,0,.2,.6,d+.15);
 for(const sz of [-1,1])box(g,color,0,h+.28,sz*(d/2-.08),w+.15,.6,.2);
 box(g,materials.trim,0,h+.58,0,w+.3,.16,d+.3);box(g,materials.paving,0,h+.68,0,w-.2,.06,d-.2);
 // Roof penthouse, tank, vents, chimney and warm terracotta detail.
 box(g,color,w*.19,h+1.0,-d*.18,w*.35,.7,d*.36);box(g,materials.terracotta,w*.19,h+1.43,-d*.18,w*.4,.16,d*.42);
 cyl(g,materials.ceramic,-w*.27,h+1.15,-d*.24,.55,1,18);cyl(g,materials.iron,-w*.27,h+1.67,-d*.24,.57,.08,18);
 for(let i=0;i<3;i++){box(g,materials.trim,w*.32-i*.65,h+.84,d*.28,.32,.25,.43);box(g,materials.dark,w*.32-i*.65,h+.98,d*.28,.25,.025,.35)}
 if(style===2){const roof=new T.Mesh(new T.ConeGeometry(1,1,4),materials.roof);roof.rotation.y=Math.PI/4;roof.scale.set(w*.7,1.65,d*.7);roof.position.y=h+1.4;g.add(roof)}
 for(let i=0;i<2;i++){const ma=i?materials.foliage:materials.flower;const px=-w*.27+i*w*.5;box(g,materials.terracotta,px,h+.85,d*.32,.75,.35,.55);for(let k=0;k<4;k++)sphere(g,ma,px+range(-.3,.3),h+1.15,d*.32+range(-.2,.2),.22)}
 return g;
}
function palm(x,z,h=6){
 const g=new T.Group();world.add(g);g.position.set(x,0,z);
 const curve=new T.CatmullRomCurve3([new T.Vector3(),new T.Vector3(.12,h*.35,.1),new T.Vector3(.4,h*.72,.1),new T.Vector3(.7,h,0)]);mesh(new T.TubeGeometry(curve,12,.18,7,false),materials.trunk,g);
 for(let i=0;i<11;i++){const y=i*h/11;const m=mesh(new T.TorusGeometry(.19-y*.006,.025,4,8),materials.trunkLight,g,.7*(y/h)**2,y,0,Math.PI/2);}
 for(let j=0;j<9;j++){
  const a=j*Math.PI*2/9,verts=[],idx=[];for(let k=0;k<=12;k++){const s=k/12,r=s*3.6,yy=h+Math.sin(s*Math.PI)*.9-s*s*1.4,w=Math.sin(s*Math.PI)*.43;const cx=.7+Math.cos(a)*r,cz=Math.sin(a)*r;verts.push(cx+Math.sin(a)*w,yy,cz-Math.cos(a)*w,cx-Math.sin(a)*w,yy,cz+Math.cos(a)*w);if(k<12){let q=k*2;idx.push(q,q+1,q+2,q+1,q+3,q+2)}}
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(verts,3));geo.setIndex(idx);geo.computeVertexNormals();mesh(geo,j%2?materials.leaf:materials.foliage,g);
  for(let k=2;k<10;k++){const s=k/12,r=s*3.6;for(const side of [-1,1]){const a1=new T.Vector3(.7+Math.cos(a)*r,h+Math.sin(s*Math.PI)*.9-s*s*1.4,Math.sin(a)*r),a2=a1.clone().add(new T.Vector3(Math.cos(a)*.25+Math.sin(a)*side*.5,-.1,Math.sin(a)*.25-Math.cos(a)*side*.5));beam(g,materials.leaf,a1,a2,.018)}}
 }
 cyl(g,materials.stone,0,.05,0,1.05,.1,16);return g;
}
function crate(x,z,w=1.2){const g=new T.Group();world.add(g);g.position.set(x,0,z);box(g,materials.wood,0,w/2,0,w,w,w);for(const y of [.13,w-.13]){box(g,materials.woodLight,0,y,w/2+.025,w,.14,.06);box(g,materials.woodLight,0,y,-w/2-.025,w,.14,.06)}for(const xx of [-w/2+.1,w/2-.1])box(g,materials.woodLight,xx,w/2,w/2+.06,.14,w,.09);const diagonal=box(g,materials.woodLight,0,w/2,w/2+.08,.1,w*1.15,.07);diagonal.rotation.z=-.7;addObstacle(x,z,w,w,w);return g}
function lamp(x,z,h=3.7){cyl(world,materials.iron,x,h/2,z,.055,h,8);box(world,materials.iron,x,h,z,.55,.07,.55);box(world,materials.glass,x,h-.3,z,.3,.5,.3);for(const dx of [-.18,.18])for(const dz of [-.18,.18])box(world,materials.iron,x+dx,h-.3,z+dz,.035,.55,.035);mesh(new T.ConeGeometry(.48,.25,4),materials.brass,world,x,h+.15,z,0,Math.PI/4);}
function market(x,z){const g=new T.Group();world.add(g);g.position.set(x,0,z);for(const xx of [-1.7,1.7])for(const zz of [-1.15,1.15])cyl(g,materials.wood,xx,1.5,zz,.055,3,7);for(let i=0;i<9;i++){const m=box(g,i%2?materials.cloth:materials.canvas,-1.6+i*.4,2.9,0,.4,.08,2.75);m.rotation.x=.13;box(g,i%2?materials.cloth:materials.canvas,-1.6+i*.4,2.6,1.35,.4,.42,.07)}box(g,materials.wood,0,.9,.2,3.2,.15,1.6);for(let i=0;i<7;i++){box(g,materials.woodLight,-1.2+i*.4,1.1,.2,.35,.24,.7);for(let j=0;j<5;j++)sphere(g,i%2?materials.fruit:materials.flower,-1.2+i*.4+range(-.12,.12),1.25,.2+range(-.2,.2),.08)}addObstacle(x,z,3.8,2.6,3);}
function makeTerrain(){
 const geo=new T.PlaneGeometry(220,220,100,100);geo.rotateX(-Math.PI/2);const p=geo.attributes.position;for(let i=0;i<p.count;i++){let x=p.getX(i),z=p.getZ(i),height=-.12;if(x<-32)height=-.12-(-x-32)*.18;else if(Math.abs(x)>35||Math.abs(z)>31)height=-.15+Math.sin(x*.09+z*.04)*Math.cos(z*.12)*.55;p.setY(i,height)}geo.computeVertexNormals();mesh(geo,materials.sandGround,world);
 box(world,materials.paving,0,-.01,0,58,.12,52);box(world,materials.stone,-29,.16,0,.7,.5,52);
 for(let i=0;i<23;i++){box(world,materials.stone,-30.1,.13,-25+i*2.2,1.4,.3,1.9)}
 // Slightly raised central square with layered edging, mosaic and inlaid paths.
 box(world,materials.stone,-3,.12,1,17,.2,14);box(world,materials.paving,-3,.24,1,16.7,.12,13.7);
 for(const z of [-5.55,7.55])box(world,materials.tile,-3,.31,z,16.7,.025,.45);
 for(const x of [-11.15,5.15])box(world,materials.tile,x,.31,1,.45,.025,13.2);
 for(let i=0;i<16;i++)for(let j=0;j<12;j++)if((i+j)%2===0)box(world,materials.inlay,-10.5+i,.311,-4.5+j,.3,.012,.3);
 for(const [x,z]of [[-28,-23],[-28,23],[25,24],[25,-24]]){box(world,materials.iron,x,.015,z,1,.025,.55);for(let k=0;k<6;k++)box(world,materials.trim,x-.4+k*.16,.04,z,.04,.03,.5)}
}
function makeWater(){
 const geo=new T.PlaneGeometry(160,240,1,1);geo.rotateX(-Math.PI/2);
 water=mesh(geo,new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uTime:{value:0},uSun:{value:new T.Vector3(-.6,.8,-.4)},uOpacity:{value:.94}},vertexShader:`varying vec3 vWorld;void main(){vec4 w=modelMatrix*vec4(position,1.);vWorld=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,fragmentShader:`precision highp float;uniform float uTime;uniform vec3 uSun;uniform float uOpacity;varying vec3 vWorld;
 float wave(vec2 p){return sin(p.x*.9+p.y*.55+uTime*1.15)*.11+sin(p.x*.31-p.y*.7+uTime*.8)*.08+sin(p.x*1.7+p.y*.4-uTime*.7)*.04;}
 void main(){vec2 p=vWorld.xz;float w=wave(p),wx=wave(p+vec2(.12,0.)),wz=wave(p+vec2(0.,.12));vec3 n=normalize(vec3((w-wx)*2.2,1.,(w-wz)*2.2));vec3 v=normalize(cameraPosition-vWorld);float fres=pow(1.-max(dot(n,v),0.),3.);float depth=smoothstep(-32.,-51.,p.x);vec3 col=mix(vec3(.32,.67,.64),vec3(.055,.29,.37),depth);col=mix(col,vec3(.73,.82,.77),fres*.65);vec3 h=normalize(v+uSun);float spec=pow(max(dot(n,h),0.),140.);col+=spec*vec3(1.,.87,.61)*.36;float stripe=sin(p.x*.85+sin(p.y*.17)*.5+uTime*1.5);float shore=(1.-smoothstep(-35.,-31.2,p.x))*smoothstep(-40.,-32.,p.x);float foam=smoothstep(.84,1.,stripe)*shore;col=mix(col,vec3(.85,.9,.78),foam*.64);col+=pow(max(w+.05,0.),3.)*.07;gl_FragColor=vec4(col,uOpacity);}`}),world,-99,-.14,0);water.receiveShadow=false;water.castShadow=false;water.renderOrder=1;
 for(let i=0;i<30;i++){const x=range(-45,-32),z=range(-45,45);sphere(world,materials.rock,x,-.48,z,range(.5,1.5),1,range(.45,.9),1.3)}
}
function makeFountain(){
 const x=-4,z=1;for(const [r,h,y]of [[2.3,.22,.38],[2.1,.4,.55],[1.85,.15,.72]])cyl(world,materials.trim,x,y,z,r,h,32);
 cyl(world,materials.tile,x,.79,z,1.75,.03,32);const pool=cyl(world,materials.poolWater,x,.83,z,1.7,.03,32);pool.castShadow=false;
 cyl(world,materials.trim,x,1.25,z,.22,.9,12);cyl(world,materials.trim,x,1.65,z,.95,.18,24);cyl(world,materials.brass,x,1.9,z,.12,.5,12);sphere(world,materials.brass,x,2.2,z,.18);
 for(let i=0;i<8;i++){const a=i*Math.PI/4;const curve=new T.CatmullRomCurve3([new T.Vector3(x,2.05,z),new T.Vector3(x+Math.cos(a)*.5,2.3,z+Math.sin(a)*.5),new T.Vector3(x+Math.cos(a)*1.2,.9,z+Math.sin(a)*1.2)]);const m=mesh(new T.TubeGeometry(curve,12,.018,5),materials.poolWater,world);m.castShadow=false}
 addObstacle(x,z,4.7,4.7,2);
}
function makeLandmark(){
 // Open colonnade, independent silhouette and spatial composition.
 const g=new T.Group();world.add(g);g.position.set(-1,0,-9);
 for(const x of [-5,-2.5,0,2.5,5]){cyl(g,materials.stone,x,1.6,0,.23,3.2,12);cyl(g,materials.trim,x,.22,0,.35,.3,12);cyl(g,materials.trim,x,3.15,0,.36,.3,12);}
 for(let i=0;i<4;i++)arch(g,materials.trim,-3.75+i*2.5,1.6,0,2.5,2,.5,.2);
 box(g,materials.sand,0,3.8,.25,10.5,.55,.85);box(g,materials.tile,0,3.72,.72,10.5,.28,.03);box(g,materials.trim,0,4.14,.25,10.9,.18,1);
 const tower=building(-13,-9,4.4,4.4,10,1,materials.peach);
 const dome=mesh(new T.SphereGeometry(2.0,24,14,0,Math.PI*2,0,Math.PI/2),materials.dome,tower,0,11.15,0);cyl(tower,materials.tile,0,11.1,0,2,.25,24);cyl(tower,materials.brass,0,13.3,0,.045,.65,8);sphere(tower,materials.brass,0,13.65,0,.14);
 for(let i=0;i<4;i++){const a=i*Math.PI/2;box(tower,materials.cream,Math.sin(a)*1.6,10.8,Math.cos(a)*1.6,.35,.8,.35)}
}
function makeSet(){
 makeTerrain();makeWater();
 const defs=[[-23,-20,10,8,6.1,0,'sand'],[-9,-21,10,7,8.6,1,'cream'],[6,-21,12,8,6.0,2,'peach'],[22,-19,9,10,8.7,1,'cream'],[-23,-6,8,12,5.9,1,'peach'],[22,-3,9,12,6.0,0,'sand'],[-23,15,10,11,8.8,1,'cream'],[-8,21,12,7,6.0,2,'sand'],[9,20,14,9,8.7,1,'peach'],[23,17,8,9,6.0,0,'cream']];
 for(const [x,z,w,d,h,st,co]of defs)building(x,z,w,d,h,st,materials[co]);
 makeLandmark();makeFountain();
 for(const [x,z,h]of [[-29,-14,7],[-28,7,7],[-28,22,6],[-16,17,7],[16,12,6],[15,-13,7],[27,7,6],[-17,-16,6],[-3,13,6],[-35,-22,7],[-34,27,7]])palm(x,z,h);
 for(const [x,z]of [[-15,8],[11,7],[-2,-15],[15,3]]){crate(x,z,1.3);crate(x+1.5,z,.95)}
 market(-12,10);market(9,-10);market(9,11);
 for(const [x,z]of [[-17,4],[-16,-14],[14,-15],[15,14],[-10,15],[3,13],[16,4],[-27,-25]])lamp(x,z);
 // Quayside steps, bollards, small original mooring boat and rope details.
 for(let i=0;i<5;i++)box(world,materials.stone,-30.1-i*.65,-.08-i*.09,11,1,.2,5);
 for(let z=-23;z<24;z+=5)cyl(world,materials.iron,-30.3,.36,z,.13,.55,8);
 const boat=new T.Group();world.add(boat);boat.position.set(-35,-.05,12);const hull=new T.Shape();hull.moveTo(-.8,-2.5);hull.quadraticCurveTo(-1.5,0,0,3.1);hull.quadraticCurveTo(1.5,0,.8,-2.5);hull.closePath();const hg=new T.ExtrudeGeometry(hull,{depth:.5,bevelEnabled:true,bevelSize:.14,bevelThickness:.14,bevelSegments:2});hg.rotateX(-Math.PI/2);mesh(hg,materials.boat,boat);box(boat,materials.wood,0,.5,0,1.5,.15,2.7);for(let i=0;i<3;i++)box(boat,materials.trim,0,.65,-1+i,1.5,.1,.25);beam(world,materials.rope,new T.Vector3(-34.3,.5,10),new T.Vector3(-30.3,.6,9),.025);
 // Planter beds, ceramic urns, sacks, street seating and pipes enrich close views.
 for(const [x,z]of [[-17,-1],[15,8],[2,15],[-16,13]]){box(world,materials.trim,x,.32,z,1.9,.55,.8);for(let j=0;j<8;j++)sphere(world,j%3?materials.foliage:materials.flower,x+range(-.8,.8),.9+range(0,.3),z+range(-.25,.25),.34);box(world,materials.wood,x+2,.6,z,1.5,.15,.65);for(const dx of [-.5,.5])box(world,materials.iron,x+2+dx,.3,z,.12,.6,.5)}
 for(const [x,z]of [[-19,1],[17,-7],[-13,15],[2,-16]]){const points=[new T.Vector2(0,0),new T.Vector2(.3,0),new T.Vector2(.5,.35),new T.Vector2(.46,.75),new T.Vector2(.22,.95),new T.Vector2(.2,1.1)];mesh(new T.LatheGeometry(points,14),materials.terracotta,world,x,0,z);cyl(world,materials.dark,x,1.08,z,.15,.04,14);addObstacle(x,z,.9,.9,1)}
 // Site inlays are authored geometry, not imported radar imagery.
 for(const [x,z,letter,co]of [[6,5,'A','#da9e57'],[-13,-3,'B','#69a9b3']]){
  const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.strokeStyle=co;g.lineWidth=6;g.strokeRect(12,12,232,232);g.fillStyle=co;g.font='bold 160px sans-serif';g.textAlign='center';g.fillText(letter,128,185);const tx=new T.CanvasTexture(c);tx.colorSpace=T.SRGBColorSpace;const ma=new T.MeshBasicMaterial({map:tx,transparent:true,opacity:.65,depthWrite:false});mesh(new T.PlaneGeometry(3.7,3.7),ma,world,x,.34,z,-Math.PI/2);}
 makeAtmosphere();bakeStatic();
}
function bakeStatic(){
 world.updateMatrixWorld(true);const bins=new Map(),remove=[];
 world.traverse(o=>{if(!o.isMesh||o===water||o.material.transparent||Array.isArray(o.material))return;const key=o.material.uuid;let geo=o.geometry.clone();geo.applyMatrix4(o.matrixWorld);if(geo.index)geo=geo.toNonIndexed();geo.deleteAttribute('uv1');if(!geo.attributes.uv){geo.setAttribute('uv',new T.BufferAttribute(new Float32Array(geo.attributes.position.count*2),2))}if(!bins.has(key))bins.set(key,{material:o.material,geos:[]});bins.get(key).geos.push(geo);remove.push(o)});
 for(const o of remove)o.parent.remove(o);
 for(const {material,geos:gs}of bins.values()){const geo=mergeGeometries(gs,false);if(!geo)throw Error('Geometry merge failed');const m=new T.Mesh(geo,material);m.castShadow=true;m.receiveShadow=true;scene.add(m);gs.forEach(g=>g.dispose())}
 sceneStats.staticBatches=bins.size;
}
function makeAtmosphere(){
 const cloudMat=new T.MeshBasicMaterial({color:0xfff3d7,transparent:true,opacity:.2,depthWrite:false});
 for(let i=0;i<12;i++){const g=new T.Group();scene.add(g);g.position.set(range(-100,100),range(40,55),range(-100,40));for(let j=0;j<4;j++){const m=sphere(g,cloudMat,j*4,range(-1,1),range(-2,2),range(3,6),1.8,.3,1);m.castShadow=false}clouds.push(g)}
 for(let i=0;i<9;i++){const g=new T.Group();scene.add(g);const wings=[];for(const side of [-1,1]){const shape=new T.Shape();shape.moveTo(0,0);shape.quadraticCurveTo(side*.3,.24,side*.75,.03);shape.quadraticCurveTo(side*.3,-.12,0,0);const wing=mesh(new T.ShapeGeometry(shape),materials.bird,g);wing.rotation.x=-Math.PI/2;wings.push(wing)}birds.push({g,wings,angle:range(0,7),r:range(15,25),height:range(14,22),speed:range(.04,.08)})}
}

// Small independent grid navigator for the visual demonstration, not source nav.
function blocked(x,z){return obstacles.some(o=>x>o.minX&&x<o.maxX&&z>o.minZ&&z<o.maxZ)}
function lineClear(a,b){const dx=b.x-a.x,dz=b.z-a.z,n=Math.ceil(Math.hypot(dx,dz)/.45);for(let i=1;i<n;i++)if(blocked(a.x+dx*i/n,a.z+dz*i/n))return false;return true}
function pathfind(start,end){
 const N=59,toGrid=v=>clamp(Math.round(v+29),0,N-1),sx=toGrid(start.x),sz=toGrid(start.z),ex=toGrid(end.x),ez=toGrid(end.z),si=sz*N+sx,ei=ez*N+ex;
 const open=[si],came=new Int32Array(N*N).fill(-1),cost=new Float32Array(N*N).fill(1e8),closed=new Uint8Array(N*N);cost[si]=0;let best=si,bestD=1e9;
 for(let tries=0;open.length&&tries<4000;tries++){
  let oi=0,score=1e9;for(let i=0;i<open.length;i++){const id=open[i],s=cost[id]+Math.hypot(id%N-ex,Math.floor(id/N)-ez);if(s<score){score=s;oi=i}}
  const cur=open.splice(oi,1)[0];if(closed[cur])continue;closed[cur]=1;const cx=cur%N,cz=Math.floor(cur/N),d=Math.hypot(cx-ex,cz-ez);if(d<bestD){bestD=d;best=cur}if(cur===ei)break;
  for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]]){const x=cx+dx,z=cz+dz;if(x<0||z<0||x>=N||z>=N||blocked(x-29,z-29))continue;if(dx&&dz&&(blocked(cx+dx-29,cz-29)||blocked(cx-29,cz+dz-29)))continue;const id=z*N+x,nc=cost[cur]+(dx&&dz?1.414:1);if(nc<cost[id]){cost[id]=nc;came[id]=cur;open.push(id)}}
 }
 const result=[];let cur=best;for(let i=0;i<4000&&cur!==si&&cur>=0;i++){result.push(new T.Vector3(cur%N-29,.34,Math.floor(cur/N)-29));cur=came[cur]}result.reverse();return result;
}
function makeAgent(index){
 const team=index<5?0:1,g=new T.Group();scene.add(g);const tint=team?materials.uniformBlue:materials.uniformAmber;
 const body=new T.Group();g.add(body);capsule(body,tint,0,1.11,0,.58,.69,.36);capsule(body,materials.vest,0,1.08,.16,.47,.51,.17);
 for(let i=0;i<3;i++)box(body,materials.pouch,-.14+i*.14,1.04,.25,.11,.19,.08);
 box(body,materials.belt,0,.81,0,.58,.12,.37);box(body,tint,0,1.43,0,.63,.17,.37);
 sphere(body,materials.skin,0,1.65,0,.21,.87,1.1,.9);sphere(body,materials.helmet,0,1.76,-.015,.235,1,.7,1);box(body,materials.visor,0,1.68,.17,.32,.09,.06);box(body,materials.mask,0,1.55,.14,.28,.14,.12);
 for(const x of [-.29,.29]){box(body,materials.pouch,x,1.35,.02,.15,.17,.33);box(body,team?materials.cyanMark:materials.amberMark,x*1.09,1.37,.18,.12,.08,.03)}
 const legs=[];for(const x of [-.15,.15]){const pivot=new T.Group();body.add(pivot);pivot.position.set(x,.82,0);capsule(pivot,tint,0,-.2,0,.24,.45,.27);capsule(pivot,materials.vest,0,-.4,.12,.22,.19,.11);capsule(pivot,tint,0,-.57,0,.19,.4,.22);capsule(pivot,materials.boot,0,-.77,.09,.25,.24,.42);legs.push(pivot)}
 const arms=[];for(const side of [-1,1]){const p=new T.Group();body.add(p);p.position.set(side*.32,1.37,.03);capsule(p,tint,side*.025,-.17,.04,.21,.4,.23);capsule(p,materials.glove,side*-.05,-.32,.25,.18,.19,.2);const fore=capsule(p,tint,side*-.03,-.29,.16,.18,.2,.37);fore.rotation.x=-.45;arms.push(p)}
 const gun=new T.Group();body.add(gun);gun.position.set(.12,1.03,.42);box(gun,materials.gun,0,.03,.25,.14,.19,.62);box(gun,materials.gunLight,0,.12,.12,.13,.05,.38);box(gun,materials.woodLight,0,-.02,-.15,.13,.15,.28);box(gun,materials.gun,0,-.17,.15,.095,.28,.14);const barrel=cyl(gun,materials.gun,0,.035,.68,.032,.3,8);barrel.rotation.x=Math.PI/2;
 if(index%5===2){box(gun,materials.gunLight,0,.18,.15,.08,.13,.12);const scope=cyl(gun,materials.gun,0,.25,.19,.075,.35,10);scope.rotation.x=Math.PI/2;gun.scale.z=1.25}
 const ring=new T.Mesh(new T.RingGeometry(.38,.48,24),new T.MeshBasicMaterial({color:team?0x66d5e9:0xf2b360,transparent:true,opacity:.7,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.035;g.add(ring);
 const glow=new T.Mesh(new T.PlaneGeometry(1.4,1.4),new T.MeshBasicMaterial({map:makeGlowTexture(),color:team?0x5cc4dc:0xefb05e,transparent:true,opacity:.25,depthWrite:false}));glow.rotation.x=-Math.PI/2;glow.position.y=.025;g.add(glow);
 const label=document.createElement('div');label.className='agent-label';label.innerHTML=`<b>${names[index]}</b><i></i>`;label.style.cssText=`position:absolute;pointer-events:auto;cursor:pointer;color:${team?'#8fe4f3':'#ffdc9e'};font-size:9px;text-align:center;text-shadow:0 1px 4px #000,0 0 8px #000;transform:translate(-50%,-100%);z-index:2;white-space:nowrap;letter-spacing:.5px;line-height:1.3`;
 label.setAttribute('role','button');label.setAttribute('aria-label',names[index]+' agentini kuzatish');label.tabIndex=0;label.querySelector('i').style.cssText='display:block;height:2px;background:currentColor;margin:3px auto;width:20px';$('#markers').append(label);const pick=()=>{selected=index;setCamera('player');updateRoster()};label.onclick=pick;label.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick()}};
 const agent={g,body,legs,arms,gun,ring,glow,label,team,index,hp:100,ammo:weapons[index%5][1],reserve:90,path:[],walk:0,nextPlan:0,nextShot:0,reload:0,stop:0,dir:new T.Vector3(0,0,1),lastPos:new T.Vector3(),moved:0,shots:0};agents.push(agent);return agent;
}
function instanceAgents(){
 const bins=new Map();for(const a of agents)a.g.traverse(m=>{if(!m.isMesh||m.material.transparent)return;const key=m.geometry.uuid+m.material.uuid;if(!bins.has(key))bins.set(key,[]);bins.get(key).push(m)});
 for(const originals of bins.values()){const inst=new T.InstancedMesh(originals[0].geometry,originals[0].material,originals.length);inst.instanceMatrix.setUsage(T.DynamicDrawUsage);inst.frustumCulled=false;inst.receiveShadow=true;inst.castShadow=false;scene.add(inst);originals.forEach(m=>m.visible=false);agentBatches.push({inst,originals})}sceneStats.agentBatches=agentBatches.length;
}
function updateAgentInstances(){for(const a of agents)a.g.updateMatrixWorld(true);for(const b of agentBatches){b.originals.forEach((m,i)=>b.inst.setMatrixAt(i,m.matrixWorld));b.inst.instanceMatrix.needsUpdate=true}}
function makeGlowTexture(){if(materials.glowTex)return materials.glowTex;const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d'),g=ctx.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'#ffffffff');g.addColorStop(.2,'#ffffffb0');g.addColorStop(1,'#ffffff00');ctx.fillStyle=g;ctx.fillRect(0,0,64,64);return materials.glowTex=new T.CanvasTexture(c)}
const routeGoals=[[-16,5],[-13,-3],[-8,9],[0,10],[6,5],[13,1],[13,-9],[0,-13],[-16,-14],[16,14],[-17,13]];
function resetAgents(){
 for(const a of agents){let x=(a.team?14:-14)+(a.index%5-2)*1.5,z=a.team?-13:14;while(blocked(x,z))z+=a.team?1:-1;a.g.position.set(x,.34,z);a.hp=100;a.ammo=weapons[a.index%5][1];a.reserve=90;a.reload=0;a.nextPlan=sim+(a.index%5)*.35;a.path=[];a.body.rotation.z=0;a.g.visible=true;a.label.style.display='';a.nextShot=sim+5;a.lastPos.copy(a.g.position)}
}

const MAX_PARTICLES=1800,pdata=[];
function initParticles(){
 particleGeo=new T.BufferGeometry();particleGeo.setAttribute('position',new T.BufferAttribute(new Float32Array(MAX_PARTICLES*3),3));particleGeo.setAttribute('color',new T.BufferAttribute(new Float32Array(MAX_PARTICLES*3),3));particleGeo.setAttribute('aSize',new T.BufferAttribute(new Float32Array(MAX_PARTICLES),1));particleGeo.setAttribute('aAlpha',new T.BufferAttribute(new Float32Array(MAX_PARTICLES),1));particleGeo.setAttribute('aKind',new T.BufferAttribute(new Float32Array(MAX_PARTICLES),1));
 const material=new T.ShaderMaterial({transparent:true,depthWrite:false,vertexColors:true,uniforms:{uTime:{value:0},uScale:{value:650}},vertexShader:`attribute float aSize;attribute float aAlpha;attribute float aKind;uniform float uScale;varying vec3 vColor;varying float vAlpha;varying float vKind;varying vec3 vPosition;void main(){vec4 mv=modelViewMatrix*vec4(position,1.);vColor=color;vAlpha=aAlpha;vKind=aKind;vPosition=position;gl_PointSize=clamp(aSize*uScale/-mv.z,1.,220.);gl_Position=projectionMatrix*mv;}`,fragmentShader:`precision highp float;uniform float uTime;varying vec3 vColor;varying float vAlpha;varying float vKind;varying vec3 vPosition;float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}void main(){vec2 p=gl_PointCoord*2.-1.;float d=length(p);if(d>1.)discard;float alpha=pow(max(0.,1.-d*d),1.7)*vAlpha;if(vKind>.5){float n=noise(p*4.+vPosition.xz+uTime*.08)*.65+noise(p*9.-uTime*.12)*.35;alpha*=smoothstep(.1,.65,n)*(1.-smoothstep(.55,1.,d));}gl_FragColor=vec4(vColor,alpha);}`});particles=new T.Points(particleGeo,material);particles.frustumCulled=false;particles.renderOrder=4;scene.add(particles);
}
function particle(pos,vel,size,life,color,kind=0,gravity=0){if(pdata.length>=MAX_PARTICLES)return;pdata.push({p:pos.clone(),v:vel.clone(),size,life,max:life,color:new T.Color(color),kind,gravity})}
function smoke(pos,n=16,scale=1,tint=0xc6c7b7){for(let i=0;i<n;i++)particle(pos.clone().add(new T.Vector3(range(-.8,.8),range(.1,.6),range(-.8,.8))),new T.Vector3(range(-.22,.22),range(.18,.55),range(-.2,.2)),range(1.3,2.5)*scale,range(3.5,6),tint,1)}
function sparkBurst(pos,n=45,power=1){for(let i=0;i<n;i++){const v=new T.Vector3(range(-1,1),range(.1,1.5),range(-1,1)).normalize().multiplyScalar(range(2,9)*power);particle(pos,v,range(.06,.2),range(.3,1.2),i%2?0xffdb85:0xe88532,0,8)}}
function pulse(pos,color=0xffd998,scale=1,duration=.35){const ma=new T.MeshBasicMaterial({map:makeGlowTexture(),transparent:true,color,depthWrite:false,blending:T.AdditiveBlending});const sprite=new T.Sprite(ma);sprite.position.copy(pos);sprite.scale.setScalar(scale);sprite.renderOrder=5;scene.add(sprite);effects.push({object:sprite,life:duration,max:duration,scale,kind:'pulse'})}
function explode(pos,big=false){
 const scale=big?2.3:1;cameraShake=Math.max(cameraShake,big?.65:.18);autoPoint.copy(pos);lastAction=sim;
 pulse(pos.clone().add(new T.Vector3(0,1,0)),0xffca74,scale*11,.65);sparkBurst(pos,Math.round(85*scale),scale);
 for(let i=0;i<18*scale;i++)particle(pos.clone().add(new T.Vector3(range(-.5,.5),range(.2,1),range(-.5,.5))),new T.Vector3(range(-2,2)*scale,range(.7,2.4)*scale,range(-2,2)*scale),range(.5,1.3)*scale,range(.5,1.2),i%2?0xf6a332:0xffd98c,0);
 smoke(pos,Math.round(28*scale),scale,0x8c8d80);
 const ring=new T.Mesh(new T.RingGeometry(.8,1,48),new T.MeshBasicMaterial({color:0xf5b66c,transparent:true,opacity:.8,depthWrite:false,side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.copy(pos);ring.position.y=.4;scene.add(ring);effects.push({object:ring,life:.65,max:.65,scale:scale*14,kind:'ring'});
 const scorch=new T.Mesh(new T.CircleGeometry(2.1*scale,32),new T.MeshBasicMaterial({map:makeGlowTexture(),color:0x31291f,transparent:true,opacity:.65,depthWrite:false}));scorch.rotation.x=-Math.PI/2;scorch.position.copy(pos);scorch.position.y=.345;scene.add(scorch);effects.push({object:scorch,life:18,max:18,kind:'scorch',scale:1});
 for(let i=0;i<Math.round(18*scale);i++){const m=new T.Mesh(new T.BoxGeometry(range(.08,.24),range(.08,.2),range(.1,.3)),materials.debris);m.position.copy(pos);scene.add(m);effects.push({object:m,life:range(1.2,2.5),max:3,velocity:new T.Vector3(range(-4,4)*scale,range(3,8),range(-4,4)*scale),kind:'debris',scale:1})}
 playSound(big?'c4':'boom',pos);if(big)notify('C4 portladi · namuna 5 soniyadan keyin yangilanadi');
}
function throwGrenade(kind,manual=false){const a=agents[selected],start=a.g.position.clone().add(new T.Vector3(0,1.2,0)),target=manual?new T.Vector3(5,.35,4):new T.Vector3(range(3,8),.35,range(1,6));if(kind==='fire')target.set(2,.35,10);if(kind==='smoke')target.set(8,.35,0);if(manual){setCamera('auto');autoPoint.copy(target);lastAction=sim;focusUntil=sim+5}const delta=target.clone().sub(start),flight=1.4;const vel=delta.multiplyScalar(1/flight);vel.y=(target.y-start.y+.5*12*flight*flight)/flight;const g=new T.Group();scene.add(g);g.position.copy(start);cyl(g,kind==='fire'?materials.bottle:materials.gun,0,0,0,.11,.3,10);box(g,materials.brass,0,.19,0,.1,.1,.13);grenades.push({g,velocity:vel,kind,age:0,life:kind==='fire'?1.7:2.2,bounces:0});notify({grenade:'HE · skeveldros ir dulkių banga',smoke:'Tutun · hajmli bulut',fire:'Olovli granata · alanga va issiqlik',flash:'Flesh · yorug‘lik impulsi'}[kind]?.replace('skeveldros ir dulkių banga','zarba, uchqun va chang')||kind);}
function detonateGrenade(g){const pos=g.g.position.clone();pos.y=.4;autoPoint.copy(pos);lastAction=sim;focusUntil=sim+4;if(g.kind==='grenade')explode(pos);else if(g.kind==='smoke'){smoke(pos,90,2.1,agents[selected].team?0x82b6c2:0xd4b580);playSound('smoke',pos);autoPoint.copy(pos);lastAction=sim}else if(g.kind==='fire'){fires.push({p:pos,until:sim+10,next:0,flames:createFlames(pos)});sparkBurst(pos,30,.5);playSound('fire',pos);autoPoint.copy(pos);lastAction=sim}else{flash=.6;pulse(pos.clone().add(new T.Vector3(0,1,0)),0xfff4d6,16,.5);playSound('flash',pos);autoPoint.copy(pos);lastAction=sim}}
function createFlames(pos){
 if(!materials.flameShader)materials.flameShader=new T.ShaderMaterial({transparent:true,depthWrite:false,side:T.DoubleSide,blending:T.NormalBlending,uniforms:{uTime:{value:sim}},vertexShader:`uniform float uTime;varying vec2 vUv;varying vec3 vPos;void main(){vUv=uv;vPos=position;vec3 p=position;p.x+=sin(p.y*5.+uTime*7.+p.x)*uv.y*.12;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,fragmentShader:`precision highp float;uniform float uTime;varying vec2 vUv;varying vec3 vPos;void main(){float y=vUv.y;float x=(vUv.x-.5)*2.;x+=sin(y*9.-uTime*6.+vPos.x*2.)*.15*y;float width=pow(1.-y,.65)*.82;float shape=1.-smoothstep(width*.4,width+.02,abs(x));float flicker=.8+.2*sin(y*19.-uTime*13.);float alpha=shape*(1.-smoothstep(.65,1.,y))*smoothstep(0.,.08,y)*flicker;vec3 col=mix(vec3(1.,.76,.24),vec3(1.,.14,.015),smoothstep(.05,.85,y));gl_FragColor=vec4(col,alpha*.85);}`});
 const group=new T.Group();group.position.copy(pos);scene.add(group);for(let i=0;i<16;i++){const angle=i*2.4,r=Math.sqrt(i/16)*1.8;const m=new T.Mesh(new T.PlaneGeometry(.65+random()*.5,1.1+random()*1.2),materials.flameShader);m.position.set(Math.cos(angle)*r,.7+random()*.25,Math.sin(angle)*r);m.rotation.y=angle;group.add(m)}return group;
}
function plantC4(manual=false){if(c4){c4.removeFromParent();c4=null}const g=new T.Group();scene.add(g);g.position.set(6,.5,5);box(g,materials.pouch,0,0,0,.62,.22,.42);for(let i=0;i<3;i++)box(g,materials.c4charge,-.2+i*.2,.17,0,.16,.18,.4);box(g,materials.gun,0,.32,.02,.34,.1,.3);box(g,materials.screen,0,.38,.02,.24,.015,.16);for(let i=0;i<6;i++)sphere(g,materials.brass,-.09+(i%3)*.08,.39,.02+Math.floor(i/3)*.06,.018);for(let i=0;i<2;i++){const a=new T.Vector3(-.25+i*.5,.2,.19),b=new T.Vector3(0,.43,-.1);beam(g,i?materials.wireRed:materials.wireBlue,a,b,.018)}c4=g;c4.userData.until=sim+(manual?8:17);c4.userData.nextBeep=sim;if(manual){setCamera('auto');focusUntil=sim+9}notify('C4 o‘rnatildi · himoya pozitsiyalari');autoPoint.copy(g.position);lastAction=sim;playSound('plant',g.position)}

let audio=null,soundOn=false,master=null;
function enableAudio(){if(!audio){const AC=window.AudioContext||window.webkitAudioContext;if(!AC){notify('Bu brauzerda audio qo‘llanmaydi');return}audio=new AC();master=audio.createGain();master.gain.value=.16;master.connect(audio.destination)}audio.resume();soundOn=!soundOn;$('#sound').setAttribute('aria-pressed',String(soundOn));$('#sound').setAttribute('aria-label',soundOn?'Ovozni o‘chirish':'Ovozni yoqish');if(soundOn){playSound('plant');notify('Original sintez ovozlari yoqildi')}}
function tone(freq,dur,type='sine',volume=.3,delay=0,end=freq){const o=audio.createOscillator(),g=audio.createGain(),now=audio.currentTime+delay;o.type=type;o.frequency.setValueAtTime(freq,now);o.frequency.exponentialRampToValueAtTime(Math.max(20,end),now+dur);g.gain.setValueAtTime(volume,now);g.gain.exponentialRampToValueAtTime(.001,now+dur);o.connect(g);g.connect(master);o.start(now);o.stop(now+dur+.02)}
function noiseSound(dur,volume,cutoff,low=false){const len=Math.ceil(audio.sampleRate*dur),b=audio.createBuffer(1,len,audio.sampleRate),d=b.getChannelData(0);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*Math.exp(-i/len*5);const src=audio.createBufferSource();src.buffer=b;const f=audio.createBiquadFilter();f.type=low?'lowpass':'highpass';f.frequency.value=cutoff;const g=audio.createGain();g.gain.value=volume;src.connect(f);f.connect(g);g.connect(master);src.start()}
function playSound(kind,pos){if(!soundOn||!audio||audio.state!=='running')return;const distance=pos?camera.position.distanceTo(pos):15,v=clamp(30/distance,.2,1);if(kind==='shot'){noiseSound(.16,.55*v,1300);tone(110,.12,'triangle',.6*v,0,35);tone(2500,.025,'square',.06*v)}else if(kind==='boom'||kind==='c4'){tone(65,kind==='c4'?1.8:.9,'sine',1*v,0,22);noiseSound(kind==='c4'?2:1,.7*v,350,true);noiseSound(.17,.5*v,900)}else if(kind==='beep'){tone(1800,.08,'sine',.2*v)}else if(kind==='plant'){tone(660,.12,'sine',.25,0,880);tone(880,.15,'sine',.2,.15,1320)}else if(kind==='flash'){noiseSound(.15,.4*v,3500);tone(4200,.4,'sine',.06*v)}else if(kind==='fire'){noiseSound(1.3,.3*v,1200,true)}else noiseSound(.8,.18*v,600,true)}

function notify(text){$('#event').textContent=text;$('#event').classList.add('visible');eventUntil=performance.now()+3300}
function setCamera(mode){cameraMode=mode;document.querySelectorAll('[data-camera]').forEach(b=>b.classList.toggle('active',b.dataset.camera===mode));$('#view-label').textContent={overview:'UMUMIY RAKURS',auto:'AUTO-ACTION',player:'AGENT · '+names[selected]}[mode];$('#roster').style.visibility=mode==='player'?'visible':'hidden';}
function updateRoster(){const root=$('#agent-buttons');root.innerHTML='';const start=selected<5?0:5;for(let i=start;i<start+5;i++){const b=document.createElement('button');b.className=i===selected?'active':'';b.innerHTML=`<b>${names[i]}</b><span>${weapons[i%5][0]}</span><i class="hp"></i>`;b.setAttribute('aria-label',names[i]+' agentini kuzatish');b.onclick=()=>{selected=i;setCamera('player');updateRoster()};root.append(b)}$('#view-label').textContent=cameraMode==='player'?'AGENT · '+names[selected]:$('#view-label').textContent}
function setupControls(){
 document.querySelectorAll('[data-camera]').forEach(b=>b.onclick=()=>setCamera(b.dataset.camera));$('#sound').onclick=enableAudio;$('#help').onclick=()=>$('#about').showModal();$('#pause').onclick=()=>{paused=!paused;$('#pause').textContent=paused?'▶':'Ⅱ';$('#pause').setAttribute('aria-label',paused?'Davom ettirish':'To‘xtatish')};
 $('#effects-toggle').onclick=()=>{const e=$('#effects'),open=e.hidden;e.hidden=!open;$('#effects-toggle').setAttribute('aria-expanded',String(open))};document.querySelectorAll('[data-effect]').forEach(b=>b.onclick=()=>b.dataset.effect==='c4'?plantC4(true):throwGrenade(b.dataset.effect,true));
 $('#quality').onclick=()=>{quality=quality==='HD'?'MOBIL':'HD';$('#quality').textContent=quality==='HD'?'HD':'ECO';resize();renderer.shadowMap.needsUpdate=true;notify(quality==='HD'?'HD · tiniq ko‘rinish':'Mobil · yengil render')};
 $('#fullscreen').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen?.();else document.documentElement.requestFullscreen?.().catch(()=>notify('To‘liq ekran brauzer tomonidan cheklangan'))};
 const pointers=new Map();let drag=null,pinch=0;renderer.domElement.addEventListener('pointerdown',e=>{pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});renderer.domElement.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY};if(pointers.size===2){const a=[...pointers.values()];pinch=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}});
 renderer.domElement.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2){const a=[...pointers.values()],dist=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(pinch>0)zoom=clamp(zoom*pinch/dist,.5,1.7);pinch=dist}else if(drag){if(cameraMode!=='overview')setCamera('overview');yaw-=(e.clientX-drag.x)*.006;pitch=clamp(pitch+(e.clientY-drag.y)*.004,.48,1.15);drag={x:e.clientX,y:e.clientY}}});
 const end=e=>{pointers.delete(e.pointerId);drag=null;pinch=0};renderer.domElement.addEventListener('pointerup',end);renderer.domElement.addEventListener('pointercancel',end);renderer.domElement.addEventListener('wheel',e=>{e.preventDefault();zoom=clamp(zoom*Math.exp(e.deltaY*.0008),.5,1.7)},{passive:false});window.addEventListener('resize',resize);window.visualViewport?.addEventListener('resize',resize);document.addEventListener('visibilitychange',()=>{clock?.getDelta();if(document.hidden)audio?.suspend();else if(soundOn)audio?.resume()});
 updateRoster();setCamera('overview');
}
function resize(){if(!renderer)return;const w=innerWidth,h=innerHeight;renderer.setPixelRatio(Math.min(devicePixelRatio,quality==='HD'?1.65:1));renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();if(particles)particles.material.uniforms.uScale.value=h*renderer.getPixelRatio()*.85;}
function updateAgent(a,dt){
 if(a.hp<=0){a.body.rotation.z=lerp(a.body.rotation.z,Math.PI/2,1-Math.exp(-dt*6));a.label.style.opacity='.35';return}a.label.style.opacity='1';
 if(sim>=a.nextPlan){const candidates=routeGoals.filter(([x,z])=>!blocked(x,z)&&Math.hypot(a.g.position.x-x,a.g.position.z-z)>5),choice=candidates[Math.floor(random()*candidates.length)];if(choice)a.path=pathfind(a.g.position,new T.Vector3(choice[0],.34,choice[1]));a.nextPlan=sim+range(6,10)}
 let enemy=null,min=19;for(const other of agents)if(other.team!==a.team&&other.hp>0){const d=a.g.position.distanceTo(other.g.position);if(d<min&&lineClear(a.g.position,other.g.position)){min=d;enemy=other}}
 const moving=a.path.length&&sim>a.stop;
 if(moving){const dest=a.path[0],delta=dest.clone().sub(a.g.position);delta.y=0;const len=delta.length();if(len<.13)a.path.shift();else{delta.normalize();const sep=new T.Vector3();for(const other of agents){if(other===a||other.hp<=0)continue;const d=a.g.position.distanceTo(other.g.position);if(d<1.15&&d>.01)sep.add(a.g.position.clone().sub(other.g.position).multiplyScalar((1.15-d)*1.2/d))}const move=delta.add(sep).normalize().multiplyScalar(dt*(enemy?1.45:2.15));const nx=a.g.position.x+move.x,nz=a.g.position.z+move.z;if(!blocked(nx,nz))a.g.position.add(move);else if(!blocked(nx,a.g.position.z))a.g.position.x=nx;else if(!blocked(a.g.position.x,nz))a.g.position.z=nz;a.dir.copy(delta).normalize();a.walk+=dt*9;a.moved+=move.length();}}
 const look=enemy?enemy.g.position.clone().sub(a.g.position):a.dir;const targetAngle=Math.atan2(look.x,look.z);let diff=T.MathUtils.euclideanModulo(targetAngle-a.g.rotation.y+Math.PI,Math.PI*2)-Math.PI;a.g.rotation.y+=diff*(1-Math.exp(-dt*8));
 const stride=moving?Math.sin(a.walk)*.42:0;a.legs[0].rotation.x=lerp(a.legs[0].rotation.x,stride,1-Math.exp(-dt*16));a.legs[1].rotation.x=lerp(a.legs[1].rotation.x,-stride,1-Math.exp(-dt*16));a.body.position.y=moving?Math.abs(Math.sin(a.walk))*.035:Math.sin(sim*2+a.index)*.008;a.body.rotation.x=moving?.055:0;
 if(a.reload&&sim>a.reload){a.ammo=weapons[a.index%5][1];a.reserve=Math.max(0,a.reserve-a.ammo);a.reload=0}a.gun.rotation.z=a.reload?Math.sin(sim*6)*.15:0;
 if(enemy&&sim>a.nextShot&&!a.reload&&sim%85>7&&sim%85<74){
  if(a.ammo<=0){a.reload=sim+2.1;a.nextShot=sim+2.2;return}a.ammo--;a.shots++;a.nextShot=sim+range(.19,.4);if(random()<.1)a.stop=sim+.5;
  const muzzle=new T.Vector3(.12,1.08,1.25).applyAxisAngle(new T.Vector3(0,1,0),a.g.rotation.y).add(a.g.position);const target=enemy.g.position.clone().add(new T.Vector3(range(-.4,.4),range(.8,1.3),range(-.4,.4)));
  const geo=new T.BufferGeometry().setFromPoints([muzzle,target]);const line=new T.Line(geo,new T.LineBasicMaterial({color:a.team?0xb4e4fa:0xffd98a,transparent:true,opacity:.8}));scene.add(line);tracers.push({line,until:sim+.065});pulse(muzzle,0xffdb8f,range(.45,.8),.045);sparkBurst(target,3,.15);playSound('shot',muzzle);if(sim>focusUntil){autoPoint.copy(muzzle).lerp(target,.5);lastAction=sim;}a.gun.position.z=.36;
  if(sim%85>30&&random()<.16)enemy.hp=Math.max(0,enemy.hp-range(2,5));
 }a.gun.position.z=lerp(a.gun.position.z,.42,1-Math.exp(-dt*18));a.ring.material.opacity=a.index===selected&&cameraMode==='player'?.95:.5;a.ring.scale.setScalar(a.index===selected?1.2:1);
}
let previousPhase=-1;
function updateScene(dt){
 const local=sim%85,phase=Math.floor(local);if(phase!==previousPhase){previousPhase=phase;$('#timer').textContent=`${String(Math.floor((85-local)/60)).padStart(2,'0')}:${String(Math.ceil((85-local)%60)).padStart(2,'0')}`;$('#phase').textContent=local>80?'Raund yakuni':c4?'C4 · '+Math.max(0,Math.ceil(c4.userData.until-sim))+' soniya':local>15?'Pozitsion otishma':'Pozitsiyalarni egallash';if(phase===13)throwGrenade('smoke');if(phase===25)throwGrenade('grenade');if(phase===38)throwGrenade('fire');if(phase===49)throwGrenade('flash');if(phase===61&&!c4)plantC4();if(phase===84){cycle++;$('#score-a').textContent=String(Math.ceil(cycle/2));$('#score-b').textContent=String(Math.floor(cycle/2));resetAgents()}}
 for(const a of agents)updateAgent(a,dt);
 if(c4){if(sim>c4.userData.nextBeep){c4.userData.nextBeep=sim+clamp((c4.userData.until-sim)/10,.12,1.0);playSound('beep',c4.position);pulse(c4.position.clone().add(new T.Vector3(0,.4,0)),0xff5836,.55,.13)}if(sim>=c4.userData.until){explode(c4.position,true);c4.removeFromParent();c4=null}}
 for(let i=grenades.length-1;i>=0;i--){const p=grenades[i];p.age+=dt;const old=p.g.position.clone();p.velocity.y-=12*dt;p.g.position.addScaledVector(p.velocity,dt);p.g.rotation.x+=dt*8;p.g.rotation.z+=dt*4;for(const o of obstacles){if(p.g.position.y<o.h+.3&&p.g.position.x>o.minX&&p.g.position.x<o.maxX&&p.g.position.z>o.minZ&&p.g.position.z<o.maxZ){if(old.x<=o.minX||old.x>=o.maxX)p.velocity.x*=-.6;else p.velocity.z*=-.6;p.g.position.copy(old);p.bounces++;break}}if(p.g.position.y<.45){p.g.position.y=.45;p.velocity.y=Math.abs(p.velocity.y)*.4;p.velocity.x*=.6;p.velocity.z*=.6;p.bounces++}if(p.age>p.life){detonateGrenade(p);p.g.removeFromParent();grenades.splice(i,1)}}
 for(let i=fires.length-1;i>=0;i--){const f=fires[i];if(sim>f.until){f.flames.removeFromParent();fires.splice(i,1);continue}if(sim>f.next){f.next=sim+.05;for(let j=0;j<4;j++){const a=random()*7,r=random()*2.1;particle(f.p.clone().add(new T.Vector3(Math.cos(a)*r,.1,Math.sin(a)*r)),new T.Vector3(range(-.1,.1),range(1.2,2.5),range(-.1,.1)),range(.45,.85),range(.3,.8),j%2?0xf7932a:0xffc35d);if(random()<.3)particle(f.p,new T.Vector3(range(-.4,.4),1.6,range(-.4,.4)),1.2,2.5,0x66675f,1)}}}
 for(let i=effects.length-1;i>=0;i--){const e=effects[i];e.life-=dt;if(e.life<=0){e.object.removeFromParent();if(e.kind!=='debris')e.object.material.dispose();e.object.geometry?.dispose();effects.splice(i,1);continue}const r=e.life/e.max;if(e.kind==='debris'){e.velocity.y-=dt*10;e.object.position.addScaledVector(e.velocity,dt);if(e.object.position.y<.4){e.object.position.y=.4;e.velocity.y*=-.25;e.velocity.x*=.7;e.velocity.z*=.7}e.object.rotation.x+=dt*5;e.object.rotation.z+=dt*3}else if(e.kind==='ring'){e.object.scale.setScalar((1-r)*e.scale);e.object.material.opacity=r*.5}else if(e.kind==='scorch'){e.object.material.opacity=Math.min(.6,e.life*.12)}else{e.object.material.opacity=r;e.object.scale.setScalar(e.scale*(.5+(1-r)*.8))}}
 for(let i=tracers.length-1;i>=0;i--)if(sim>tracers[i].until){tracers[i].line.removeFromParent();tracers[i].line.geometry.dispose();tracers[i].line.material.dispose();tracers.splice(i,1)}
 if(frame%4===0&&random()<.5){particle(new T.Vector3(range(-30,30),range(.5,4),range(-28,28)),new T.Vector3(.5,.02,.18),range(.04,.09),range(2,5),0xd6bb87)}
 for(let i=pdata.length-1;i>=0;i--){const p=pdata[i];p.life-=dt;if(p.life<=0){pdata.splice(i,1);continue}p.v.y-=p.gravity*dt;p.p.addScaledVector(p.v,dt);if(p.kind){p.size+=dt*.26;p.v.x+=dt*.015}}
 const attrs=particleGeo.attributes;for(let i=0;i<pdata.length;i++){const p=pdata[i],r=p.life/p.max;attrs.position.setXYZ(i,p.p.x,p.p.y,p.p.z);attrs.color.setXYZ(i,p.color.r,p.color.g,p.color.b);attrs.aSize.setX(i,p.size);attrs.aAlpha.setX(i,Math.min(1,(1-r)*8)*Math.min(1,r*3)*(p.kind?.5:1));attrs.aKind.setX(i,p.kind)}for(const a of Object.values(attrs))a.needsUpdate=true;particleGeo.setDrawRange(0,pdata.length);particles.material.uniforms.uTime.value=sim;
 water.material.uniforms.uTime.value=sim;if(materials.flameShader)materials.flameShader.uniforms.uTime.value=sim;materials.poolWater.opacity=.78+Math.sin(sim)*.05;
 for(const b of birds){const a=b.angle+sim*b.speed;b.g.position.set(-15+Math.cos(a)*b.r,b.height+Math.sin(a*2),Math.sin(a)*b.r);b.g.rotation.y=-a;for(let j=0;j<2;j++)b.wings[j].rotation.y=Math.sin(sim*4+b.angle)*(j?-1:1)*.3}
 for(const c of clouds){c.position.x+=dt*.25;if(c.position.x>110)c.position.x=-110}
}
function updateCamera(dt){
 const portrait=innerWidth/innerHeight<.85;let distance,heading=yaw,elevation=pitch;
 if(cameraMode==='overview'){viewPoint.set(0,1.5,0);distance=(portrait?168:96)*zoom;heading=yaw;elevation=pitch}
 else if(cameraMode==='auto'){viewPoint.copy(sim-lastAction<5?autoPoint:new T.Vector3(-3,1,1));distance=portrait?39:31;heading=.78+(reduced?0:Math.sin(sim*.045)*.35);elevation=.8+(reduced?0:Math.sin(sim*.07)*.05)}
 else {const a=agents[selected];viewPoint.copy(a.g.position).add(new T.Vector3(0,.9,0));distance=portrait?27:22;heading=.7+(reduced?0:Math.sin(sim*.035)*.18);elevation=.72;}
 const speed=cameraMode==='overview'?3:1.75,alpha=1-Math.exp(-dt*speed);camAim.lerp(viewPoint,alpha);camGoal.set(camAim.x+Math.sin(heading)*Math.cos(elevation)*distance,camAim.y+Math.sin(elevation)*distance,camAim.z+Math.cos(heading)*Math.cos(elevation)*distance);camera.position.lerp(camGoal,alpha);cameraShake*=Math.exp(-dt*7);if(!reduced&&cameraShake>.005)camera.position.add(new T.Vector3((random()-.5)*cameraShake,(random()-.5)*cameraShake,0));camera.lookAt(camAim);
 for(const a of agents){tempV.copy(a.g.position).add(new T.Vector3(0,2.4,0)).project(camera);const visible=Math.abs(tempV.x)<.96&&Math.abs(tempV.y)<.92&&tempV.z<1;a.label.style.visibility=visible?'visible':'hidden';a.label.style.left=(tempV.x*.5+.5)*innerWidth+'px';a.label.style.top=(-tempV.y*.5+.5)*innerHeight+'px';a.label.querySelector('i').style.width=clamp(a.hp/100*20,0,20)+'px';a.label.querySelector('b').textContent=cameraMode==='player'&&a.index===selected?`${names[a.index]} · ${weapons[a.index%5][0]} ${a.ammo}/${a.reserve}`:names[a.index]}
}
function tick(){requestAnimationFrame(tick);if(!ready)return;const elapsed=clock.getDelta(),raw=Math.min(elapsed,.06),dt=document.hidden?0:raw;frame++;if(!paused){sim+=dt;updateScene(dt)}updateCamera(dt);if(flash>0){flash=Math.max(0,flash-dt*.8);$('#flash-overlay').style.opacity=String(flash)}else $('#flash-overlay').style.opacity='0';if(eventUntil&&performance.now()>eventUntil){$('#event').classList.remove('visible');eventUntil=0}updateAgentInstances();renderer.render(scene,camera);frames++;fpsTime+=elapsed;if(fpsTime>=1){lastFps=Math.round(frames/fpsTime);frames=0;fpsTime=0;$('#performance').textContent=`${quality} · ${lastFps} FPS`}}

async function boot(){
 try{
 renderer=new T.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;$('#scene').append(renderer.domElement);
 scene=new T.Scene();scene.background=new T.Color(0xd6d4bd);scene.fog=new T.FogExp2(0xd6d4bd,.0023);camera=new T.PerspectiveCamera(38,innerWidth/innerHeight,.2,350);camera.position.set(46,65,53);world=new T.Group();scene.add(world);
 scene.add(new T.HemisphereLight(0xc2e6eb,0x8d7251,1.85));sun=new T.DirectionalLight(0xffdfb4,3.2);sun.position.set(-40,70,-36);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-54,right:54,top:54,bottom:-54,near:1,far:180});sun.shadow.bias=-.00035;sun.shadow.normalBias=.04;sun.shadow.radius=2;scene.add(sun);scene.add(sun.target);const fill=new T.DirectionalLight(0x9ed8e8,.65);fill.position.set(20,30,40);scene.add(fill);
 geos.box=new T.BoxGeometry(1,1,1);geos.capsule=new T.CapsuleGeometry(1,1,4,10);geos.sphere=new T.SphereGeometry(1,10,8);
 mat('sand','#ccad7f');mat('cream','#e6d7b8');mat('peach','#c59779');mat('trim','#e4d9bf','stone');mat('stone','#b2a48b','stone');mat('paving','#bdad91','paving');mat('sandGround','#c6b28b');mat('tile','#18474b','tile');mat('roof','#b65d39','roof');mat('wood','#6e5540','wood');mat('woodLight','#a58b5d','wood');mat('trunk','#756245','wood');
 solid('trunkLight',0x927b50);solid('foliage',0x516d41,{side:T.DoubleSide});solid('leaf',0x7c914d,{side:T.DoubleSide});solid('flower',0xb28c73);solid('fruit',0xd99543);solid('iron',0x354345,{metalness:.55,roughness:.4});solid('dark',0x253b3a);solid('brass',0xbda365,{metalness:.7,roughness:.35});solid('terracotta',0xa96c46);solid('ceramic',0xc4b59a);solid('cloth',0x2e6a68);solid('canvas',0xd7c393);solid('glass',0xf1c489,{emissive:0xeab878,emissiveIntensity:.3});solid('dome',0x547e76,{metalness:.35,roughness:.4});solid('inlay',0x71847a);solid('rock',0x918b72);solid('boat',0x365b60);solid('rope',0xa29776);solid('bird',0x354644,{side:T.DoubleSide});solid('poolWater',0x519d9c,{metalness:.3,roughness:.17,transparent:true,opacity:.8});
 solid('uniformAmber',0xbca178);solid('uniformBlue',0x577e87);solid('vest',0x354346);solid('pouch',0x53624f);solid('belt',0x292e2b);solid('skin',0xc69d7b);solid('helmet',0x576253);solid('visor',0x283f43,{metalness:.4,roughness:.2});solid('mask',0x6f7968);solid('glove',0x383e39);solid('boot',0x343a36);solid('gun',0x283335,{metalness:.65,roughness:.37});solid('gunLight',0x687672,{metalness:.65,roughness:.32});solid('amberMark',0xe9b973,{emissive:0xc38332,emissiveIntensity:.3});solid('cyanMark',0x73d5e2,{emissive:0x397b91,emissiveIntensity:.3});solid('debris',0x9d896c);solid('bottle',0x456851,{metalness:.2,roughness:.2});solid('c4charge',0xa58d61);solid('screen',0x81d5a6,{emissive:0x64e296,emissiveIntensity:.8});solid('wireRed',0xac5144);solid('wireBlue',0x547cad);
 resize();await new Promise(r=>setTimeout(r,60));makeSet();initParticles();for(let i=0;i<10;i++)makeAgent(i);instanceAgents();resetAgents();setupControls();resize();clock=new T.Clock();ready=true;await renderer.compileAsync(scene,camera);$('#loading').classList.add('done');setTimeout(()=>$('#loading').remove(),750);tick();
 window.arenaShowcase={version:'original18',stats:sceneStats,getState:()=>({sim,paused,cameraMode,selected,cycle,particleCount:pdata.length,grenades:grenades.length,fires:fires.length,c4:!!c4,agents:agents.map(a=>({name:names[a.index],x:a.g.position.x,z:a.g.position.z,hp:a.hp,ammo:a.ammo,moved:a.moved,shots:a.shots})),render:{calls:renderer.info.render.calls,triangles:renderer.info.render.triangles},fps:lastFps}),effect:(kind)=>kind==='c4'?plantC4(true):throwGrenade(kind,true),advance:(seconds)=>{for(let i=0;i<Math.ceil(seconds*30);i++){sim+=1/30;updateScene(1/30)}updateCamera(4);updateAgentInstances();renderer.render(scene,camera);return sim}};
 if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&location.pathname.includes('/original18/'))navigator.serviceWorker.register(new URL('sw.js',location.href),{scope:'./'}).catch(()=>{});
 }catch(e){console.error(e);$('#loading').innerHTML='<div class="load-mark">ARENA</div><h1>3D ochilmadi</h1><p>Chrome yoki Safari’da WebGL yoqilganini tekshiring.</p><p id="startup-error"></p><button onclick="location.reload()">Qayta ochish</button>';$('#startup-error').textContent=e.message}
}
boot();
