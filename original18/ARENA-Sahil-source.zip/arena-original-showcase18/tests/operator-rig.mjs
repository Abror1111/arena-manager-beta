import {createOperator,poseOperator} from '../operators.js';
import assert from 'node:assert/strict';
globalThis.document={createElement:()=>({width:0,height:0,getContext:()=>({createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),putImageData:()=>{}})})};
const op=createOperator(0);let maxFoot=0,maxArm=0;const results=[];
for(const test of [{name:'idle'},{name:'walk',vz:1.3},{name:'run',vz:2.8},{name:'strafe',vx:1.4,aim:true},{name:'backward',vz:-1.2,aim:true},{name:'crouch',crouch:1,aim:true},{name:'reload',reload:.5},{name:'throw',throw:.6},{name:'plant',plant:.5},{name:'switch',switch:.7}]){
 for(let i=0;i<180;i++){const p=poseOperator(op,{time:i/60,...test},1/60);maxFoot=Math.max(maxFoot,p.footError);maxArm=Math.max(maxArm,p.armError);for(const leg of op.legs){assert(Math.abs(leg.upper.position.distanceTo(leg.lower.position)-.43)<1e-5);const foot=op.feet[op.legs.indexOf(leg)];assert(Math.abs(leg.lower.position.distanceTo(foot.position)-.43)<1e-5)}for(const arm of op.arms){assert(Math.abs(arm.upper.position.distanceTo(arm.lower.position)-.285)<1e-5);const hand=op.hands[op.arms.indexOf(arm)];assert(Math.abs(arm.lower.position.distanceTo(hand.position)-.27)<1e-5)}op.root.updateMatrixWorld(true);op.root.traverse(o=>{for(const v of o.matrixWorld.elements)assert(Number.isFinite(v),test.name+' has non-finite transform')});}
 results.push({name:test.name,pose:op.lastPose});
}
console.log(JSON.stringify({joints:op.jointCount,stats:op.stats,maxFoot,maxArm,results},null,2));assert(maxFoot<.01,'Unreachable foot target');assert(maxArm<.005,'Unreachable grip target');
