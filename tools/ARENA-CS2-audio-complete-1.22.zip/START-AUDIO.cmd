@echo off
setlocal
set PYTHONUTF8=1
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto use_python
py -3 launch-cs2-audio.py
goto done
:use_python
python launch-cs2-audio.py
:done
echo.
echo Tayyor ZIP yoki XATO yozuvini yuqoridan tekshiring.
pause
