ARENA CS2 audio export 1.22 (Windows PC)

1. ZIP ichidagi barcha fayllarni yangi papkaga oching.
2. START-AUDIO.cmd faylini ishga tushiring. Python 3 kerak.
3. CS2 papkasini kiriting yoki Enter bosing. Standart:
   E:\Steam Game\steamapps\common\Counter-Strike Global Offensive
4. TAYYOR yozuvi va ARENA-CS2-AUDIO-....zip faylini kuting.
5. Shu bitta ZIP'ni GitHub release'ga yuklash mumkin.
   https://github.com/Abror1111/arena-manager-beta/releases/tag/cs2-map-exports-1

CS2 asl fayllari o'zgartirilmaydi. Source2Viewer-CLI20.1 rasmiy
GitHub manbasidan tekshiriladigan SHA256 bilan olinadi.
Oldingi eksportlar saqlanadi, yangi vaqt nomli papka ishlatiladi.

Yangilik: tasodifiy variantlardan oldin otish, C4 portlashi, qo'yish,
zararsizlantirish va qayta o'qlash tanlanadi. Asosiy menyu va natija
musiqalari ham tanlanadi. Bu ZIP o'zida Valve o'yin fayllarini saqlamaydi.
Xato bo'lsa oynani yopmang; diagnostics.txt faylini yuboring.
