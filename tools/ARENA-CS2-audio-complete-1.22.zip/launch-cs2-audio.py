"""Windows helper: user input is passed as an argument, never as shell code."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
default=r'E:\Steam Game\steamapps\common\Counter-Strike Global Offensive'
print('ARENA CS2 AUDIO 1.22 - original recordings, read-only export')
print('CS2 papka, Enter = '+default)
game=input('> ').strip() or default
raise SystemExit(subprocess.run([sys.executable,str(root/'export-cs2-audio.py'),'--game',game],cwd=root).returncode)
