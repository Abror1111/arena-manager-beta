"""Read-only CS2 sound export. Uses official pinned Source2Viewer; no game assets are downloaded."""
import argparse,datetime,importlib.util,json,os,re,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('arena_export_common',ROOT/'export-cs2-visuals.py');common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
RESOURCE=re.compile(r'(?i)(?<![a-z0-9_./-])(sounds/(?:[a-z0-9_.-]+/)*[a-z0-9_.-]+\.vsnd_c)')
WEAPON=re.compile(r'hkp2000|p2000|elite|mp5sd|ak47|m4a1|m4a4|awp|glock|usp|deagle|nova|mp9|mp7|p250|famas|galil|sg556|aug|ssg08|scar20|g3sg1|xm1014|mag7|sawedoff|negev|m249|p90|bizon|ump45|mac10|tec9|fiveseven|cz75|revolver|knife|taser',re.I)
OTHER=re.compile(r'c4|bomb|grenade|molotov|incendiary|flashbang|smokegrenade|footstep|concrete|dirt|land|glass',re.I)
def select_resources(text):
 paths=sorted({p.lower() for p in RESOURCE.findall(text.replace('\\','/')) if '..' not in p.split('/')});buckets={}
 def role(p):
  name=p.rsplit('/',1)[-1]
  if re.search(r'explod|explos|deton',name):return (0,'explosion')
  if re.search(r'beep|blip',name):return (1,'beep')
  if re.search(r'plant',name):return (2,'plant')
  if re.search(r'defus',name):return (3,'defuse')
  if re.search(r'reload|addammo|clipin|clipout|boltforward',name):return (4,'reload')
  if re.search(r'fire|shot|shoot|single|burst|[_-]\d+(?:_\d+)?\.vsnd_c$',name) and not re.search(r'distant|tail|dry|empty|bolt|clip|draw|impact|magazine',name):return (0 if '_' in name else 2,'silenced-shot' if 'silenc' in name else 'shot')
  return (9,'other')
 for p in paths:
  if '/music/' in p:
   name=p.rsplit('/',1)[-1];cue=next((c for c,rx in [('menu',r'mainmenu|main_menu|^menu\.'),('win',r'roundwon|roundmvp|mvpanthem'),('loss',r'roundlost'),('planted',r'bombplanted'),('countdown',r'tensec')] if re.search(rx,name)),None)
   if cue:buckets.setdefault('music:'+cue,[]).append(p)
   continue
  match=WEAPON.search(p) or OTHER.search(p)
  if match:buckets.setdefault(match[0].lower(),[]).append(p)
 for family,paths in buckets.items():
  if family.startswith('music:'):
   buckets[family]=sorted(paths,key=lambda p:('valve_csgo_01' not in p,'valve' not in p,p))[:1];continue
  # Ensure one sample of each essential action before alternate variants.
  paths.sort(key=lambda p:(role(p)[0],p));seen=set();first=[];rest=[]
  for p in paths:
   action=role(p)[1]
   if action not in seen:first.append(p);seen.add(action)
   else:rest.append(p)
  buckets[family]=(first+rest)[:5]
 chosen=[]
 for n in range(5):
  for category in sorted(buckets):
   if n<len(buckets[category]):chosen.append(buckets[category][n])
 return chosen[:180]
def export(game,viewer,output):
 game=common.normalize_game(game);out=Path(output).resolve();install=game.parent.parent
 if out==install or install in out.parents:raise ValueError('Eksport papkasi CS2 papkasidan tashqarida bolsin.')
 out.mkdir(parents=True,exist_ok=False);assets=out/'sounds';assets.mkdir();pak=game/'pak01_dir.vpk'
 if not pak.is_file():raise ValueError('pak01_dir.vpk topilmadi: '+str(pak))
 with (out/'diagnostics.txt').open('w',encoding='utf-8') as log:
  common.RUN_LOG=log
  try:
   selected=select_resources(common.run_cli([str(viewer),'--input',str(pak),'--vpk_list','--vpk_extensions','vsnd_c'],capture=True))
   if not selected:raise ValueError('Ovoz resurslari topilmadi. diagnostics.txt faylini tekshiring.')
   for i in range(0,len(selected),10):
    print('OVOZ:',i,'/',len(selected),flush=True);common.run_cli([str(viewer),'--input',str(pak),'--vpk_filepath',','.join(selected[i:i+10]),'--decompile','--threads','2','--output',str(assets)+os.sep])
    if sum(p.stat().st_size for p in assets.rglob('*') if p.is_file())>160*1024**2:raise ValueError('160 MiB chegarasi oshdi. Mavjud fayllar va diagnostika saqlandi.')
   files=[p for p in assets.rglob('*') if p.is_file() and p.suffix.lower() in ['.wav','.mp3','.ogg','.opus','.flac']]
   if not files:raise ValueError('Oqiladigan WAV/MP3/OGG chiqmadi. Bosh ZIP tayyor deb korsatilmaydi.')
   manifest={'schema':1,'assetType':'cs2-audio','clientVersion':common.client_version(game),'exporter':'Source2Viewer-CLI20.1','files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':common.file_hash(p)} for p in files},'rights':'Valve/CS2 original sound assets, locally exported by the user.'}
   m=out/'ARENA-audio-export.json';m.write_text(json.dumps(manifest,indent=2),encoding='utf-8');files.append(m);archive=out.with_suffix('.zip');partial=archive.with_suffix('.zip.partial')
   if archive.exists() or partial.exists():raise ValueError('Oldingi ZIP saqlanadi. Yangi papka nomini tanlang.')
   with zipfile.ZipFile(partial,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for p in files:z.write(p,p.relative_to(out).as_posix())
   with zipfile.ZipFile(partial) as z:
    if z.testzip():raise ValueError('ZIP tekshiruvi otmadi.')
   partial.rename(archive);print('TAYYOR:',archive,flush=True);return archive
  finally:common.RUN_LOG=None
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--game',default=r'E:\Steam Game\steamapps\common\Counter-Strike Global Offensive');p.add_argument('--viewer');p.add_argument('--output');a=p.parse_args()
 try:export(a.game,Path(a.viewer).resolve() if a.viewer else common.official_viewer(),a.output or 'ARENA-CS2-AUDIO-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
 except Exception as e:print('XATO:',e,flush=True);raise SystemExit(1)
if __name__=='__main__':main()
