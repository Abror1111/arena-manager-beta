@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 export-cs2-audio.py --game "E:\Steam Game\steamapps\common\Counter-Strike Global Offensive"
echo.
pause
