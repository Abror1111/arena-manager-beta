ARENA CS2 OVOZ EKSPORTI

1. ZIPni alohida papkaga oching. CS2 o‘rnatilgan bo‘lsin.
2. EXPORT-AUDIO.cmd faylini ikki marta bosing. Python3 kerak.
3. CS2 manzili: E:\Steam Game\steamapps\common\Counter-Strike Global Offensive
   Boshqa joyda bo‘lsa, CMD ichida --game manzilini o‘zgartiring.
4. Rasmiy Source2Viewer20.1 avtomatik olinadi. O‘yin fayllari faqat o‘qiladi.
5. TAYYOR yozuvidan keyin shu papka yonida ARENA-CS2-AUDIO-....zip paydo bo‘ladi.
6. Uni GitHub arena-manager-beta Releases ga bir fayl qilib qo‘shing va havolasini yuboring.

Bu vosita asl Valve tovushlarini faqat o‘rnatilgan CS2 dan eksport qiladi.
Hozirgi ARENA ovozlari sintezlangan; asl CS2 audio bu ZIP tayyor bo‘lgach alohida moslashtiriladi.
XATO bo‘lsa diagnostics.txt saqlanadi, bo‘sh ZIP muvaffaqiyat deb ko‘rsatilmaydi.
