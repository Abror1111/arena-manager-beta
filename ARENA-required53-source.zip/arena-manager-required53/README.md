# ARENA Manager1.53 — Mandatory first-run guide

Mandatory first-run onboarding: persisted required53 marker for unfinished real clubs; the coach cannot be paused or hidden. Settings remain accessible from its gear control without completing or skipping the guide. Optional isolated Help replay stays dismissible.

Stage advancement additionally requires roster inspection, both training selections, rest acknowledgement, map/strategy acknowledgement and every actual battle control. Normal tutorial gates still require five paid recruits, real training/rest, objective/cosmetic actions and a settled non-forfeit practice; completion remains once-only400XP.

Migration resumes older paused onboarding and recognizes real training/practice already completed before this requirement; it never spends/grants funds. Completed clubs and legacy clubs without onboarding remain unchanged. Geometry, art, audio, battle simulation and economy are preserved apart from tutorial gates and display version1.53.

This release updates the web game and source. The1.52 APK remains unchanged; its signing key was in the previous ephemeral runtime and is unavailable after environment restart. No replacement certificate is published under the existing application ID.

Build: `node --test tests/*.test.mjs`; `ARENA_MANAGER_OUT=/tmp/arena53-web npm run build`; `python pack-web31.py /tmp/arena53-web`. runtime53.json pins a SHA-verified immutable compressed runtime. verification53 contains current tests; verification52 retains prior full mobile-layout evidence. Serve with shared root assets at /arena-manager-beta/remix31/. Prior release: https://github.com/Abror1111/arena-manager-beta/tree/arena-mobile52-source .
