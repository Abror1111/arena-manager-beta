import{PortraitFrame49}from'./PortraitFrame49.jsx';
import{FRAMES49}from'./VisualCatalog49.js';
import React,{createContext,useContext,useMemo,useEffect,useState}from'react';
import sheets from'./portraits44.json'with{type:'json'};
import thumbs from'./portrait-thumbs44.json'with{type:'json'};
import{loadAsset}from'./asset-cache.js';
import{portraitIndex44}from'./portrait-identity44.js';
const Portraits=createContext({}),ready=new Map(),pending=new Map();
export function PortraitProvider44({roster,frame,children}){const slots=useMemo(()=>({...Object.fromEntries(roster.flatMap(p=>[[p.id,p.portrait44],[p.name,p.portrait44]])),__frame45:frame||'none'}),[roster,frame]);return <Portraits.Provider value={slots}>{children}</Portraits.Provider>}
export function loadPortraitSheet44(sheet){if(ready.has(sheet))return Promise.resolve(ready.get(sheet));if(pending.has(sheet))return pending.get(sheet);const job=loadAsset(sheets[sheet]).then(({bytes})=>{const url=URL.createObjectURL(new Blob([bytes],{type:'image/webp'}));ready.set(sheet,url);return url;}).finally(()=>pending.delete(sheet));pending.set(sheet,job);return job;}
export function PlayerPortrait44({index=0,team=0,identity,name,portrait,frame}){
 const roster=useContext(Portraits),candidate=portrait??roster[identity]??portraitIndex44(identity,name,index+team*5),n=Number.isInteger(candidate)&&candidate>=0&&candidate<72?candidate:0,sheet=Math.floor(n/36),cell=n%36,[state,setState]=useState(()=>({sheet,url:ready.get(sheet)||thumbs[sheet]}));
 useEffect(()=>{let live=true;setState({sheet,url:ready.get(sheet)||thumbs[sheet]});loadPortraitSheet44(sheet).then(url=>{if(live)setState({sheet,url})}).catch(()=>{});return()=>{live=false}},[sheet]);const url=state.sheet===sheet?state.url:ready.get(sheet)||thumbs[sheet],full=url===ready.get(sheet);
 const activeFrame=frame??roster.__frame45??'none',model=FRAMES49[activeFrame],photoStyle={backgroundImage:`url(${url})`,backgroundSize:'600% 600%',backgroundPosition:`${cell%6*20}% ${Math.floor(cell/6)*20}%`,backgroundRepeat:'no-repeat'};
 return <span className={'player-photo player-art '+(model?'framed-photo49':'')} aria-hidden="true" data-frame={activeFrame} data-portrait={n} data-portrait-version="44" data-portrait-quality={full?'full':'preview'} style={{display:'block',width:'100%',height:'100%',position:'relative',...(!model?photoStyle:{})}}>{model&&<span className="portrait-face49" style={{...photoStyle,clipPath:`inset(${model.clip.map(v=>v+'%').join(' ')} round 4%)`}}/>}<PortraitFrame49 frame={activeFrame}/></span>;
}
