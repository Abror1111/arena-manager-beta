import React from'react';
import{useVisualImage49}from'./Art49.jsx';
import{FRAMES49}from'./VisualCatalog49.js';
import manifest from'./art49.json'with{type:'json'};
export function PortraitFrame49({frame='none'}){const f=FRAMES49[frame],url=useVisualImage49('frames',!!f);if(!f)return null;const e=manifest.frames,r=e.rects[f.cell];return <svg className="portrait-frame49" viewBox="0 0 100 120" preserveAspectRatio="none" data-frame-model={f.model} data-frame-quality={url?'full':'vector'} aria-hidden="true">{url?<svg width="100" height="120" viewBox={r.join(' ')} preserveAspectRatio="none"><image href={url} width={e.width} height={e.height}/></svg>:<g fill="none" stroke={f.color}><path d="M4 20 18 4h64l14 16v80l-14 16H18L4 100V20Z" strokeWidth="3"/><path d="m50 1 9 10-9 9-9-9 9-10Zm0 99 9 10-9 9-9-9 9-10Z" fill={f.color} fillOpacity=".4"/><path d="m5 34 8 8m82-8-8 8M5 86l8-8m82 8-8-8M25 7l7 9h36l7-9M25 113l7-9h36l7 9"/></g>}</svg>}
