import*as T from'three';
import{terrainHeight25,terrainAxes25,stairAt25,ROAD_AREAS25,STAIRS25}from'./coastal-elevation25.js';
import{insidePlan}from'./coastal-layout24.js';
export function buildElevatedGround25({world,mesh,materials:m}){const axes=terrainAxes25(),bins={sand:[],paving:[],asphalt:[],riser:[],nosing:[]},e=.00004;
 function tri(bin,a,b,c){bin.push(...a,...b,...c)}
 function quad(bin,a,b,c,d){tri(bin,a,b,c);tri(bin,c,b,d)}
 for(let i=0;i<axes.x.length-1;i++)for(let j=0;j<axes.z.length-1;j++){const x0=axes.x[i],x1=axes.x[i+1],z0=axes.z[j],z1=axes.z[j+1],x=(x0+x1)/2,z=(z0+z1)/2,px=x/1.2+50,pz=z/1.2+50,step=stairAt25(px,pz),raised=(px>=61.5&&px<=91&&pz<35)||(px<26&&pz<34),bin=step||raised?bins.paving:ROAD_AREAS25.some(p=>insidePlan([px,pz],p))?bins.asphalt:bins.sand;
  const a=[x0,terrainHeight25(x0+e,z0+e),z0],b=[x1,terrainHeight25(x1-e,z0+e),z0],c=[x0,terrainHeight25(x0+e,z1-e),z1],d=[x1,terrainHeight25(x1-e,z1-e),z1];quad(bin,a,c,b,d);
  // Neighbouring floors meet at a closed vertical retaining face or stair riser.
  if(i){const a0=terrainHeight25(x0-e,z0+e),a1=terrainHeight25(x0-e,z1-e);if(Math.max(Math.abs(a0-a[1]),Math.abs(a1-c[1]))>.025){quad(bins.riser,[x0,a0,z0],[x0,a1,z1],a,c);if(step?.axis==='x'){const h=Math.max(a0,a[1])+.025;quad(bins.nosing,[x0-.05,h,z0],[x0-.05,h,z1],[x0+.05,h,z0],[x0+.05,h,z1])}}}
  if(j){const a0=terrainHeight25(x0+e,z0-e),a1=terrainHeight25(x1-e,z0-e);if(Math.max(Math.abs(a0-a[1]),Math.abs(a1-b[1]))>.025){quad(bins.riser,[x0,a0,z0],a,[x1,a1,z0],b);if(step?.axis==='z'){const h=Math.max(a0,a[1])+.025;quad(bins.nosing,[x0,h,z0-.05],[x0,h,z0+.05],[x1,h,z0-.05],[x1,h,z0+.05])}}}
 }
 let triangles=0;for(const[k,positions]of Object.entries(bins)){if(!positions.length)continue;const g=new T.BufferGeometry(),uv=[];for(let i=0;i<positions.length;i+=3)uv.push(positions[i]*.25,positions[i+2]*.25);g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.computeVertexNormals();const base=k==='sand'?m.sandGround:k==='asphalt'?m.asphaltRoad:k==='riser'?m.stone:k==='nosing'?m.trim:m.paving,ma=base.clone();ma.side=T.DoubleSide;if(k==='nosing')ma.normalMap=null;m['elevation25-'+k]=ma;const o=mesh(g,ma,world);o.castShadow=k==='riser';o.name='elevation25-'+k;triangles+=positions.length/9}
 return{triangles,stairFlights:STAIRS25.length,stairTreads:STAIRS25.reduce((n,s)=>n+s.steps,0),min:.05,max:4.25};}
