import {AdaptiveDeck,card} from './AdaptiveDeck.jsx';
import React,{useEffect,useRef,useState} from 'react';
import {MAPS,mapMeta} from './maps.js';
import {downloadableMaps,downloadBytes,mapDownloadStatus,prepareMaps} from './map-downloads.js';
import {packaged} from './asset-cache.js';
const mb=bytes=>Math.ceil(bytes/1000000);
export function MapLibrary({onExplore}){
 const [ready,setReady]=useState({}),[working,setWorking]=useState(false),[progress,setProgress]=useState({progress:0,map:null}),[message,setMessage]=useState('');const controller=useRef(null);
 useEffect(()=>{let mounted=true;mapDownloadStatus().then(s=>{if(mounted)setReady(s);});return()=>{mounted=false;controller.current?.abort();};},[]);
 async function download(){
  const job=new AbortController();controller.current=job;setWorking(true);setMessage('');
  try{const status=await prepareMaps({signal:job.signal,onProgress:setProgress});if(!job.signal.aborted){setReady(status);setMessage('Xaritalar saqlandi. Keyingi ochishda qayta yuklanmaydi.');}}
  catch(e){if(!job.signal.aborted)setMessage(e.message);}
  finally{if(!job.signal.aborted)setWorking(false);}
 }
 async function stop(){controller.current?.abort();setWorking(false);setReady(await mapDownloadStatus());setMessage('Yuklash to‘xtatildi. Tayyor fayllar saqlanib qoldi.');}
 const count=Object.values(ready).filter(Boolean).length;
 return <section className="map-library" data-testid="map-library"><div className="screen-heading"><div><span className="eyebrow">QURILMADAGI XARITALAR</span><h1>Xaritalar</h1></div><span className="tag-badge">{count}/{downloadableMaps.length} tayyor</span></div>
 <AdaptiveDeck label="Xaritalar" items={[
 card('downloads',packaged?'Internetsiz o‘yin':'Bir marta yuklang',<><p className="deck-copy">{packaged?'Xaritalar ilovada tayyor.':'Xarita birinchi ochilganda qurilmada saqlanadi. Hammasi: taxminan '+mb(downloadBytes)+' MB.'}</p>{!packaged&&(working?<><progress aria-label="Xaritalarni yuklash" value={progress.progress} max="1"/><button onClick={stop}>To‘xtatish · {Math.floor(progress.progress*100)}%</button></>:<button className="primary" onClick={download} disabled={count===downloadableMaps.length}>{count===downloadableMaps.length?'✓ Barchasi tayyor':'Barcha xaritalarni yuklash'}</button>)}{message&&<small role="status">{message}</small>}</>),
 ...MAPS.map(m=>card(m.id,mapMeta(m.id).name,<div className="map-library-card"><button className="map-image-action" aria-label={`${mapMeta(m.id).name} xaritasini ko‘rish`} onClick={()=>onExplore(m.id)}><img src={mapAssetsPreview(m.id)} alt={`${mapMeta(m.id).name} xaritasi`} loading="lazy"/><span>3D xaritani ko‘rish ↗</span></button><small className={ready[m.id]?'good':'muted'}>{ready[m.id]?'✓ Qurilmada tayyor':mb(downloadableMaps.find(a=>a.id===m.id)?.bytes||0)+' MB · bir marta yuklanadi'}</small></div>))
 ]}/></section>;

}
export function mapAssetsPreview(id){return `./sahil-preview28.jpg`;}
