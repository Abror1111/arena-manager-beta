import{DISTRICTS,toWorld,coastalHeight24,coastalSolids24,ROUTES,COVERS_PLAN,PALMS_PLAN}from'./coastal-layout24.js';
export{WIDTH,DEPTH}from'./coastal-layout24.js';
export const BUILDINGS=DISTRICTS;
export const OUTSKIRTS=[[-48,-66,14,9,7,4,'sand'],[-28,-66,17,9,8,1,'cream'],[-5,-66,18,10,7,0,'sand'],[18,-66,15,10,8,1,'cream'],[40,-67,15,11,8,0,'sand'],[65,-43,10,16,7,1,'cream'],[67,-17,11,17,9,0,'cream'],[67,11,11,16,7,1,'sand'],[65,38,10,14,7,0,'sand'],[-44,66,17,9,7,4,'sand'],[-20,67,17,10,8,1,'cream'],[5,67,15,10,7,0,'sand'],[28,67,15,10,8,1,'cream'],[49,66,14,10,7,0,'sand']];
export const ROOM={x:0,z:0,w:0,d:0,h:0},TUNNEL_FLOORS=[],TUNNEL_WALLS=[],ROOM_WALLS=[],SITE_WALLS=[],PERIMETER_WALLS=[],MID_WALLS=[],LAMPS=[],MARKET_STALLS=[];
export const COVERS=COVERS_PLAN.map(([x,z,w])=>{const q=toWorld([x,z]);return[q.x,q.z,w*1.2]});
export const PALMS=PALMS_PLAN.map(([x,z,h])=>{const q=toWorld([x,z]);return[q.x,q.z,h]});
export const districtHeight22=coastalHeight24,districtSolids22=coastalSolids24;
export const TACTICAL_ROUTES=ROUTES.map(r=>({id:r.id,points:r.p.map(p=>{const q=toWorld(p);return[q.x,q.z,p[2]]})}));
