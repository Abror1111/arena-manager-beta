// Door frames, adjoining walls, open leaves and collision derive from this plan.
export const DOORS26=[{id:'MID',p:[46.2,36.2],yaw:-.22,width:3.65,h:4},{id:'B',p:[25,23],yaw:Math.PI/2,width:3.65,h:4},{id:'LONG IN',p:[69,65.5],yaw:0,width:3.65,h:4.2},{id:'LONG OUT',p:[72,54.8],yaw:0,width:3.65,h:4.2}];
export const CHOKE_WALLS26=[
 {id:'mid-left',a:[43,35.48],b:[44.72,35.87],h:4},{id:'mid-right',a:[47.68,36.53],b:[50,37.05],h:4},
 {id:'b-north',a:[25,12],b:[25,21.48],h:3.2},{id:'b-south',a:[25,24.52],b:[25,29.5],h:3.2},
 {id:'long-west',a:[66.4,54.8],b:[66.4,65.5],h:4.2},{id:'long-east',a:[75,54.8],b:[75,65.5],h:4.2},
 {id:'long-in-left',a:[66.4,65.5],b:[67.48,65.5],h:4.2},{id:'long-in-right',a:[70.52,65.5],b:[75,65.5],h:4.2},
 {id:'long-out-left',a:[66.4,54.8],b:[70.48,54.8],h:4.2},{id:'long-out-right',a:[73.52,54.8],b:[75,54.8],h:4.2}
];
export function leafSegments26(d){return[-1,1].map(side=>{const angle=d.yaw+side*1.18,x=d.p[0]+side*d.width/2*Math.cos(d.yaw)/1.2,z=d.p[1]-side*d.width/2*Math.sin(d.yaw)/1.2;return{id:d.id+'-leaf-'+side,a:[x,z],b:[x-side*1.65*Math.cos(angle)/1.2,z+side*1.65*Math.sin(angle)/1.2],h:3.4,width:.12}})}
export function segmentSolid26(r,base){const[a,b]=[r.a,r.b].map(([x,z])=>({x:(x-50)*1.2,z:(z-50)*1.2})),dx=b.x-a.x,dz=b.z-a.z,l=Math.hypot(dx,dz),nx=-dz/l*(r.width||.32)/2,nz=dx/l*(r.width||.32)/2,points=[{x:a.x+nx,z:a.z+nz},{x:a.x-nx,z:a.z-nz},{x:b.x-nx,z:b.z-nz},{x:b.x+nx,z:b.z+nz}],x=(a.x+b.x)/2,z=(a.z+b.z)/2;return{x,z,w:Math.max(...points.map(p=>p.x))-Math.min(...points.map(p=>p.x)),d:Math.max(...points.map(p=>p.z))-Math.min(...points.map(p=>p.z)),polygon:points.map(p=>({x:p.x-x,z:p.z-z})),y:base(x,z),h:r.h,id:r.id}}
