// Metres in the authored coastal plan. CT starts in open air west of Short.
export const BRIDGE26=[{x0:61,x1:66,z0:20,z1:32,y:4.25},{x0:61,x1:78,z0:18,z1:22.5,y:4.25}];
export const STAIRS26=[{id:'short',axis:'z',start:37,end:32,x0:60,x1:66,z0:32,z1:37,low:2.6,high:4.25,steps:11},{id:'upper-to-lower',axis:'x',start:25,end:33,x0:25,x1:33,z0:38,z1:47.5,low:1.8,high:.15,steps:11},{id:'lower-mid',axis:'x',start:40,end:46,x0:40,x1:46,z0:38.5,z1:43.5,low:.15,high:.05,steps:1}];
const within=(x,z,r)=>x>=r.x0&&x<=r.x1&&z>=r.z0&&z<=r.z1,clamp=(t)=>Math.max(0,Math.min(1,t)),lerp=(a,b,t)=>a+(b-a)*clamp(t);
export function bridgeHeight26(x,z){const px=x/1.2+50,pz=z/1.2+50;return BRIDGE26.some(r=>within(px,pz,r))?4.25:null}
export function stairAt26(px,pz){return STAIRS26.find(r=>within(px,pz,r))||null}
export function groundFloor26(x,z){if(Math.abs(x)>60||Math.abs(z)>60)return .05;const px=x/1.2+50,pz=z/1.2+50,s=stairAt26(px,pz);if(s){const t=((s.axis==='x'?px:pz)-s.start)/(s.end-s.start),n=Math.max(0,Math.min(s.steps,Math.floor(t*s.steps+1e-8)));return s.low+(s.high-s.low)*n/s.steps}
 if(px>=33&&px<=40&&pz>=38.5&&pz<=43.5)return .15;
 if(px>=77&&px<=91&&pz<=24)return 4.25;
 // CT's open street and A ramp run below the Short crossing, then emerge south of it.
 if(px>=66&&px<=80&&pz>=23&&pz<=28.5)return lerp(.05,4.25,(px-66)/14);
 if(px>=83&&px<=91&&pz>24&&pz<=32)return lerp(4.25,3.2,(pz-24)/8);
 if(px>=83&&px<=91&&pz>32&&pz<=66)return 3.2;
 if(px>=66&&px<=91&&pz>=46&&pz<=68)return 3.2;
 if(px>=66&&px<=76&&pz>=53&&pz<=83)return 3.2;
 if(px>=50&&px<=66&&pz>=37&&pz<=43)return 2.6;
 if(px>=43.5&&px<=50&&pz>=36&&pz<=48)return pz<37.2?.05:pz<41.2?lerp(.05,2.6,(pz-37.2)/4):2.6;
 if(px>=43.5&&px<=50&&pz>48&&pz<85)return lerp(2.6,3.2,(pz-48)/37);
 if(px<=26&&pz<=34)return 1.8;
 if(px>26&&px<=40&&pz<=30)return lerp(1.8,.05,(px-26)/14);
 if(px<=28&&pz>=34&&pz<=74)return 1.8;
 if(px<=28&&pz>74&&pz<=85)return lerp(1.8,3.2,(pz-74)/11);
 if(px>=56&&px<=76&&pz>=68)return 3.2;
 if(pz>=85)return 3.2;
 if(pz>68)return lerp(.05,3.2,(pz-68)/17);
 return .05;
}
export function floor26(x,z,hint){const low=groundFloor26(x,z),high=bridgeHeight26(x,z);if(high!==null&&Number.isFinite(hint)&&Math.abs(high-hint)<Math.abs(low-hint))return high;return low}
export const ROAD_AREAS26=[[[83,24],[90,24],[90,65],[84,65],[84,54],[72,54],[69,57],[68,55],[71,51],[83,51]],[[43.5,34],[49,34],[49,85],[43.5,85]],[[26,18],[43,18],[45,20],[61,20],[61,23],[79,23],[80,28],[61,28],[56,26],[45,26],[42,24],[26,24]]];
export function axes26(){const xs=new Set(),zs=new Set();for(let i=0;i<=120;i++){xs.add(i-60);zs.add(i-60)}for(const v of[25,26,28,33,40,43.5,50,60,61,66,76,77,78,80,83,91])xs.add((v-50)*1.2);for(const v of[18,20,22.5,23,24,28.5,30,32,34,36,37,37.2,38,38.5,40,41.2,43,43.5,47.5,48,53,66,68,74,83,85])zs.add((v-50)*1.2);for(const r of STAIRS26)for(let i=0;i<=r.steps;i++)(r.axis==='x'?xs:zs).add((r.start+(r.end-r.start)*i/r.steps-50)*1.2);const clean=s=>[...s].sort((a,b)=>a-b).filter((x,i,a)=>!i||x-a[i-1]>.00001);return{x:clean(xs),z:clean(zs)}}
