import {collisionRay} from './world-collision.js';
// Sparse state: intact objects stay in the map's original batched draw calls.
export const mapProps=map=>map.props||[];
export function impactMapProps(game,kind,x,z,y,clearLine){
 if(!['he','c4'].includes(kind))return;
 const radius=kind==='c4'?15:5.5;
 for(const prop of mapProps(game.map)){
  const d=Math.hypot(prop.x-x,prop.z-z,prop.y-y);
  if(d>=radius||Math.abs(prop.y-y)>3)continue;
  if(clearLine&&!clearLine(game.map,{x,z,y:y+.2},{x:prop.x,z:prop.z,y:prop.y+prop.size[1]/2+.12}))continue;
  let state=game.propStates[prop.id];
  if(!state&&Object.keys(game.propStates).length>=64)continue;
  state??=game.propStates[prop.id]=initial(prop);
  const strength=(1-d/radius)*(kind==='c4'?1.35:1);
  state.burn=Math.max(state.burn,strength*.45);
  if(!prop.movable)continue;
  const dx=prop.x-x,dz=prop.z-z,len=Math.hypot(dx,dz)||1;
  state.vx=Math.max(-8,Math.min(8,state.vx+dx/len*strength*4));state.vz=Math.max(-8,Math.min(8,state.vz+dz/len*strength*4));state.vy=Math.max(state.vy,strength*5.5);state.age=0;state.settled=false;
  state.broken||=['wood','ceramic'].includes(prop.kind)&&strength>.4;
 }
}
const initial=prop=>({x:prop.x,y:prop.y,z:prop.z,vx:0,vy:0,vz:0,rx:0,ry:0,rz:0,burn:0,heat:0,age:0,broken:false,settled:true});
export function tickMapProps(game,dt){
 const props=mapProps(game.map),fires=game.effects.filter(e=>e.kind==='fire'&&!e.extinguished);
 for(const prop of props){
  let state=game.propStates[prop.id];
  const fire=fires.find(e=>Math.hypot((state?.x??prop.x)-e.x,(state?.z??prop.z)-e.z)<3.2&&Math.abs((state?.y??prop.y)-(e.y??0))<2);
  if(fire&&!state&&Object.keys(game.propStates).length<64)state=game.propStates[prop.id]=initial(prop);
  if(!state)continue;
  state.age+=dt;
  if(fire){state.burn=Math.min(1,state.burn+dt*.19);if(['wood','furniture'].includes(prop.kind))state.heat=Math.min(7,state.heat+dt);}
  else state.heat=Math.max(0,state.heat-dt*.65);
  if(prop.movable&&state.heat>3&&!state.broken){state.broken=true;state.age=0;state.vy=.9;state.settled=false;}
  if(!prop.movable||state.settled)continue;
  state.vy-=dt*9.8;state.x+=state.vx*dt;state.z+=state.vz*dt;state.y+=state.vy*dt;
  state.rx+=dt*state.vz*1.3;state.ry+=dt*(state.vx+state.vz)*.6;state.rz-=dt*state.vx*1.3;
  // Floor is the authored object's original level; never fall into a Nuke floor.
  const support=game.map.rebuilt?collisionRay(game.map,{x:state.x,y:state.y+.4,z:state.z},{x:state.x,y:-100,z:state.z},{ignoreProp:prop.id,ignoreStart:.002}):null,floor=game.map.rebuilt?(support?.y??-100):prop.y;
  if(state.y<=floor){state.y=floor;state.vy=Math.abs(state.vy)*.18;state.vx*=Math.exp(-dt*12);state.vz*=Math.exp(-dt*12);if(Math.hypot(state.vx,state.vy,state.vz)<.2){state.vx=state.vy=state.vz=0;state.settled=true;}}
  if(state.age>4&&state.y<=floor+.1){state.vx=state.vy=state.vz=0;state.y=floor;state.settled=true;}
 }
}
export function validPropStates(map,states){
 if(!states||typeof states!=='object'||Array.isArray(states)||Object.keys(states).length>64)return false;
 const props=mapProps(map);
 for(const [key,s]of Object.entries(states)){
  const p=props[Number(key)];if(!p||String(p.id)!==key||!s||Object.keys(s).sort().join(',')!=='age,broken,burn,heat,rx,ry,rz,settled,vx,vy,vz,x,y,z')return false;
  if(typeof s.broken!=='boolean'||typeof s.settled!=='boolean')return false;
  for(const name of ['x','y','z','vx','vy','vz','rx','ry','rz','burn','heat','age'])if(!Number.isFinite(s[name]))return false;
  if(s.burn<0||s.burn>1||s.heat<0||s.heat>7||s.age<0||s.age>10000||Math.hypot(s.x-p.x,s.z-p.z)>30||Math.abs(s.y-p.y)>30||Math.hypot(s.vx,s.vy,s.vz)>100)return false;
 }
 return true;
}
