import {navUseful} from './reference-nav.js';
import {newLearning,checkMotion,advanceControl} from './adaptive-play.js';
import {prepareSquadPlan,configureSquad,spreadPosition,validSquadExtras,grenadeHazard,experienceOf,roleOf,teamDefuser,defuseETA} from './squad-tactics.js';
// Reactive, seeded tactical simulation. Geometry caches contain no live enemy data.
const grids=new WeakMap();
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const position=p=>({x:p.x,z:p.z,y:p.y||0});
const limit=(v,a,b)=>Math.max(a,Math.min(b,v));
const angle=(a,b)=>Math.atan2(b.x-a.x,b.z-a.z);
const sameFloor=(a,b)=>Math.abs((a.y||0)-(b.y||0))<1.2;
export const TACTICAL_STATES=['setup','control','execute','anchor','rotate','engage','cover','reload','postplant','retake','defuse','plant','save','turn','evade','spacing','peek'];
function nearby(map,center,radius=6){
 if(map.original20)return map.walkableSamples.filter(p=>distance(p,center)<radius&&sameFloor(center,p));
 if(!map.nav)return [...map.sites,...map.spawns].filter(p=>distance(p,center)<radius);
 let grid=grids.get(map.nav);
 if(!grid){grid=new Map();for(const row of map.nav.rows){const [x,z,y]=row[3];if(!navUseful(map,{x,z,y}))continue;const key=`${Math.floor(x/4)},${Math.floor(z/4)}`;if(!grid.has(key))grid.set(key,[]);grid.get(key).push({x,z,y});}grids.set(map.nav,grid);}
 const result=[];
 for(let x=Math.floor((center.x-radius)/4);x<=Math.floor((center.x+radius)/4);x++)for(let z=Math.floor((center.z-radius)/4);z<=Math.floor((center.z+radius)/4);z++)for(const p of grid.get(`${x},${z}`)||[])if(sameFloor(center,p)&&distance(center,p)<radius)result.push(p);
 return result;
}
function routePoint(game,p,goal,fraction,tools){
 const route=tools.pathfind(game.map,p,goal);if(!route.length)return position(goal);
 let from=p,total=0;for(const q of route){total+=distance(from,q);from=q;}
 let walked=0;from=p;for(const q of route){const segment=distance(from,q);if(segment&&walked+segment>=total*fraction){const t=(total*fraction-walked)/segment,x=from.x+(q.x-from.x)*t,z=from.z+(q.z-from.z)*t,y=(from.y||0)+((q.y||0)-(from.y||0))*t;return{x,z,y:tools.heightAt(game.map,x,z,y)};}walked+=segment;from=q;}
 return position(route.at(-1));
}
function formation(game,site,slot){
 const choices=nearby(game.map,site,5).filter(q=>distance(q,site)>1.4);
 const heading=slot*Math.PI*2/5;
 choices.sort((a,b)=>Math.abs(Math.atan2(Math.sin(angle(site,a)-heading),Math.cos(angle(site,a)-heading)))-Math.abs(Math.atan2(Math.sin(angle(site,b)-heading),Math.cos(angle(site,b)-heading))));
 return position(choices[0]||site);
}
function makeTeamPlanBase(game,team,tools){
 const strategy=team===0?game.strategy:game.enemyStrategy;
 const site=strategy==='a'?0:strategy==='b'?1:Math.floor(game.random()*2);
 const executeAt=game.elapsed+(strategy==='hold'?32:strategy==='a'||strategy==='b'?14:20)+game.random()*12;
 const plan={site,executeAt,contact:null,sightings:[],trade:null,switched:false,lastUtilityAt:-99};
 for(const p of game.players.filter(p=>p.team===team)){
  const slot=p.id%5,siteCT=game.map.sites[strategy==='a'?0:strategy==='b'?1:slot===1||slot===4?1:0];
  p.brain={state:'setup',think:game.random()*.35,burstLeft:0,burstPause:0,spray:0,cover:null,coverUntil:0,rallyUntil:0,memory:null,
   staging:routePoint(game,p,game.map.sites[site],.43+slot*.025,tools),anchor:formation(game,p.side==='CT'?siteCT:game.map.sites[site],slot),postPlant:null,escape:null};
 }
 return plan;
}
export function makeTeamPlan(game,team,tools){const plan=makeTeamPlanBase(game,team,tools);return game.tactics?.version>=3?prepareSquadPlan(game,team,plan,tools):plan;}
export function resetTactics(game,tools){const history=game.tactics?.version>=3?game.tactics.history:[0,1].map(()=>({attempts:[0,0],wins:[0,0],fragLosses:0}));const learning=game.tactics?.version>=4?game.tactics.learning:newLearning();game.tactics={version:4,learning,history,teams:[]};game.tactics.teams=[makeTeamPlan(game,0,tools),makeTeamPlan(game,1,tools)];}
export function validTactics(state){
 if(!state.tactics||!Array.isArray(state.tactics.teams)||state.tactics.teams.length!==2)return false;
 const point=p=>p&&['x','y','z'].every(k=>Number.isFinite(p[k]));
 const report=r=>point(r)&&Number.isFinite(r.at)&&Number.isInteger(r.id)&&r.id>=0&&r.id<=9;
 for(const t of state.tactics.teams)if(!t||![0,1].includes(t.site)||!Number.isFinite(t.executeAt)||!Number.isFinite(t.lastUtilityAt)||typeof t.switched!=='boolean'||!Array.isArray(t.sightings)||t.sightings.length>5||t.sightings.some(r=>!report(r))||(t.contact!==null&&!report(t.contact))||(t.trade!==null&&!report(t.trade)))return false;
 for(const p of state.players){const b=p.brain;if(!b||!TACTICAL_STATES.includes(b.state)||!['think','burstLeft','burstPause','spray','coverUntil','rallyUntil'].every(k=>Number.isFinite(b[k]))||!point(b.staging)||!point(b.anchor))return false;
  for(const k of ['cover','postPlant','escape'])if(b[k]!==null&&!point(b[k]))return false;
  if(b.memory!==null&&(!point(b.memory)||!Number.isFinite(b.memory.at)||!Number.isInteger(b.memory.id)||b.memory.id<0||b.memory.id>9))return false;
 }
 if(state.tactics.version>=4&&state.tactics.teams.some(t=>!['contact','split','fast','late'].includes(t.variant)||typeof t.reason!=='string'||t.reason.length>100||t.approach!==null&&!point(t.approach)))return false;return validSquadExtras(state);
}
export function tacticalDeath(game,victim,killer,source){if(game.tactics?.version>=3&&['he','fire'].includes(source))game.tactics.history[victim.team].fragLosses=Math.min(1000,game.tactics.history[victim.team].fragLosses+1);const memory=victim.brain?.memory;if(killer&&memory?.id===killer.id&&game.elapsed-memory.at<2){const t=game.tactics.teams[victim.team];t.trade={...memory,at:game.elapsed};t.contact={...t.trade};}}
function coverPoint(game,p,threat,tools){
 const candidates=nearby(game.map,p,5.5).filter(q=>distance(q,p)>.8&&!game.effects.some(e=>e.kind==='fire'&&!e.extinguished&&sameFloor(q,e)&&distance(q,e)<3.5));
 const score=q=>distance(p,q)+(tools.clearLine(game.map,q,threat)?8:0)-Math.min(2,distance(q,threat)*.12);
 candidates.sort((a,b)=>score(a)-score(b));
 return position(candidates[0]||p.brain.staging);
}
function escapePoint(game,p){
 const options=[...game.map.spawns,...game.map.sites,p.brain.staging];
 options.sort((a,b)=>(Math.max(0,30-distance(a,game.bomb))*4+distance(p,a))-(Math.max(0,30-distance(b,game.bomb))*4+distance(p,b)));
 return position(options[0]);
}
const fireProfiles={ak:{accuracy:.65,burst:3,pause:.52,recoil:.075},m4:{accuracy:.68,burst:3,pause:.47,recoil:.065},mp9:{accuracy:.58,burst:5,pause:.38,recoil:.055},awp:{accuracy:.8,burst:1,pause:.35,recoil:.1},nova:{accuracy:.67,burst:1,pause:.2,recoil:.1},glock:{accuracy:.57,burst:1,pause:.17,recoil:.04},usp:{accuracy:.62,burst:1,pause:.14,recoil:.035},deagle:{accuracy:.62,burst:1,pause:.36,recoil:.12}};
export function tacticalShot(game,p,target,{WEAPONS}){
 const gun=WEAPONS[p.weapon],b=p.brain;if(!b||p.cooldown>0||p.reload>0||b.burstPause>0)return;
 if(p.weapon==='knife'){if(distance(p,target)<1.8){game.hurt(target,42,p);p.cooldown=gun.rate;}return;}
 if(p.ammo<=0){if(p.reserve){p.reload=gun.reload;game.emit?.('reload',{weapon:p.weapon,owner:p.id,x:p.x,y:p.y,z:p.z});}else p.weapon='knife';return;}
 const profile=gun.profile||fireProfiles[p.weapon];
 if(b.burstLeft<=0){b.burstLeft=profile.burst+(profile.burst>1?Math.floor(game.random()*2):0);b.spray=0;}
 const range=distance(p,target),crossfire=game.tactics?.version>=3&&game.players.some(q=>q.team===p.team&&q.alive&&q.id!==p.id&&distance(q,p)>3&&q.brain?.memory?.id===target.id&&game.elapsed-q.brain.memory.at<1.2)?.025:0,highGround=game.tactics?.version>=3?limit(((p.y||0)-(target.y||0))*.012,0,.025):0,accuracy=limit(profile.accuracy+crossfire+highGround+(game.tactics.version>=4?b.experience*.0006-.02:0)+((p.aim??p.skill)-70)*.006-range/gun.range*.26-b.spray*profile.recoil-(p.moving?.28:0)-(p.blind>0?.6:0),.035,.88);
 p.ammo--;p.cooldown=gun.rate;b.burstLeft--;b.spray++;
 if(b.burstLeft===0)b.burstPause=profile.pause+game.random()*.16;
 const hit=game.random()<accuracy,spread=Math.max(.5,range*.07);
 const headshot=hit&&game.random()<limit(.035+((p.aim??p.skill)-70)*.001,0,.11)*(p.moving?.25:1);
 game.shots.push({x:p.x,z:p.z,tx:target.x+(hit?0:(game.random()-.5)*spread),tz:target.z+(hit?0:(game.random()-.5)*spread),age:0,y:p.y,ty:target.y,team:p.team,weapon:p.weapon,pellets:gun.pellets,hit,headshot});
 if(hit){const scale=game.combatVersion>=2?(gun.family==='sniper'?.76:gun.family==='pistol'?.78:gun.family==='special'?1:.66):1;game.hurt(target,gun.damage*scale*(p.weapon==='awp'?1.35:1)*(headshot?2.2:1),p);}game.emit?.('shot',{weapon:p.weapon,owner:p.id,x:p.x,y:p.y,z:p.z});
 p.angle=angle(p,target);
}
function tacticalAIBase(game,p,dt,tools){
 const {WEAPONS,clearLine}=tools,b=p.brain,plan=game.tactics.teams[p.team],gun=WEAPONS[p.weapon];agentTimers(p,dt,WEAPONS);
 if(b.think<=0){
  b.think=.25+(100-(p.tacticalSkill??p.skill))*.003+game.random()*.12;
  const visible=game.players.filter(q=>q.team!==p.team&&q.alive&&distance(p,q)<gun.range&&p.blind<.7&&clearLine(game.map,p,q)&&!game.obscured(p,q));
  const priority=q=>(q.id===p.targetId?-2:0)+(q.id===plan.trade?.id&&game.elapsed-plan.trade.at<4?-4:0);
  visible.sort((a,c)=>distance(p,a)-distance(p,c)+priority(a)-priority(c));
  const seen=visible[0];if(seen){
   if(p.targetId!==seen.id)p.acquire=limit(.2+(100-(p.reaction??p.skill))*.006+distance(p,seen)*.004-(game.tactics.version>=3?b.experience*.0008:0),.22,.8);
   p.targetId=seen.id;b.memory={...position(seen),id:seen.id,at:game.elapsed};plan.contact={...b.memory};
   plan.sightings=plan.sightings.filter(r=>game.elapsed-r.at<8&&!visible.some(q=>q.id===r.id));
   for(const q of visible)plan.sightings.push({...position(q),id:q.id,at:game.elapsed});
   const strategy=p.team===0?game.strategy:game.enemyStrategy;
   if(p.side==='T'&&strategy==='balanced'&&!plan.switched&&game.bomb.state==='carried'&&game.clock>35&&plan.sightings.filter(r=>distance(r,game.map.sites[plan.site])<10).length>=3){
    plan.site=1-plan.site;plan.switched=true;plan.executeAt=game.elapsed+5;
    if(game.tactics.version>=3)configureSquad(game,p.team,plan,tools);else for(const q of game.players.filter(q=>q.team===p.team&&q.alive)){q.brain.staging=routePoint(game,q,game.map.sites[plan.site],.3,tools);q.brain.anchor=formation(game,game.map.sites[plan.site],q.id%5);q.path=[];q.goal=null;}
   }
  }else p.targetId=null;
 }
 p.acquire=Math.max(0,p.acquire-dt);
 let enemy=p.targetId!==null?game.players[p.targetId]:null;
 if(!enemy?.alive||distance(p,enemy)>gun.range||p.blind>.7||!clearLine(game.map,p,enemy)||game.obscured(p,enemy))enemy=null;
 const teamContact=plan.contact&&game.elapsed-plan.contact.at<8?plan.contact:null;
 const threat=enemy||(b.memory&&game.elapsed-b.memory.at<5?b.memory:null)||teamContact;
 // A teammate's flash call prompts a short look-away rather than self-blinding.
 const friendlyFlash=game.effects.find(e=>e.kind==='grenade'&&e.type==='flash'&&e.age>e.life-.42&&game.players[e.owner]?.team===p.team&&distance(p,{x:e.tx,z:e.tz})<14);
 if(friendlyFlash){p.angle=angle({x:friendlyFlash.tx,z:friendlyFlash.tz},p);b.state='turn';return;}
 const fire=game.effects.find(e=>e.kind==='fire'&&!e.extinguished&&sameFloor(p,e)&&distance(p,e)<3.5);
 if(fire||p.blind>.8||(enemy&&(p.hp<45||p.reload>0||p.ammo===0))){
  if(!b.cover||b.coverUntil<game.elapsed){b.cover=coverPoint(game,p,fire||threat||p,tools);b.coverUntil=game.elapsed+2.2;}
 }
 if(b.cover&&game.elapsed<b.coverUntil){
  b.state=p.reload>0?'reload':'cover';if(distance(p,b.cover)>.45)moveAgent(game,p,b.cover,dt,p.blind>.8?1.8:3.0);
  if(enemy&&p.acquire<=0&&p.blind<.5)game.shoot(p,enemy);return;
 }
 if(!enemy&&p.ammo<Math.ceil(gun.mag*.3)&&p.reserve>0&&p.reload<=0){p.reload=gun.reload;b.state='reload';game.emit?.('reload',{weapon:p.weapon,owner:p.id,x:p.x,y:p.y,z:p.z});}
 if(enemy){
  b.state='engage';p.angle=angle(p,enemy);
  if(p.weapon==='knife')moveAgent(game,p,enemy,dt,4.3);
  if(p.acquire<=0&&p.blind<.5)game.shoot(p,enemy);
  if(game.tactics.version>=4&&b.burstPause>.12&&b.spray>=Math.max(1,gun.profile?.burst||1)&&game.elapsed-(b.lastPeek??-99)>2&&distance(p,enemy)>3){const cover=coverPoint(game,p,enemy,tools);if(distance(p,cover)>.7&&distance(p,cover)<5.8){b.cover=cover;b.coverUntil=game.elapsed+.75+b.experience*.006;b.lastPeek=game.elapsed;}}
  // Utility is coordinated across teammates and avoids nearby friendly HE damage.
  if(p.throwCD<=0&&game.elapsed-plan.lastUtilityAt>3){
   const near=distance(p,enemy),allies=game.players.filter(q=>q.team===p.team&&q.alive&&q.id!==p.id);
   const kind=p.hp<55&&p.grenades.smoke?'smoke':near<13&&p.grenades.he&&!allies.some(q=>sameFloor(q,enemy)&&distance(q,enemy)<4.8)?'he':near<14&&p.grenades.flash?'flash':p.grenades.fire&&near<12?'fire':null;
   if(kind&&game.utility(p.id,kind,enemy))plan.lastUtilityAt=game.elapsed;
  }
 }
 const bomb=game.bomb;
 if(bomb.state==='planted'){
  const d=distance(p,bomb),defuse=p.kit?5:10,travel=d/2.9*1.2;
  const save=p.side==='T'?bomb.timer<Math.max(8,Math.max(0,29-d)/3.5+2)&&d<29:game.tactics.version>=3?bomb.timer<defuseETA(game)+.65:bomb.timer<defuse+.65||(game.alive(p.team)<2&&bomb.timer<travel+defuse+1);
  if(save){b.state='save';b.escape??=escapePoint(game,p);moveAgent(game,p,b.escape,dt,3.5);return;}
  if(p.side==='CT'){
   const defuser=game.tactics.version>=3?teamDefuser(game):p;
   if(defuser?.id!==p.id&&!enemy){b.state='retake';if(!b.postPlant)b.postPlant=spreadPosition(game,bomb,p,game.players.filter(q=>q.id!==p.id&&q.alive&&q.team===p.team).map(q=>q.brain.postPlant||q),tools,6);if(distance(p,b.postPlant)>.6)moveAgent(game,p,b.postPlant,dt,2.8);else p.angle=angle(p,threat||game.map.spawns[0]);return;}
   if(d<1.6&&sameFloor(p,bomb)&&!enemy&&p.blind<.5){
    b.state='defuse';if(bomb.actor===null||bomb.actor===p.id){if(bomb.actor===null){bomb.actor=p.id;bomb.progress=0;}bomb.progress+=dt;if(bomb.progress>=defuse){bomb.state='defused';game.emit?.('defuse',{x:p.x,y:p.y,z:p.z,owner:p.id});p.money=Math.min(16000,p.money+300);game.endRound(p.team,'C4 zararsizlantirildi');}}return;
   }
   if(enemy)return;b.state='retake';
   const friends=game.players.filter(q=>q.id!==p.id&&q.team===p.team&&q.alive);
   if(d<9&&bomb.timer>16&&friends.length&&friends.every(q=>distance(p,q)>7)){
    if(b.rallyUntil===0)b.rallyUntil=game.elapsed+2.5;
    if(game.elapsed<b.rallyUntil){p.angle=angle(p,bomb);return;}b.rallyUntil=-1;
   }
   moveAgent(game,p,bomb,dt,2.8);return;
  }
  if(enemy)return;b.state='postplant';b.postPlant??=game.tactics.version>=3?spreadPosition(game,bomb,p,game.players.filter(q=>q.id!==p.id&&q.alive&&q.team===p.team).map(q=>q.brain.postPlant||q),tools,7):formation(game,bomb,p.id%5);
  if(distance(p,b.postPlant)>.6)moveAgent(game,p,b.postPlant,dt,2.4);else if(threat)p.angle=angle(p,threat);return;
 }
 if(enemy)return;
 if(p.side==='T'&&bomb.state==='dropped'){
  const nearest=game.players.filter(q=>q.side==='T'&&q.alive).sort((a,c)=>distance(a,bomb)-distance(c,bomb))[0];
  if(nearest===p){if(distance(p,bomb)<1.6&&sameFloor(p,bomb)){bomb.state='carried';bomb.carrier=p.id;}else{b.state='execute';moveAgent(game,p,bomb,dt,2.9);return;}}
 }
 const site=game.map.sites[plan.site];
 if(p.side==='T'){
  if(bomb.carrier===p.id&&distance(p,site)<2&&sameFloor(p,site)){
   b.state='plant';p.plant+=dt;bomb.progress=p.plant;bomb.x=p.x;bomb.z=p.z;bomb.y=p.y;bomb.actor=p.id;
   if(p.plant>=3.2){bomb.state='planted';bomb.carrier=null;p.plant=0;p.money=Math.min(16000,p.money+300);bomb.timer=40;bomb.progress=0;bomb.actor=null;game.note(`C4 qo‘yildi · ${site.label}`);game.emit?.('plant',{x:p.x,y:p.y,z:p.z,owner:p.id});}return;
  }
  p.plant=0;
  if(game.map.original22&&followArchitectureRoute(game,p,plan,dt))return;
  if(b.routeVia&&!b.viaCleared&&distance(p,b.routeVia)<1.5)b.viaCleared=true;
  const execute=game.elapsed>=plan.executeAt+(game.tactics.version>=3?b.entryDelay:0)||game.clock<35||game.alive(p.team)<3;
  b.state=execute?'execute':'control';let goal=execute?(bomb.carrier===p.id?site:b.anchor):b.staging;if(execute&&b.routeVia&&!b.viaCleared)goal=b.routeVia;
  if(distance(p,goal)>.5)moveAgent(game,p,goal,dt,p.blind>0?1.7:p.weapon==='awp'?2.6:2.9);
  else p.angle=angle(p,threat||site)+(threat?0:Math.sin(game.elapsed*.55+p.id)*.18);
  if(execute&&p.throwCD<=0&&p.grenades.flash&&game.elapsed-plan.lastUtilityAt>3&&distance(p,site)<13&&(p.id%5===4||p.id%5===0))if(game.utility(p.id,'flash',threat||site))plan.lastUtilityAt=game.elapsed;
 }else{
  const rotate=teamContact&&(p.id%5===3||game.alive(p.team)<3||(game.tactics.version>=3&&roleOf(p)==='captain'&&plan.sightings.filter(r=>game.elapsed-r.at<4).length>=3))&&distance(teamContact,b.anchor)>7;
  if(!rotate&&game.map.original22&&followArchitectureRoute(game,p,plan,dt))return;const goal=rotate?teamContact:b.anchor;b.state=rotate?'rotate':'anchor';
  if(distance(p,goal)>.7)moveAgent(game,p,goal,dt,rotate?3:2.7);
  else p.angle=angle(p,threat||game.map.staging||game.map.spawns[0])+(threat?0:Math.sin(game.elapsed*.45+p.id)*.2);
 }
}

function followArchitectureRoute(game,p,plan,dt){const b=p.brain;if(!b.archWaypoints)return false;while(b.archIndex<b.archWaypoints.length&&distance(p,b.archWaypoints[b.archIndex])<1.35&&Math.abs((p.y||0)-b.archWaypoints[b.archIndex].y)<.4)b.archIndex++;const next=b.archWaypoints[b.archIndex];if(!next)return false;if(p.side==='T'&&b.archIndex>=2&&game.elapsed<plan.executeAt+b.entryDelay&&game.clock>35){b.state='control';p.angle=angle(p,next);return true;}b.state=p.side==='T'?'execute':'anchor';moveAgent(game,p,next,dt,p.weapon==='awp'?2.6:2.9);return true;}
function agentTimers(p,dt,weapons){const b=p.brain,gun=weapons[p.weapon];p.moving=false;p.cooldown=Math.max(0,p.cooldown-dt);p.blind=Math.max(0,p.blind-dt);p.throwCD-=dt;b.think-=dt;b.burstPause=Math.max(0,b.burstPause-dt);if(p.reload>0){p.reload-=dt;if(p.reload<=0){const n=Math.min(gun.mag-p.ammo,p.reserve);p.ammo+=n;p.reserve-=n;}}}
function moveAgent(game,p,goal,dt,speed=3.1){game.move(p,goal,dt,speed,true);}
export function tacticalAI(game,p,dt,tools){
 if(game.tactics?.version>=3&&grenadeHazard(game,p,tools)){agentTimers(p,dt,tools.WEAPONS);p.brain.state='evade';moveAgent(game,p,p.brain.evade,dt,3.5);return;}
 if(game.tactics?.version>=4){checkMotion(game,p,tools);if(p.brain.yieldPoint&&p.brain.yieldUntil>game.elapsed){agentTimers(p,dt,tools.WEAPONS);p.brain.state='spacing';if(distance(p,p.brain.yieldPoint)>.2)moveAgent(game,p,p.brain.yieldPoint,dt,2.5);return;}if(p.targetId===null)advanceControl(game,p,game.tactics.teams[p.team],tools);}
 tacticalAIBase(game,p,dt,tools);
}
