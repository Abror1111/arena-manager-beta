import {smokeColor} from './team-colors.js';
import {createSmokeVolumes} from './volume-smoke.js';
import * as T from 'three';

import {atlas,spriteFrame} from './vfx-sprites.js';
import {VFX_BUDGETS,randomAt,effectSeed,fireFootprint,fireEnvelope,blastHoleRadius} from './effect-model.js';
import {mapProps} from './map-prop-physics.js';
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const vertex=`attribute vec3 center;attribute vec4 shape;attribute vec4 tint;attribute float frame;attribute float facing;
uniform vec3 cameraRight;uniform vec3 cameraUp;uniform bool ground;
varying vec2 vUv;varying vec4 vTint;varying float vFrame;varying float vPhase;varying vec3 vWorld;
void main(){vUv=uv;vTint=tint;vFrame=frame;vPhase=shape.w;vec2 p=position.xy;float c=cos(shape.z),s=sin(shape.z);p=mat2(c,-s,s,c)*p;p*=shape.xy;
vec3 world=center+((ground||facing>.5)?vec3(p.x,0.,p.y):cameraRight*p.x+cameraUp*p.y);vWorld=world;gl_Position=projectionMatrix*viewMatrix*vec4(world,1.);}`;
const fragment=`uniform int kind;uniform bool atlasEnabled;uniform sampler2D flameMap;uniform float clock;uniform vec4 holes[4];uniform int holeCount;
varying vec2 vUv;varying vec4 vTint;varying float vFrame;varying float vPhase;varying vec3 vWorld;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){return noise(p)*.57+noise(p*2.07+13.1)*.29+noise(p*4.13+7.7)*.14;}
void main(){vec2 q=vUv*2.-1.;float r=length(q);vec3 color=vTint.rgb;float alpha=vTint.a;
if(vFrame>=0.&&atlasEnabled){float f=floor(vFrame);vec2 cell=vec2(mod(f,${atlas.columns}.),${atlas.rows-1}.-floor(f/${atlas.columns}.));vec2 uv=(cell*${atlas.cell}.+${atlas.padding}.+vUv*${atlas.cell-2*atlas.padding}.)/${atlas.width}.;vec4 pixel=texture2D(flameMap,uv);color*=pixel.rgb;alpha*=pixel.a;
}else if(kind==0){float n=fbm(q*3.2+vec2(vPhase+clock*.055,clock*.09));float edge=1.-smoothstep(.48,.99,r+(n-.5)*.28);float body=sqrt(max(0.,1.-dot(q,q)));float light=.55+body*.24+q.y*.16+(n-.5)*.2;color*=light;alpha*=edge*(.68+body*.32);
 for(int i=0;i<4;i++){if(i>=holeCount)break;float d=distance(vWorld,holes[i].xyz);alpha*=smoothstep(holes[i].w*.6,holes[i].w,d);}
}else if(kind==1){vec4 pixel=texture2D(flameMap,vUv);color*=pixel.rgb;alpha*=clamp(max(pixel.r,max(pixel.g,pixel.b))*5.,0.,1.);
}else if(kind==2){float core=exp(-r*r*28.),halo=exp(-r*r*5.)*.24;color*=core+halo;alpha*=1.-smoothstep(.6,1.,r);
}else if(kind==3){float n=fbm(q*5.+vPhase);alpha*=(1.-smoothstep(.55,1.,r+(n-.5)*.25))*(.45+n*.55);
}else{alpha*=exp(-dot(q,q)*7.);}
if(alpha<.003)discard;gl_FragColor=vec4(color,alpha);
#include <colorspace_fragment>
}`;
function batch(scene,capacity,kind,ground=false){
 const plane=new T.PlaneGeometry(1,1),geometry=new T.InstancedBufferGeometry();geometry.index=plane.index;geometry.attributes.position=plane.attributes.position;geometry.attributes.uv=plane.attributes.uv;
 const fields={center:3,shape:4,tint:4,frame:1,facing:1},attributes={};for(const [name,size]of Object.entries(fields)){const a=new T.InstancedBufferAttribute(new Float32Array(capacity*size),size).setUsage(T.DynamicDrawUsage);geometry.setAttribute(name,a);attributes[name]=a;}
 const uniforms={atlasEnabled:{value:false},kind:{value:kind},ground:{value:ground},cameraRight:{value:new T.Vector3(1,0,0)},cameraUp:{value:new T.Vector3(0,1,0)},flameMap:{value:null},clock:{value:0},holes:{value:Array.from({length:4},()=>new T.Vector4())},holeCount:{value:0}};
 const material=new T.ShaderMaterial({uniforms,vertexShader:vertex,fragmentShader:fragment,transparent:true,depthWrite:false,depthTest:true,blending:[2,4].includes(kind)?T.AdditiveBlending:T.NormalBlending,toneMapped:false,side:T.DoubleSide});
 const mesh=new T.Mesh(geometry,material);mesh.frustumCulled=false;mesh.renderOrder=kind===0?6:kind===3?1:kind===1?3:4;scene.add(mesh);let count=0;const color=new T.Color();
 return{uniforms,reset(){count=0;},add(x,y,z,w,h,rotation,hex,opacity,phase=0,frame=-1,facing=ground?1:0){if(count>=capacity||opacity<=.002)return;const i=count++;color.set(hex);attributes.center.setXYZ(i,x,y,z);attributes.shape.setXYZW(i,w,h,rotation,phase);attributes.tint.setXYZW(i,color.r,color.g,color.b,clamp(opacity));attributes.frame.setX(i,frame);attributes.facing.setX(i,facing);},flush(camera,time){geometry.instanceCount=count;mesh.visible=count>0;for(const a of Object.values(attributes))a.needsUpdate=true;uniforms.cameraRight.value.setFromMatrixColumn(camera.matrixWorld,0);uniforms.cameraUp.value.setFromMatrixColumn(camera.matrixWorld,1);uniforms.clock.value=time;},get count(){return count;},dispose(){mesh.removeFromParent();geometry.dispose();material.dispose();}};
}
export function createParticleVFX(scene,{mobile,reducedMotion,fallbackFlame}){
 const limits=VFX_BUDGETS[mobile?'mobile':'desktop'],smoke=batch(scene,limits.smoke,0),flames=batch(scene,limits.flame,1),glow=batch(scene,limits.glow,2),scorch=batch(scene,limits.scorch,3,true),embers=batch(scene,limits.sparks,4),batches=[smoke,flames,glow,scorch,embers];
 const volumes=createSmokeVolumes(scene,mobile);
 const controller=new AbortController();let ready=false,sourceName='generated-fallback',disposed=false,sourceTexture=null;
 // Fallback is a single frame. It is used only if the verified source PNG fails.
 flames.uniforms.flameMap.value=fallbackFlame;
 const promise=Promise.resolve();ready=true;sourceName='arena-original-procedural';
 // Two bounded local lights; no extra shadow maps or render passes on phones.
 const blastLight=new T.PointLight('#ffd4a0',0,11,2),fireLight=new T.PointLight('#ff9c48',0,6,2);if(!mobile)scene.add(blastLight,fireLight);
 const screenGeo=new T.PlaneGeometry(2,2),screenMaterial=new T.ShaderMaterial({uniforms:{strength:{value:0}},vertexShader:'void main(){gl_Position=vec4(position.xy,0.,1.);}',fragmentShader:'uniform float strength;void main(){gl_FragColor=vec4(1.,.99,.94,strength);}',transparent:true,depthTest:false,depthWrite:false,toneMapped:false});
 const screen=new T.Mesh(screenGeo,screenMaterial);screen.frustumCulled=false;screen.renderOrder=100;scene.add(screen);
 function flame(x,y,z,w,h,age,opacity,seed){flames.add(x,y+h*.42,z,w,h,Math.sin(age*7+seed)*.04,'#ffffff',opacity,seed,spriteFrame('flame',age,seed));}
 function cloud(x,y,z,size,opacity,color,seed,age=0,role='dust'){smoke.add(x,y,z,size,size*.86,seed*.7,color,opacity,seed*17,spriteFrame(role,age,seed));}
 function flare(x,y,z,w,h,color,opacity,seed,role='flare',ground=false){glow.add(x,y,z,w,h,0,color,opacity,seed,spriteFrame(role,0,seed),ground?1:0);}
 return{promise,get ready(){return ready;},get source(){return sourceName;},get count(){return volumes.count+batches.reduce((n,b)=>n+b.count,0);},get drawCalls(){return volumes.drawCalls+batches.filter(b=>b.count>0).length;},get limits(){return limits;},
  update(game,camera,time,clipHeight=1000){
   batches.forEach(b=>b.reset());volumes.reset();blastLight.intensity=fireLight.intensity=0;screenMaterial.uniforms.strength.value=0;
   const cx=(game.map.width||60)/2,cz=(game.map.height||40)/2,activeFire=game.effects.filter(e=>e.kind==='fire'&&!e.extinguished),perGround=Math.max(2,Math.floor((limits.glow-8)/Math.max(1,activeFire.length))),perFire=Math.max(6,Math.floor((limits.flame-24)/Math.max(1,activeFire.length)/2)),holes=game.effects.filter(e=>blastHoleRadius(e)>0).sort((a,b)=>a.age-b.age).slice(0,4);
   smoke.uniforms.holeCount.value=holes.length;holes.forEach((e,i)=>smoke.uniforms.holes.value[i].set(e.x-cx,(e.y||0)+.7,e.z-cz,blastHoleRadius(e)));
   for(const e of game.effects){const x=e.x-cx,z=e.z-cz,y=e.y||0,age=e.age,seed=effectSeed(e);if(y>clipHeight+.1)continue;
    if(e.kind==='fire'||e.kind==='scorch'){
     const cells=fireFootprint(game.map,e),groundStride=Math.max(1,Math.ceil(cells.length/perGround)),stride=Math.max(1,Math.ceil(cells.length/perFire));
     for(let i=0;i<cells.length;i++){const c=cells[i],px=c.x-cx,pz=c.z-cz;
      if(e.kind==='scorch'){scorch.add(px,c.y+.016,pz,c.r*2.3,c.r*1.9,randomAt(seed,i)*6.28,'#251e18',clamp(age*1.4)*clamp((e.life-age)/4)*.65,seed+i,spriteFrame('scorch'));continue;}
      const fade=fireEnvelope(e,c.delay),v=randomAt(seed,i+8);if(i%groundStride===0)glow.add(px,c.y+.03,pz,c.r*2.3,c.r*2.3,v*6.28,'#ffffff',fade*.8,seed+i,spriteFrame('groundFire',age,seed+i),1);
      if(i%stride===0){const h=.85+v*.45+Math.sin(age*9+i)*.07;flame(px-.1,c.y,pz,.7+v*.2,h,age,fade*.96,seed+i*.73);flame(px+.12,c.y,pz+.09,.5+v*.2,h*.75,age,fade*.65,seed+i*.73+8);if(i%5===0&&!reducedMotion){const t=(age*.7+v)%1;embers.add(px+Math.sin(t*6+i)*.12,c.y+t*1.3,pz,.025,.07,0,'#ffb45e',(1-t)*fade*.7,seed+i);}if(i%3===0&&fade>.1)cloud(px,c.y+1+age*.07,pz,.9,fade*.3,'#62635c',seed+i,age,'smoke');}
     }
     if(e.kind==='fire'&&fireEnvelope(e)>.1&&fireLight.intensity===0){fireLight.position.set(x,y+.65,z);fireLight.intensity=6*fireEnvelope(e);}
    }else if(e.kind==='smoke'){
     const growth=.08+.92*clamp(age/1.1),fade=clamp(age/.35)*clamp((e.life-age)/3);volumes.add(x,y,z,growth,fade,seed,smokeColor(game,e));
    }else if(['he','c4'].includes(e.kind)){
     const c4=e.kind==='c4',power=c4?1.85:1,flash=clamp(1-age/.13),dust=clamp((age-.035)/.22)*clamp((e.life-age)/.65);
     if(flash>0){flare(x,y+.55,z,4*power,3.2*power,'#fff2cd',flash,seed);if(age<.075)flare(x,y+.65,z,1.8*power,1.6*power,'#ffffff',flash,seed,'flash');blastLight.position.set(x,y+1,z);blastLight.intensity=Math.max(blastLight.intensity,flash*(c4?45:20));}
     if(age<.68){const progress=age/.68,fade=clamp(age/.035)*clamp((.68-age)/.16),size=(1.5+age*3.7)*power;(atlas.sprites.blast.blend==='add'?glow:flames).add(x,y+.3+size*.28,z,size,size*.82,seed*.2,'#ffb963',fade,seed,spriteFrame('blast',age,seed,progress));}
     for(let i=0;i<(c4?9:6);i++){const a=i*2.39996+seed,r=(.3+age*1.7)*power;cloud(x+Math.cos(a)*r,y+.3+age*(i%2?.7:1),z+Math.sin(a)*r,(1.2+age*1.1)*power,dust*(i%2?.56:.46),i%2?'#b2aa98':'#b6a38c',seed+i*.31,age,i%2?'smoke':'dust');}
     if(age<.8&&!reducedMotion)for(let i=0;i<(c4?22:12);i++){const a=randomAt(seed,i)*Math.PI*2,speed=(1.3+randomAt(seed,i+40)*3.2)*power,r=age*speed,py=y+.35+age*(2+randomAt(seed,i+70)*3)-age*age*4;if(py<y)continue;embers.add(x+Math.cos(a)*r,py,z+Math.sin(a)*r,.04,.1+age*.06,a,'#ffe6ad',clamp(1-age/.8),seed+i);}
    }else if(e.kind==='flash'){
     const fade=clamp(1-age/.25);if(fade>0){flare(x,y+.75,z,5.3*fade,5.3*fade,'#ffd7c5',fade,seed,'flash');flare(x,y+.8,z,1.6,1.6,'#ffffff',fade,seed,'flare');const view=new T.Vector3(x,y+.75,z).project(camera);if(!reducedMotion&&Math.abs(view.x)<1&&Math.abs(view.y)<1&&Math.abs(view.z)<1)screenMaterial.uniforms.strength.value=Math.max(screenMaterial.uniforms.strength.value,fade*.12);blastLight.position.set(x,y+.8,z);blastLight.intensity=Math.max(blastLight.intensity,fade*30);}
    }else if(e.kind==='grenade'&&e.type==='fire'){
     const t=age/e.life,py=y+1.1*(game.map.playerScale||1)+((e.ty??y)-y)*t+Math.sin(t*Math.PI)*(1.8+Math.hypot(e.tx-e.sx,e.tz-e.sz)*.06);if(game.players[e.owner]?.side!=='CT')flame(e.sx+(e.tx-e.sx)*t-cx,py+.15,e.sz+(e.tz-e.sz)*t-cz,.18,.28,age,.8,seed);
    }
   }
   for(const [id,state]of Object.entries(game.propStates||{})){if(state.heat<.1||state.y>clipHeight+.1)continue;const p=mapProps(game.map)[Number(id)];if(!p)continue;const fade=clamp(state.heat),x=state.x-cx,z=state.z-cz;cloud(x,state.y+p.size[1]*.5+.4,z,.8,fade*.35,'#77786e',Number(id),state.age,'smoke');if(state.heat>1)flame(x,state.y,z,.24,.7,state.age,fade,Number(id));}
   batches.forEach(b=>b.flush(camera,time));volumes.flush(camera,smoke.uniforms.holes.value.slice(0,holes.length),time);screen.visible=screenMaterial.uniforms.strength.value>.002;
  },
  dispose(){disposed=true;controller.abort();batches.forEach(b=>b.dispose());volumes.dispose();for(const l of[blastLight,fireLight])l.removeFromParent();screen.removeFromParent();screenGeo.dispose();screenMaterial.dispose();if(sourceTexture){sourceTexture.source.data.close?.();sourceTexture.dispose();}}
 };
}
