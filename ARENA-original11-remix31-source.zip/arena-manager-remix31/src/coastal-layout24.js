import{stairGuards29}from'./stair-guards29.js';
import{verticalSolid29,frameProfiles29}from'./vertical-solids29.js';
import{CHOKE_WALLS26,DOORS26,leafSegments26,segmentSolid26}from'./chokepoints26.js';import{BRIDGE26,groundFloor26}from'./route-levels26.js';
import{terrainHeight25}from'./coastal-elevation25.js';
import{ShapeUtils,Vector2}from'three';
// Hand-authored plan guided by the reference radar's landmark arrangement.
// Plan coordinates are percentages; rendering and physics share these outlines.
export const WIDTH=120,DEPTH=120,SCALE=1.2;
export const toWorld=([x,z])=>({x:(x-50)*SCALE,z:(z-50)*SCALE});
export const toGame=([x,z])=>({x:x*SCALE,z:z*SCALE});
export const OUTLINE=[[8,2],[13,2],[13,8],[21,8],[25,11],[31,11],[31,15],[47,15],[47,20],[55,20],[56,15],[60,15],[60,10],[77,10],[77,3],[90,3],[90,10],[91,10],[91,21],[95,21],[95,31],[92,33],[91,46],[95,48],[95,67],[83,67],[83,55],[75,55],[75,67],[72,68],[72,82],[66,82],[66,94],[59,94],[59,98],[47,98],[47,96],[15,96],[15,95],[5,95],[5,86],[9,82],[9,58],[16,56],[16,50],[13,50],[13,49],[6,49],[6,40],[9,40],[9,32],[6,32],[6,18],[8,17]];
export const DISTRICTS=[
 {id:'west-upper',h:8.4,style:4,color:'sand',p:[[1,2],[7.2,2],[7.2,17],[5.2,18],[5.2,32],[1,32]]},
 {id:'b-back',h:8,style:0,color:'sand',p:[[14,1],[29,1],[29,10],[25,10],[21,7],[14,7]]},
 {id:'b-courtyard-flank',h:6.2,style:1,color:'cream',p:[[27,1],[47,1],[47,14],[32,14],[32,10],[27,10]]},
 {id:'north-mid',h:7.6,style:0,color:'sand',p:[[48,1],[59,1],[59,14],[55,14],[54,19],[48,19]]},
 {id:'a-back',h:7.4,style:1,color:'cream',p:[[61,1],[76,1],[76,9],[61,9]]},
 {id:'a-east',h:9.2,style:0,color:'cream',p:[[92,2],[99,2],[99,46],[92,45],[93,34],[96,32],[96,20],[92,20]]},
 {id:'b-tunnel-mid-block',h:7.2,style:0,color:'sand',p:[[25,27],[37,27],[37,35],[25,35],[23,38],[20,38],[20,35],[16,35],[16,29],[21,29]]},
 {id:'upper-to-lower-tunnel',h:8.2,style:1,color:'sand',p:[[21,51],[27,51],[33,48],[33,44],[42,44],[42,53],[37,53],[37,61],[38,68],[42,69],[42,85],[35,85],[35,74],[30,74],[29,76],[25,76],[24,73],[21,73]]},
 {id:'t-spawn-island',h:6.5,style:0,color:'cream',p:[[49,68],[55,68],[56,70],[56,80],[55,81],[49,81],[48,79],[48,70]]},
 {id:'mid-short-block',h:5.4,style:3,color:'sand',p:[[50,29],[59,29],[59,35],[51,35],[51,37],[50,37]]},
 {id:'long-short-quarter',h:8.6,style:1,color:'cream',p:[[67,29],[80,29],[80,43],[73,43],[67,47],[67,63],[55,63],[54,60],[54,47],[63,44],[67,41]]},
 {id:'long-door-house',h:6.4,style:3,color:'sand',p:[[77,57],[82,57],[82,68],[77,68],[77,63],[75.7,61],[75.7,58]]},
 {id:'west-tunnel-outside',h:6.6,style:0,color:'cream',p:[[1,41],[5,41],[5,50],[12,50],[12,51],[15,51],[15,55],[8,57],[8,81],[4,85],[1,85]]},
 {id:'south-tunnel-flank',h:7.7,style:4,color:'sand',p:[[1,96],[14,96],[14,97],[46,97],[46,99],[1,99]]},
 {id:'south-east-quarter',h:7.8,style:0,color:'cream',p:[[73,69],[82,69],[82,68],[99,68],[99,99],[60,99],[60,95],[67,95],[67,83],[73,83]]}
];
export const SITES=[{label:'A',p:[84,18.5]},{label:'B',p:[17.5,17.5]}];
export const SPAWNS=[[43,90],[54,24]];
export const ROUTES=[
{id:'A LONG',p:[[43,90],[56,90],[63,85],[67,78],[69.2,70],[69.2,67],[69.2,61],[73,55],[73,52],[86,52],[86,44],[86,30],[85,27],[84,18.5]]},
{id:'A SHORT',p:[[43,90],[46,84],[47,70],[47,55],[47,46],[47,42],[51,42],[56,41],[63,39],[63,33],[63,31,6.1],[63,24,6.1],[63,20,6.1],[72,20,6.1],[78,21,6.1],[84,18.5]]},
{id:'B TUNNEL',p:[[43,90],[30,90],[22,84],[18,77],[15,70],[15,61],[17,54],[14,47],[11,44],[11,35],[17,26],[17.5,17.5]]},
{id:'B MID',p:[[43,90],[46,84],[47,70],[47,50],[47,42],[46.8,34],[45,30],[39,25],[31,25],[26,25],[22,25],[17.5,17.5]]},
{id:'CT A',p:[[54,24],[58,26],[61,27],[68,27],[76,27],[83.5,27],[85,27],[85,23],[84,18.5]]},
{id:'CT B',p:[[54,24],[48,25],[40,25],[31,25],[26,25],[22,25],[17.5,17.5]]},
{id:'LOWER LINK',p:[[19,43],[25,43],[29,42],[33,41],[40.5,41],[41,37],[41,32],[46.8,32]]}
];
export const INTERIORS=[{id:'upper-b',p:[[9.5,60],[24,60],[26,70],[24,73],[9.5,73]],h:7.2},{id:'upper-b-exit',p:[[7,41],[17,41],[17,48],[7,48]],h:7.3},{id:'lower-b',p:[[30,39],[43,39],[43,43.5],[30,43.5]],h:4.3},{id:'lower-return',p:[[39.2,32],[42.8,32],[42.8,39],[39.2,39]],h:4.3},{id:'long-house',p:[[65.8,67],[65.8,59],[69.6,55],[76.3,55],[76.3,67]],h:8.1}];
export const LANDMARK_WALLS=[[12.5,10,24,10,2.8],[12.5,10,12.5,22,2.8],[78,12,89,12,1],[89,12,89,22,1]];
export const COVERS_PLAN=[[21,15,1.4],[24,19,1.3],[15,28,1.2],[82,15,1.6],[80,23,1.3],[87,21,1.1],[89,33,1.7],[87,50,1.3],[68,73,1.7],[12,45,1],[31,94,1.4],[49,31,1]];
export const PALMS_PLAN=[[2,31,7],[3,52,8],[3,78,7],[12,99,8],[35,100,7],[57,100,8],[99,45,8],[98,72,7],[87,7,7],[12,13,6]];
export const coastalHeight24=terrainHeight25;
export function insidePlan(p,poly=OUTLINE){let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside}return inside}
function collider(p,y,h,id){const pts=p.map(toWorld),minX=Math.min(...pts.map(v=>v.x)),maxX=Math.max(...pts.map(v=>v.x)),minZ=Math.min(...pts.map(v=>v.z)),maxZ=Math.max(...pts.map(v=>v.z)),x=(minX+maxX)/2,z=(minZ+maxZ)/2;let polygon=pts.map(p=>({x:p.x-x,z:p.z-z}));const area=polygon.reduce((s,a,i)=>{const b=polygon[(i+1)%polygon.length];return s+a.x*b.z-b.x*a.z},0);if(area<0)polygon.reverse();return{x,z,w:maxX-minX,d:maxZ-minZ,y,h,id,polygon}}
export function coastalSolids24(){const rows=[];const triangulate=(p,y,h,id)=>{const v=p.map(([x,z])=>new Vector2(x,z));for(const tri of ShapeUtils.triangulateShape(v,[]))rows.push(collider(tri.map(i=>p[i]),y,h,id))};
 const outer=[[0,0],[100,0],[100,100],[0,100]],vertices=[...outer,...OUTLINE],tris=ShapeUtils.triangulateShape(outer.map(p=>new Vector2(...p)),[OUTLINE.map(p=>new Vector2(...p))]);for(const tri of tris)rows.push(collider(tri.map(i=>vertices[i]),-1.5,14,'boundary'));
 for(const d of DISTRICTS){const base=Math.min(...d.p.map(p=>{const w=toWorld(p);return coastalHeight24(w.x,w.z)}));triangulate(d.p,base-.2,d.h+Math.max(...d.p.map(p=>{const q=toWorld(p);return coastalHeight24(q.x,q.z)}))-base,d.id)}
 for(const[ax,az,bx,bz,h]of LANDMARK_WALLS){const a=toWorld([ax,az]),b=toWorld([bx,bz]),x=(a.x+b.x)/2,z=(a.z+b.z)/2;rows.push({x,z,w:Math.max(.32,Math.abs(b.x-a.x)),d:Math.max(.32,Math.abs(b.z-a.z)),y:coastalHeight24(x,z),h,id:'landmark-wall'})}
 for(const [propId29,[x,z,w]]of COVERS_PLAN.entries()){const q=toWorld([x,z]);rows.push({...q,w:w*SCALE,d:w*SCALE,y:coastalHeight24(q.x,q.z),h:w*SCALE,id:'cover',propId29})}for(const px of[61,66])for(const pz of[23,30]){const q=toWorld([px,pz]);rows.push({...q,w:.28,d:.28,y:groundFloor26(q.x,q.z),h:6.1-.35-groundFloor26(q.x,q.z),id:'bridge-column'})}
 rows.push(...stairGuards29().solids);for(const r of [...CHOKE_WALLS26,...DOORS26.flatMap(leafSegments26)])rows.push(segmentSolid26(r,groundFloor26));return rows}
export function roofSolids24(){const arches=DOORS26.flatMap(d=>{const a=toWorld(d.p),b={x:a.x+Math.cos(d.yaw),z:a.z-Math.sin(d.yaw)},base=groundFloor26(a.x,a.z);return frameProfiles29(d).map((profile,i)=>verticalSolid29(a,b,profile,base,.32,d.id+'-frame-'+i))});const copings=DISTRICTS.flatMap(d=>{const heights=d.p.map(p=>{const q=toWorld(p);return coastalHeight24(q.x,q.z)}),top=Math.max(...heights)+d.h-.2;return d.p.map((a,i)=>{const b=d.p[(i+1)%d.p.length];return segmentSolid26({id:d.id+'-coping-'+i,a,b,h:.48,width:.3},()=>top)})});return [...arches,...copings,...BRIDGE26.map(r=>({x:((r.x0+r.x1)/2-50)*SCALE,z:((r.z0+r.z1)/2-50)*SCALE,w:(r.x1-r.x0)*SCALE,d:(r.z1-r.z0)*SCALE,y:r.y-.25,h:.25,id:'short-bridge'})),...INTERIORS.flatMap(d=>{const v=d.p.map(p=>new Vector2(...p));return ShapeUtils.triangulateShape(v,[]).map(tri=>{const row=collider(tri.map(i=>d.p[i]),d.h,.2,d.id);return row})})]}
