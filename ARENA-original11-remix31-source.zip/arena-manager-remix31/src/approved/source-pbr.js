import * as T from 'three';
import {loadAsset}from'./asset-cache.js';
import manifest from './pbr128-manifest.json'with{type:'json'};
// Genuine normal/roughness recordings restored from supplied exports; only
// bounded runtime copies are loaded. No source model, UV or archive is edited.
export async function enhanceSourcePBR(root,map,renderer,signal){
 const records=manifest.maps[map.id]||[],byName=new Map(),textures=[],bitmaps=new Set(),bindings=[];root.traverse(o=>{if(!o.isMesh||!o.visible)return;for(const m of Array.isArray(o.material)?o.material:[o.material]){if(!m.map||m.transparent)continue;if(!byName.has(m.map.name))byName.set(m.map.name,new Set());byName.get(m.map.name).add(m);}});
 const images=new Map();let bytes=0,disposed=false;
 async function image(entry){if(!images.has(entry.url))images.set(entry.url,(async()=>{const {bytes}=await loadAsset(entry,{signal});const blob=new Blob([bytes],{type:'image/webp'});if(typeof createImageBitmap==='function'){const b=await createImageBitmap(blob,{premultiplyAlpha:'none',colorSpaceConversion:'none'});bitmaps.add(b);return b;}const url=URL.createObjectURL(blob);try{return await new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=reject;i.src=url;});}finally{URL.revokeObjectURL(url);}})());return images.get(entry.url);}
 async function texture(entry,source,color){const im=await image(entry);if(disposed||signal.aborted){im.close?.();throw new DOMException('Aborted','AbortError');}const t=new T.Texture(im);t.name=color?source.name:entry.sourceImage;t.colorSpace=color?T.SRGBColorSpace:T.NoColorSpace;t.flipY=false;t.wrapS=source.wrapS;t.wrapT=source.wrapT;t.repeat.copy(source.repeat);t.offset.copy(source.offset);t.rotation=source.rotation;t.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());t.needsUpdate=true;textures.push(t);bytes+=im.width*im.height*4;return t;}
 function dispose(){disposed=true;textures.forEach(t=>t.dispose());bitmaps.forEach(b=>b.close?.());}
 try{for(const record of records){const mats=byName.get(record.texture);if(!mats?.size)continue;const source=[...mats][0].map,entries=record.textures;
  // Source alpha-tested paving/foliage keeps its original color AND coverage.
  // Its genuine normal and roughness recordings can still be restored safely.
  const opaque=[...mats].some(m=>!m.alphaTest);
  const [base,normal,roughness]=await Promise.all([opaque&&entries.baseColor?texture(entries.baseColor,source,true):null,entries.normal?texture(entries.normal,source,false):null,entries.roughness?texture(entries.roughness,source,false):null]);if(signal.aborted){dispose();return{maps:0,bytes:0,bindings:[],dispose(){}};}for(const m of mats){if(base&&!m.alphaTest)m.map=base;if(normal){m.normalMap=normal;m.normalScale.set(.65,.65);}if(roughness){m.roughnessMap=roughness;m.roughness=.92;}m.needsUpdate=true;}bindings.push(record.texture);}
 }catch(error){dispose();throw error;}
 return{maps:bindings.length,bytes,bindings,dispose};
}
