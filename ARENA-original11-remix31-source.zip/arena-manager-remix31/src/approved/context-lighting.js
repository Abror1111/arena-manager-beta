import * as T from 'three';
// A fixed 45-unit shadow camera missed the new exterior collar. Fit the
// existing sun to the measured city/scenery bounds without changing its angle
// or intensity. Dust II retains its accepted lighting and source sun setup.
export function fitContextSun(sun,frame){
 if(!frame)return null;const center=new T.Vector3(...frame.min).add(new T.Vector3(...frame.max)).multiplyScalar(.5),radius=Math.max(36,new T.Vector3(...frame.max).sub(new T.Vector3(...frame.min)).length()/2+6),direction=sun.position.clone().sub(sun.target.position).normalize(),distance=radius*2+40;
 sun.target.position.copy(center);sun.position.copy(center).addScaledVector(direction,distance);const c=sun.shadow.camera;c.left=c.bottom=-radius;c.right=c.top=radius;c.near=Math.max(.1,distance-radius-12);c.far=distance+radius+12;c.updateProjectionMatrix();return{radius,distance};
}
