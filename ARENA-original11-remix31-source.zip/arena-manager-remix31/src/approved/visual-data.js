import {loadAsset} from './asset-cache.js';
export async function loadVisualData(map,signal,onProgress){
 if(!map.hdProfile){const {bytes}=await loadAsset(map.visual,{signal,onProgress});return bytes;}
 const asset=map.hdProfile.asset,chunks=[];let completed=0;
 for(const part of asset.parts){const {bytes}=await loadAsset(part,{signal,onProgress:p=>onProgress((completed+p*part.bytes)/asset.bytes*.94)});chunks.push(bytes);completed+=part.bytes;}
 if(signal.aborted)throw new DOMException('Aborted','AbortError');
 const compressed=new Blob(chunks);chunks.length=0;
 const bytes=await new Response(compressed.stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
 if(signal.aborted)throw new DOMException('Aborted','AbortError');
 if(bytes.byteLength!==asset.decodedGLBBytes)throw Error('HD model to‘liq ochilmadi.');onProgress(1);return bytes;
}
