import * as T from 'three';
// The source map is static between camera/visibility changes. Preserve its full
// resolution HDR color and depth; animate the small exterior over that depth.
export function createCachedWorld(renderer,scene,camera,dynamicScene){
 const gl=renderer.getContext(),floatSupported=renderer.extensions.has('EXT_color_buffer_float');let target=null,quad=null,quadScene=null,size=new T.Vector2(),valid=false,captures=0,baseCalls=0,baseTriangles=0,ambientFrames=0;
 if(floatSupported){
  const samples=[...gl.getInternalformatParameter(gl.RENDERBUFFER,gl.RGBA16F,gl.SAMPLES)].filter(n=>n<=4);const sampleCount=samples.length?Math.max(...samples):0;
  // Devices without float multisample support use the direct antialiased path.
  if(sampleCount){target=new T.WebGLRenderTarget(1,1,{type:T.HalfFloatType,format:T.RGBAFormat,minFilter:T.NearestFilter,magFilter:T.NearestFilter,samples:sampleCount,depthBuffer:true,stencilBuffer:false});target.texture.colorSpace=T.LinearSRGBColorSpace;target.depthTexture=new T.DepthTexture(1,1,T.UnsignedIntType);target.depthTexture.minFilter=target.depthTexture.magFilter=T.NearestFilter;quadScene=new T.Scene();const material=new T.ShaderMaterial({depthTest:true,depthWrite:true,depthFunc:T.AlwaysDepth,toneMapped:true,uniforms:{worldColor:{value:target.texture},worldDepth:{value:target.depthTexture}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',fragmentShader:'varying vec2 vUv;uniform sampler2D worldColor,worldDepth;void main(){gl_FragColor=texture2D(worldColor,vUv);gl_FragDepth=texture2D(worldDepth,vUv).x;\n#include <tonemapping_fragment>\n#include <colorspace_fragment>\n}'});quad=new T.Mesh(new T.PlaneGeometry(2,2),material);quad.frustumCulled=false;quadScene.add(quad);}
 }
 const screenCamera=new T.Camera();
 function resize(){renderer.getDrawingBufferSize(size);if(target&&(target.width!==size.x||target.height!==size.y)){target.setSize(size.x,size.y);valid=false;}}
 resize();
 return{get mode(){return target?'hdr-depth-cache':'direct';},get captures(){return captures;},get baseCalls(){return baseCalls;},get baseTriangles(){return baseTriangles;},get ambientFrames(){return ambientFrames;},resize,invalidate(){valid=false;},render(dirty){
  const oldClear=renderer.autoClear;renderer.autoClear=false;
  if(target){
   if(!valid||dirty){renderer.setRenderTarget(target);renderer.clear(true,true,true);renderer.render(scene,camera);baseCalls=renderer.info.render.calls;baseTriangles=renderer.info.render.triangles;captures++;valid=true;}
   renderer.setRenderTarget(null);renderer.clear(true,true,true);renderer.render(quadScene,screenCamera);renderer.render(dynamicScene,camera);ambientFrames++;
  }else{renderer.setRenderTarget(null);renderer.clear(true,true,true);renderer.render(scene,camera);baseCalls=renderer.info.render.calls;baseTriangles=renderer.info.render.triangles;captures++;renderer.render(dynamicScene,camera);ambientFrames++;}
  renderer.autoClear=oldClear;
 },dispose(){target?.dispose();target?.depthTexture?.dispose();quad?.geometry.dispose();quad?.material.dispose();quadScene?.clear();}};
}
