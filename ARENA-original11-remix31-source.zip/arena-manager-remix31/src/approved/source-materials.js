import fixes from './material-fixes.json' with {type:'json'};
// Source 2 exports compiler brushes and foliage animation weights into glTF.
// Compiler brushes are invisible in-game; foliage weights are not color tints.
export function configureSourceMaterial(material){
 const source=material.userData?.vmat;
 if(!source)return true;
 if(source.Name?.toLowerCase().startsWith('materials/tools/'))return false;
 if(source.ShaderName==='csgo_foliage.vfx'&&source.IntParams?.F_VERTEX_ANIMATION>=1)material.vertexColors=false;
 return true;
}

export function configureMobileSourceMaterial(material,mapId){
 const entry=fixes[mapId==='ancient-night'?'ancient':mapId];if(!entry||!entry.textures.includes(material.map?.name))return false;
 material.vertexColors=false;material.needsUpdate=true;return true;
}
