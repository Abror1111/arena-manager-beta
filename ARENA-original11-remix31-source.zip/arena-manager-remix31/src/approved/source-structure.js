import * as T from 'three';
import {loadAsset}from'./asset-cache.js';
import manifest from './structure-manifest.json' with {type:'json'};
import {finishExteriorMaterial}from'./facade-finish.js';
export async function loadSourceStructure(map,signal){const entry=manifest[map.id];if(!entry||entry.sourceSHA256!==map.visual.sha256)throw Error('Xarita poydevor ma’lumoti mos kelmadi.');const{bytes}=await loadAsset(entry,{signal});const decoded=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();if(signal.aborted)throw new DOMException('Aborted','AbortError');if(decoded.byteLength!==entry.decodedBytes)throw Error('Xona modeli to‘liq yuklanmadi.');return JSON.parse(new TextDecoder().decode(decoded));}
// Closed solids with measured source UV gradients; all original source meshes
// stay unchanged. New back, side, bottom and roof faces are real geometry.
export function buildSourceStructure({b,plan,profile,ground,sourceByTexture,materials,ownedMaterials,textures}){
 const data=plan.structure,stats={rooms:0,supports:0,wallBaseMaxGap:-Infinity,inspection:null,materialBindings:0},roomBodies=[];
 function sourceMaterial(texture,fallback='wall',worldUV=false){const key='measured-'+(worldUV?'wrapped-':'')+texture;if(materials.has(key))return key;const src=sourceByTexture.get(texture);if(!src)return fallback;const mat=src.clone();if(worldUV)for(const k of ['map','normalMap','roughnessMap','metalnessMap','aoMap'])if(mat[k]){const t=mat[k].clone();t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(1,1);t.offset.set(0,0);t.rotation=0;t.needsUpdate=true;textures.add(t);mat[k]=t;}mat.vertexColors=false;mat.side=T.DoubleSide;mat.shadowSide=T.FrontSide;mat.clippingPlanes=[];mat.clipShadows=false;mat.transparent=false;mat.opacity=1;mat.alphaTest=0;mat.onBeforeCompile=()=>{};mat.customProgramCacheKey=()=> 'measured-source-solid';finishExteriorMaterial(mat,/brick|stone|block|concrete/i.test(texture)?'stone':'plaster');materials.set(key,mat);ownedMaterials.add(mat);stats.materialBindings++;return key;}
 function face(key,p,uv){b.tri(key,p[0],p[1],p[2],uv.slice(0,3));b.tri(key,p[0],p[2],p[3],[uv[0],uv[2],uv[3]]);}
 const roofKey=sourceMaterial(data.roofTexture,'roof',true);
 function solid(r,bottom){const key=sourceMaterial(r.texture),u=r.tangent,n=r.normal,L=r.length,D=r.depth,at=(a,y,d)=>[r.a[0]+u[0]*a+n[0]*d,y,r.a[1]+u[1]*a+n[1]*d],uv=(along,y)=>{const f=r.uvFrame;return[f[0][0]*along+f[1][0]*y+f[2][0],f[0][1]*along+f[1][1]*y+f[2][1]];},start=r.a[0]*u[0]+r.a[1]*u[1];
  if(r.clipped){
   for(const ring of[r.footprint,...(r.holes||[])])for(let i=0;i<ring.length;i++){const a=ring[i],bb=ring[(i+1)%ring.length],a0=[a[0],bottom,a[1]],b0=[bb[0],bottom,bb[1]],b1=[bb[0],r.top,bb[1]],a1=[a[0],r.top,a[1]],sa=a[0]*u[0]+a[1]*u[1],projected=bb[0]*u[0]+bb[1]*u[1],sb=Math.abs(projected-sa)>.2*Math.hypot(bb[0]-a[0],bb[1]-a[1])?projected:sa+Math.hypot(bb[0]-a[0],bb[1]-a[1]);face(key,[a0,b0,b1,a1],[uv(sa,bottom),uv(sb,bottom),uv(sb,r.top),uv(sa,r.top)]);}
   for(const y of[bottom,r.top])for(const t of r.roofTriangles)b.tri(y===r.top?roofKey:key,...t.map(p=>[p[0],y,p[1]]),t.map(p=>[p[0]*.5,p[1]*.5]));
  }else{
   // Front and rear retain original source UVs; returns wrap the same density.
   for(const d of[0,D]){const p=[at(0,bottom,d),at(L,bottom,d),at(L,r.top,d),at(0,r.top,d)],t=[uv(start,bottom),uv(start+L,bottom),uv(start+L,r.top),uv(start,r.top)];face(key,p,t);}
   for(const a of[0,L]){const p=[at(a,bottom,0),at(a,bottom,D),at(a,r.top,D),at(a,r.top,0)],t=[uv(start+a,bottom),uv(start+a+D,bottom),uv(start+a+D,r.top),uv(start+a,r.top)];face(key,p,t);}
   for(const y of[bottom,r.top]){const p=[at(0,y,0),at(L,y,0),at(L,y,D),at(0,y,D)];b.quad(y===r.top?roofKey:key,...p,.5);}
   const yaw=Math.atan2(-u[1],u[0]),center=at(L/2,r.top+.07,D/2);b.box('trim',center,[L+.10,.12,D+.10],yaw);
   if(profile.family==='village'){const rise=Math.min(.75,D*.3);for(const sign of[-1,1]){const near=sign<0?0:D;const a=at(-.03,r.top+.12,near),bb=at(L+.03,r.top+.12,near),c=at(L+.03,r.top+rise,D/2),d=at(-.03,r.top+rise,D/2);b.quad(roofKey,a,bb,c,d);for(let x=0;x<=L;x+=.36)b.tube(roofKey,[at(x,r.top+.14,near),at(x,r.top+rise+.025,D/2)],.025,.025,5);}for(const x of[0,L])b.tri(key,at(x,r.top,0),at(x,r.top,D),at(x,r.top+rise,D/2));}
   if(profile.family==='temple')for(const d of[.1,D-.1])b.box('trim',at(L/2,r.top+.21,d),[L-.12,.18,.22],yaw);
  }
  const mid=at(L/2,Math.min(r.top-1,bottom+2.0),D),f={...r,a:[r.a[0]+n[0]*D,r.a[1]+n[1]*D],b:[r.b[0]+n[0]*D,r.b[1]+n[1]*D],top:r.top,length:L};roomBodies.push({...f,bottom,footprint:r.footprint});
  if(!stats.inspection&&L>3&&r.top-bottom>2.4){const t=52*Math.PI/180,yaw=Math.atan2(n[0],n[1])+.18;stats.inspection={target:[mid[0],Math.max(bottom+.7,Math.min((r.top+bottom)/2,r.top-.4)),mid[2]],zoom:2.6,offset:[Math.sin(yaw)*Math.sin(t)*900,Math.cos(t)*900,Math.cos(yaw)*Math.sin(t)*900]};}
 }
 for(const r of data.rooms){const bottom=Math.min(r.sourceBottom-.08,ground.minimum(r.footprint,.12));if(r.top-bottom<.25)continue;solid(r,bottom);for(const p of r.footprint)stats.wallBaseMaxGap=Math.max(stats.wallBaseMaxGap,bottom-ground.height(...p));stats.rooms++;}
 const foundationKey=sourceMaterial(data.foundationTexture,'trim',true);
 for(const p of data.supports){const bottom=ground.minimum([p.a,p.b],.12),L=Math.hypot(p.b[0]-p.a[0],p.b[1]-p.a[1]);if(p.top-bottom<.18)continue;const yaw=Math.atan2(-(p.b[1]-p.a[1]),p.b[0]-p.a[0]);b.box(foundationKey,[(p.a[0]+p.b[0])/2,(bottom+p.top)/2,(p.a[1]+p.b[1])/2],[L+.018,p.top-bottom,.16],yaw);stats.supports++;}
 if(profile.architecture==='skyline'){
  const q=plan.navBounds,base=plan.sourceBounds[1]-.82,top=plan.groundY+.60,x0=q[0]-.4,x1=q[2]+.4,z0=q[1]-.4,z1=q[3]+.4,w=x1-x0,d=z1-z0;b.box('wall',[(x0+x1)/2,(base+top)/2,(z0+z1)/2],[w,top-base,d]);
  // Fully closed tower under the lowest playable floor, with all four sides.
  for(let y=base+1.6;y<top-1;y+=2.6){for(const z of[z0-.035,z1+.035]){b.box('glass',[(x0+x1)/2,y,z],[w-.5,1.65,.05]);b.box('metal',[(x0+x1)/2,y+1,z],[w,.15,.08]);}for(const x of[x0-.035,x1+.035]){b.box('glass',[x,y,(z0+z1)/2],[.05,1.65,d-.5]);b.box('metal',[x,y+1,(z0+z1)/2],[.08,.15,d]);}}
  for(let x=x0+2;x<x1;x+=3)for(const z of[z0-.08,z1+.08])b.box('metal',[x,(base+top)/2,z],[.12,top-base,.10]);for(let z=z0+2;z<z1;z+=3)for(const x of[x0-.08,x1+.08])b.box('metal',[x,(base+top)/2,z],[.10,top-base,.12]);stats.rooms=1;stats.wallBaseMaxGap=-.32;
 }
 return{...stats,roomBodies,wallBaseMaxGap:Number.isFinite(stats.wallBaseMaxGap)?stats.wallBaseMaxGap:0};
}
