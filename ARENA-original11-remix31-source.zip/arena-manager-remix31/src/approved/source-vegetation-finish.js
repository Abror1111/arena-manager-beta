// Source 2 vegetation vertex channels carry wind weights, not black color.
// Keep the source alpha texture/UVs; remove the erroneous runtime multiplier.
export function finishNativeVegetation(material){const name=material.map?.name||'';if(!/(?:^|_)trees?_|barks?|foliage|palm|cypress|birch|(?:^|_)oak_|(?:^|_)pine_|trunk|(?:^|_)fern(?:_|\d)|branches/i.test(name)||/overlay|street|ground_leaves/i.test(name))return false;material.vertexColors=false;material.needsUpdate=true;return true;}
