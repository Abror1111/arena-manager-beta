import * as T from 'three';
import {loadAsset} from './asset-cache.js';
import manifest from './route-mask-manifest.json' with {type:'json'};

// Preserve exterior roofs. Only remove geometry directly above playable routes,
// using each route's own elevation rather than one plane across the whole map.
export async function loadRouteCutaway(map,cutoff,signal){
 const entry=manifest[map.id];
 const {bytes:compressed}=await loadAsset(entry,{signal});
 const bytes=await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
 const view=new DataView(bytes);
 if(String.fromCharCode(...new Uint8Array(bytes,0,4))!=='ARF1')throw Error('Route mask invalid');
 const w=view.getUint32(4,true),h=view.getUint32(8,true),low=view.getFloat32(12,true),span=view.getFloat32(16,true);
 if(bytes.byteLength!==20+w*h*4)throw Error('Route mask incomplete');
 const texture=new T.DataTexture(new Uint8Array(bytes,20),w,h,T.RGBAFormat);
 texture.magFilter=texture.minFilter=T.NearestFilter;texture.flipY=false;texture.needsUpdate=true;
 const clipUniform={get value(){return cutoff.constant;}},applied=new WeakSet(),f=n=>Number(n).toFixed(6);
 return{
  apply(material){
   if(applied.has(material))return;
   applied.add(material);
   const before=material.onBeforeCompile,key=material.customProgramCacheKey();
   material.onBeforeCompile=function(shader,renderer){
    before.call(this,shader,renderer);
    shader.uniforms.arenaRouteMask={value:texture};shader.uniforms.arenaRouteClip=clipUniform;
    shader.vertexShader=shader.vertexShader
     .replace('#include <common>','#include <common>\nvarying vec3 vArenaCutPosition;')
     .replace('#include <project_vertex>',`#include <project_vertex>
      vec4 arenaPosition=vec4(transformed,1.);
      #ifdef USE_BATCHING
       arenaPosition=batchingMatrix*arenaPosition;
      #endif
      #ifdef USE_INSTANCING
       arenaPosition=instanceMatrix*arenaPosition;
      #endif
      vArenaCutPosition=(modelMatrix*arenaPosition).xyz;`);
    shader.fragmentShader=shader.fragmentShader
     .replace('#include <common>','#include <common>\nvarying vec3 vArenaCutPosition;uniform sampler2D arenaRouteMask;uniform float arenaRouteClip;')
     .replace('#include <clipping_planes_fragment>',`
      vec2 routeUV=(vArenaCutPosition.xz+vec2(${f(map.width/2)},${f(map.height/2)}))/vec2(${f(map.width)},${f(map.height)});
      if(all(greaterThanEqual(routeUV,vec2(0.)))&&all(lessThanEqual(routeUV,vec2(1.)))){
       vec4 route=texture2D(arenaRouteMask,routeUV);
       float encoded=arenaRouteClip<${f(map.upperClip-.1)}?route.b:route.g;
       float localClip=${f(low)}+encoded*${f(span)}-.75;
       if(route.r>.5&&vArenaCutPosition.y>min(arenaRouteClip,localClip))discard;
      }
      #include <clipping_planes_fragment>`);
   };
   material.customProgramCacheKey=()=>key+'-route-cutaway-130';material.needsUpdate=true;
  },
  dispose(){texture.dispose();}
 };
}
