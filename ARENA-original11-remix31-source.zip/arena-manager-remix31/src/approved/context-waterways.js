import * as T from 'three';
import{createCoastalWater}from'./exterior-life.js';
export const canalCenter=(plan,z)=>plan.sourceBounds[3]+12+2.6*Math.sin(z*.053)+1.2*Math.sin(z*.137);
export function createParkCanal({plan,scene,dynamicScene,renderer,time,geometries,materials,b,ground}){
 const base=plan.sourceBounds[3]-4,old=new Set(materials);
 function geometry(){const p=[],uv=[];for(let z=-1200;z<1200;z+=z< -150||z>150?50:2){const next=z+(z< -150||z>150?50:2),v=[[canalCenter(plan,z)-4.25,-1.5,z],[canalCenter(plan,z)+4.25,-1.5,z],[canalCenter(plan,next)+4.25,-1.5,next],[canalCenter(plan,next)-4.25,-1.5,next]];for(const k of[0,1,2,0,2,3]){p.push(...v[k]);uv.push(v[k][0],v[k][2]);}}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.computeVertexNormals();return g;}
 const water=createCoastalWater({scene,dynamicScene,renderer,time,geometries,materials,surfaceGeometry:geometry,shoreBaseX:base});for(const m of materials)if(!old.has(m)&&m.uniforms?.waterDeep){m.uniforms.waterDeep.value.set('#345e5c');m.uniforms.waterShallow.value.set('#729487');m.vertexShader=m.vertexShader.replace('coastalWave(p.xz,time).x','coastalWave(p.xz,time).x*.18');m.fragmentShader=m.fragmentShader.replace('vec3 wave=coastalWave(vWorld.xz,time);','vec3 wave=coastalWave(vWorld.xz,time);wave.yz*=.18;');}
 const bounds=plan.districts.navBounds;
 for(let z=bounds[1]-40;z<bounds[3]+40;z+=2)for(const sign of[-1,1]){const x=canalCenter(plan,z)+sign*4.5,top=ground.height(canalCenter(plan,z)+sign*6,z)+.2,bottom=-3.85;b.box('district-stone',[x,(top+bottom)/2,z],[.55,top-bottom,2.1]);b.box('trim',[x,top+.06,z],[.75,.18,2.12]);if(Math.floor(z/2)%2===0)b.tube('metal',[[x,top+.12,z],[x,top+.95,z]],.035,.035,6);b.tube('metal',[[x,top+.93,z-.95],[x,top+.93,z+.95]],.035,.035,6);}
 return water;
}
