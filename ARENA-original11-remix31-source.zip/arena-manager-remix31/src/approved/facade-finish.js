// Layered, world-scaled PBR finish for NEW exterior geometry only. Original
// source materials are never passed here. No extra image downloads are needed.
export function finishExteriorMaterial(material,kind='plaster'){
 const mode={plaster:0,stone:1,wood:2,metal:3,canvas:4}[kind]??0;
 material.onBeforeCompile=shader=>{
  shader.uniforms.exteriorFinishKind={value:mode};
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vExteriorWorld; varying vec3 vExteriorNormal;').replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nvExteriorWorld=(modelMatrix*vec4(transformed,1.)).xyz;vExteriorNormal=normalize(mat3(modelMatrix)*objectNormal);');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>',`#include <common>
varying vec3 vExteriorWorld,vExteriorNormal;uniform float exteriorFinishKind;
float extHash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float extNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(extHash(i),extHash(i+vec2(1.,0.)),f.x),mix(extHash(i+vec2(0.,1.)),extHash(i+1.),f.x),f.y);}
vec2 extCoordinates(){vec3 w=abs(vExteriorNormal);if(w.y>.72)return vExteriorWorld.xz;return vec2(w.x>w.z?vExteriorWorld.z:vExteriorWorld.x,vExteriorWorld.y);}
vec3 extSurface(vec2 p){
 float cloud=extNoise(p*.31)*.65+extNoise(p*1.3)*.35,grain=extNoise(p*32.);
 vec2 bricks=p*vec2(1.35,3.1);float row=floor(bricks.y);bricks.x+=mod(row,2.)*.5;vec2 cell=fract(bricks);float edge=min(min(cell.x,1.-cell.x),min(cell.y,1.-cell.y));
 float mortar=1.-smoothstep(.015,.055,edge),stone=extHash(floor(bricks));
 float chippedArea=smoothstep(.55,.76,extNoise(p*.85+7.));
 float streak=pow(extNoise(vec2(p.x*6.2,p.y*.18)),3.);float damp=exp(-max(p.y-.6,0.)*.55);
 float relief=(grain-.5)*.005-mortar*.012*(exteriorFinishKind<.5?chippedArea:1.);
 float shade=.91+cloud*.16+(grain-.5)*.04-streak*.11-damp*.06;
 if(exteriorFinishKind>.5&&exteriorFinishKind<1.5){shade=.82+stone*.26-mortar*.13+(grain-.5)*.05;}
 if(exteriorFinishKind>1.5&&exteriorFinishKind<2.5){float fiber=sin(p.y*45.+extNoise(p*.9)*4.);shade=.89+cloud*.12+fiber*.045;relief=fiber*.003;}
 if(exteriorFinishKind>2.5&&exteriorFinishKind<3.5){shade=.83+cloud*.20-streak*.13;relief=(grain-.5)*.002;}
 if(exteriorFinishKind>3.5){shade=.92+sin(p.x*5.5)*.055+(grain-.5)*.04;relief=(grain-.5)*.001;}
 return vec3(shade,relief,chippedArea*mortar);
}
`);
  shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
vec2 exteriorUV=extCoordinates();vec3 exteriorFinish=extSurface(exteriorUV);
diffuseColor.rgb*=exteriorFinish.x;
if(exteriorFinishKind<.5){
 float fade=extNoise(exteriorUV*.21+13.);float band=(1.-smoothstep(.0,.12,abs(exteriorUV.y-2.7)-.23))*.16;
 diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*vec3(.74,.82,.75),band);
 diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*vec3(1.02,.86,.70),exteriorFinish.z*.24);
 diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*vec3(1.04,1.015,.96),fade*.2);
}
`);
  shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nroughnessFactor=clamp(roughnessFactor+(extNoise(extCoordinates()*2.)-.5)*.12,.35,1.);');
  shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
float exteriorRelief=extSurface(extCoordinates()).y;
vec3 exteriorDx=dFdx(-vViewPosition),exteriorDy=dFdy(-vViewPosition),exteriorR1=cross(exteriorDy,normal),exteriorR2=cross(normal,exteriorDx);
float exteriorDet=dot(exteriorDx,exteriorR1);
normal=normalize(abs(exteriorDet)*normal-sign(exteriorDet)*(dFdx(exteriorRelief)*exteriorR1+dFdy(exteriorRelief)*exteriorR2));
`);
 };
 material.customProgramCacheKey=()=> 'arena-exterior-layered-pbr-'+mode;
 material.needsUpdate=true;
}
