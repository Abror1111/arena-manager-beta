// Authored29 metre-scale design. Reference analysis supplied elevation ranges,
// not source vertices, polygons, navigation or textures.
export const LEVELS29={ct:.4,b:3.8,upperTunnel:3.9,lowerTunnel:.65,midTop:4.2,long:3.6,t:6.6,a:6.1};
export const BRIDGE26=[{x0:61,x1:66,z0:20,z1:32,y:6.1},{x0:61,x1:78,z0:18,z1:22.5,y:6.1}];
export const STAIRS26=[{id:'mid-street',axis:'z',start:35,end:41.2,x0:43.5,x1:50,z0:35,z1:41.2,low:.4,high:4.2,steps:24},{id:'short',axis:'z',start:37,end:32,x0:60,x1:66,z0:32,z1:37,low:4.2,high:6.1,steps:12},{id:'upper-to-lower',axis:'x',start:25,end:33,x0:25,x1:33,z0:38,z1:47.5,low:3.9,high:.65,steps:22}];
const within=(x,z,r)=>x>=r.x0&&x<=r.x1&&z>=r.z0&&z<=r.z1,clamp=t=>Math.max(0,Math.min(1,t)),lerp=(a,b,t)=>a+(b-a)*clamp(t);
export function exteriorHeight29(x,z){return x< -65?Math.max(-.04,.05-(-x-65)*.16):.05+Math.max(0,Math.abs(z)-55)*.012}
export function bridgeHeight26(x,z){const px=x/1.2+50,pz=z/1.2+50;return BRIDGE26.some(r=>within(px,pz,r))?6.1:null}
export const stairAt26=(px,pz)=>STAIRS26.find(r=>within(px,pz,r))||null;
export function groundFloor26(x,z){if(Math.abs(x)>60||Math.abs(z)>60)return exteriorHeight29(x,z);const px=x/1.2+50,pz=z/1.2+50,s=stairAt26(px,pz);if(s){const t=((s.axis==='x'?px:pz)-s.start)/(s.end-s.start),n=Math.max(0,Math.min(s.steps,Math.floor(t*s.steps+1e-8)));return s.low+(s.high-s.low)*n/s.steps}
 if(px>=33&&px<=43&&pz>=38.5&&pz<=43.5)return .65;
 if(px>=38.5&&px<=43&&pz>=31&&pz<38.5)return lerp(.4,.65,(pz-31)/7.5);
 if(px>=77&&px<=91&&pz<=24)return 6.1;
 if(px>=82&&px<=91&&pz<=29)return 6.1;
 if(px>=60&&px<=82&&pz>=23&&pz<=28.5)return lerp(.4,6.1,(px-60)/22);
 if(px>=83&&px<=91&&pz>29&&pz<=43)return lerp(6.1,3.6,(pz-29)/14);
 if(px>=83&&px<=91&&pz>43&&pz<=68)return 3.6;
 if(px>=65&&px<=91&&pz>=46&&pz<=68)return 3.6;
 if(px>=65&&px<=77&&pz>=54&&pz<=75)return 3.6;
 if(px>=50&&px<=66&&pz>=37&&pz<=43)return 4.2;
 if(px>=43.5&&px<=50&&pz>=41.2&&pz<=48)return 4.2;
 if(px>=43.5&&px<=50&&pz>48&&pz<86)return lerp(4.2,6.6,(pz-48)/38);
 if(px<=26&&pz<=34)return 3.8;
 if(px>26&&px<=40&&pz<=30)return lerp(3.8,.4,(px-26)/14);
 if(px<=28&&pz>=34&&pz<=74)return 3.9;
 if(px<=28&&pz>74&&pz<=86)return lerp(3.9,6.6,(pz-74)/12);
 if(px>=56&&px<=77&&pz>=75&&pz<=86)return lerp(3.6,6.6,(pz-75)/11);
 if(pz>=86)return 6.6;
 if(pz>68)return lerp(.4,6.6,(pz-68)/18);
 return .4;
}
export function floor26(x,z,hint){const low=groundFloor26(x,z),high=bridgeHeight26(x,z);return high!==null&&Number.isFinite(hint)&&Math.abs(high-hint)<Math.abs(low-hint)?high:low}
export const ROAD_AREAS26=[[[83,29],[91,29],[91,68],[84,68],[84,54],[72,54],[69,57],[66,57],[70,50],[83,50]],[[43.5,31],[50,31],[50,86],[43.5,86]],[[26,18],[43,18],[45,20],[60,20],[60,23],[83,23],[85,29],[60,29],[54,26],[45,26],[42,24],[26,24]]];
export function axes26(){const xs=new Set(),zs=new Set();for(let i=0;i<=120;i++){xs.add(i-60);zs.add(i-60)}for(const v of[25,26,28,33,38.5,40,43,43.5,50,56,60,61,65,66,77,78,82,83,91])xs.add((v-50)*1.2);for(const v of[18,20,22.5,23,24,28.5,29,30,31,32,34,35,37,38,38.5,41.2,43,43.5,46,47.5,48,54,68,74,75,86])zs.add((v-50)*1.2);for(const r of STAIRS26)for(let i=0;i<=r.steps;i++)(r.axis==='x'?xs:zs).add((r.start+(r.end-r.start)*i/r.steps-50)*1.2);const clean=s=>[...s].sort((a,b)=>a-b).filter((x,i,a)=>!i||x-a[i-1]>.00001);return{x:clean(xs),z:clean(zs)}}
