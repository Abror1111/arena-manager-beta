import * as T from 'three';
import {mapProps} from './map-prop-physics.js';
// Cut triangle selections from the map's own mesh; retain its UVs/albedo/colors.
// Intact objects cost no extra draw calls. Promote to dynamic only on impact.
export function bindMapProps(gltf,map,scene){
 const meshes=new Map(),originals=new Map(),promoted=new Map(),props=mapProps(map);
 gltf.scene.updateWorldMatrix(true,true);
 gltf.scene.traverse(o=>{if(o.isMesh){const a=gltf.parser.associations.get(o);if(a?.meshes!==undefined)meshes.set(a.meshes+':'+(a.primitives??0),o);}});
 for(const p of props)for(const part of p.parts){const o=meshes.get(part.mesh+':'+part.primitive);if(!o?.geometry.index||part.ranges.some(([start,count])=>start<0||count<1||(start+count)*3>o.geometry.index.count))throw Error('Xarita buyumlari modeli mos emas.');}
 function promote(prop){
  if(promoted.has(prop.id))return promoted.get(prop.id);
  const root=new T.Group(),chunks=[],geometries=[],materials=[];
  root.name='map-object-'+prop.id;root.position.set(prop.x-map.width/2,prop.y,prop.z-map.height/2);scene.add(root);
  for(const part of prop.parts){
   const original=meshes.get(part.mesh+':'+part.primitive);if(!original?.geometry.index)throw Error('Xarita buyumi geometriyasi mos emas.');
   const source=original.geometry,index=source.index;
   if(!originals.has(original))originals.set(original,index.array.slice());const untouched=originals.get(original),indices=[];
   for(const [start,count]of part.ranges)for(let t=start*3;t<(start+count)*3;t++){indices.push(untouched[t]);index.array[t]=0;}
   index.needsUpdate=true;
   const transform=new T.Matrix4().makeTranslation(-(prop.x-map.width/2),-prop.y,-(prop.z-map.height/2)).multiply(original.matrixWorld);
   const partitions=Array.from({length:4},()=>[]),pos=source.attributes.position,point=new T.Vector3(),center=new T.Vector3();
   for(let i=0;i<indices.length;i+=3){center.set(0,0,0);for(let j=0;j<3;j++)center.add(point.fromBufferAttribute(pos,indices[i+j]).applyMatrix4(transform));center.multiplyScalar(1/3);const q=(center.x>=0?1:0)+(center.z>=0?2:0);partitions[q].push(indices[i],indices[i+1],indices[i+2]);}
   const base=Array.isArray(original.material)?original.material[0]:original.material,material=base.clone();material.color.copy(base.color);material.userData.propBaseColor=base.color.clone();materials.push(material);
   partitions.unshift(indices);
   for(let slot=0;slot<5;slot++)if(partitions[slot].length){const q=slot-1;const geometry=new T.BufferGeometry();for(const [name,attribute]of Object.entries(source.attributes))geometry.setAttribute(name,attribute);geometry.setIndex(partitions[slot]);geometry.computeBoundingSphere();geometries.push(geometry);
    const pivot=new T.Group(),mesh=new T.Mesh(geometry,material);mesh.matrixAutoUpdate=false;mesh.matrix.copy(transform);mesh.castShadow=true;mesh.receiveShadow=true;pivot.add(mesh);root.add(pivot);chunks.push({pivot,q});}
  }
  const value={root,chunks,geometries,materials};promoted.set(prop.id,value);return value;
 }
 // Never write into decoder/cache-backed index storage.
 for(const o of new Set(meshes.values()))if(o.geometry.index)o.geometry.setIndex(o.geometry.index.clone());
 let round=null;
 function update(game){
  if(round!==game.round){for(const [mesh,values]of originals){mesh.geometry.index.array.set(values);mesh.geometry.index.needsUpdate=true;}for(const p of promoted.values())p.root.visible=false;round=game.round;}
  for(const [key,state]of Object.entries(game.propStates||{})){
   const prop=props[Number(key)];if(!prop)continue;const existing=promoted.get(prop.id),p=promote(prop);
   // A previously promoted object is restored to the static batch at round reset.
   if(existing&&!p.root.visible)for(const part of prop.parts){const index=meshes.get(part.mesh+':'+part.primitive).geometry.index;for(const [start,count]of part.ranges)index.array.fill(0,start*3,(start+count)*3);index.needsUpdate=true;}
   p.root.visible=true;p.root.position.set(state.x-map.width/2,state.y,state.z-map.height/2);p.root.rotation.set(state.broken?0:state.rx,state.ry,state.broken?0:state.rz);
   for(const {pivot,q}of p.chunks){pivot.visible=state.broken?q>=0:q===-1;if(!pivot.visible)continue;const t=Math.min(state.age,2),dx=q%2?1:-1,dz=q>=2?1:-1,spread=state.broken?Math.min(.6,t*.42):0;pivot.position.set(dx*spread,state.broken?Math.max(-prop.size[1]*.3,Math.sin(Math.min(1,t)*Math.PI)*.35-t*.12):0,dz*spread);pivot.rotation.set(state.broken?dx*t*.5:0,0,state.broken?dz*t*.4:0);}
   for(const material of p.materials)material.color.copy(material.userData.propBaseColor).multiplyScalar(1-state.burn*.73);
  }
 }
 return{update,get count(){return props.length;},get active(){return [...promoted.values()].filter(p=>p.root.visible).length;},dispose(){for(const p of promoted.values()){p.root.removeFromParent();p.geometries.forEach(g=>g.dispose());p.materials.forEach(m=>m.dispose());}}};
}
