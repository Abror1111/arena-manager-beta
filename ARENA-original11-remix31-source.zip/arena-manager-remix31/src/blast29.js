// Virtual gameplay values in map metres and hit points, not an ordnance model.
export const C4_BLAST29=Object.freeze({damageRadius:48,waveRadius:62,safeDistance:54,coreRadius:9,peakDamage:520,waveSpeed:36,waveLife:2.3});
export function blastDistance29(a,b){return Math.hypot(a.x-b.x,a.z-b.z,(a.y??0)-(b.y??0))}
export function blastDamage29(distance,exposure=1){const c=C4_BLAST29;if(distance>=c.damageRadius)return 0;const t=Math.max(0,(distance-c.coreRadius)/(c.damageRadius-c.coreRadius));return c.peakDamage*(1-t)**2*(.12+.88*Math.max(0,Math.min(1,exposure)))}
export function blastExposure29(map,origin,target,clearLine){let visible=0;const scale=map.remix31?(map.playerScale||1):1,dx=target.x-origin.x,dz=target.z-origin.z,l=Math.hypot(dx,dz)||1;for(const [side,vertical]of[[-.24,.45],[0,.95],[.24,1.5]])if(clearLine(map,{...origin,y:(origin.y??0)+.18*scale},{x:target.x-dz/l*side*scale,z:target.z+dx/l*side*scale,y:(target.y??0)+vertical*scale}))visible++;return visible/3}
export const shockRadius29=age=>Math.min(C4_BLAST29.waveRadius,Math.max(0,age)*C4_BLAST29.waveSpeed);
