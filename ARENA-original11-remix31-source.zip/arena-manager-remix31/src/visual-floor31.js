import{navLocation}from'./reference-nav.js';import{collisionRay,hasCollision}from'./world-collision.js';
const offsets=new WeakMap();
// Keep simulation on the source navigation; correct the rendered ground contact
// against the supplied collision surface, caching the offset per nav polygon.
export function visualFloor31(map,x,z,hint){if(!map.remix31||!hasCollision(map))return hint;const q=navLocation(map,{x,z,y:hint});if(!q)return hint;let rows=offsets.get(map.nav);if(!rows){rows=new Map();offsets.set(map.nav,rows)}let offset=rows.get(q.index);if(offset===undefined){const s=map.playerScale||1,hit=collisionRay(map,{x,z,y:q.y+.6*s},{x,z,y:q.y-.8*s},{ignoreStart:.001});offset=hit&&hit.ny>.5&&Math.abs(hit.y-q.y)<.75*s?hit.y-q.y:0;rows.set(q.index,offset)}return q.y+offset}
