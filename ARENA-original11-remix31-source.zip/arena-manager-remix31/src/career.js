import {ensureFinance,validateFinance,post,settleFinance,SPONSORS,SHOP,OBJECTIVES} from './club-finance.js';
export {salary,clubCosts,matchQuote,sponsorOffers,activeSponsor,SHOP,SPONSORS,OBJECTIVES,PRACTICE_ALLOWANCE} from './club-finance.js';
import {experienceBonus,careerExperience,recruitProgress} from './player-development.js';
import {ALL_MAPS,modernMapId,REFERENCE_REVISION} from './maps.js';
import {MAPS, Match, clamp} from './engine.js';

export const SAVE_KEY='arena-career-remix31';
export const BACKUP_KEY=SAVE_KEY+'-backup';
export const SAVE_SCHEMA=2;
export const SKILLS=['aim','reaction','tactics','utility'];
export const SKILL_NAMES={aim:'Aniqlik',reaction:'Reaksiya',tactics:'Taktika',utility:'Granatalar'};
export const ROLES=['Kapitan','Rifler','Snayper','Entry','Support'];
export const OPPONENTS=[
 {id:'iron',name:'IRON FIVE',short:'I5',strategy:'balanced',rating:75,color:'#e1a44c',players:['FROST','VIPER','GHOST','BLAZE','STORM']},
 {id:'nomad',name:'NOMAD',short:'NM',strategy:'a',rating:77,color:'#9cc4a3',players:['STEPPE','QUM','BO‘RON','JET','MIRAGE']},
 {id:'vector',name:'VECTOR',short:'VX',strategy:'b',rating:79,color:'#80b5dc',players:['DELTA','AXIS','ZERO','ARC','NODE']},
 {id:'orion',name:'ORION',short:'OR',strategy:'hold',rating:82,color:'#b8a3e5',players:['VEGA','RIGEL','NOVA-X','LUNA','COMET']},
 {id:'pulse',name:'PULSE',short:'PL',strategy:'a',rating:84,color:'#ea9a9e',players:['BEAT','SPARK','VOLTA','AMP','SURGE']},
];
const defaults=['ACE','NOVA','SHADOW','REX','ECHO','PIXEL'];
const copy=value=>JSON.parse(JSON.stringify(value));
const average=values=>Math.round(values.reduce((a,b)=>a+b,0)/values.length);
export function overall(p){return Math.round(p.aim*.45+p.reaction*.2+p.tactics*.2+p.utility*.15);}
export function effective(p){return Math.round(clamp(overall(p)+experienceBonus(p)-(100-p.energy)*.11-(100-p.morale)*.025,20,99));}
export function lineupPlayers(c){return c.lineup.map(id=>c.roster.find(p=>p.id===id)).filter(Boolean);}
export function teamRating(c){return average(lineupPlayers(c).map(effective));}
export function xpLevel(c){return 1+Math.floor(c.xp/400);}
function makePlayer(id,name,role,rating,index=0){
 const profile={id,name,role,aim:clamp(rating+(index%3-1)*2,30,97),reaction:clamp(rating+(index%2?2:-1),30,97),tactics:clamp(rating+(role==='Kapitan'?4:-2),30,97),utility:clamp(rating+(role==='Support'?5:-3),30,97),energy:100,morale:85,xp:0,kills:0,deaths:0,matches:0,lastTrained:0};
 return profile;
}
function rand(seed){let s=seed>>>0||1;return()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};}
function makeSeason(number){
 let ids=['club',...OPPONENTS.map(o=>o.id).reverse()],fixtures=[];
 for(let round=0;round<5;round++){
  const pairs=[];
  for(let i=0;i<3;i++)pairs.push({home:ids[i],away:ids[5-i]});
  fixtures.push({round:round+1,pairs});
  ids=[ids[0],ids[5],...ids.slice(1,5)];
 }
 return {number,stage:'league',fixtures,week:0,results:[],table:Object.fromEntries(['club',...OPPONENTS.map(o=>o.id)].map(id=>[id,{id,played:0,wins:0,losses:0,points:0,for:0,against:0}])),playoffOpponent:null,placement:null,completed:false,prize:0};
}
export function createCareer(legacyRating=80){
 const base=clamp(Math.round(Number(legacyRating)||80),75,95);
 const career={schema:SAVE_SCHEMA,newsSeq:1,clubName:'UZB FIVE',credits:12000,fans:420,reputation:0,xp:0,day:1,trainingLevel:1,seasonNumber:1,roster:defaults.map((n,i)=>makePlayer('starter-'+i,n,ROLES[i%5],base+[2,0,3,-2,-1,-6][i],i)),lineup:defaults.slice(0,5).map((_,i)=>'starter-'+i),season:makeSeason(1),history:[],pending:null,nextMatch:1,settled:[],news:[{id:'welcome',text:'Klubingiz tayyor. Tarkibni tanlang va birinchi liga uchrashuviga chiqing.',day:1}],settings:{map:'dust2',strategy:'a',side:'T',quality:'3d'},totalWins:0,totalMatches:0};ensureFinance(career);return career;
}
function news(c,text){c.newsSeq=(c.newsSeq||1)+1;c.news.unshift({id:`news-${c.newsSeq}`,text,day:c.day});c.news=c.news.slice(0,12);}
export function orderedTable(c){return Object.values(c.season.table).sort((a,b)=>b.points-a.points||(b.for-b.against)-(a.for-a.against)||b.for-a.for||a.id.localeCompare(b.id));}
export function opponent(c,id){const p=OPPONENTS.find(o=>o.id===id);return p?{...p,rating:Math.min(96,p.rating+(c.seasonNumber-1)*2)}:{id:'club',name:c.clubName,short:c.clubName.replace(/[^A-Z0-9]/gi,'').slice(0,3).toUpperCase()||'U5',rating:teamRating(c)};}
export function nextFixture(c){
 const s=c.season;if(s.completed)return null;
 if(s.stage==='league'){
  const pair=s.fixtures[s.week]?.pairs.find(p=>p.home==='club'||p.away==='club');if(!pair)return null;
  const other=pair.home==='club'?pair.away:pair.home;
  return {...opponent(c,other),format:1,label:`Liga · ${s.week+1}/5`,stage:'league'};
 }
 return {...opponent(c,s.playoffOpponent),format:3,label:s.stage==='semifinal'?'Yarim final · BO3':'Final · BO3',stage:s.stage};
}
function playerValue(p){return Math.max(800,Math.round((Math.max(0,overall(p)-50)**2*8+careerExperience(p)*30+Math.max(0,(p.potential||97)-overall(p))*15)/100)*100);}
export function market(c){
 const random=rand(c.seasonNumber*713+41),names=['RAVEN','NEXUS','KAI','BLITZ','SAFIR','ZEN'];
 return names.map((name,i)=>{const rookie=i%3===0,rating=clamp((rookie?52:77)+Math.floor(random()*(rookie?15:15))+(c.seasonNumber-1)*2,45,97);const p=makePlayer(`market-${c.seasonNumber}-${i}`,name,ROLES[i%5],rating,i);const progress=recruitProgress(rating,i);return {...p,...progress,price:playerValue({...p,...progress})};}).filter(p=>!c.roster.some(q=>q.id===p.id)&&!c.history.some(h=>h.type==='transfer'&&h.playerId===p.id));
}
function assertReady(c){if(c.pending)throw Error('Avval davom etayotgan uchrashuvni yakunlang.');}
export function trainPlayer(state,id,skill){
 assertReady(state);if(!SKILLS.includes(skill))throw Error('Mashg‘ulot turi tanlanmagan.');const c=copy(state),p=c.roster.find(p=>p.id===id);if(!p)throw Error('O‘yinchi topilmadi.');
 const cost=300+c.trainingLevel*100;if(c.credits<cost)throw Error('Mashg‘ulot uchun klub krediti yetarli emas.');if(p.energy<35)throw Error('O‘yinchi charchagan. Bir kun dam bering.');if(p.lastTrained===c.day)throw Error('Bu o‘yinchi bugun mashq qildi. Keyingi kunni boshlang.');if(p[skill]>=97)throw Error('Bu skill maksimal darajada.');
 const ceiling=Math.min(97,p.potential??97);if(p[skill]>=ceiling)throw Error('Bu skill salohiyatning maksimal darajasida.');const gain=Math.min(ceiling-p[skill],1+c.trainingLevel);post(c,'training',-cost,`${p.name} · ${SKILL_NAMES[skill]}`);ensureFinance(c).stats.training++;p[skill]+=gain;p.energy=Math.max(0,p.energy-12);p.morale=clamp(p.morale+2,0,100);p.xp+=20;p.lastTrained=c.day;c.xp+=10;news(c,`${p.name}: ${SKILL_NAMES[skill]} +${gain}.`);return c;
}
export function restDay(state){assertReady(state);const c=copy(state);c.day++;for(const p of c.roster){p.energy=Math.min(100,p.energy+24);p.morale=Math.min(100,p.morale+2);}news(c,'Jamoa dam oldi: energiya +24. Yangi kun boshlandi.');return c;}
export function upgradeTraining(state){assertReady(state);const c=copy(state);if(c.trainingLevel>=4)throw Error('Mashg‘ulot bazasi maksimal darajada.');const cost=c.trainingLevel*3000;if(c.credits<cost)throw Error('Bazani yaxshilash uchun kredit yetarli emas.');post(c,'facility',-cost,'Mashg‘ulot bazasini yaxshilash');c.trainingLevel++;news(c,`Mashg‘ulot bazasi ${c.trainingLevel}-darajaga ko‘tarildi.`);return c;}
export function buyPlayer(state,id,replaceId=null){
 assertReady(state);const p=market(state).find(p=>p.id===id);if(!p)throw Error('Bu taklif mavjud emas.');if(state.credits<p.price)throw Error('Transfer uchun kredit yetarli emas.');if(state.roster.length>=8)throw Error('Tarkibda ko‘pi bilan 8 o‘yinchi bo‘ladi. Avval birini soting.');
 const c=copy(state);post(c,'transfer-buy',-p.price,`${p.name} · transfer`);ensureFinance(c).stats.recruits++;const {price,...profile}=p;c.roster.push(profile);c.history.unshift({type:'transfer',playerId:p.id,name:p.name,price,day:c.day});c.history=c.history.slice(0,100);if(replaceId&&c.lineup.includes(replaceId))c.lineup=c.lineup.map(x=>x===replaceId?p.id:x);news(c,`${p.name} klubga qo‘shildi.`);return c;
}
export function sellPlayer(state,id){assertReady(state);if(state.lineup.includes(id))throw Error('Faol tarkibdagi o‘yinchini avval zaxiraga almashtiring.');if(state.roster.length<=5)throw Error('Klubda kamida besh o‘yinchi qolishi kerak.');const c=copy(state),p=c.roster.find(p=>p.id===id);if(!p)throw Error('O‘yinchi topilmadi.');const price=sellValue(p);c.roster=c.roster.filter(p=>p.id!==id);post(c,'transfer-sell',price,`${p.name} · sotish`);news(c,`${p.name} transferga ketdi. +${price} kredit.`);return c;}
export function sellValue(p){return Math.max(400,Math.round(playerValue(p)/200)*100);}
export function swapPlayer(state,slot,id){assertReady(state);const c=copy(state);if(!Number.isInteger(slot)||slot<0||slot>4||!c.roster.some(p=>p.id===id))throw Error('Tarkib tanlovi noto‘g‘ri.');if(c.lineup.includes(id)&&c.lineup[slot]!==id)throw Error('Bu o‘yinchi allaqachon faol tarkibda.');c.lineup[slot]=id;return c;}
export function setClubName(state,name){assertReady(state);const clean=String(name).trim().slice(0,24);if(clean.length<2)throw Error('Klub nomi kamida 2 belgidan iborat bo‘lsin.');const c=copy(state);c.clubName=clean;return c;}
export function updatePlan(state,plan){const c=copy(state);if(plan.map&&MAPS.some(m=>m.id===plan.map))c.settings.map=plan.map;if(['balanced','a','b','hold'].includes(plan.strategy))c.settings.strategy=plan.strategy;if(['T','CT'].includes(plan.side))c.settings.side=plan.side;if(['2d','3d'].includes(plan.quality))c.settings.quality=plan.quality;return c;}
function gameProfiles(c,enemy){
 const own=lineupPlayers(c).map(p=>({...p,skill:effective(p),aim:clamp(p.aim+experienceBonus(p)-(100-p.energy)*.1-(100-p.morale)*.04,20,99),reaction:clamp(p.reaction+experienceBonus(p)-(100-p.energy)*.08-(100-p.morale)*.03,20,99)}));
 const other=enemy.players.map((name,i)=>{const p=makePlayer(`enemy-${i}`,name,ROLES[i],enemy.rating,i);return {...p,skill:overall(p),matches:Math.max(5,(enemy.rating-65)*2+c.seasonNumber*4),xp:Math.max(0,enemy.rating-65)*80};});return {own,other};
}
export function startMatch(state,practice=false){
 assertReady(state);const c=copy(state),fixture=practice?{...opponent(c,'iron'),format:1,label:'Mashq uchrashuvi',stage:'practice'}:nextFixture(c);if(!fixture)throw Error('Mavsum yakunlangan. Yangi mavsumni boshlang.');
 const id=`s${c.seasonNumber}-m${c.nextMatch++}`;const first=MAPS.findIndex(m=>m.id===modernMapId(c.settings.map)),maps=Array.from({length:fixture.format},(_,i)=>MAPS[(Math.max(0,first)+i)%MAPS.length].id);const {own,other}=gameProfiles(c,fixture);
 const options={practice,map:maps[0],enemyStrategy:fixture.strategy||'balanced',strategy:c.settings.strategy,side:c.settings.side,rating:teamRating(c),ownSquad:own,enemySquad:other,teamNames:[c.clubName,fixture.name],seed:c.seasonNumber*17001+c.nextMatch*89};
 const game=new Match(options);game.careerToken=id+'-0';ensureFinance(c);c.pending={id,type:practice?'practice':'season',fixture,options,maps,mapIndex:0,mapResults:[],series:[0,0],snapshot:game.snapshot(),summary:{kills:0,deaths:0,players:Object.fromEntries(own.map(p=>[p.id,{kills:0,deaths:0}]))}};return c;
}
export function checkpoint(state,snapshot,token){if(!state.pending||(token&&token!==`${state.pending.id}-${state.pending.mapIndex}`)||snapshot.mapId!==state.pending.maps[state.pending.mapIndex])return state;const c=copy(state);if(c.pending.snapshot.state.careerToken&&snapshot.state?.careerToken&&c.pending.snapshot.state.careerToken!==snapshot.state.careerToken)return state;c.pending.snapshot=snapshot;return c;}
export function restartOnSourceMap(state){
 if(!state.pending)throw Error('Davom etayotgan uchrashuv yo‘q.');
 const c=copy(state),p=c.pending;p.maps=p.maps.map(modernMapId);
 const game=new Match({...p.options,map:p.maps[p.mapIndex],mapRevision:REFERENCE_REVISION});game.careerToken=`${p.id}-${p.mapIndex}`;p.snapshot=game.snapshot();
 return c;
}
function addTable(s,home,away,score){
 const a=s.table[home],b=s.table[away],win=score[0]>score[1];a.played++;b.played++;a.for+=score[0];a.against+=score[1];b.for+=score[1];b.against+=score[0];a.wins+=win?1:0;a.losses+=win?0:1;b.wins+=win?0:1;b.losses+=win?1:0;a.points+=win?3:0;b.points+=win?0:3;s.results.push({home,away,score,week:s.week+1});
}
function leagueWeek(c,score){
 const s=c.season,random=rand(c.seasonNumber*888+s.week*31+17);
 for(const pair of s.fixtures[s.week].pairs){let result;if(pair.home==='club')result=score;else if(pair.away==='club')result=[score[1],score[0]];else{const left=opponent(c,pair.home),right=opponent(c,pair.away),win=random()<clamp(.5+(left.rating-right.rating)*.035,.15,.85),loser=5+Math.floor(random()*7);result=win?[13,loser]:[loser,13];}addTable(s,pair.home,pair.away,result);}
 s.week++;if(s.week>=5){const table=orderedTable(c),place=table.findIndex(t=>t.id==='club')+1;s.placement=place;if(place<=4){s.stage='semifinal';const opponentId=table[place===1?3:place===4?0:place===2?2:1].id;s.playoffOpponent=opponentId;news(c,`Liga yakuni: ${place}-o‘rin. Yarim finalga chiqdingiz!`);}else finishSeason(c,place);}
}
function finishSeason(c,placement){const s=c.season;s.completed=true;s.stage='complete';s.placement=placement;const expected=placement<=2?7:placement<=4?6:5,participation=Math.min(1,ensureFinance(c).seasonCompleted/expected),basePrize=[0,9000,5500,3000,2400,1800,1200][placement]||1200;s.prize=Math.floor(basePrize*participation);post(c,'season',s.prize,'Mavsum sovrini',`season-${c.seasonNumber}-prize`);if(participation>0){if(placement===1)ensureFinance(c).stats.championships++;c.fans+=Math.floor((placement===1?300:100)*participation);c.reputation+=Math.floor((placement===1?5:1)*participation);c.xp+=Math.floor((placement===1?300:100)*participation);}news(c,`${s.number}-mavsum: ${placement}-o‘rin. Sovrin +${s.prize} tanga${participation<1?' · qatnashuvga mos':''}.`);}

function settleSeries(c,forfeit=false){
 const pending=c.pending;if(!pending||c.settled.includes(pending.id))return c;const won=pending.series[0]>pending.series[1],finance=settleFinance(c,pending,won,forfeit),reward=finance.net;c.xp+=finance.eligible?(won?120:65):0;c.fans=Math.max(0,c.fans+(forfeit?-25:finance.eligible?(won?70:15):0));c.totalMatches++;c.totalWins+=won?1:0;
 for(const p of c.roster){const stats=pending.summary.players[p.id];if(stats){p.kills+=stats.kills;p.deaths+=stats.deaths;p.matches++;p.energy=Math.max(10,p.energy-(pending.mapResults.length||1)*12);p.morale=clamp(p.morale+(won?5:-4),20,100);p.xp+=finance.eligible?(won?60:35):0;}}
 const record={id:pending.id,type:pending.type,opponent:pending.fixture.name,opponentId:pending.fixture.id,series:[...pending.series],maps:pending.mapResults,win:won,reward,day:c.day,season:c.seasonNumber,forfeit,finance};c.history.unshift(record);c.history=c.history.slice(0,100);c.settled.push(pending.id);c.settled=c.settled.slice(-150);c.day++;
 if(pending.type==='season'){
  if(c.season.stage==='league'){const score=forfeit?[0,13]:pending.mapResults[0].score;leagueWeek(c,score);}
  else if(c.season.stage==='semifinal'){if(won){const table=orderedTable(c).filter(t=>t.id!=='club'&&t.id!==pending.fixture.id);c.season.stage='final';c.season.playoffOpponent=table[0].id;news(c,'Finalga chiqdingiz. Chempionlik uchun BO3!');}else finishSeason(c,3);}
  else if(c.season.stage==='final')finishSeason(c,won?1:2);
 }
 news(c,`${pending.fixture.name}: ${won?'g‘alaba':'mag‘lubiyat'}${forfeit?' (taslim bo‘lish)':` · +${reward} kredit`}.`);c.pending=null;return c;
}
export function completeMap(state,snapshot){
 if(!state.pending)return state;const game=Match.restore(snapshot);if(game.phase!=='matchend'||game.outro>0)throw Error('Xarita hali tugamagan.');const c=copy(state),p=c.pending;
 const old=Match.restore(p.snapshot);if(old.careerToken&&game.careerToken!==old.careerToken)throw Error('Bu natija boshqa uchrashuvga tegishli.');if(old.map.id!==game.map.id||p.maps[p.mapIndex]!==game.map.id)throw Error('Uchrashuv xaritasi mos kelmadi.');
 const winner=game.score[0]>game.score[1]?0:1;p.series[winner]++;p.mapResults.push({map:game.map.id,score:[...game.score]});for(const member of game.players.filter(x=>x.team===0)){const id=member.profileId,stats=p.summary.players[id];if(stats){stats.kills+=member.kills;stats.deaths+=member.deaths;}p.summary.kills+=member.kills;p.summary.deaths+=member.deaths;}
 if(p.series[winner]>=Math.ceil(p.fixture.format/2))return settleSeries(c);
 p.mapIndex++;p.options={...p.options,map:p.maps[p.mapIndex],seed:p.options.seed+997};const nextGame=new Match(p.options);nextGame.careerToken=`${p.id}-${p.mapIndex}`;p.snapshot=nextGame.snapshot();return c;
}
export function abandonMatch(state){if(!state.pending)return state;const c=copy(state);c.pending.series=[0,Math.ceil(c.pending.fixture.format/2)];return settleSeries(c,true);}
export function nextSeason(state){assertReady(state);if(!state.season.completed)throw Error('Hozirgi mavsum hali tugamagan.');const c=copy(state);c.seasonNumber++;c.season=makeSeason(c.seasonNumber);ensureFinance(c).seasonCompleted=0;for(const p of c.roster){p.energy=100;p.morale=Math.max(85,p.morale);}news(c,`${c.seasonNumber}-mavsum boshlandi. Raqiblar kuchaydi.`);return c;}

export function validateCareer(value){
 const c=copy(value);const fail=()=>{throw Error('Zaxira fayli noto‘g‘ri yoki bu versiyaga mos emas.');};
 if(!c||c.schema!==SAVE_SCHEMA||typeof c.clubName!=='string'||c.clubName.length<2||c.clubName.length>24)fail();
 for(const key of ['credits','fans','reputation','xp','day','seasonNumber','trainingLevel','nextMatch','totalMatches','totalWins'])if(!Number.isInteger(c[key])||c[key]<0||c[key]>100000000)fail();
 if(c.day<1||c.seasonNumber<1||c.trainingLevel<1||c.trainingLevel>4||c.nextMatch<1||c.totalWins>c.totalMatches)fail();
 if(!Array.isArray(c.roster)||c.roster.length<5||c.roster.length>8||new Set(c.roster.map(p=>p.id)).size!==c.roster.length)fail();
 for(const p of c.roster){if(p.potential!==undefined&&(!Number.isInteger(p.potential)||p.potential<45||p.potential>99))fail();if(typeof p.id!=='string'||p.id.length>60||typeof p.name!=='string'||p.name.length>24||!ROLES.includes(p.role))fail();for(const key of [...SKILLS,'energy','morale','xp','kills','deaths','matches','lastTrained'])if(!Number.isInteger(p[key])||p[key]<0||p[key]>100000000)fail();for(const k of SKILLS)if(p[k]<20||p[k]>99)fail();if(p.energy>100||p.morale>100)fail();}
 if(!Array.isArray(c.lineup)||c.lineup.length!==5||new Set(c.lineup).size!==5||c.lineup.some(id=>!c.roster.some(p=>p.id===id)))fail();
 const s=c.season,ids=['club',...OPPONENTS.map(o=>o.id)];if(!s||s.number!==c.seasonNumber||!['league','semifinal','final','complete'].includes(s.stage)||!Number.isInteger(s.week)||s.week<0||s.week>5||typeof s.completed!=='boolean')fail();
 if(!s.table||Object.keys(s.table).length!==6)fail();for(const id of ids){const t=s.table[id];if(!t||t.id!==id)fail();for(const k of ['played','wins','losses','points','for','against'])if(!Number.isInteger(t[k])||t[k]<0||t[k]>10000)fail();}
 s.fixtures=makeSeason(s.number).fixtures;if(['semifinal','final'].includes(s.stage)&&!OPPONENTS.some(o=>o.id===s.playoffOpponent))fail();
 if(!Array.isArray(s.results)||s.results.length>15)fail();for(const r of s.results){if(!r||!ids.includes(r.home)||!ids.includes(r.away)||!Array.isArray(r.score)||r.score.length!==2||r.score.some(n=>!Number.isInteger(n)||n<0||n>1000))fail();}
 if(!Array.isArray(c.history)||c.history.length>100||!Array.isArray(c.settled)||c.settled.length>150||c.settled.some(id=>typeof id!=='string')||!Array.isArray(c.news)||c.news.length>12)fail();
 for(const n of c.news)if(!n||typeof n.id!=='string'||typeof n.text!=='string'||n.text.length>500||!Number.isInteger(n.day))fail();
 for(const h of c.history){if(!h||!['season','practice','transfer'].includes(h.type))fail();if(h.type==='transfer'){if(typeof h.playerId!=='string'||typeof h.name!=='string'||!Number.isInteger(h.price))fail();}else{if(typeof h.id!=='string'||typeof h.opponent!=='string'||typeof h.win!=='boolean'||!Number.isInteger(h.reward)||!Array.isArray(h.series)||h.series.length!==2||h.series.some(n=>!Number.isInteger(n)||n<0||n>2)||!Array.isArray(h.maps)||h.maps.length>3)fail();for(const m of h.maps)if(!m||!ALL_MAPS.some(x=>x.id===m.map)||!Array.isArray(m.score)||m.score.length!==2||m.score.some(n=>!Number.isInteger(n)||n<0||n>1000))fail();}}
 if(s.completed!==(s.stage==='complete')||(s.completed&&(!Number.isInteger(s.placement)||s.placement<1||s.placement>6||!Number.isInteger(s.prize)||s.prize<0)))fail();
 if(!c.settings||!ALL_MAPS.some(m=>m.id===c.settings.map)||!['a','b','hold','balanced'].includes(c.settings.strategy)||!['T','CT'].includes(c.settings.side)||!['2d','3d'].includes(c.settings.quality))fail();
 if(c.pending){const p=c.pending;if(typeof p.id!=='string'||!['practice','season'].includes(p.type)||!p.fixture||![1,3].includes(p.fixture.format)||!OPPONENTS.some(o=>o.id===p.fixture.id)||!Array.isArray(p.maps)||p.maps.length!==p.fixture.format||p.maps.some(id=>!ALL_MAPS.some(m=>m.id===id))||!Number.isInteger(p.mapIndex)||p.mapIndex<0||p.mapIndex>=p.maps.length||!Array.isArray(p.series)||p.series.length!==2||p.series.some(n=>!Number.isInteger(n)||n<0||n>2)||!Array.isArray(p.mapResults)||p.mapResults.length!==p.mapIndex||!p.summary?.players||!p.options)fail();if(typeof p.fixture.name!=='string'||p.fixture.name.length>24||typeof p.fixture.label!=='string'||p.fixture.label.length>60||!Array.isArray(p.fixture.players)||p.fixture.players.length!==5||p.fixture.players.some(n=>typeof n!=='string'||n.length>24))fail();if(!Number.isInteger(p.summary.kills)||!Number.isInteger(p.summary.deaths)||!Array.isArray(p.options.ownSquad)||p.options.ownSquad.length!==5||!Array.isArray(p.options.enemySquad)||p.options.enemySquad.length!==5)fail();for(const id of c.lineup){const stats=p.summary.players[id];if(!stats||!Number.isInteger(stats.kills)||stats.kills<0||!Number.isInteger(stats.deaths)||stats.deaths<0)fail();}const game=Match.restore(p.snapshot);p.snapshot=game.snapshot();if(game.map.id!==p.maps[p.mapIndex]||game.players.filter(q=>q.team===0).some(q=>!c.lineup.includes(q.profileId)))fail();}

 if(c.finance!==undefined&&(!c.finance||typeof c.finance!=='object'||Array.isArray(c.finance)))fail();
 for(const h of c.history)if(h.finance!==undefined){const f=h.finance;if(!f||typeof f!=='object'||['prize','sponsor','fans','support','salary','operations','gross'].some(k=>!Number.isSafeInteger(f[k])||f[k]<0||f[k]>100000000)||!Number.isSafeInteger(f.net)||Math.abs(f.net)>100000000||f.net!==h.reward||typeof f.eligible!=='boolean')fail();}
 validateFinance(c);return c;
}
export function exportCareer(c){return JSON.stringify({game:'ARENA',schema:SAVE_SCHEMA,savedAt:new Date().toISOString(),career:validateCareer(c)},null,2);}
export function importCareer(text){if(typeof text!=='string'||text.length>1000000)throw Error('Zaxira fayli juda katta.');let raw;try{raw=JSON.parse(text);}catch{throw Error('JSON zaxira fayli o‘qilmadi.');}return validateCareer(raw.game==='ARENA'?raw.career:raw);}
export function loadCareer(storage){
 let corrupt=false;for(const key of [SAVE_KEY,BACKUP_KEY]){try{const raw=storage.getItem(key);if(raw){const c=validateCareer(JSON.parse(raw));return {career:c,notice:corrupt?'Asosiy saqlash buzilgan edi. Zaxiradan tiklandi.':''};}}catch{corrupt=true;}}
 let rating=80;try{rating=Number(storage.getItem('arena-test-rating'))||80;}catch{}return {career:createCareer(rating),notice:corrupt?'Saqlangan ma’lumot o‘qilmadi. Yangi klub yaratildi; import orqali zaxirani tiklashingiz mumkin.':''};
}
export function saveCareer(storage,c){try{const data=JSON.stringify(c),previous=storage.getItem(SAVE_KEY);if(previous){try{validateCareer(JSON.parse(previous));storage.setItem(BACKUP_KEY,previous);}catch{}}storage.setItem(SAVE_KEY,data);return true;}catch{return false;}}

export function signSponsor(state,id){assertReady(state);const offer=SPONSORS.find(s=>s.id===id);if(!offer)throw Error('Homiy topilmadi.');const c=copy(state),f=ensureFinance(c);if(f.sponsor.remaining>0)throw Error('Hozirgi shartnoma tugashini kuting.');if(c.fans<offer.fans||c.reputation<offer.reputation)throw Error('Homiy uchun muxlis yoki obro‘ yetarli emas.');f.sponsor={id,remaining:offer.length};news(c,`${offer.name}: ${offer.length} rasmiy uchrashuvga shartnoma.`);return c;}
export function buyClubItem(state,id){assertReady(state);const item=SHOP.find(s=>s.id===id);if(!item)throw Error('Do‘kon mahsuloti topilmadi.');const c=copy(state),f=ensureFinance(c);if(f.owned.includes(id))throw Error('Bu bezak sizda bor.');if(c.credits<item.price)throw Error('Klub tangasi yetarli emas.');post(c,'shop',-item.price,item.name);f.owned.push(id);f[item.kind]=item.value;return c;}
export function equipClubItem(state,id){const item=SHOP.find(s=>s.id===id),c=copy(state),f=ensureFinance(c);if(!item||!f.owned.includes(id))throw Error('Avval bezakni oling.');f[item.kind]=item.value;return c;}
export function claimObjective(state,id){assertReady(state);const goal=OBJECTIVES.find(q=>q.id===id),c=copy(state),f=ensureFinance(c);if(!goal)throw Error('Vazifa topilmadi.');if(f.claimed.includes(id))throw Error('Mukofot avval olingan.');if(f.stats[goal.stat]<goal.target)throw Error('Vazifa hali bajarilmadi.');post(c,'objective',goal.reward,goal.name,'objective:'+id);f.claimed.push(id);return c;}
