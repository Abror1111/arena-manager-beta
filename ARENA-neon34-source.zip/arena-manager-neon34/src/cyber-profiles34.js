// Original ARENA palettes. Inspired by neon anime cities; no franchise assets.
export const CYBER34={
 dust2:{wall:'#cbb498',panel:'#256e7e',roof:'#36496e',ink:'#16233d',neon:'#54ffe4',accent:'#ff619e',sky:'#8b9db7',sun:'#ffe3bf'},
 mirage:{wall:'#d6b5c5',panel:'#385c88',roof:'#5b4576',ink:'#232342',neon:'#67e8ff',accent:'#ff9864',sky:'#9694b8',sun:'#ffe3d3'},
 inferno:{wall:'#ce9f95',panel:'#386c77',roof:'#773b59',ink:'#29223a',neon:'#62ffdb',accent:'#ffc462',sky:'#9c91a9',sun:'#ffddbf'},
 nuke:{wall:'#b9cedb',panel:'#344873',roof:'#263655',ink:'#17243b',neon:'#66dcff',accent:'#ffe668',sky:'#839db9',sun:'#e1eeff'},
 train:{wall:'#a8b6af',panel:'#414a70',roof:'#39394e',ink:'#192a38',neon:'#cbff62',accent:'#ff796b',sky:'#869bad',sun:'#ffe8cd'},
 ancient:{wall:'#99b6ad',panel:'#356761',roof:'#435b77',ink:'#192e3c',neon:'#65ffd8',accent:'#da88ff',sky:'#829eaf',sun:'#dfedcf'},
 'ancient-night':{wall:'#8199b3',panel:'#42446e',roof:'#343251',ink:'#142139',neon:'#80eaff',accent:'#ff85d5',sky:'#344567',sun:'#b9caff'},
 anubis:{wall:'#d8bf9d',panel:'#317a86',roof:'#514b7a',ink:'#263049',neon:'#74f5ff',accent:'#d59bff',sky:'#a59aaf',sun:'#fff0ca'},
 overpass:{wall:'#a9b8cb',panel:'#3d6375',roof:'#3e4664',ink:'#1a2c42',neon:'#82ffd1',accent:'#ffa26d',sky:'#8b9fb7',sun:'#dcecff'},
 vertigo:{wall:'#c2ccd7',panel:'#375e88',roof:'#40426b',ink:'#1d2d46',neon:'#79e8ff',accent:'#ffc66d',sky:'#8ca5c6',sun:'#f0eaff'},
 cache:{wall:'#b3bcaa',panel:'#3d6972',roof:'#4e4c68',ink:'#253447',neon:'#90ffe0',accent:'#ff927d',sky:'#929eb2',sun:'#f2e6c9'}
};
export const cyberProfile34=id=>CYBER34[id]||CYBER34.dust2;
