import * as T from 'three';
import {cyberProfile34} from './cyber-profiles34.js';

// Canvas-painted, repeatable ARENA surfaces: hard ink lines, graphic panels,
// hand-drawn service markings and small emissive circuits. No external art.
export function createCyberMaterials34(mapId,renderer){
 const p=cyberProfile34(mapId),tiles=new Map(),owned=new Set(),applied=new WeakSet();let changed=0,hidden=0;
 const aniso=Math.min(8,renderer.capabilities.getMaxAnisotropy());
 function canvas(){const c=document.createElement('canvas');c.width=c.height=512;return c;}
 function tex(c,name,color=true){const t=new T.CanvasTexture(c);if(color)t.colorSpace=T.SRGBColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=aniso;t.name='arena-anime34-'+mapId+'-'+name;owned.add(t);return t;}
 function surface(kind){
  if(tiles.has(kind))return tiles.get(kind);
  const c=canvas(),e=canvas(),g=c.getContext('2d'),light=e.getContext('2d');light.fillStyle='#000';light.fillRect(0,0,512,512);
  const base=kind==='metal'?p.panel:kind==='tile'?p.roof:kind==='paving'?p.panel:kind==='wood'?p.panel:p.wall;
  g.fillStyle=base;g.fillRect(0,0,512,512);if(kind==='tile'||kind==='paving'){g.fillStyle='#b9cbe23b';g.fillRect(0,0,512,512);}g.lineJoin='bevel';g.lineCap='square';
  const rect=(x,y,w,h,color=p.ink,line=4)=>{g.strokeStyle=color;g.lineWidth=line;g.strokeRect(x,y,w,h);};
  const line=(points,color=p.neon,width=5,emissive=false)=>{for(const q of emissive?[g,light]:[g]){q.strokeStyle=color;q.lineWidth=width;q.beginPath();points.forEach(([x,y],i)=>q[i?'lineTo':'moveTo'](x,y));q.stroke();}};
  const bolt=(x,y)=>{g.fillStyle=p.ink;g.beginPath();g.arc(x,y,5,0,Math.PI*2);g.fill();g.fillStyle='#d9e4ec';g.fillRect(x-2,y-1,4,2);};
  if(kind==='soil'){
   g.fillStyle=p.wall;g.fillRect(0,0,512,512);g.fillStyle='#24334a0a';for(let i=0;i<100;i++)g.fillRect((i*137)%512,(i*71)%512,7,2);
  }else if(kind==='plaster'){
   rect(5,5,502,502,p.ink+'55',2);line([[256,0],[256,512]],p.ink+'33',2);line([[0,320],[512,320]],p.ink+'44',2);
   g.fillStyle='#ffffff20';g.fillRect(12,12,488,8);g.fillStyle=p.panel;g.fillRect(375,357,97,111);rect(375,357,97,111,p.ink,3);for(let y=377;y<446;y+=13)line([[389,y],[458,y]],p.ink+'88',3);
   line([[389,456],[438,456]],p.neon,3,true);g.fillStyle=p.ink+'88';g.font='bold 14px monospace';g.fillText('AR-34',27,291);line([[34,33],[34,88]],p.accent,3,true);
  }else if(kind==='tile'){
   for(let y=0;y<512;y+=64){g.fillStyle=y%128?p.panel:p.roof;g.fillRect(0,y,512,60);line([[0,y+4],[512,y+4]],p.ink+'88',3);line([[0,y+10],[512,y+10]],'#b2c4df55',2);for(let x=40;x<512;x+=128)bolt(x,y+30);}
   line([[44,28],[44,160],[126,160],[126,350],[470,350]],p.neon,3,true);line([[430,36],[430,115],[470,115]],p.accent,3,true);rect(215,34,154,82,p.ink+'88',3);
   g.fillStyle='#dce8ee';g.font='bold 32px monospace';g.fillText('S-04',231,87);
  }else if(kind==='paving'){
   for(let y=0;y<512;y+=128)for(let x=0;x<512;x+=128){rect(x+2,y+2,124,124,p.panel,2);line([[x+9,y+9],[x+34,y+9]],'#8da2b54d',2);}
   for(let y=40;y<512;y+=120){g.fillStyle='#d3d4c580';g.fillRect(242,y,20,63);}line([[38,12],[38,156],[84,202],[84,500]],p.neon,3,true);
  }else if(kind==='stone'){
   for(let y=0;y<512;y+=128)for(let x=-128;x<512;x+=256){const off=(y/128%2)*128;rect(x+off+3,y+3,250,122,p.ink,4);line([[x+off+9,y+9],[x+off+245,y+9]],'#f4ecda77',3);}
   rect(207,178,98,156,p.panel,9);g.fillStyle=p.panel;g.fillRect(223,194,66,124);line([[255,203],[255,309]],p.neon,7,true);line([[240,226],[271,226]],p.accent,5,true);
  }else if(kind==='metal'){
   for(let y=0;y<512;y+=256)for(let x=0;x<512;x+=256){rect(x+8,y+8,240,240,p.ink,8);rect(x+18,y+18,220,220,'#bfcee155',2);for(const dx of[29,226])for(const dy of[29,226])bolt(x+dx,y+dy);for(let yy=72;yy<185;yy+=15)line([[x+42,y+yy],[x+213,y+yy]],p.ink,7);line([[x+45,y+205],[x+150,y+205]],p.neon,7,true);g.fillStyle='#dbe7ed';g.font='15px monospace';g.fillText('AR // 06',x+42,y+56);}
  }else{
   for(let x=0;x<512;x+=64){rect(x+3,3,58,506,p.ink,5);line([[x+12,18],[x+12,488]],'#f4c9bd44',3);bolt(x+32,30);bolt(x+32,480);}g.fillStyle=p.ink;g.fillRect(0,110,512,40);g.fillRect(0,360,512,40);line([[30,125],[215,125]],p.accent,5,true);
  }
  // Sparse screen-tone hatching, rather than noisy photographic grain.
  g.strokeStyle='#14223a08';g.lineWidth=1;for(let y=0;y<512;y+=32){g.beginPath();g.moveTo(0,y);g.lineTo(512,y+128);g.stroke();}
  const n=document.createElement('canvas');n.width=n.height=256;const ng=n.getContext('2d'),small=document.createElement('canvas');small.width=small.height=256;const sg=small.getContext('2d');sg.drawImage(c,0,0,256,256);const pixels=sg.getImageData(0,0,256,256).data,img=ng.createImageData(256,256),lum=(x,y)=>pixels[(((y+256)%256)*256+(x+256)%256)*4];for(let y=0;y<256;y++)for(let x=0;x<256;x++){const i=(y*256+x)*4;img.data.set([128+(lum(x-1,y)-lum(x+1,y))*.12,128+(lum(x,y-1)-lum(x,y+1))*.12,253,255],i);}ng.putImageData(img,0,0);
  const result={map:tex(c,kind),emissive:tex(e,kind+'-light'),normal:tex(n,kind+'-relief',false)};tiles.set(kind,result);return result;
 }
 function foliage(){if(tiles.has('leaf'))return tiles.get('leaf').map;const c=canvas(),g=c.getContext('2d');g.clearRect(0,0,512,512);for(let i=0;i<11;i++){g.save();g.translate(256,270);g.rotate(i*Math.PI*2/11);g.fillStyle=i%2?'#62afae':'#81bca3';g.strokeStyle=p.ink;g.lineWidth=5;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-84,-128,0,-238);g.quadraticCurveTo(62,-121,0,0);g.fill();g.stroke();g.strokeStyle='#c1e6ba';g.lineWidth=3;g.beginPath();g.moveTo(0,-12);g.lineTo(0,-216);g.stroke();g.restore();}const map=tex(c,'leaf');tiles.set('leaf',{map});return map;}
 return{apply(m){
  if(applied.has(m))return;applied.add(m);const name=[m.userData?.vmat?.Name,m.name,m.map?.name].filter(Boolean).join(' ').toLowerCase();
  const plant=/foliage|leaf|leaves|palm|grass|bush|vine|tree/.test(name)||/foliage/.test(m.userData?.vmat?.ShaderName||'');
  if(/decal|graffiti|signage|overlay|bombsite/.test(name)||(m.transparent&&!plant&&!/glass|water/.test(name))){m.visible=false;hidden++;return;}
  const glass=/glass|window_glass/.test(name),kind=m.userData.cyberGround34?'soil':/metal|steel|iron|container|pipe/.test(name)?'metal':/wood|crate|plank|pallet/.test(name)?'wood':/tile|roof/.test(name)?'tile':/asphalt|floor|ground|terrain|paving|road/.test(name)?'paving':/brick|rock|stone|concrete/.test(name)?'stone':'plaster';
  const tile=plant?null:surface(kind);m.map=plant?foliage():tile.map;m.normalMap=tile?.normal||null;m.normalScale?.set(.08,.08);m.lightMap=m.roughnessMap=m.metalnessMap=m.aoMap=m.alphaMap=m.bumpMap=null;m.emissiveMap=tile?.emissive||null;m.emissive?.set('#ffffff');m.emissiveIntensity=plant||kind==='soil'?0:mapId==='ancient-night'?.65:.32;m.color.setScalar(.95);m.vertexColors=false;m.roughness=kind==='metal'?.58:.88;m.metalness=kind==='metal'?.2:0;
  if(plant){m.transparent=false;m.alphaTest=.28;m.side=T.DoubleSide;m.depthWrite=true;}else if(glass){m.transparent=true;m.opacity=.4;m.color.set(p.neon);m.roughness=.18;m.emissiveIntensity=.12;}else{m.transparent=false;m.opacity=1;m.alphaTest=0;}
  const before=m.onBeforeCompile,key=m.customProgramCacheKey();m.onBeforeCompile=function(shader,r){before.call(this,shader,r);if(!shader.fragmentShader.includes('float animeLum34='))shader.fragmentShader=shader.fragmentShader.replace('#include <opaque_fragment>',`float animeLum34=dot(outgoingLight,vec3(.2126,.7152,.0722));
   float animeBand34=floor(animeLum34*7.+.5)/7.;
   outgoingLight*=mix(1.,animeBand34/max(.06,animeLum34),.18);
   float animeEdge34=smoothstep(.035,.24,abs(dot(normalize(vViewPosition),normal)));
   outgoingLight*=mix(.83,1.,animeEdge34);
   #include <opaque_fragment>`);};m.customProgramCacheKey=()=>key+'-arena-anime34';m.userData.cyber34=true;m.needsUpdate=true;changed++;
 },get changed(){return changed;},get hidden(){return hidden;},get textureCount(){return owned.size;},profile:'anime-neon34',dispose(){owned.forEach(t=>t.dispose());}};
}
