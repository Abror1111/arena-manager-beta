import * as T from 'three';

const markedMaterials=new WeakMap();
const stencilKeys=['stencilWrite','stencilRef','stencilFunc','stencilWriteMask','stencilFuncMask','stencilFail','stencilZFail','stencilZPass'];
function markVisible(material){
 const old=markedMaterials.get(material);
 if(old){old.users++;return;}
 const original=Object.fromEntries(stencilKeys.map(k=>[k,material[k]]));markedMaterials.set(material,{users:1,original});
 Object.assign(material,{stencilWrite:true,stencilRef:1,stencilFunc:T.AlwaysStencilFunc,stencilWriteMask:255,stencilFuncMask:255,stencilFail:T.KeepStencilOp,stencilZFail:T.KeepStencilOp,stencilZPass:T.ReplaceStencilOp});
}
function unmark(material){const state=markedMaterials.get(material);if(!state||--state.users)return;Object.assign(material,state.original);markedMaterials.delete(material);}

// Draw the actual animated body only where scene depth hides it. Normal visible
// pixels retain the source material; walls and smoke remain intact in the world.
export function createObserverSilhouette(root){
 const material=new T.MeshBasicMaterial({color:'#f2aa51',transparent:true,opacity:.74,depthWrite:false,depthTest:true,depthFunc:T.GreaterDepth,side:T.DoubleSide,toneMapped:false,stencilWrite:true,stencilRef:1,stencilFunc:T.NotEqualStencilFunc,stencilFail:T.KeepStencilOp,stencilZFail:T.KeepStencilOp,stencilZPass:T.KeepStencilOp});
 const sources=[];root.traverse(o=>{if(o.isMesh&&!o.userData.observerGhost)sources.push(o);});
 // Visible actor pixels veto the overlay, including the actor's own rear faces.
 // A depth-only overlay would paint those rear faces over the normal visible skin.
 const originals=new Set(sources.flatMap(o=>Array.isArray(o.material)?o.material:[o.material]));originals.forEach(markVisible);
 const ghosts=sources.map(source=>{
  const priorOrder=source.renderOrder;
  // Mark visibility after opaque map geometry has finished writing depth.
  // Otherwise a later wall can cover actor pixels already marked in stencil.
  source.renderOrder=Math.max(10,priorOrder);
  const mesh=source.isSkinnedMesh?new T.SkinnedMesh(source.geometry,material):new T.Mesh(source.geometry,material);
  if(source.isSkinnedMesh){mesh.bindMode=source.bindMode;mesh.bind(source.skeleton,source.bindMatrix);}
  mesh.morphTargetInfluences=source.morphTargetInfluences;mesh.morphTargetDictionary=source.morphTargetDictionary;
  mesh.name='observer-occluded-body';mesh.userData.observerGhost=true;mesh.frustumCulled=false;mesh.renderOrder=32;
  mesh.matrixAutoUpdate=false;source.parent.add(mesh);return{source,mesh,priorOrder};
 });
 let team=null;
 return{count:ghosts.length,update(player){if(player.team!==team){team=player.team;material.color.set(team?'#55c5ff':'#ffb53f');}for(const {source,mesh}of ghosts){source.updateMatrix();mesh.matrix.copy(source.matrix);mesh.visible=source.visible&&player.alive;}},dispose(){ghosts.forEach(({source,mesh,priorOrder})=>{source.renderOrder=priorOrder;mesh.removeFromParent();});originals.forEach(unmark);material.dispose();}};
}
