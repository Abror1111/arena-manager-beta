export const atlas={columns:1,rows:1,cell:64,padding:0,width:64,sprites:{blast:{blend:'normal'}}};export const spriteFrame=()=>-1;
