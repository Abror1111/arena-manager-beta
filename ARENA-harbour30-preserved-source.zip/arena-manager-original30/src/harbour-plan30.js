// Independently authored ARENA port plan, in plan-percent coordinates (1.2m/unit).
// Neither source-game vertices, navigation nor a traced radar are used here.
export const SITES30=[{label:'A',p:[18,40],name:'Nasos stansiyasi'},{label:'B',p:[79,69],name:'Quruq dok'}];
export const SPAWNS30=[[32,90],[57,20]];
export const OUTLINE30=[[9,7],[42,7],[42,12],[68,12],[68,7],[94,7],[94,43],[90,43],[90,77],[86,77],[86,94],[14,94],[14,82],[8,82],[8,55],[5,55],[5,26],[9,26]];
export const DISTRICTS30=[
{id:'marina-edge',h:5.8,style:3,color:'cream',p:[[6,29],[12,29],[12,38],[10,40],[12,43],[12,52],[6,52]]},
{id:'pump-archive',h:6.5,style:1,color:'sand',p:[[25,27],[35,27],[35,33],[31,36],[25,36]]},
{id:'west-cistern',h:7,style:4,color:'cream',p:[[7,12],[25,12],[27,14],[27,20],[7,20]]},
{id:'auction-hall',h:7.2,style:1,color:'cream',p:[[30,20],[44,20],[44,33],[28,33],[27,29],[27,23]]},
{id:'customs-office',h:8,style:0,color:'sand',p:[[46,13],[52,13],[52,28],[50,31],[46,31]]},
{id:'signal-house',h:9,style:3,color:'cream',p:[[65,10],[72,10],[72,22],[69,25],[64,24],[64,14]]},
{id:'east-radio',h:7,style:0,color:'cream',p:[[84,12],[93,12],[93,37],[87,37],[84,33]]},
{id:'east-warehouse',h:6.2,style:4,color:'sand',p:[[86,45],[90,45],[90,61],[84,61],[84,49]]},
{id:'dock-edge',h:5.5,style:3,color:'cream',p:[[86,73],[89,73],[89,84],[85,84],[85,76]]},
{id:'dock-hangar',h:6.5,style:4,color:'cream',p:[[64,90],[83,90],[83,94],[64,94]]},
{id:'south-workshop',h:6,style:3,color:'sand',p:[[15,85],[23,85],[23,94],[15,94]]},
{id:'western-market',h:7.1,style:1,color:'cream',p:[[24,70],[35,70],[37,72],[37,82],[24,82]]},
{id:'market-workshops',h:5.8,style:3,color:'sand',p:[[31,56],[43,56],[43,66],[34,66],[31,63]]},
{id:'southern-arcade',h:6.7,style:1,color:'cream',p:[[45,74],[59,74],[59,82],[48,82],[45,79]]},
{id:'northeast-houses',h:8,style:0,color:'cream',p:[[62,31],[75,31],[75,43],[67,43],[61,39]]},
{id:'west-arcade',h:6,style:1,color:'sand',p:[[32,43],[44,43],[44,48],[31,48],[31,45]]},
{id:'service-island',h:5.4,style:3,color:'sand',p:[[56,39],[61,39],[61,45],[57,45],[55,43]]},
{id:'dock-office',h:5.8,style:4,color:'cream',p:[[71,58],[75,58],[75,64],[70,64],[70,60]]}
];
export const ROUTES30=[
{id:'A PROMENADE',site:0,side:'T',lane:0,p:[[32,90],[26,84],[18,82],[18,67],[18,55],[18,40]]},
{id:'A VIADUCT',site:0,side:'T',lane:1,p:[[32,90],[40,86],[40,70],[52,70],[55,62],[58,56],[69,52],[68,52],[60,52,4.6],[40,52,4.6],[32,52,2.8],[22,52],[18,40]]},
{id:'B WORKSHOPS',site:1,side:'T',lane:0,p:[[32,90],[40,86],[40,70],[52,70],[60,70],[69,68],[79,69]]},
{id:'B GANTRY',site:1,side:'T',lane:1,p:[[32,90],[40,86],[40,70],[52,70],[55,62],[58,56],[69,48],[77,42],[81,43],[81,57],[79,69]]},
{id:'CT A',site:0,side:'CT',lane:0,p:[[57,20],[57,34],[51,36],[47,41],[39,41],[29,41],[18,40]]},
{id:'CT B',site:1,side:'CT',lane:0,p:[[57,20],[58,29],[79,28],[81,42],[81,57],[79,69]]},
{id:'DOCK STAIRS',site:1,side:'rotation',lane:0,p:[[51,49],[58,56],[61,60],[69,60],[69,66],[79,69]]}
];
export const INTERIORS30=[{id:'market-gallery',p:[[38,67],[54,67],[54,72],[38,72]],h:4.6},{id:'pump-canopy',p:[[14,34],[23,34],[23,37],[14,37]],h:7.2}];
export const DOORS30=[{id:'PUMP GATE',p:[35,41],yaw:Math.PI/2,width:4.4,h:4.5},{id:'MARKET GATE',p:[44,70],yaw:Math.PI/2,width:4.8,h:4.3},{id:'DOCK GATE',p:[81,55],yaw:0,width:4.8,h:4.5}];
export const WALLS30=[{id:'pump-north',a:[35,33],b:[35,39.166667],h:4.5},{id:'pump-south',a:[35,42.833333],b:[35,43],h:4.5},{id:'market-north',a:[44,66],b:[44,68],h:4.3},{id:'market-south',a:[44,72],b:[44,74],h:4.3},{id:'dock-west',a:[75,55],b:[79,55],h:4.5},{id:'dock-east',a:[83,55],b:[86,55],h:4.5}];
export const COVERS30=[[16,37.5,1.3],[22,42,1.5],[25,51,1.2],[77,66,1.4],[82,70,1.2],[70,71,1.3],[52,47,1.2],[47,59,1.3],[60,27,1.1],[21,62,1.2],[34,86,1.4],[73,49,1.2]];
export const PALMS30=[[6,30,7],[6,55,8],[10,78,7],[12,96,8],[35,98,7],[58,98,8],[97,45,8],[93,72,7],[88,8,7],[23,24,6],[25,40,6],[83,79,7]];
export const LANDMARK_WALLS30=[[13,32,24,32,1.0],[25,47,25,54,1.1],[72,81,83,81,1.0],[70,66,70,68,1.1]];
export const BRIDGE_COLUMNS30=[[42,50],[42,54],[58,50],[58,54]];
export const BRIDGE30=[{x0:40,x1:60,z0:50,z1:54,y:4.6}];
export const STAIRS30=[{id:'promenade-north',axis:'z',start:25,end:30,x0:13,x1:23,z0:25,z1:30,low:1,high:2.8,steps:12},{id:'viaduct-west',axis:'x',start:32,end:40,x0:32,x1:40,z0:50,z1:54,low:2.8,high:4.6,steps:12},{id:'viaduct-east',axis:'x',start:68,end:60,x0:60,x1:68,z0:50,z1:54,low:1,high:4.6,steps:24},{id:'dock-stairs',axis:'x',start:61,end:69,x0:61,x1:69,z0:58,z1:62,low:1,high:4,steps:20}];
export const ROADS30=[[[38,34],[57,34],[57,43],[38,43]],[[38,65],[61,65],[61,73],[38,73]],[[77,25],[84,25],[84,59],[77,59]],[[13,57],[23,57],[23,88],[13,88]]];
