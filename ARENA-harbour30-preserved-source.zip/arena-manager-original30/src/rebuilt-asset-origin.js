export const REBUILT_ASSET_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/90563479fc575c7c1cda4a9ee5827b5388b3741e/rebuilt131/";
