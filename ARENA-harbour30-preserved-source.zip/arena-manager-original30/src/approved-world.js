export function addApprovedWorld(){throw Error('Original beta supports authored geometry only.')}export function approvedInspectionFrame(){return null}
