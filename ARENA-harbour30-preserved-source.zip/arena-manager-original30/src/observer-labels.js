// Keep portrait pins near their actual actors; use compact neighbouring columns
// when a spawn is crowded instead of lifting a name across the entire map.
export function placeObserverLabels(items,width,height){
 const stepX=Math.max(38,...items.map(p=>p.name.length*6+20))+5;
 const placed=[],clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
 for(const item of [...items].sort((a,b)=>Number(b.selected)-Number(a.selected)||a.y-b.y||a.id-b.id)){
  const w=Math.max(38,item.name.length*6+20),h=item.height||18,candidates=[];
  for(const dy of [0,-(h+4),h+4,-2*(h+4),2*(h+4)])for(const dx of [0,-stepX,stepX]){
   const x=clamp(item.x+dx,w/2+4,width-w/2-4),bottom=clamp(item.y+dy,h+4,height-4);
   const collisions=placed.filter(p=>Math.abs(p.x-x)<(p.width+w)/2+3&&Math.abs(p.bottom-bottom)<(p.height+h)/2+3).length;
   candidates.push({x,bottom,cost:collisions*1e6+(x-item.x)**2+(bottom-item.y)**2});
  }
  candidates.sort((a,b)=>a.cost-b.cost);const best=candidates[0];
  placed.push({...item,x:best.x,bottom:best.bottom,width:w,height:h,lift:item.y-best.bottom,anchorX:item.x,anchorY:item.y});
 }
 return placed;
}
