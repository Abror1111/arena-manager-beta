// Smoke ownership follows the club, including after a side switch.
export const TEAM_SMOKE=['#e6bf40','#529bff'];
export function smokeColor(game,e){const team=e.team??game.players[e.owner]?.team;return TEAM_SMOKE[team]||'#b4bfbb';}
