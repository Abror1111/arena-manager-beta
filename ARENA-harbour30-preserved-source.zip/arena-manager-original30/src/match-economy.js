import {WEAPONS} from './weapons.js';
import {winTarget} from './match-rules.js';
export const BUY_LABELS={auto:'Avtomatik',pistol:'Pistolet',full:'To‘liq xarid',semi:'Yarim xarid',eco:'Tejam',force:'Majburiy xarid'};
export const UTILITY_PRICES={he:300,smoke:300,flash:200,fire:400};
export function ensureEconomy(g){return g.economy??={lossStreak:[0,0],policy:['auto','auto'],buy:['pistol','pistol'],spent:[0,0],income:[0,0]};}
export function validEconomy(e){return !!e&&['lossStreak','policy','buy','spent','income'].every(k=>Array.isArray(e[k])&&e[k].length===2)&&e.lossStreak.every(n=>Number.isInteger(n)&&n>=0&&n<=5)&&e.policy.every(p=>['auto','eco','force','full'].includes(p))&&e.buy.every(p=>Object.hasOwn(BUY_LABELS,p))&&['spent','income'].every(k=>e[k].every(n=>Number.isInteger(n)&&n>=0&&n<=100000));}
export const killReward=id=>id==='knife'?1500:id==='awp'?100:id==='zeus'?0:WEAPONS[id]?.family==='shotgun'?900:WEAPONS[id]?.family==='smg'&&id!=='p90'?600:300;
export function equipmentValue(p){return (WEAPONS[p.weapon]?.price||0)+(p.armor>0?(p.helmet?1000:650):0)+(p.kit?400:0)+Object.entries(p.grenades||{}).reduce((n,[k,v])=>n+v*(k==='fire'&&p.side==='CT'?500:UTILITY_PRICES[k]||0),0);}
export function buyTeam(g,team,oldEquipment,reset){
 const economy=ensureEconomy(g),crew=g.players.filter(p=>p.team===team),pistol=g.round===1||g.round===13;
 if(reset)economy.lossStreak[team]=0;
 for(const p of crew){const old=oldEquipment[p.id],keep=old?.alive&&!reset;
  p.weapon=keep&&old.weapon?old.weapon:p.side==='T'?'glock':'usp';p.armor=keep?old.armor:0;p.helmet=keep?!!old.helmet:false;p.kit=keep&&p.side==='CT'?!!old.kit:false;p.grenades=keep?{...old.grenades}:{he:0,smoke:0,flash:0,fire:0};p.purchaseSpent=0;p.giftFrom=null;
 }
 const funded=crew.filter(p=>WEAPONS[p.weapon].price>=1050||p.money>=(p.side==='T'?3600:3800)).length,mean=crew.reduce((n,p)=>n+p.money,0)/5,matchPoint=g.score[1-team]>=winTarget(g.score)-1;
 const mode=pistol?'pistol':economy.policy[team]!=='auto'?economy.policy[team]:funded>=3?'full':matchPoint?'force':mean>=2300&&economy.lossStreak[team]>=2?'force':funded>=2&&mean>=1800?'semi':'eco';economy.buy[team]=mode;economy.spent[team]=0;
 const spend=(p,cost)=>{if(p.money<cost)return false;p.money-=cost;p.purchaseSpent+=cost;economy.spent[team]+=cost;return true;};
 const awper=crew.filter(p=>p.role==='Snayper').sort((a,b)=>(b.aim??b.skill)-(a.aim??a.skill))[0]||crew[2];
 for(const p of crew){
  if(WEAPONS[p.weapon].price<1050&&!pistol&&mode!=='eco'){
   const rifle=p.side==='T'?'ak':'m4',budget=p.money-(mode==='full'?950:650),gun=p===awper&&budget>=4750?'awp':budget>=WEAPONS[rifle].price?rifle:budget>=(p.side==='T'?1800:1950)?p.side==='T'?'galil':'famas':budget>=(p.side==='T'?1050:1250)?p.side==='T'?'mac10':'mp9':mode==='force'&&budget>=700?'deagle':null;
   if(gun&&spend(p,WEAPONS[gun].price))p.weapon=gun;
  }
 }
 // Rich teammates buy an extra rifle for an underfunded teammate during full buys.
 if(mode==='full')for(const receiver of crew.filter(p=>WEAPONS[p.weapon].price<1050)){
  const gun=receiver.side==='T'?'ak':'m4',donor=crew.filter(p=>p!==receiver&&WEAPONS[p.weapon].price>=1050&&p.money>=WEAPONS[gun].price+650).sort((a,b)=>b.money-a.money)[0];
  if(donor&&spend(donor,WEAPONS[gun].price)){receiver.weapon=gun;receiver.giftFrom=donor.id;}
 }
 let kits=crew.filter(p=>p.kit).length;
 for(const p of [...crew].sort((a,b)=>(a.role==='Support'?-1:0)-(b.role==='Support'?-1:0)||a.id-b.id)){
  const reserve=mode==='eco'?Math.max(0,p.money-300):0;
  const purchase=(cost,action)=>{if(p.money-cost<reserve||!spend(p,cost))return false;action();return true;};
  if(mode!=='eco'&&p.armor<70&&(mode!=='pistol'||['Entry','Rifler'].includes(p.role)||(!p.role&&p.id%5<2))){const helmet=mode==='full'&&p.money>=1000;purchase(helmet?1000:650,()=>{p.armor=100;p.helmet=helmet||p.helmet;});}
  if(mode==='full'&&!p.helmet&&p.armor>=70)purchase(350,()=>{p.helmet=true;});
  if(p.side==='CT'&&!p.kit&&kits<2&&['full','force','semi'].includes(mode))purchase(400,()=>{p.kit=true;kits++;});
  const order=p.role==='Support'?['smoke','flash','fire','he']:p.role==='Snayper'?['smoke','flash','he','fire']:p.role==='Entry'?['flash','he','smoke','fire']:['smoke','he','flash','fire'];
  for(const kind of order)if(!p.grenades[kind])purchase(kind==='fire'&&p.side==='CT'?500:UTILITY_PRICES[kind],()=>{p.grenades[kind]=1;});
  p.ammo=WEAPONS[p.weapon].mag;p.reserve=WEAPONS[p.weapon].reserve;
 }
}
export function awardRound(g,winner,reason){
 const e=ensureEconomy(g);e.income=[0,0];const tTeam=g.players.find(p=>p.side==='T').team,planted=['planted','defused','exploded'].includes(g.bomb.state);
 const winReward=['defused','exploded'].includes(g.bomb.state)?3500:3250;
 for(let team=0;team<2;team++){
  e.lossStreak[team]=team===winner?Math.max(0,e.lossStreak[team]-1):Math.min(5,e.lossStreak[team]+1);
  for(const p of g.players.filter(p=>p.team===team)){
   let reward=team===winner?winReward:1400+Math.max(0,e.lossStreak[team]-1)*500;
   if(team!==winner&&team===tTeam&&p.alive&&reason==='Vaqt tugadi')reward=0;
   if(team!==winner&&team===tTeam&&planted)reward+=800;
   const received=Math.min(16000-p.money,reward);p.money+=received;p.roundIncome=received;e.income[team]+=received;
  }
 }
}
