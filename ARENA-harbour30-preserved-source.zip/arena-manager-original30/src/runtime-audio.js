import studio from'./studio-audio.json';export const runtimeAudio=studio;
