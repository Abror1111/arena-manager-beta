import * as T from 'three';
import {environmentProfile} from './environment-profiles132.js';
import {sourceWater,waterAt} from './water-surface.js';
import {grenadePosition} from './grenade-physics.js';
export function createWater(scene,map,{mobile=false,reducedMotion=false,interactionOnly=false}={}){
 const rows=sourceWater(map),meshes=[],ripples=[],steps=new Map(),seen=new WeakSet(),flights=new WeakMap(),cx=map.width/2,cz=map.height/2;
 const profile=environmentProfile(map);const uniforms={skyTop:{value:new T.Color(profile.sky)},skyHorizon:{value:new T.Color(profile.horizon)},clock:{value:0},clipHeight:{value:1000},tint:{value:new T.Color(map.id==='train'?'#79805a':map.id==='ancient'?'#438779':'#4394a1')},rings:{value:Array.from({length:12},()=>new T.Vector4(0,0,-99,0))}};
 const material=new T.ShaderMaterial({uniforms,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,side:T.DoubleSide,
 vertexShader:'varying vec3 world;void main(){world=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:`uniform float clock,clipHeight;uniform vec3 tint,skyTop,skyHorizon;uniform vec4 rings[12];varying vec3 world;
 void main(){if(world.y>clipHeight+.02)discard;vec2 p=world.xz;float waves=sin(p.x*3.7+clock*.72)*sin(p.y*4.1-clock*.49),shine=pow(max(0.,sin(p.x*8.+p.y*5.-clock*.8)*cos(p.y*6.-clock*.6)),10.);vec3 color=tint*(.94+waves*.055)+vec3(.55,.67,.64)*shine*.33;float foam=0.;
 for(int i=0;i<12;i++){float age=clock-rings[i].z;if(age<0.||age>2.2)continue;float d=distance(p,rings[i].xy),ring=exp(-pow((d-age*.65-.05)*25.,2.))*(1.-age/2.2)*rings[i].w;foam+=ring;color+=vec3(.27,.35,.32)*ring;}
 vec3 normal=normalize(vec3(-cos(p.x*3.7+clock*.72)*sin(p.y*4.1-clock*.49)*.07,1.,-sin(p.x*3.7+clock*.72)*cos(p.y*4.1-clock*.49)*.07)),view=normalize(cameraPosition-world),reflection=reflect(-view,normal);float fresnel=.025+.975*pow(1.-max(0.,dot(view,normal)),4.);vec3 sky=mix(skyHorizon,skyTop,smoothstep(0.,.8,reflection.y));color=mix(color,sky,fresnel*.72);color+=vec3(.8,.83,.72)*pow(max(0.,dot(reflection,normalize(vec3(-.43,.68,-.52)))),72.)*.22;gl_FragColor=vec4(color,clamp(.43+fresnel*.3+shine*.12+foam*.12,.43,.8));
 ${interactionOnly?'gl_FragColor=vec4(vec3(.8,.9,.88),clamp(foam*.5,0.,.7));if(gl_FragColor.a<.002)discard;':''}
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
 }`});
 for(const row of rows){const p=new Float32Array(row.positions);for(let i=0;i<p.length;i+=3){p[i]-=cx;p[i+2]-=cz;}const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(p,3));geometry.computeBoundingSphere();const mesh=new T.Mesh(geometry,material);mesh.name='source-water-surface';mesh.renderOrder=2;scene.add(mesh);meshes.push(mesh);}
 const capacity=rows.length?(reducedMotion?48:mobile?96:160):0,particles=Array.from({length:capacity},()=>({end:-1})),matrix=new T.Matrix4(),rotation=new T.Quaternion(),scale=new T.Vector3(),position=new T.Vector3(),plane=new T.Plane(new T.Vector3(0,-1,0),1000);
 const sprayGeometry=new T.SphereGeometry(1,5,3),sprayMaterial=new T.MeshBasicMaterial({color:'#c5eeed',transparent:true,opacity:.72,depthWrite:false,clippingPlanes:[plane]}),spray=new T.InstancedMesh(sprayGeometry,sprayMaterial,capacity);spray.name='water-spray';spray.instanceMatrix.setUsage(T.DynamicDrawUsage);spray.frustumCulled=false;spray.count=0;if(capacity)scene.add(spray);let cursor=0,splashes=0;
 const ripple=(x,z,time,power)=>{ripples.push(new T.Vector4(x-cx,z-cz,time,power));if(ripples.length>12)ripples.shift();};
 function splash(x,z,y,time,power){
  ripple(x,z,time,Math.min(2,power));splashes++;const count=Math.min(capacity,Math.ceil(6+power*13));
  for(let i=0;i<count;i++){const p=particles[cursor++%capacity],angle=i*2.399963+splashes*.7,spread=.2+((i*7)%11)/11,life=.35+Math.min(1.2,power)*.28;Object.assign(p,{x:x-cx,z:z-cz,y:y+.025,time,end:time+life,vx:Math.sin(angle)*spread*power,vz:Math.cos(angle)*spread*power,vy:(1.2+spread*1.3)*Math.sqrt(power)*(reducedMotion?.5:1),size:.018+Math.min(power,2)*.012});}
 }
 return{surfaces:rows.length,get splashes(){return splashes;},get particles(){return spray.count;},capacity,material,update(time,players,effects,clipHeight){if(!rows.length)return;uniforms.clock.value=time;uniforms.clipHeight.value=clipHeight;plane.constant=clipHeight;
  const alive=new Set();for(const p of players){alive.add(p.id);const y=waterAt(map,p.x,p.z,p.y),last=steps.get(p.id);if(!p.alive||!p.moving||y===null){steps.delete(p.id);continue;}if(!last||Math.hypot(p.x-last.x,p.z-last.z)>.35){splash(p.x,p.z,y,time,.22);steps.set(p.id,{x:p.x,z:p.z});}}for(const id of steps.keys())if(!alive.has(id))steps.delete(id);
  for(const e of effects){
   if(e.kind==='grenade'){const p=grenadePosition(e,map.playerScale||1),last=flights.get(e),y=waterAt(map,p.x,p.z,p.y);if(!seen.has(e)&&y!==null&&p.y<=y+.09&&p.y>=y-.65&&(!last||last.y>y+.09)){seen.add(e);splash(p.x,p.z,y,time,.7);}flights.set(e,p);}
   else if(['he','c4'].includes(e.kind)&&!seen.has(e)){seen.add(e);const y=waterAt(map,e.x,e.z,e.y??null);if(y!==null)splash(e.x,e.z,y,time,e.kind==='c4'?3:1.8);}
  }
  for(let i=0;i<12;i++){const r=ripples[i];if(r)uniforms.rings.value[i].copy(r);else uniforms.rings.value[i].set(0,0,-99,0);}
  let active=0;for(const p of particles){if(time<p.time||time>=p.end)continue;const t=time-p.time,y=p.y+p.vy*t-3.9*t*t;if(y<p.y-.02)continue;position.set(p.x+p.vx*t,y,p.z+p.vz*t);const fade=Math.min(1,(p.end-time)*6);scale.set(p.size*fade,p.size*(1.5+Math.abs(p.vy-7.8*t)*.3)*fade,p.size*fade);matrix.compose(position,rotation,scale);spray.setMatrixAt(active++,matrix);}spray.count=active;spray.instanceMatrix.needsUpdate=true;
 },dispose(){for(const m of meshes){m.removeFromParent();m.geometry.dispose();}material.dispose();spray.removeFromParent();spray.dispose();sprayGeometry.dispose();sprayMaterial.dispose();steps.clear();ripples.length=0;}};
}
