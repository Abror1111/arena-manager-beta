import equipmentIcons from './equipment-icons.json' with {type:'json'};
import {WEAPONS} from './weapons.js';
import React,{memo} from 'react';

const rosterNames=['ACE','NOVA','SHADOW','REX','ECHO','PIXEL','RAVEN','NEXUS','KAI','BLITZ','SAFIR','ZEN'];
export function portraitIndex(identity,index=0){const known=rosterNames.indexOf(String(identity||'').toUpperCase());if(known>=0)return known;const starter=String(identity||'').match(/^starter-(\d+)$/);if(starter)return Number(starter[1])%16;const market=String(identity||'').match(/^market-\d+-(\d+)$/);if(market)return(6+Number(market[1]))%16;if(identity===undefined)return Math.abs(Number(index)||0)%16;let h=2166136261;for(const c of String(identity))h=Math.imul(h^c.charCodeAt(0),16777619);return(h>>>0)%16;}
export const PlayerAvatar=memo(function PlayerAvatar({index=0,team=0,identity}){
 const n=portraitIndex(identity,index+team*5);
 return <span className="player-photo player-art" aria-hidden="true" data-portrait={n} style={{display:'block',width:'100%',height:'100%',backgroundImage:`url(${new URL('../ui15/anime-player-portraits.png',document.baseURI).href})`,backgroundSize:'400% 400%',backgroundPosition:`${(n%4)*100/3}% ${Math.floor(n/4)*100/3}%`}}/>;
});

const paths={
 play:'m9 5 11 7-11 7Z',pause:'M8 5v14M16 5v14',
 static:'M3 5h18v14H3ZM8 9h8v6H8Z',auto:'M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M9 9l7 3-7 3Z',
 player:'M15 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM5 21v-3a7 7 0 0 1 14 0v3',
 settings:'M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M10 15v6',back:'m14 5-7 7 7 7',
 he:'M15 4h3M14 3l2 5M7 10a7 7 0 1 0 10-1l-5-4-5 5ZM8 13h8M9 18h6',
 smoke:'M5 20h14M7 20V10h10v10M9 6q-3-3 1-5M14 7q4-3 1-6',
 flash:'m14 2-9 12h6l-1 8 9-13h-6Z',
 fire:'M12 2q2 7 7 10c5 10-17 15-15 1q1-5 4-7 0 5 2 6 3-4 2-10Z',
};
export function UIIcon({name}){if(equipmentIcons[name])return <img className={`ui-icon equipment-icon icon-${name}`} src={equipmentIcons[name].url} alt="" aria-hidden="true"/>;return <svg className={`ui-icon icon-${name}`} viewBox="0 0 24 24" fill={name==='play'?'currentColor':'none'} stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]||paths.settings}/></svg>;}
export function WeaponIcon({weapon}){const f=WEAPONS[weapon]?.family;const d=weapon==='knife'?'M8 19 29 4l31-2-18 13-13 1-13 8Z':f==='pistol'?'M10 5h39v8H31l-5 10H15l4-12h-9Z':f==='sniper'?'M2 9h14V7h17V3h14v3H35v3h27v3H34l-5 9h-5v-9H13l-2 6H4l2-6H2Z':f==='shotgun'?'M2 8h59v5H30l-4 8h-6l1-8H13l-3 6H3l3-6H2Z':f==='smg'?'M9 6h30v3h18v4H33v9h-7V12H18l-3 9H8l3-10H9Z':'M3 8h11V5h24v3h21v3H37l-5 8h-6l1-8h-9l-2 5H9l1-5H3Z';return <svg className="weapon-icon" data-weapon={weapon} viewBox="0 0 64 24" fill="currentColor" aria-hidden="true"><path d={d}/></svg>}
