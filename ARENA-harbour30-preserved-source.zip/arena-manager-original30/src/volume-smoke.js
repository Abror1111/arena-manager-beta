import * as T from 'three';
// One low-poly volume per grenade, eight bounded samples on phones. No depth
// buffer copy, 3D textures, compute shaders or secondary scene render.
export function createSmokeVolumes(scene,mobile){
 const capacity=12,base=new T.SphereGeometry(1,24,16),geometry=new T.InstancedBufferGeometry();geometry.index=base.index;geometry.attributes.position=base.attributes.position;
 const centers=new T.InstancedBufferAttribute(new Float32Array(capacity*4),4).setUsage(T.DynamicDrawUsage),sizes=new T.InstancedBufferAttribute(new Float32Array(capacity*4),4).setUsage(T.DynamicDrawUsage);geometry.setAttribute('cloud',centers);geometry.setAttribute('extent',sizes);const colors=new T.InstancedBufferAttribute(new Float32Array(capacity*3),3).setUsage(T.DynamicDrawUsage);geometry.setAttribute('cloudColor',colors);const tint=new T.Color();
 const uniforms={clock:{value:0},ray:{value:new T.Vector3()},holes:{value:Array.from({length:4},()=>new T.Vector4())},holeCount:{value:0}};
 const vertex=`attribute vec4 cloud;attribute vec4 extent;attribute vec3 cloudColor;varying vec3 vColor;varying vec3 localEntry;varying vec4 vCloud;varying vec4 vExtent;
 void main(){vColor=cloudColor;vCloud=cloud;vExtent=extent;localEntry=position;vec3 world=cloud.xyz+position*extent.xyz;gl_Position=projectionMatrix*viewMatrix*vec4(world,1.);}`;
 const fragment=`varying vec3 vColor;uniform float clock;uniform vec3 ray;uniform vec4 holes[4];uniform int holeCount;varying vec3 localEntry;varying vec4 vCloud;varying vec4 vExtent;
 float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
 float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
 void main(){vec3 d=normalize(ray/vExtent.xyz),p=localEntry;float lengthIn=max(0.,-2.*dot(p,d));if(lengthIn<=0.)discard;
 float stepSize=lengthIn/float(STEPS),alpha=0.;vec3 color=vec3(0.);
 for(int i=0;i<STEPS;i++){vec3 q=p+d*(float(i)+.5)*stepSize;vec3 world=vCloud.xyz+q*vExtent.xyz;
  float n=noise(q*3.2+vec3(clock*.04,clock*.025,vCloud.w));n=n*.75+noise(q*6.1+vCloud.w)*.25;
  float density=(1.-smoothstep(.53,1.,length(q)+(n-.5)*.23))*(.75+n*.65);
  // Keep the volume above the source floor, including on stacked maps.
  density*=smoothstep(vCloud.y-vExtent.y*.65,vCloud.y-vExtent.y*.45,world.y);
  for(int j=0;j<4;j++){if(j>=holeCount)break;density*=smoothstep(holes[j].w*.6,holes[j].w,distance(world,holes[j].xyz));}
  float a=(1.-exp(-density*stepSize*3.8))*vExtent.w;float shade=.53+q.y*.18+n*.17;vec3 lit=mix(vec3(.61,.64,.60),vColor,.72)*shade;
  color+=(1.-alpha)*a*lit;alpha+=(1.-alpha)*a;if(alpha>.99)break;
 }
 if(alpha<.008)discard;gl_FragColor=vec4(color/max(alpha,.001),alpha);
 #include <colorspace_fragment>
 }`;
 const material=new T.ShaderMaterial({defines:{STEPS:mobile?8:12},uniforms,vertexShader:vertex,fragmentShader:fragment,transparent:true,depthWrite:false,depthTest:true,side:T.FrontSide,toneMapped:false});
 const mesh=new T.Mesh(geometry,material);mesh.frustumCulled=false;mesh.renderOrder=7;scene.add(mesh);let count=0;
 return{reset(){count=0;},add(x,y,z,growth,fade,seed,color='#b4bfbb'){if(count>=capacity||fade<=.002)return;centers.setXYZW(count,x,y+1.05*growth,z,seed);sizes.setXYZW(count,3.1*growth,1.85*growth,3.1*growth,fade);tint.set(color);colors.setXYZ(count,tint.r,tint.g,tint.b);count++;},flush(camera,holes,time){uniforms.clock.value=time;camera.getWorldDirection(uniforms.ray.value);uniforms.holeCount.value=holes.length;holes.forEach((h,i)=>uniforms.holes.value[i].copy(h));geometry.instanceCount=count;mesh.visible=count>0;centers.needsUpdate=sizes.needsUpdate=colors.needsUpdate=true;},get count(){return count;},get drawCalls(){return count?1:0;},dispose(){mesh.removeFromParent();geometry.dispose();material.dispose();}};
}
