import {navLocation,navWalkLine} from './reference-nav.js';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
export const VFX_BUDGETS={mobile:{smoke:96,flame:160,glow:48,scorch:192,sparks:192},desktop:{smoke:144,flame:240,glow:64,scorch:256,sparks:288}};
export const effectSeed=e=>Math.sin(e.x*12.9898+e.z*78.233+(e.owner??0)*4.13)*43758.5453%1;
export const randomAt=(seed,i)=>{const n=Math.sin(seed*67.17+i*127.1)*43758.5453;return n-Math.floor(n);};
export const flameFrame=(age,offset=0)=>((Math.floor(age/.05)+offset)%25+25)%25;
const layouts=new WeakMap();
// Stable, floor-aware ground patches. Original nav paths and mesh are untouched.
export function fireFootprint(map,e){
 let cache=layouts.get(map);if(!cache){cache=new Map();layouts.set(map,cache);}
 const key=[e.x.toFixed(3),e.z.toFixed(3),(e.y||0).toFixed(3),e.owner??0].join(':');if(cache.has(key))return cache.get(key);
 let origin={x:e.x,z:e.z,y:e.y||0};
 if(map.reference){const p=navLocation(map,origin,true);if(p&&Math.hypot(p.x-origin.x,p.z-origin.z)<1&&Math.abs(p.y-origin.y)<.8)origin=p;}
 const cells=[{...origin,r:.62,delay:0}];
 for(const [ring,count,radius]of [[0,6,.72],[1,10,1.48],[2,14,2.32]])for(let i=0;i<count;i++){
  const a=i/count*Math.PI*2+ring*.43,p={x:origin.x+Math.sin(a)*radius,z:origin.z+Math.cos(a)*radius,y:origin.y};
  if(map.reference){const location=navLocation(map,p);if(!location||Math.abs(location.y-origin.y)>.45||!navWalkLine(map,origin,p))continue;p.y=location.y;}
  else if(p.x<1||p.z<1||p.x>(map.width||60)-1||p.z>(map.height||40)-1||map.blocks.some(b=>Math.abs(p.x-b.x)<b.w/2+.1&&Math.abs(p.z-b.z)<b.d/2+.1))continue;
  cells.push({...p,r:.57+randomAt(effectSeed(e),i+ring*20)*.16,delay:radius*.28});
 }
 if(cache.size>=64)cache.delete(cache.keys().next().value);cache.set(key,cells);return cells;
}
export function fireAt(map,e,p){return !e.extinguished&&fireFootprint(map,e).some(c=>e.age>=c.delay&&Math.abs((p.y||0)-c.y)<1.2&&Math.hypot(p.x-c.x,p.z-c.z)<c.r+.35);}
export function fireEnvelope(e,delay=0){const age=e.age-delay;return age<0?0:clamp(age*4)*clamp((e.life-e.age)*2)*(e.extinguished?clamp((e.life-e.age)/.45):1);}
export const blastHoleRadius=e=>['he','c4'].includes(e.kind)&&e.age>=0&&e.age<1.3?(e.kind==='c4'?7:4.5)*Math.sin(Math.min(1,e.age/.12)*Math.PI/2)*clamp((1.3-e.age)/.7):0;
const segmentPoint=(a,b,t)=>({x:a.x+(b.x-a.x)*t,z:a.z+(b.z-a.z)*t,y:(a.y||0)+((b.y||0)-(a.y||0))*t});
export function smokeBlocks(effects,a,b){
 for(const e of effects){if(e.kind!=='smoke'||e.age<=.5||e.age>=15)continue;
  const dx=b.x-a.x,dz=b.z-a.z,length2=dx*dx+dz*dz,t=clamp(((e.x-a.x)*dx+(e.z-a.z)*dz)/(length2||1)),near=segmentPoint(a,b,t);
  if(Math.hypot(near.x-e.x,near.z-e.z)>=3.3||Math.abs(near.y-(e.y||0))>2.8)continue;
  // Sample only the occupied segment, so a temporary HE opening also clears LOS.
  const span=3.3/Math.max(1,Math.sqrt(length2));let filled=false;
  for(let i=0;i<9;i++){const p=segmentPoint(a,b,clamp(t+(i/8-.5)*span*2));if(Math.hypot(p.x-e.x,p.z-e.z)>=3.3)continue;
   const cleared=effects.some(blast=>{const radius=blastHoleRadius(blast);return radius>0&&Math.hypot(p.x-blast.x,p.z-blast.z)<radius&&Math.abs(p.y-(blast.y||0))<2.8;});if(!cleared){filled=true;break;}
  }
  if(filled)return true;
 }
 return false;
}
