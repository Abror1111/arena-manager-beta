// Verified, content-addressed downloads. Only bounded binary data stays in RAM;
// scenes, textures and GPU resources still belong to the active match.
export function createAssetStore({baseURL,fetcher,storage,hash,packaged=false,memoryLimit=80*1024**2,externalPrefixes=[]}){
 const memory=new Map(),pending=new Map();let memoryBytes=0,cachePromise;
 const aborted=()=>new DOMException('Yuklash bekor qilindi.','AbortError');
 function identity(entry){
  if(!/^[a-f0-9]{64}$/.test(entry.sha256)||!Number.isSafeInteger(entry.bytes)||entry.bytes<=0||entry.bytes>128*1024**2)throw Error('Fayl tavsifi noto‘g‘ri.');
  const url=new URL(entry.url,baseURL);if(url.origin!==new URL(baseURL).origin&&!externalPrefixes.some(prefix=>url.href.startsWith(prefix)))throw Error('Tashqi fayl manzili rad etildi.');
  url.search='';url.hash='';const download=url.href;url.searchParams.set('arena-asset',entry.sha256);return{key:url.href,download};
 }
 async function cache(){if(packaged||!storage)return null;return cachePromise??=Promise.resolve().then(()=>storage.open('arena-verified-assets-v1')).catch(()=>null);}
 function remember(key,bytes,persisted){
  const old=memory.get(key);if(old){memoryBytes-=old.bytes.byteLength;memory.delete(key);}
  if(bytes.byteLength>memoryLimit)return;
  while(memoryBytes+bytes.byteLength>memoryLimit&&memory.size){const [oldKey,item]=memory.entries().next().value;memory.delete(oldKey);memoryBytes-=item.bytes.byteLength;}
  memory.set(key,{bytes,persisted});memoryBytes+=bytes.byteLength;
 }
 async function verified(bytes,entry){return bytes.byteLength===entry.bytes&&await hash(bytes)===entry.sha256;}
 async function read(entry,id,job){
  const cached=memory.get(id.key);
  if(cached){memory.delete(id.key);memory.set(id.key,cached);job.progress(1);return{...cached,source:packaged?'package':'memory'};}
  const disk=await cache();if(job.controller.signal.aborted)throw aborted();
  if(disk){
   let response;try{response=await disk.match(id.key);}catch{}
   if(response){
    const bytes=await response.arrayBuffer();if(job.controller.signal.aborted)throw aborted();
    if(await verified(bytes,entry)){remember(id.key,bytes,true);job.progress(1);return{bytes,persisted:true,source:'cache'};}
    await disk.delete(id.key).catch(()=>{});
   }
  }
  const response=await fetcher(id.download,{signal:job.controller.signal,cache:'no-store'});if(!response.ok)throw Error('Fayl yuklanmadi: '+response.status);
  let bytes;
  if(response.body){
   const pieces=[];let received=0;const reader=response.body.getReader();
   try{while(true){const {done,value}=await reader.read();if(done)break;received+=value.byteLength;if(received>entry.bytes)throw Error('Fayl hajmi mos kelmadi.');pieces.push(value);job.progress(received/entry.bytes*.94);}}
   finally{reader.releaseLock();}
   const combined=new Uint8Array(received);let offset=0;for(const part of pieces){combined.set(part,offset);offset+=part.byteLength;}bytes=combined.buffer;
  }else bytes=await response.arrayBuffer();
  if(job.controller.signal.aborted)throw aborted();
  if(!await verified(bytes,entry))throw Error('Fayl buzilgan yoki versiyasi mos emas.');
  let persisted=packaged;
  if(disk){try{await disk.put(id.key,new Response(bytes,{headers:{'Content-Type':'application/octet-stream','X-Arena-SHA256':entry.sha256}}));persisted=true;}catch{/* Quota failure must not stop an otherwise playable match. */}}
  if(job.controller.signal.aborted)throw aborted();
  remember(id.key,bytes,persisted);job.progress(1);return{bytes,persisted,source:packaged?'package':'network'};
 }
 function get(entry,{signal,onProgress=()=>{}}={}){
  if(signal?.aborted)return Promise.reject(aborted());const id=identity(entry);let job=pending.get(id.key);
  if(!job){
   job={controller:new AbortController(),subscribers:new Set(),percent:0,progress(value){this.percent=value;for(const s of this.subscribers)s.onProgress(value);}};
   pending.set(id.key,job);
   job.promise=Promise.resolve().then(()=>read(entry,id,job)).finally(()=>{if(pending.get(id.key)===job)pending.delete(id.key);});
  }
  const active=job;
  return new Promise((resolve,reject)=>{
   const subscriber={onProgress};let finished=false;active.subscribers.add(subscriber);onProgress(active.percent);
   const leave=()=>{active.subscribers.delete(subscriber);signal?.removeEventListener('abort',cancel);};
   const cancel=()=>{if(finished)return;finished=true;leave();reject(aborted());if(!active.subscribers.size){if(pending.get(id.key)===active)pending.delete(id.key);active.controller.abort();}};
   signal?.addEventListener('abort',cancel,{once:true});
   active.promise.then(value=>{if(!finished){finished=true;leave();resolve(value);}},error=>{if(!finished){finished=true;leave();reject(error);}});
  });
 }
 async function status(entries){
  if(packaged)return entries.map(()=>true);const disk=await cache();if(!disk)return entries.map(()=>false);
  try{const keys=new Set((await disk.keys()).map(r=>r.url));return entries.map(e=>keys.has(identity(e).key));}catch{return entries.map(()=>false);}
 }
 return{get,status,get memoryBytes(){return memoryBytes;},clearMemory(){memory.clear();memoryBytes=0;}};
}
