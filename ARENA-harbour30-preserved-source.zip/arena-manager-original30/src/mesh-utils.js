import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

// Only merge parts whose transforms will stay fixed relative to parent.
// Animated joints, destructible crates and transient effects remain separate.
export function mergeStaticMeshes(parent,directOnly=false){
 parent.updateWorldMatrix(true,true);const inverse=parent.matrixWorld.clone().invert(),groups=new Map();
 const collect=o=>{if(!o.isMesh||Array.isArray(o.material))return;const key=`${o.material.uuid}:${o.castShadow}:${o.receiveShadow}`;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(o);};
 if(directOnly)parent.children.forEach(collect);else parent.traverse(collect);
 for(const meshes of groups.values()){
  if(meshes.length<2)continue;
  const parts=meshes.map(mesh=>mesh.geometry.clone().applyMatrix4(new T.Matrix4().multiplyMatrices(inverse,mesh.matrixWorld)));
  const geometry=mergeGeometries(parts,false);parts.forEach(g=>g.dispose());if(!geometry)continue;
  const mesh=new T.Mesh(geometry,meshes[0].material);mesh.castShadow=meshes[0].castShadow;mesh.receiveShadow=meshes[0].receiveShadow;parent.add(mesh);meshes.forEach(o=>o.removeFromParent());
 }
}
