import {environmentProfile} from './environment-profiles132.js';
export function mapLighting(map){
 if(map.approved)return{sky:map.night?'#a1b5ce':'#dbe4ec',ground:map.style==='desert'?'#9c8d70':'#758371',sun:map.night?'#a2c0df':'#fff0d7',sunPower:map.night?1.2:2.5,ambient:1.5,exposure:map.night?1.12:1.03,shadowSize:1024};
 if(map.rebuilt){const p=environmentProfile(map);return{sky:p.ambientSky||p.sky,ground:p.ambientGround||p.earth,sun:p.sun,sunPower:p.sunPower,ambient:p.ambient,exposure:p.exposure,shadowSize:1280};}
 const night=map.night,jungle=map.style==='jungle',desert=map.style==='desert';
 return {sky:night?'#b0cbd7':jungle?'#d1e4cf':'#dce8ef',ground:night?'#314536':desert?'#8c795b':'#596553',sun:night?'#a8c6ef':desert?'#ffe5bc':'#fff1d5',sunPower:night?1.34:2.15,ambient:night?1.65:1.4,exposure:night?1.16:jungle?1.15:1.12,shadowSize:1024};
}
export function shadowFrame(map){const v=map.view||{minX:0,maxX:60,minZ:0,maxZ:40},x=(v.minX+v.maxX)/2-map.width/2,z=(v.minZ+v.maxZ)/2-map.height/2,r=Math.max(v.maxX-v.minX,v.maxZ-v.minZ)*.66+12;return{x,z,r,near:.5,far:180};}
