export const ENVIRONMENT_ASSET_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/dea09d88806712ac5f8d8d6d4c1e9db6346f5293/environment132/";
