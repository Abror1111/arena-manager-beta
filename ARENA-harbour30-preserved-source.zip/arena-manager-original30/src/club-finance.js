// Club coins are earned in play. They are independent of a match's round dollars.
export const COIN_LIMIT=100000000;
export const PRACTICE_ALLOWANCE=3;
export const SPONSORS=[
 {id:'local',name:'Mahalla Gaming',tag:'BOSHLANG‘ICH',fans:0,reputation:0,fee:450,bonus:200,length:3,color:'#d9bc83'},
 {id:'tech',name:'VECTOR Tech',tag:'HUDUDIY',fans:800,reputation:0,fee:750,bonus:350,length:3,color:'#81bcd8'},
 {id:'arena',name:'NOVA Hardware',tag:'PROFESSIONAL',fans:1800,reputation:8,fee:1150,bonus:550,length:3,color:'#ba9cde'},
];
export const SHOP=[
 {id:'theme-gold',kind:'theme',value:'gold',name:'Classic Gold',price:0,color:'#e2bf80',description:'Klassik oltin klub uslubi.'},
 {id:'theme-azure',kind:'theme',value:'azure',name:'Arctic Blue',price:1600,color:'#7bc9ed',description:'Sovuq ko‘k tugmalar va klub aksentlari.'},
 {id:'theme-crimson',kind:'theme',value:'crimson',name:'Crimson Five',price:2200,color:'#ec8b99',description:'Qizil rangli klub aksentlari.'},
 {id:'theme-jade',kind:'theme',value:'jade',name:'Jade Circuit',price:2800,color:'#85d7b1',description:'Yashil jade aksentlari.'},
 {id:'theme-violet',kind:'theme',value:'violet',name:'Neon Violet',price:3600,color:'#b7a0ef',description:'Binafsha turnir uslubi.'},
 {id:'crest-arena',kind:'crest',value:'arena',name:'ARENA Shield',price:0,color:'#e2bf80',description:'Klubning boshlang‘ich emblemasi.'},
 {id:'crest-bolt',kind:'crest',value:'bolt',name:'Storm Mark',price:1200,color:'#99cfe6',description:'Chaqmoq belgili klub emblemasi.'},
 {id:'crest-wings',kind:'crest',value:'wings',name:'Falcon Wings',price:3500,color:'#dcb67e',description:'Qanotli turnir emblemasi.'},
 {id:'crest-crown',kind:'crest',value:'crown',name:'Crown Five',price:6500,color:'#e4c77d',description:'Chempion uslubidagi toj emblemasi.'},
];
export const OBJECTIVES=[
 {id:'debut',name:'Katta sahnaga qadam',description:'Bitta rasmiy uchrashuvni oxirigacha o‘ynang.',stat:'officialMatches',target:1,reward:400},
 {id:'winner',name:'Birinchi g‘alaba',description:'Rasmiy uchrashuvda g‘alaba qozoning.',stat:'officialWins',target:1,reward:600},
 {id:'coach',name:'Tajriba va mehnat',description:'Uchta shaxsiy mashg‘ulotni bajaring.',stat:'training',target:3,reward:350},
 {id:'scout',name:'Yangi iste’dod',description:'Transferdan bitta o‘yinchi oling.',stat:'recruits',target:1,reward:500},
 {id:'champion',name:'ARENA chempioni',description:'Bir mavsumda chempion bo‘ling.',stat:'championships',target:1,reward:2000},
];
const categories=new Set(['opening','match','sponsor','fans','salary','operations','support','season','training','facility','transfer-buy','transfer-sell','shop','objective']);
const int=(n,max=COIN_LIMIT)=>Number.isSafeInteger(n)&&n>=0&&n<=max;
export function ensureFinance(c){
 if(c.finance)return c.finance;
 const official=(c.history||[]).filter(h=>h.type==='season'&&!h.forfeit),current=official.filter(h=>h.season===c.seasonNumber);
 c.finance={version:1,sequence:0,anchor:c.credits,income:0,expenses:0,ledger:[],sponsor:{id:'local',remaining:3},practicePaid:0,seasonCompleted:current.length,stats:{officialMatches:official.length,officialWins:official.filter(h=>h.win).length,training:0,recruits:(c.history||[]).filter(h=>h.type==='transfer').length,championships:c.season?.completed&&c.season.placement===1?1:0},claimed:[],owned:['theme-gold','crest-arena'],theme:'gold',crest:'arena'};
 return c.finance;
}
export function post(c,category,amount,label,key){
 const f=ensureFinance(c);if(!categories.has(category)||!Number.isSafeInteger(amount)||typeof label!=='string')throw Error('Moliyaviy amal noto‘g‘ri.');
 if(key&&f.ledger.some(e=>e.key===key))throw Error('Bu to‘lov avval hisoblangan.');
 if(amount<0&&c.credits< -amount)throw Error('Klub tangasi yetarli emas.');
 const actual=amount>0?Math.min(amount,COIN_LIMIT-c.credits):amount;if(!actual)return 0;
 c.credits+=actual;f.sequence++;f.income+=Math.max(0,actual);f.expenses+=Math.max(0,-actual);
 f.ledger.push({id:f.sequence,key:key||'tx-'+f.sequence,day:c.day,category,label,amount:actual,balance:c.credits});
 while(f.ledger.length>120)f.anchor=f.ledger.shift().balance;
 return actual;
}
export function salary(p){const o=Math.round(p.aim*.45+p.reaction*.2+p.tactics*.2+p.utility*.15);return 60+Math.max(0,o-50)*3;}
export function clubCosts(c){return{salary:c.roster.reduce((n,p)=>n+salary(p),0),operations:40+c.trainingLevel*35};}
export function sponsorOffers(c){return SPONSORS.map(s=>({...s,available:c.fans>=s.fans&&c.reputation>=s.reputation}));}
export function activeSponsor(c){const f=c.finance;if(!f||f.sponsor.remaining<=0)return null;return SPONSORS.find(s=>s.id===f.sponsor.id)||null;}
export function matchQuote(c,win=false,practice=false){
 if(practice){const paid=(c.finance?.practicePaid||0)<PRACTICE_ALLOWANCE;return{prize:paid?(win?350:180):0,sponsor:0,fans:0,salary:0,operations:0,support:0,gross:paid?(win?350:180):0,net:paid?(win?350:180):0};}
 const costs=clubCosts(c),s=activeSponsor(c),prize=win?2200:900,sponsor=s?(s.fee+(win?s.bonus:0)):0,fans=Math.min(600,180+Math.floor(c.fans/30)*10),support=Math.max(0,costs.salary+costs.operations+200-prize-sponsor-fans),gross=prize+sponsor+fans+support;
 return{prize,sponsor,fans,support,...costs,gross,net:gross-costs.salary-costs.operations};
}
export function settleFinance(c,pending,won,forfeit){
 const f=ensureFinance(c),before=c.credits,practice=pending.type==='practice',eligible=!forfeit&&(!practice||f.practicePaid<PRACTICE_ALLOWANCE);
 if(!forfeit){const q=matchQuote(c,won,practice),rows=[['prize','match',practice?'Mashq mukofoti':'Uchrashuv mukofoti'],['sponsor','sponsor','Homiy to‘lovi'],['fans','fans','Muxlislar va klub savdosi'],['support','support','Liga ishtirok yordami'],['salary','salary','Tarkib maoshi'],['operations','operations','Klub xizmat xarajati']];
  // At the wallet cap, settle expenses first so a win cannot reduce a full wallet.
  if(before+q.gross>COIN_LIMIT&&before>=q.salary+q.operations)rows.sort((a,b)=>Number(['salary','operations'].includes(b[0]))-Number(['salary','operations'].includes(a[0])));
  let gross=0;for(const[k,category,label]of rows){const amount=post(c,category,q[k]*(k==='salary'||k==='operations'?-1:1),label,pending.id+':'+k);gross+=Math.max(0,amount);}q.gross=gross;
  if(practice){if(eligible)f.practicePaid++;}else{f.stats.officialMatches++;f.stats.officialWins+=won?1:0;f.seasonCompleted++;f.practicePaid=0;if(f.sponsor.remaining>0)f.sponsor.remaining--;}
  return{...q,net:c.credits-before,eligible};
 }
 return{prize:0,sponsor:0,fans:0,support:0,salary:0,operations:0,gross:0,net:0,eligible:false};
}
export function validateFinance(c){
 const f=ensureFinance(c),fail=()=>{throw Error('Klub moliyasi yoki hamyon tarixi noto‘g‘ri.');};
 if(!f||f.version!==1||!int(f.sequence,1e12)||!int(f.anchor)||!int(f.income,1e15)||!int(f.expenses,1e15)||!Array.isArray(f.ledger)||f.ledger.length>120)fail();
 if(!f.sponsor||!SPONSORS.some(s=>s.id===f.sponsor.id)||!int(f.sponsor.remaining,3)||!int(f.practicePaid,3)||!int(f.seasonCompleted,7))fail();
 if(!f.stats||['officialMatches','officialWins','training','recruits','championships'].some(k=>!int(f.stats[k],1e9))||f.stats.officialWins>f.stats.officialMatches)fail();
 if(!Array.isArray(f.claimed)||new Set(f.claimed).size!==f.claimed.length||f.claimed.some(id=>!OBJECTIVES.some(q=>q.id===id)))fail();
 if(!Array.isArray(f.owned)||f.owned.length>SHOP.length||new Set(f.owned).size!==f.owned.length||f.owned.some(id=>!SHOP.some(s=>s.id===id))||!f.owned.includes('theme-gold')||!f.owned.includes('crest-arena'))fail();
 for(const kind of['theme','crest'])if(!SHOP.some(s=>s.kind===kind&&s.value===f[kind]&&f.owned.includes(s.id)))fail();
 let balance=f.anchor,last=0;const keys=new Set();for(const e of f.ledger){if(!e||!int(e.id,1e12)||e.id<=last||e.id>f.sequence||typeof e.key!=='string'||e.key.length>100||keys.has(e.key)||!int(e.day)||e.day<1||e.day>c.day||!categories.has(e.category)||typeof e.label!=='string'||e.label.length>100||!Number.isSafeInteger(e.amount)||!e.amount||Math.abs(e.amount)>COIN_LIMIT||!int(e.balance))fail();balance+=e.amount;if(balance!==e.balance)fail();keys.add(e.key);last=e.id;}
 if(balance!==c.credits||f.ledger.length&&last!==f.sequence)fail();
 return f;
}
