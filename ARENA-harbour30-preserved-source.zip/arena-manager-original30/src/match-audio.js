import {createSoundtrack,musicCue,readMusicVolume,readEffectsVolume,AUDIO_SETTINGS_EVENT} from './music.js';
import {createOriginalAudioBank} from './audio-pack-store.js';
import {WEAPONS} from './weapons.js';
// Automatically bundled verified CS2 samples, with optional local override and procedural fallback.
export const AUDIO_PRESETS={rifle:{tone:92,decay:.18,cutoff:6800,gain:.34},smg:{tone:118,decay:.12,cutoff:5400,gain:.25},sniper:{tone:49,decay:.5,cutoff:7500,gain:.55},pistol:{tone:160,decay:.16,cutoff:6100,gain:.25},shotgun:{tone:68,decay:.38,cutoff:4500,gain:.48},heavy:{tone:78,decay:.22,cutoff:5800,gain:.38},special:{tone:175,decay:.2,cutoff:3600,gain:.22},melee:{tone:420,decay:.15,cutoff:1700,gain:.12}};
export function createMatchAudio({context=null,mobile=false,resumed=false,onState=()=>{}}={}){
 const Context=globalThis.AudioContext||globalThis.webkitAudioContext;if(!context&&!Context)return{unlock(){},update(){},setEnabled(){},dispose(){},get state(){return'unavailable';},get voices(){return 0;}};
 const ctx=context||new Context({latencyHint:'interactive'}),master=ctx.createGain(),limiter=ctx.createDynamicsCompressor(),voices=new Set();master.gain.value=.7*readEffectsVolume();limiter.threshold.value=-4;limiter.knee.value=6;limiter.ratio.value=3;limiter.attack.value=.003;limiter.release.value=.16;master.connect(limiter);limiter.connect(ctx.destination);
 const sampleCount=Math.round(ctx.sampleRate*2),noise=ctx.createBuffer(1,sampleCount,ctx.sampleRate),samples=noise.getChannelData(0);let seed=71;
 for(let i=0;i<samples.length;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;samples[i]=(seed/4294967296*2-1)*.8;}
 const originals=createOriginalAudioBank(ctx),music=createSoundtrack();let originalPlayed=0,lastKey=null,lastOrigin=null,duckUntil=0,lastAmbient=-99,paused=false,audioRetries=0,nextRetry=Date.now()+2000;originals.prepare().catch(()=>{});
 const syncVolume=()=>{music.setVolume(readMusicVolume());master.gain.setTargetAtTime(enabled?.7*readEffectsVolume():0,ctx.currentTime,.04);},syncVisibility=()=>music.setHidden(paused||globalThis.document?.hidden===true);globalThis.addEventListener?.(AUDIO_SETTINGS_EVENT,syncVolume);globalThis.document?.addEventListener('visibilitychange',syncVisibility);syncVisibility();
 let enabled=true,lastSeq=resumed?null:0,disposed=false,lastFire=-99,played=0;const foot=new Map();
 const limit=mobile?14:22;
 function release(voice){if(voice.done)return;voice.done=true;voices.delete(voice);for(const source of voice.sources)try{source.stop();}catch{}for(const n of [...voice.nodes,voice.bus,voice.stereo])n.disconnect();}
 function room(priority){if(voices.size<limit)return true;const candidate=[...voices].filter(v=>v.priority<priority||priority===3&&ctx.currentTime-v.start>.12).sort((a,b)=>a.priority-b.priority||a.start-b.start)[0];if(!candidate)return false;release(candidate);return true;}

 function sound({frequency=100,decay=.2,cutoff=4000,gain=.2,pan=0,when=0,tone=true,noisePart=true,type='triangle'}){
  if(!enabled||disposed||ctx.state!=='running'&&!context||voices.size>=limit)return;
  const start=ctx.currentTime+when,end=start+decay,bus=ctx.createGain(),stereo=ctx.createStereoPanner();bus.gain.setValueAtTime(.0001,start);bus.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),start+.003);bus.gain.exponentialRampToValueAtTime(.0001,end);stereo.pan.value=Math.max(-.85,Math.min(.85,pan));bus.connect(stereo);stereo.connect(master);
  const nodes=[],sources=[];
  if(noisePart){const source=ctx.createBufferSource(),filter=ctx.createBiquadFilter();source.buffer=noise;filter.type='lowpass';filter.frequency.setValueAtTime(cutoff,start);filter.frequency.exponentialRampToValueAtTime(Math.max(80,cutoff*.15),end);source.connect(filter);filter.connect(bus);source.start(start,(played%9)*.13);source.stop(end+.02);nodes.push(source,filter);sources.push(source);}
  if(tone){const oscillator=ctx.createOscillator(),level=ctx.createGain();oscillator.type=type;oscillator.frequency.setValueAtTime(frequency,start);oscillator.frequency.exponentialRampToValueAtTime(Math.max(25,frequency*.42),end);level.gain.value=noisePart?.2:1;oscillator.connect(level);level.connect(bus);oscillator.start(start);oscillator.stop(end+.02);nodes.push(oscillator,level);sources.push(oscillator);}
  const voice={bus,stereo,nodes,sources,priority:0,start};voices.add(voice);played++;let remaining=sources.length;for(const s of sources)s.onended=()=>{if(--remaining>0)return;release(voice);};
 }
 function clip(key,gain=1,pan=0){const entry=originals.get(key),priority=key==='c4'||key==='he'?4:key.startsWith('shot:')?3:key==='footstep'?1:key.startsWith('ambient:')||key==='fireloop'?0:2;if(!entry||!enabled||disposed||ctx.state!=='running'&&!context||!room(priority))return false;const source=ctx.createBufferSource(),bus=ctx.createGain(),stereo=ctx.createStereoPanner();source.buffer=entry.buffer;bus.gain.value=entry.gain*gain;stereo.pan.value=Math.max(-.85,Math.min(.85,pan));source.connect(bus);bus.connect(stereo);stereo.connect(master);const voice={bus,stereo,nodes:[source],sources:[source],priority,start:ctx.currentTime};voices.add(voice);source.onended=()=>release(voice);source.start();played++;lastKey=key;lastOrigin=entry.origin;originalPlayed++;if(key.startsWith('shot:'))duckUntil=Date.now()+450;return true;}
 function play(event,game,follow){
  const selected=game.players[follow],focus=selected||{x:game.map.width/2,z:game.map.height/2},distance=Math.hypot(event.x-focus.x,event.z-focus.z),gain=Math.max(.3,1/(1+distance*.025)),pan=(event.x-focus.x)/25;
  const key=event.kind==='shot'||event.kind==='reload'?event.kind+':'+event.weapon:event.kind;if(clip(key,gain,pan)||originals.hasKey(key))return;if(event.kind==='reload'&&(clip('reload',gain*.45,pan)||originals.hasKey('reload')))return;
  const hit=(preset,extra={})=>sound({...preset,gain:(preset.gain||.2)*gain,pan,...extra});
  if(event.kind==='shot'){const w=WEAPONS[event.weapon],p=AUDIO_PRESETS[w?.family]||AUDIO_PRESETS.rifle;hit(p,w?.silenced?{cutoff:1700,gain:p.gain*.42*gain,decay:.105}:{});}
  else if(event.kind==='reload')for(const [when,f]of [[0,900],[.38,650],[.95,1200]])hit({tone:false,gain:.09,cutoff:f*3,decay:.065},{when});
  else if(event.kind==='bounce')hit({tone:true,noisePart:false,frequency:1500,decay:.09,gain:.09,type:'sine'});
  else if(event.kind==='throw')hit({tone:false,cutoff:1800,decay:.16,gain:.07});
  else if(event.kind==='he')hit({frequency:52,decay:1.05,cutoff:2900,gain:.65});
  else if(event.kind==='c4'){hit({frequency:35,decay:3.5,cutoff:3400,gain:.9});hit({frequency:58,decay:1.3,cutoff:1800,gain:.4},{when:.16});}
  else if(event.kind==='smoke')hit({tone:false,decay:1.4,cutoff:2500,gain:.16});
  else if(event.kind==='flash'){hit({frequency:1800,noisePart:false,decay:.6,gain:.025,type:'sine'});hit({tone:false,decay:.12,cutoff:7000,gain:.25});}
  else if(event.kind==='fire')hit({tone:false,decay:.65,cutoff:6000,gain:.2});
  else if(event.kind==='c4beep')hit({frequency:2300,noisePart:false,decay:.075,gain:.07,type:'sine'});
  else if(event.kind==='hit'||event.kind==='death')hit({tone:false,cutoff:event.kind==='hit'?1400:650,decay:.07,gain:.07});
  else if(['plant','defuse','roundStart','roundEnd'].includes(event.kind))for(let i=0;i<3;i++)hit({frequency:(event.kind==='roundEnd'?event.winner===0?660:330:520)*(1+i*.22),noisePart:false,decay:.12,gain:.07,type:'sine'},{when:i*.13});
 }
 return{async unlock({force=false}={}){if(disposed)return;try{const resume=ctx.resume();music.unlock();await resume;await originals.prepare({force});onState(ctx.state);}catch{}},async audition(weapon='ak'){await this.unlock({force:true});return clip(WEAPONS[weapon]?'shot:'+weapon:weapon,.9,0);},get lastKey(){return lastKey;},get lastOrigin(){return lastOrigin;},get originalStatus(){return originals.status;},get originalCount(){return originals.loaded;},get originalExpected(){return originals.expected;},get originalErrors(){return originals.errors;},get originalFormats(){return originals.formats;},setEnabled(value){enabled=!!value;music.setEnabled(enabled);master.gain.setTargetAtTime(enabled?.7*readEffectsVolume():0,ctx.currentTime,.04);},get state(){return enabled?ctx.state:'muted';},get voices(){return voices.size;},get played(){return played;},get originalPlayed(){return originalPlayed;},get source(){return originals.source;},setPaused(value){paused=!!value;syncVisibility();},get musicCue(){return music.cue;},get musicPlayed(){return music.played;},get limit(){return limit;},
  update(game,follow){
   if(disposed)return;music.setDucked(Date.now()<duckUntil);if(originals.errors&&originals.status!=='loading'&&audioRetries<3&&Date.now()>=nextRetry){audioRetries++;nextRetry=Date.now()+5000*audioRetries;originals.prepare().catch(()=>{});}music.setCue(musicCue(game));if(lastSeq===null){lastSeq=game.soundSeq||0;return;}for(const e of game.soundEvents||[]){if(e.seq<=lastSeq)continue;lastSeq=e.seq;play(e,game,follow);}
   if(game.phase==='live')for(const p of game.players){const before=foot.get(p.id)||0;if(p.alive&&p.moving&&p.walk-before>3.1){foot.set(p.id,p.walk);if((p.id===follow||p.id%3===0)&&!clip('footstep',p.id===follow?.12:.045,(p.x-game.map.width/2)/35))sound({tone:false,cutoff:650,decay:.075,gain:p.id===follow?.07:.025,pan:(p.x-game.map.width/2)/35});}else if(p.walk<before)foot.set(p.id,p.walk);}
   if(game.elapsed-lastFire>1&&game.effects?.some(e=>e.kind==='fire'&&!e.extinguished)){lastFire=game.elapsed;clip('fireloop',.05,0);}
   if(!paused&&game.phase==='live'&&game.elapsed-lastAmbient>3.6){lastAmbient=game.elapsed;const kind=game.map.style==='jungle'?'forest':['industry','warehouse'].includes(game.map.style)?'industry':game.map.style==='town'||game.map.id==='vertigo'?'city':'wind';clip('ambient:'+kind,.035,0);}
  },
  dispose(){disposed=true;music.dispose();globalThis.removeEventListener?.(AUDIO_SETTINGS_EVENT,syncVolume);globalThis.document?.removeEventListener('visibilitychange',syncVisibility);originals.dispose();for(const v of [...voices])release(v);voices.clear();master.disconnect();limiter.disconnect();if(!context)ctx.close().catch(()=>{});}
 };
}
