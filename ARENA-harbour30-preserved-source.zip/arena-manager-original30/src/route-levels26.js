import{STAIRS30,BRIDGE30,ROADS30}from'./harbour-plan30.js';
export const BRIDGE26=BRIDGE30,STAIRS26=STAIRS30,ROAD_AREAS26=ROADS30;
export const LEVELS30={street:1,pump:2.8,dock:4,viaduct:4.6};
const within=(x,z,r)=>x>=r.x0&&x<=r.x1&&z>=r.z0&&z<=r.z1,clamp=t=>Math.max(0,Math.min(1,t)),lerp=(a,b,t)=>a+(b-a)*clamp(t);
export function exteriorHeight29(x,z){return x< -65?Math.max(-.04,.05-(-x-65)*.16):.05+Math.max(0,Math.abs(z)-55)*.012}
export function bridgeHeight26(x,z){const px=x/1.2+50,pz=z/1.2+50;return BRIDGE26.some(r=>within(px,pz,r))?4.6:null}
export const stairAt26=(px,pz)=>STAIRS26.find(r=>within(px,pz,r))||null;
export function groundFloor26(x,z){if(Math.abs(x)>60||Math.abs(z)>60)return exteriorHeight29(x,z);const px=x/1.2+50,pz=z/1.2+50,s=stairAt26(px,pz);if(s){const t=((s.axis==='x'?px:pz)-s.start)/(s.end-s.start),n=Math.max(0,Math.min(s.steps,Math.floor(t*s.steps+1e-8)));return s.low+(s.high-s.low)*n/s.steps}
 if(px<=29&&pz>=30&&pz<=55)return 2.8;
 if(px>=29&&px<=32&&pz>=50&&pz<=54)return 2.8;
 if(px<=29&&pz>55&&pz<=67)return lerp(2.8,1,(pz-55)/12);
 if(px>=29&&px<=39&&pz>=38&&pz<=45)return lerp(2.8,1,(px-29)/10);
 if(px>=69&&pz>=57&&pz<=81)return 4;
 if(px>=76&&pz>=43&&pz<57)return lerp(1,4,(pz-43)/14);
 if(px>=69&&pz>81&&pz<=89)return lerp(4,1,(pz-81)/8);
 if(px>=60&&px<=69&&pz>=65&&pz<=74)return lerp(1,4,(px-60)/9);
 return 1;
}
export function floor26(x,z,hint){const low=groundFloor26(x,z),high=bridgeHeight26(x,z);return high!==null&&Number.isFinite(hint)&&Math.abs(high-hint)<Math.abs(low-hint)?high:low}
export function axes26(){const xs=new Set(),zs=new Set();for(let i=0;i<=120;i++){xs.add(i-60);zs.add(i-60)}for(const v of[13,23,29,32,39,40,60,61,68,69,76])xs.add((v-50)*1.2);for(const v of[25,30,38,43,45,50,54,55,57,58,62,65,67,74,81,89])zs.add((v-50)*1.2);for(const r of STAIRS26)for(let i=0;i<=r.steps;i++)(r.axis==='x'?xs:zs).add((r.start+(r.end-r.start)*i/r.steps-50)*1.2);const clean=s=>[...s].sort((a,b)=>a-b).filter((x,i,a)=>!i||x-a[i-1]>.00001);return{x:clean(xs),z:clean(zs)}}
