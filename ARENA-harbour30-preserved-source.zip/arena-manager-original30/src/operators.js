import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

// Original fitted operator geometry and analytic animation rig. No exported
// meshes, textures, animation clips, motion data or weapon models are loaded.
const V=(x=0,y=0,z=0)=>new T.Vector3(x,y,z),Y=V(0,-1,0),clamp=T.MathUtils.clamp;
const cache=new Map(),partCache=new Map(),shared={};let palette;
function geometry(key,fn){if(!cache.has(key))cache.set(key,fn());return cache.get(key)}
function material(name,color,opts={}){return new T.MeshStandardMaterial({name,color,roughness:.78,...opts})}
function fabricTexture(normal=false){const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d'),im=g.createImageData(256,256);for(let y=0;y<256;y++)for(let x=0;x<256;x++){const i=(y*256+x)*4,n=Math.sin(x*2.4)*Math.cos(y*2.4),weave=(x%4<2?1:-1)*(y%4<2?1:-1);if(normal){im.data[i]=128+n*9;im.data[i+1]=128+weave*8;im.data[i+2]=252}else{const a=210+n*9+weave*8;im.data[i]=im.data[i+1]=im.data[i+2]=a}im.data[i+3]=255}g.putImageData(im,0,0);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(4,4);if(!normal)t.colorSpace=T.SRGBColorSpace;return t}
function getPalette(){if(palette)return palette;const map=fabricTexture(),normalMap=fabricTexture(true),cloth={map,normalMap,normalScale:new T.Vector2(.23,.23),roughness:.94};palette={
 amber:material('uniform-amber',0x8f8367,cloth),blue:material('uniform-blue',0x52666c,cloth),vest:material('plate-carrier',0x424b40,cloth),web:material('nylon-webbing',0x686c50,cloth),patch:material('patch',0x212e2c,cloth),lining:material('cloth-seams',0x9e9b7f),skin:material('skin',0xbc9478,{roughness:.7}),skinDark:material('skin-shadow',0x9a735c),hair:material('brows',0x3f3b31),eye:material('eye',0x151e1c,{roughness:.2}),helmet:material('helmet',0x66705a,{roughness:.65}),rubber:material('rubber',0x30372f),sole:material('boot-sole',0x252e2c),boot:material('boot-leather',0x5b6050,{roughness:.85}),glove:material('glove',0x4a5145,{roughness:.94}),metal:material('gunmetal',0x303d3e,{metalness:.75,roughness:.34}),edge:material('machined-metal',0x6e7a76,{metalness:.85,roughness:.32}),bronze:material('anodised-bronze',0x897b59,{metalness:.65,roughness:.38}),lens:material('optic-glass',0x2b5c60,{metalness:.65,roughness:.12}),amberMark:material('amber-unit',0xd4ac67),blueMark:material('blue-unit',0x64bac7),red:material('wire',0xaa5a43)};return palette}
function add(parent,geo,ma,x=0,y=0,z=0,sx=1,sy=1,sz=1){const m=new T.Mesh(geo,ma);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=false;m.receiveShadow=true;parent.add(m);return m}
function rounded(w,h,d,r=.018){return geometry(`r:${w}:${h}:${d}:${r}`,()=>{const s=new T.Shape(),x=-w/2,y=-h/2;r=Math.min(r,w*.48,h*.48);s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);const geo=new T.ExtrudeGeometry(s,{depth:d,steps:1,bevelEnabled:true,bevelSize:Math.min(.006,d*.15),bevelThickness:Math.min(.004,d*.15),bevelSegments:1,curveSegments:3});geo.translate(0,0,-d/2);return geo})}
function box(p,ma,x,y,z,w,h,d,r=.012){return add(p,rounded(w,h,d,r),ma,x,y,z)}
function ball(p,ma,x,y,z,w,h=w,d=w){return add(p,geometry('ball',()=>new T.SphereGeometry(1,12,10)),ma,x,y,z,w,h,d)}
function cylinder(p,ma,x,y,z,r,h,rotate=false){const m=add(p,geometry('cylinder',()=>new T.CylinderGeometry(1,1,1,10)),ma,x,y,z,r,h,r);if(rotate)m.rotation.x=Math.PI/2;return m}
function loft(key,rings,segments=14,fold=.008){return geometry(key,()=>{const positions=[],uv=[],indices=[];for(let j=0;j<rings.length;j++){const [y,w,d,cz=0]=rings[j];for(let i=0;i<=segments;i++){const a=i/segments*Math.PI*2,wrinkle=1+Math.sin(a*5+j*2.3)*fold*3;positions.push(Math.sin(a)*w*wrinkle,y,Math.cos(a)*d*wrinkle+cz);uv.push(i/segments,j/(rings.length-1));if(j<rings.length-1&&i<segments){const k=j*(segments+1)+i;if(rings.at(-1)[0]>rings[0][0])indices.push(k,k+1,k+segments+1,k+1,k+segments+2,k+segments+1);else indices.push(k,k+segments+1,k+1,k+1,k+segments+1,k+segments+2)}}}const up=rings.at(-1)[0]>rings[0][0];for(const end of [0,rings.length-1]){const center=positions.length/3;positions.push(0,rings[end][0],rings[end][3]||0);uv.push(.5,end?1:0);for(let i=0;i<segments;i++){const a=end*(segments+1)+i,b=a+1;if((end===0)===up)indices.push(center,b,a);else indices.push(center,a,b)}}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g})}
function strap(p,ma,points,width=.014){const curve=new T.CatmullRomCurve3(points.map(a=>V(...a)));return add(p,new T.TubeGeometry(curve,12,width,5,false),ma)}
function joint(parent,name){const g=new T.Group();g.name=name;g.userData.joint=true;parent.add(g);return g}
function bake(part,key){part.updateMatrix();const bins=new Map();for(const m of [...part.children])if(m.isMesh){const name=m.material.name;let g=m.geometry.clone();m.updateMatrix();g.applyMatrix4(m.matrix);if(g.index)g=g.toNonIndexed();if(!bins.has(name))bins.set(name,{ma:m.material,geos:[]});bins.get(name).geos.push(g);part.remove(m)}for(const [name,{ma,geos}]of bins){const id=key+':'+name;let geo=partCache.get(id);if(!geo){geo=mergeGeometries(geos,false);partCache.set(id,geo)}for(const g of geos)g.dispose();add(part,geo,ma)}}
function makeGun(parent,m){
 const gun=joint(parent,'weapon');
 add(gun,loft('receiver',[[-.07,.037,.2,.13],[-.04,.045,.23,.13],[.06,.045,.23,.13],[.08,.03,.19,.13]],10,0),m.metal);
 box(gun,m.bronze,0,.022,.41,.073,.091,.27,.015);for(let i=0;i<8;i++){box(gun,m.rubber,.04,.02,.32+i*.026,.009,.029,.014,.003);box(gun,m.rubber,-.04,.02,.32+i*.026,.009,.029,.014,.003);box(gun,m.edge,0,.081,.05+i*.055,.058,.012,.02,.003)}
 cylinder(gun,m.metal,0,.025,.62,.017,.22,true);cylinder(gun,m.edge,0,.025,.745,.025,.065,true);for(let i=0;i<3;i++)box(gun,m.rubber,.024,.023,.73+i*.015,.004,.02,.009,.001);
 box(gun,m.rubber,0,-.09,.12,.045,.115,.058,.012).rotation.x=-.25;
 const trigger=add(gun,geometry('trigger',()=>new T.TorusGeometry(.028,.006,5,10,Math.PI*1.7)),m.metal,0,-.062,.19);trigger.rotation.y=Math.PI/2;
 box(gun,m.metal,0,.019,-.16,.052,.053,.21,.01);box(gun,m.rubber,0,.012,-.285,.065,.13,.07,.02);box(gun,m.bronze,0,.06,-.21,.065,.045,.15,.012);
 for(const x of [-.048,.048]){cylinder(gun,m.edge,x,.025,.04,.01,.01).rotation.z=Math.PI/2;box(gun,m.bronze,x,-.004,.13,.009,.018,.035,.003)}
 const magazine=joint(gun,'magazine');magazine.position.set(0,-.04,.29);add(magazine,loft('rifle-mag',[[0,.031,.049,0],[-.07,.032,.05,.006],[-.14,.031,.048,.025],[-.2,.03,.043,.052]],10,0),m.metal);for(let i=0;i<3;i++)box(magazine,m.edge,.032,-.07-i*.035,.016+i*.01,.005,.013,.077,.003);box(magazine,m.rubber,0,-.2,.049,.067,.018,.094,.005);
 const optic=joint(gun,'optic');optic.position.set(0,.11,.2);cylinder(optic,m.metal,0,.035,0,.032,.15,true);cylinder(optic,m.lens,0,.035,.08,.024,.004,true);box(optic,m.bronze,0,0,0,.045,.045,.045,.006);cylinder(optic,m.edge,.044,.04,0,.018,.026).rotation.z=Math.PI/2;
 return {gun,magazine,optic};
}
function buildHand(parent,name,m){const g=joint(parent,name);box(g,m.glove,0,-.016,0,.065,.08,.035,.018);box(g,m.rubber,0,.008,-.018,.055,.025,.014,.005);for(let i=0;i<4;i++){const x=(i-1.5)*.014;box(g,m.glove,x,-.063,.009,.012,.045,.021,.005);box(g,m.boot,x,-.043,.019,.011,.018,.007,.003)}box(g,m.glove,-.043,-.024,.012,.023,.047,.028,.01).rotation.z=-.5;return g}
export function createOperator(team=0,id=0){
 const m=getPalette(),cloth=team?m.blue:m.amber,mark=team?m.blueMark:m.amberMark,root=new T.Group(),pelvis=joint(root,'pelvis'),chest=joint(root,'chest'),head=joint(chest,'head');
 add(pelvis,loft('hips',[[-.1,.09,.075],[-.06,.15,.105],[.04,.16,.11],[.12,.135,.095]],16,.004),cloth);box(pelvis,m.web,0,.06,.102,.3,.045,.038,.012);box(pelvis,m.edge,0,.06,.128,.043,.036,.012,.004);
 for(const x of [-.12,-.06,.06,.12])box(pelvis,m.lining,x,.065,.128,.013,.05,.008,.003);
 add(chest,loft('anatomical-torso',[[0,.133,.09],[.1,.15,.103],[.22,.178,.108],[.35,.208,.105],[.43,.195,.09],[.5,.073,.064]],18,.004),cloth);
 add(chest,loft('fitted-carrier',[[.05,.137,.105],[.12,.16,.128],[.28,.164,.13],[.36,.145,.117]],16,.001),m.vest);
 box(chest,m.web,0,.23,.133,.28,.24,.031,.025);box(chest,m.patch,0,.3,.156,.115,.045,.009,.008);box(chest,mark,0,.3,.163,.072,.012,.004,.003);
 for(let row=0;row<5;row++)for(let col=0;col<5;col++)box(chest,m.web,-.115+col*.057,.11+row*.035,.158,.044,.009,.009,.002);
 for(let i=0;i<3;i++){const x=(i-1)*.081;box(chest,m.vest,x,.105,.175,.072,.13,.056,.009);box(chest,m.web,x,.16,.201,.07,.027,.014,.005);box(chest,m.lining,x,.09,.207,.012,.087,.005,.002)}
 for(const side of [-1,1]){strap(chest,m.web,[[side*.13,.28,.13],[side*.17,.43,.05],[side*.14,.38,-.1]],.019);box(chest,m.rubber,side*.14,.35,.12,.037,.043,.027,.004);box(chest,m.web,side*.17,.17,.013,.045,.17,.21,.012);box(chest,mark,side*.213,.38,.026,.013,.052,.06,.006)}
 box(chest,m.vest,0,.22,-.13,.26,.28,.075,.025);for(let i=0;i<3;i++)box(chest,m.web,0,.12+i*.06,-.174,.24,.012,.014,.003);
 // Radio, cable and a utility/medical pouch are modeled in relief.
 box(chest,m.metal,-.12,.32,.16,.055,.09,.036,.006);cylinder(chest,m.rubber,-.13,.412,.16,.006,.1);strap(chest,m.rubber,[[-.12,.32,.18],[-.18,.39,.15],[-.17,.49,.03],[-.12,.56,-.02]],.004);
 box(pelvis,m.vest,-.19,-.015,-.04,.085,.15,.15,.015);box(pelvis,m.web,-.235,.01,-.04,.014,.025,.12,.004);for(let i=0;i<2;i++){cylinder(pelvis,m.vest,.17,-.005,.10+i*.075,.028,.085);box(pelvis,m.edge,.17,.048,.10+i*.075,.012,.025,.035,.003);const pin=add(pelvis,geometry('pin',()=>new T.TorusGeometry(.018,.003,4,10)),m.edge,.18,.047,.12+i*.075);pin.rotation.y=Math.PI/2}
 // Proper adult head proportions; sculpted jaw, nose, brow, ears and eyes.
 head.position.set(0,.64,.006);cylinder(chest,m.skin,0,.526,0,.047,.1);
 add(head,loft('head-form',[[-.12,.059,.062,.025],[-.09,.09,.085,.013],[-.025,.12,.099],[.065,.115,.094],[.115,.084,.073],[.135,.035,.04]],18,.0005),m.skin);
 for(const side of [-1,1]){ball(head,m.skin,side*.12,-.008,-.003,.024,.041,.018);ball(head,m.skinDark,side*.129,-.007,.007,.009,.023,.008);box(head,m.hair,side*.049,.04,.091,.053,.011,.012,.004).rotation.z=side*.08;ball(head,m.eye,side*.049,.022,.097,.013,.006,.005);ball(head,m.skin,side*.04,-.019,.086,.036,.018,.004)}
 add(head,loft('nose',[[-.034,.012,.01,.108],[-.016,.021,.026,.112],[.045,.012,.008,.097]],10,0),m.skin);box(head,m.skinDark,0,-.069,.094,.041,.004,.006,.002);
 const helmet=add(head,geometry('helmet-shell',()=>new T.SphereGeometry(1,20,12,0,Math.PI*2,0,Math.PI*.57)),m.helmet,0,.052,-.012,.143,.135,.154);helmet.rotation.x=.05;
 const rim=add(head,geometry('helmet-rim',()=>new T.TorusGeometry(1,.035,5,24)),m.rubber,0,.032,-.012,.145,.155,.145);rim.rotation.x=Math.PI/2;
 for(const side of [-1,1]){box(head,m.bronze,side*.139,.066,-.009,.013,.025,.13,.005);for(let i=0;i<4;i++)box(head,m.rubber,side*.149,.067,-.06+i*.03,.008,.026,.009,.002);ball(head,m.rubber,side*.129,-.012,-.027,.031,.046,.036);strap(head,m.web,[[side*.12,.023,.08],[side*.105,-.082,.05],[side*.04,-.112,.08]],.007)}
 box(head,m.metal,0,.108,.128,.045,.048,.017,.007);box(head,m.edge,0,.115,.143,.025,.029,.012,.004);strap(head,m.rubber,[[.14,-.015,-.01],[.17,-.065,.1],[.07,-.084,.14]],.004);ball(head,m.rubber,.06,-.083,.139,.016,.01,.01);
 // Clear low-profile ballistic glasses and a fabric neck gaiter.
 for(const side of [-1,1])box(head,m.lens,side*.048,.023,.104,.071,.032,.008,.01);box(head,m.rubber,0,.024,.113,.018,.008,.008,.002);
 add(chest,loft('gaiter',[[.44,.09,.073],[.52,.073,.069],[.56,.068,.067]],16,.006),m.web);
 const legs=[],feet=[],arms=[],hands=[];
 for(let i=0;i<2;i++){
  const side=i?1:-1,upper=joint(root,'thigh'+i),lower=joint(root,'shin'+i),foot=joint(root,'foot'+i);
  add(upper,loft('tailored-thigh',[[0,.085,.085],[-.08,.088,.095],[-.22,.076,.087],[-.35,.064,.069],[-.43,.059,.063]],14,.007),cloth);
  box(upper,m.web,side*.082,-.2,.008,.034,.088,.105,.009);box(upper,m.vest,side*.1,-.2,.016,.034,.08,.092,.009);
  add(lower,loft('tailored-calf',[[0,.062,.066],[-.06,.067,.073],[-.17,.061,.072],[-.31,.045,.05],[-.43,.044,.045]],14,.008),cloth);
  box(lower,m.rubber,0,-.025,.064,.103,.119,.037,.027);for(let j=0;j<3;j++)box(lower,m.helmet,0,-.002-j*.028,.086,.076,.013,.008,.004);
  for(const y of [-.02,-.17]){const strapRing=add(lower,geometry('leg-strap',()=>new T.TorusGeometry(1,.08,4,14)),m.web,0,y,0,.069,.073,.069);strapRing.rotation.x=Math.PI/2}
  add(foot,loft('boot-leather',[[-.07,.047,.072,.025],[-.04,.053,.105,.043],[.01,.053,.113,.045],[.06,.048,.071,.001],[.14,.045,.045,-.015]],16,.002),m.boot);
  box(foot,m.sole,0,-.074,.044,.112,.031,.224,.026);for(let k=0;k<6;k++)box(foot,m.rubber,0,-.094,-.04+k*.034,.106,.012,.017,.003);
  for(let k=0;k<4;k++){const lace=box(foot,m.lining,0,.06-k*.015,.042+k*.012,.065,.005,.006,.002);lace.rotation.z=k%2?.12:-.12}
  legs.push({upper,lower,side});feet.push(foot);
  const upperArm=joint(root,'upperArm'+i),forearm=joint(root,'forearm'+i),hand=buildHand(root,'hand'+i,m);
  add(upperArm,loft('jacket-sleeve',[[0,.065,.065],[-.07,.077,.075],[-.17,.065,.062],[-.285,.052,.052]],14,.006),cloth);
  box(upperArm,m.vest,side*.068,-.08,.009,.019,.083,.073,.008);box(upperArm,mark,side*.079,-.082,.014,.006,.043,.049,.003);
  add(forearm,loft('rolled-forearm',[[0,.053,.053],[-.08,.06,.057],[-.18,.042,.045],[-.27,.032,.032]],12,.008),cloth);
  box(forearm,m.rubber,0,-.025,-.045,.075,.065,.019,.015);if(i===0){box(forearm,m.rubber,-.036,-.21,0,.022,.038,.052,.007);box(forearm,m.lens,-.05,-.21,0,.006,.025,.035,.004)}
  arms.push({upper:upperArm,lower:forearm,side});hands.push(hand);
 }
 // Thigh holster and compact sidearm, not a rectangular placeholder.
 const holster=legs[1].upper;box(holster,m.vest,.103,-.22,.017,.061,.17,.089,.012);box(holster,m.metal,.105,-.137,.022,.042,.025,.14,.008);box(holster,m.rubber,.103,-.18,-.031,.044,.092,.043,.008).rotation.x=-.2;
 const {gun,magazine,optic}=makeGun(root,m),heldMagazine=joint(hands[0],'held-magazine');box(heldMagazine,m.metal,0,-.035,.025,.054,.16,.077,.009);heldMagazine.scale.setScalar(0);
 const heldGrenade=new T.Group();heldGrenade.name='held-grenade';hands[1].add(heldGrenade);cylinder(heldGrenade,m.vest,0,-.03,.015,.025,.07);box(heldGrenade,m.edge,0,.012,.015,.013,.02,.028,.003);heldGrenade.scale.setScalar(0);
 const knife=new T.Group();knife.name='knife-prop';root.add(knife);cylinder(knife,m.rubber,0,0,-.025,.018,.12,true);box(knife,m.edge,0,0,.044,.065,.014,.018,.004);const blade=new T.Shape();blade.moveTo(-.014,0);blade.lineTo(.014,0);blade.lineTo(.011,.19);blade.lineTo(-.009,.25);blade.lineTo(-.014,.14);blade.closePath();const bladeGeo=new T.ExtrudeGeometry(blade,{depth:.006,bevelEnabled:false});bladeGeo.rotateX(Math.PI/2);add(knife,bladeGeo,m.edge,0,.003,.05);knife.scale.setScalar(0);
 const sidearm=joint(root,'sidearm');box(sidearm,m.metal,0,.025,.11,.045,.052,.19,.01);box(sidearm,m.bronze,0,-.007,.11,.043,.025,.16,.007);box(sidearm,m.rubber,0,-.056,.045,.042,.095,.05,.009).rotation.x=-.18;cylinder(sidearm,m.metal,0,.025,.215,.012,.04,true);box(sidearm,m.edge,0,.057,.04,.023,.009,.016,.002);sidearm.scale.setScalar(0);
 for(const part of [pelvis,chest,head,...legs.flatMap(l=>[l.upper,l.lower]),...feet,...arms.flatMap(l=>[l.upper,l.lower]),...hands,gun,magazine,optic,heldMagazine,sidearm,heldGrenade,knife])bake(part,part.name);
 const op={root,pelvis,chest,head,legs,feet,arms,hands,gun,magazine,optic,heldMagazine,heldGrenade,sidearm,knife,id,phase:(id%5)*.41,speed:0,crouch:0,recoil:0,kickVelocity:0,aim:0,dead:0,team,anchors:[],footPhases:[],lastYaw:null,turn:0,accelX:0,accelZ:0,lastVX:0,lastVZ:0,jointCount:0,wristTargets:[],lastPose:{},stats:{footError:0,armError:0,meshes:0,triangles:0}};
 root.traverse(o=>{if(o.userData.joint)op.jointCount++;if(o.isMesh){op.stats.meshes++;op.stats.triangles+=o.geometry.index?o.geometry.index.count/3:o.geometry.attributes.position.count/3}});return op;
}

function solve(start,end,l1,l2,pole){const axis=end.clone().sub(start),distance=clamp(axis.length(),.005,l1+l2-.001);axis.normalize();const along=(l1*l1-l2*l2+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,l1*l1-along*along)),perp=pole.clone().addScaledVector(axis,-pole.dot(axis)).normalize();return start.clone().addScaledVector(axis,along).addScaledVector(perp,height)}
function pointSegment(g,a,b){g.position.copy(a);g.quaternion.setFromUnitVectors(Y,b.clone().sub(a).normalize())}
function smooth(a,b,s,dt){return T.MathUtils.lerp(a,b,1-Math.exp(-s*dt))}
// Hand-authored action poses; cubic timing gives anticipation, contact and recovery.
function track(keys,t){t=clamp(t,0,1);for(let i=1;i<keys.length;i++)if(t<=keys[i][0]){const a=keys[i-1],b=keys[i],u=clamp((t-a[0])/(b[0]-a[0]),0,1),v=u*u*(3-2*u);return V(a[1],a[2],a[3]).lerp(V(b[1],b[2],b[3]),v)}const b=keys.at(-1);return V(b[1],b[2],b[3])}
const THROW_HAND=[[0,.17,.31,.26],[.22,.2,.62,-.18],[.4,.19,.69,-.29],[.58,.14,.56,.6],[.78,.08,.19,.62],[1,.18,.3,.31]];
const PLANT_HAND=[[0,.12,.4,.35],[.2,.12,.36,.38],[.38,.1,.405,.32],[.53,.13,.38,.37],[.7,.1,.405,.33],[.87,.12,.37,.37],[1,.14,.43,.31]];
export function poseOperator(op,p,dt){
 const time=(p.time||0)+op.id*1.731,speed=Math.hypot(p.vx||0,p.vz||0),crouchTarget=p.crouch||0,reload=p.reload??-1,throwing=p.throw??-1,plant=p.plant??-1;
 op.speed=smooth(op.speed,speed,10,dt);op.crouch=smooth(op.crouch,plant>=0?1:crouchTarget,9,dt);op.aim=smooth(op.aim,p.aim?1:0,8,dt);op.dead=smooth(op.dead,p.dead?1:0,4,dt);if(p.shot)op.kickVelocity+=2.6;op.kickVelocity+=(-92*op.recoil-15*op.kickVelocity)*dt;op.recoil=clamp(op.recoil+op.kickVelocity*dt,0,1.6);
 op.accelX=smooth(op.accelX,clamp(((p.vx||0)-op.lastVX)/Math.max(.001,dt),-6,6),5,dt);op.accelZ=smooth(op.accelZ,clamp(((p.vz||0)-op.lastVZ)/Math.max(.001,dt),-6,6),5,dt);op.lastVX=p.vx||0;op.lastVZ=p.vz||0;
 const turnTarget=p.world&&op.lastYaw!==null?Math.atan2(Math.sin(p.world.yaw-op.lastYaw),Math.cos(p.world.yaw-op.lastYaw))/Math.max(.001,dt):0;op.lastYaw=p.world?.yaw??null;op.turn=smooth(op.turn,clamp(turnTarget,-4,4),7,dt);
 const run=clamp((op.speed-1.5)/1.8,0,1),support=.62-.23*run,stride=clamp(op.speed*(.7+(.98-.7)*(1-run))*support,.1,.84),cycleSpeed=op.speed/stride*support;op.phase+=dt*(cycleSpeed+Math.abs(op.turn)*.16*(1-clamp(op.speed/.3,0,1)))*Math.PI*2;
 const active=Math.max(clamp(op.speed/.25,0,1),clamp(Math.abs(op.turn)/2,0,1)),direction=V(p.vx||0,0,p.vz||0);if(direction.lengthSq()>.0001)direction.normalize();else direction.set(0,0,1);
 const w=p.world,terrainDrop=w&&p.groundAt?clamp((w.y||0)-Math.min(...[-.3,.3].map(d=>p.groundAt(w.x+Math.sin(w.yaw)*d,w.z+Math.cos(w.yaw)*d))),0,.2)*.75:0;
 const hip=.925-terrainDrop-op.crouch*.285-.085*active-run*.015+Math.cos(op.phase*2)*.009*active,breath=Math.sin(time*2.5)*.002*(1-active),lean=.025+run*.08-op.aim*.02+op.accelZ*.008;
 op.root.rotation.z=op.dead*1.52;op.root.position.y=-op.dead*.65;
 op.pelvis.position.set(Math.sin(op.phase)*.012*active,hip,Math.cos(op.phase*2)*.006*active);op.pelvis.position.x+=Math.sin(op.phase)*.012*(1-run)*active;op.pelvis.rotation.y=Math.sin(op.phase)*.065*active;
 op.chest.position.set(-op.pelvis.position.x*.35,hip+.065+breath,-op.crouch*.035);op.pelvis.rotation.z=Math.sin(op.phase)*.018*active;op.chest.rotation.set(lean+op.crouch*.1+op.recoil*.03,clamp(p.aimYaw||0,-.78,.78)*op.aim-Math.sin(op.phase)*.025*active,Math.sin(op.phase)*.016*active-op.accelX*.009-op.turn*.012);
 op.head.rotation.set(smooth(op.head.rotation.x,-.03-run*.06+op.aim*.07+Math.sin(time*1.6)*.008,9,dt),smooth(op.head.rotation.y,clamp(p.aimYaw||0,-.8,.8)*.35+(1-op.aim)*(Math.sin(time*.57)*.1+clamp(op.turn*.09,-.2,.2)),7,dt),-.025*op.aim);op.head.position.z=.008+op.aim*.025;
 let maxFootError=0;
 for(let i=0;i<2;i++){
  const l=op.legs[i],phase=((op.phase/(Math.PI*2)+i*.5)%1+1)%1,stance=phase<support,u=stance?phase/support:(phase-support)/(1-support);
  const sweep=stance?.5-u:-.5+u,raise=stance?0:(1-Math.cos(u*Math.PI*2))*.5*(.08+run*.12),ankle=V(l.side*.105, .098+raise*active,0).addScaledVector(direction,sweep*stride*active);
  ankle.z-=op.crouch*.025;ankle.x+=l.side*op.crouch*.04;
  if(p.world){const w=p.world,cs=Math.cos(w.yaw),sn=Math.sin(w.yaw);if(stance){if(!op.anchors[i]||op.footPhases[i]===false){const wx=w.x+ankle.x*cs+ankle.z*sn,wz=w.z-ankle.x*sn+ankle.z*cs;op.anchors[i]={x:wx,z:wz,y:(p.groundAt?.(wx,wz)??w.y??0)+ankle.y}}const anchor=op.anchors[i],dx=anchor.x-w.x,dz=anchor.z-w.z;ankle.set(dx*cs-dz*sn,anchor.y-(w.y||0),dx*sn+dz*cs)}else{op.anchors[i]=null;const wx=w.x+ankle.x*cs+ankle.z*sn,wz=w.z-ankle.x*sn+ankle.z*cs;ankle.y+=(p.groundAt?.(wx,wz)??w.y??0)-(w.y||0)}op.footPhases[i]=stance;}
  const hipPos=V(l.side*.105+op.pelvis.position.x,hip,0),reach=ankle.clone().sub(hipPos);if(reach.length()>.855){ankle.copy(hipPos).add(reach.setLength(.855));if(p.world)op.anchors[i]=null}const knee=solve(hipPos,ankle,.43,.43,V(l.side*.12,.05,1));pointSegment(l.upper,hipPos,knee);pointSegment(l.lower,knee,ankle);op.feet[i].position.copy(ankle);op.feet[i].rotation.set((stance?(u<.2?-.12*(1-u/.2):u>.78?.24*(u-.78)/.22:0):-Math.sin(u*Math.PI)*.16)*active,clamp((p.vx||0)*.08,-.25,.25),0);
  maxFootError=Math.max(maxFootError,Math.abs(hipPos.distanceTo(knee)-.43),Math.abs(knee.distanceTo(ankle)-.43));
 }
 op.gun.position.set(.075+Math.sin(op.phase)*.006*active,hip+.31+.18*op.aim-op.crouch*.025,.24);op.gun.rotation.set((1-op.aim)*(.29+run*.37)-.015-op.recoil*.07,op.chest.rotation.y,.02+Math.sin(op.phase)*.022*active*(1-op.aim));op.gun.position.x+=op.turn*.008-op.accelX*.002;op.gun.position.z-=op.recoil*.027;op.gun.position.y+=Math.sin(time*2)*.002+Math.cos(op.phase*2)*.007*active;
 op.heldGrenade.scale.setScalar(throwing>=0&&throwing<.66?1:0);let leftTarget=null,rightTarget=null;const switchPhase=p.switch??-1,pistol=p.sidearm||switchPhase>.45;const handling=throwing>=0||plant>=0;op.gun.scale.setScalar(pistol||p.knife||handling?0:1);op.sidearm.scale.setScalar(pistol&&!p.knife&&!handling?1:0);op.knife.scale.setScalar(p.knife&&!handling?1:0);if(p.sniper&&op.gun.scale.x>0)op.gun.scale.z=1.2;
 if(switchPhase>=0||p.sidearm){op.sidearm.position.set(.105,hip+.31+.22*op.aim,.37+.1*op.aim);op.sidearm.rotation.set((1-op.aim)*.32-op.recoil*.05,op.chest.rotation.y,0);if(switchPhase>=0&&switchPhase<.65){const t=clamp(switchPhase/.65,0,1);op.sidearm.position.lerp(V(.22,hip-.16,.12),1-t);op.gun.rotation.x+=Math.sin(switchPhase*Math.PI)*.8;op.gun.position.y-=Math.sin(switchPhase*Math.PI)*.2}if(pistol){rightTarget=op.sidearm.position.clone().add(V(0,-.06,.04));leftTarget=rightTarget.clone().add(V(-.055,0,.015))}}
 if(reload>=0){const down=Math.sin(clamp(reload/.16,0,1)*Math.PI/2)*(1-clamp((reload-.85)/.15,0,1));op.gun.rotation.z=-.28*down;op.gun.rotation.x=.24*down;op.gun.position.y-=.12*down;op.magazine.scale.setScalar(reload>.2&&reload<.64?0:1);op.heldMagazine.scale.setScalar(reload>.3&&reload<.65?1:0)}else{op.magazine.scale.setScalar(1);op.heldMagazine.scale.setScalar(0)}
 if(p.knife){op.knife.position.set(.14,hip+.3,.38);op.knife.rotation.set(.06,op.chest.rotation.y,.04);rightTarget=op.knife.position.clone().add(V(0,-.015,-.025));leftTarget=V(-.18,hip+.28,.22)}
 if(throwing>=0){op.gun.rotation.x=.7;op.gun.position.y-=.15;const t=clamp(throwing,0,1);rightTarget=track(THROW_HAND,t);rightTarget.y+=hip;leftTarget=V(-.18,hip+.1,.2);op.chest.rotation.y+=Math.sin(t*Math.PI*2)*.12;op.chest.rotation.x-=Math.sin(t*Math.PI)*.06}
 if(plant>=0){op.gun.position.y-=.22;op.gun.rotation.x=.9;leftTarget=V(-.11,.37,.32);rightTarget=track(PLANT_HAND,plant);op.chest.rotation.x=.32;op.head.rotation.x=.34}
 const equipT=clamp(p.equip??1,0,1),equipDip=1-equipT*equipT*(3-2*equipT);op.gun.position.y-=equipDip*.23;op.gun.rotation.x+=equipDip*.55;op.sidearm.position.y-=equipDip*.18;op.sidearm.rotation.x+=equipDip*.35;if(pistol&&plant<0&&throwing<0){if(leftTarget)leftTarget.y-=equipDip*.18;if(rightTarget)rightTarget.y-=equipDip*.18}op.gun.updateMatrix();op.chest.updateMatrix();
 let maxArmError=0;
 for(let i=0;i<2;i++){
  const a=op.arms[i],shoulder=V(a.side*.205,.395,0).applyMatrix4(op.chest.matrix),target=(i?V(.015,-.08,.13):V(-.025,-.015,.45)).applyMatrix4(op.gun.matrix);
  if(!i&&reload>=0){const magwell=V(0,-.14,.29).applyMatrix4(op.gun.matrix),pouch=V(-.09,hip+.12,.26),bolt=V(-.05,.065,.045).applyMatrix4(op.gun.matrix);if(reload<.2)target.copy(magwell);else if(reload<.4)target.copy(magwell).lerp(pouch,(reload-.2)/.2);else if(reload<.65)target.copy(pouch).lerp(magwell,(reload-.4)/.25);else if(reload<.83)target.copy(magwell).lerp(bolt,(reload-.65)/.18);else target.copy(bolt).lerp(V(-.025,-.015,.45).applyMatrix4(op.gun.matrix),(reload-.83)/.17)}
  if(!i&&leftTarget)target.copy(leftTarget);if(i&&rightTarget)target.copy(rightTarget);
  if(!op.wristTargets[i])op.wristTargets[i]=target.clone();op.wristTargets[i].lerp(target,1-Math.exp(-dt*18));target.copy(op.wristTargets[i]);const delta=target.clone().sub(shoulder);if(delta.length()>.55)target.copy(shoulder).add(delta.setLength(.55));const elbow=solve(shoulder,target,.285,.27,V(a.side,-.4,-.25));pointSegment(a.upper,shoulder,elbow);pointSegment(a.lower,elbow,target);op.hands[i].position.copy(target);op.hands[i].rotation.set(plant>=0?-.15:throwing>=0?-.5:-1.1,op.gun.rotation.y+(plant>=0?.2:0),i?.13:-.7);
  maxArmError=Math.max(maxArmError,Math.abs(shoulder.distanceTo(elbow)-.285),Math.abs(elbow.distanceTo(target)-.27));
 }
 op.lastPose={action:switchPhase>=0?'switch':plant>=0?'plant':throwing>=0?'throw':reload>=0?'reload':op.crouch>.4?'crouch':op.aim>.5&&op.speed<.1?'aim':Math.abs(p.vx||0)>Math.abs(p.vz||0)?'strafe':op.speed>1.8?'run':op.speed>.1?'walk':'idle',speed:op.speed,crouch:op.crouch,reload,phase:op.phase,footError:maxFootError,armError:maxArmError};op.stats.footError=maxFootError;op.stats.armError=maxArmError;return op.lastPose;
}
