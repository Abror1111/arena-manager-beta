const profiles={
 desert:{sky:'#719fbf',horizon:'#eadbc1',zenith:'#376991',sun:'#fff0ca',earth:'#c9b692',rock:'#b5a187',plants:'#76814b',fog:'#d8cfb5',relief:2.5,clouds:.25,ambient:1.48,sunPower:2.0,exposure:1.17},
 clay:{sky:'#94b8d0',horizon:'#f2dfc4',zenith:'#5785ad',sun:'#ffe5bb',earth:'#a8aa85',rock:'#b5ab92',plants:'#67844d',fog:'#d2d3ba',relief:3.6,clouds:.46,ambient:1.52,sunPower:1.95,exposure:1.16},
 industry:{sky:'#95b3c2',horizon:'#d8e0dd',zenith:'#5e849c',sun:'#f4f1d9',earth:'#9daba0',rock:'#929c94',plants:'#6f855a',fog:'#ccd7d5',relief:2.2,clouds:.62,ambient:1.53,sunPower:1.84,exposure:1.14},
 jungle:{sky:'#91b9b5',horizon:'#d9e1bc',zenith:'#527e8b',sun:'#fff0cc',earth:'#839367',rock:'#929c77',plants:'#476e43',fog:'#c3d1b7',relief:5.0,clouds:.44,ambient:1.57,sunPower:1.92,exposure:1.18},
 river:{sky:'#82b9d0',horizon:'#ecdfbf',zenith:'#467eaa',sun:'#fff0c8',earth:'#b9b68f',rock:'#ccbd9a',plants:'#6b8b5a',fog:'#dad8ba',relief:2.1,clouds:.24,ambient:1.48,sunPower:2.0,exposure:1.17},
 city:{sky:'#96bace',horizon:'#e0e5d8',zenith:'#5d89ac',sun:'#fff0d7',earth:'#9ca98e',rock:'#a3afa3',plants:'#5c8056',fog:'#d1dace',relief:2.8,clouds:.51,ambient:1.5,sunPower:1.93,exposure:1.15}
};
const families={dust2:'desert',mirage:'desert',inferno:'clay',nuke:'industry',train:'industry',ancient:'jungle','ancient-night':'jungle',anubis:'river',overpass:'city',vertigo:'city',cache:'city'};
export function environmentProfile(map){const family=families[map.id]||'city',p={...profiles[family],family,night:!!map.night,cityDepth:map.id==='vertigo'?18:0};if(p.night)Object.assign(p,{sky:'#1c374e',horizon:'#516c78',zenith:'#09182b',sun:'#bedcf7',fog:'#536c74',earth:'#6d8476',rock:'#82928b',ambientSky:'#b0cbd7',ambientGround:'#36574a',ambient:1.65,sunPower:1.22,exposure:1.2,clouds:.28});if(map.id==='train'&&!p.night)Object.assign(p,{horizon:'#e2cbb4',sun:'#ffe0b3',clouds:.54});if(map.id==='vertigo')Object.assign(p,{clouds:.33,earth:'#98a5a4'});return p;}
