import manifest from './bundled-audio.json' with {type:'json'};
import {loadAsset} from './asset-cache.js';
export const bundledAudio=manifest;
export function musicKey(name){
 const p=name.toLowerCase(),file=p.split('/').at(-1);
 if(!p.includes('/music/')||!/^[-a-z0-9_.]+\.(wav|mp3|ogg|opus|flac)$/.test(file))return null;
 if(/mainmenu|main_menu|^menu\./.test(file))return'music:menu';
 if(/roundmvp|mvpanthem|roundwon|round_won|^win\./.test(file))return'music:win';
 if(/roundlost|round_lost|^loss\./.test(file))return'music:loss';
 if(/bombplanted|bomb_planted/.test(file))return'music:planted';
 if(/tensec|ten_sec/.test(file))return'music:countdown';
 return null;
}
export function validateBundledAudio(pack){
 if(pack?.schema!==1||pack.assetType!=='arena-runtime-audio'||!Array.isArray(pack.clips)||pack.clips.length>128)throw Error('Audio manifest invalid');
 const keys=new Set();let total=0;
 for(const c of pack.clips){
  if(typeof c.key!=='string'||keys.has(c.key)||!/^(shot:[a-z0-9]+|reload:[a-z0-9]+|ambient:(wind|forest|city|industry|water)|footstep|he|c4|c4beep|plant|defuse|bounce|throw|flash|fire|fireloop|smoke|reload|hit|death|roundStart|roundEnd|music:(menu|match|win|loss|planted|countdown))$/.test(c.key)||!/^audio\/[a-f0-9]{64}\.(ogg|mp3|wav)$/.test(c.url)||!Number.isSafeInteger(c.bytes)||c.bytes<1||c.bytes>8*1024**2||!/^[a-f0-9]{64}$/.test(c.sha256)||!Number.isFinite(c.duration)||c.duration<=0||c.duration>(c.key.startsWith('music:')?120:8))throw Error('Audio entry invalid');
  if(c.fallback&&(!/^audio\/[a-f0-9]{64}\.wav$/.test(c.fallback.url)||!Number.isSafeInteger(c.fallback.bytes)||c.fallback.bytes<44||c.fallback.bytes>2*1024**2||!/^[a-f0-9]{64}$/.test(c.fallback.sha256)))throw Error('Audio compatibility entry invalid');
  keys.add(c.key);total+=c.bytes+(c.fallback?.bytes||0);
 }
 if(total>24*1024**2)throw Error('Audio budget exceeded');
 return pack.clips;
}
export async function loadBundledClip(entry,{signal}={}){return(await loadAsset({...entry,url:'../'+entry.url},{signal})).bytes;}
