// MR12 regulation and repeatable MR3 overtime. Team identities do not change.
export function sideAt(initial,team,round){const swapped=round<=24?round>12:Math.floor((round-25)/3)%2===0;const first=(initial==='T')!==swapped?'T':'CT';return team===0?first:first==='T'?'CT':'T';}
export function winTarget(score){return Math.min(...score)<12?13:16+Math.floor((Math.min(...score)-12)/3)*3;}
export function roundStatus(game){
 const r=game.round,ot=r>24,block=ot?Math.floor((r-25)/6)+1:0,halfEnd=ot?24+Math.ceil((r-24)/3)*3:r<=12?12:24;
 const target=winTarget(game.score),left=ot?24+block*6-r:24-r;
 return{target,overtime:block,halfEnd,untilSwitch:Math.max(0,halfEnd-r),roundsLeft:Math.max(0,left),toWin:game.score.map(s=>Math.max(0,target-s)),nextSide:sideAt(game.initialSide,0,r+1),switchNext:sideAt(game.initialSide,0,r)!==sideAt(game.initialSide,0,r+1)};
}
