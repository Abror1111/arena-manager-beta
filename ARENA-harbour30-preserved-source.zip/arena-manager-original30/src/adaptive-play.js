import {navStepLocation} from './reference-nav.js';
const dist=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const point=p=>({x:p.x,y:p.y||0,z:p.z});
const variants=['contact','split','fast','late'];
export const PLAN_LABELS={contact:'Nazorat bilan kirish',split:'Ikki yo‘nalish',fast:'Tezkor bosim',late:'Granata bilan tayyorlash'};
export function newLearning(){return[0,1].map(()=>({lastPlan:null,lastSite:null,lastWon:null,losses:0,plays:[0,0,0,0],wins:[0,0,0,0],danger:[]}));}
export function chooseAdaptation(game,team,plan,tools){
 const learning=game.tactics.learning[team],strategy=team===0?game.strategy:game.enemyStrategy;
 const crew=game.players.filter(p=>p.team===team),skill=crew.reduce((n,p)=>n+(p.tacticalSkill??p.skill),0)/5;
 if(learning.lastWon===false&&strategy==='balanced')plan.site=1-learning.lastSite;
 const choices=variants.map((id,i)=>({id,i,weight:(learning.wins[i]+1)/(learning.plays[i]+2)+game.random()*(1.4-skill*.009)})).filter(p=>learning.lastWon!==false||p.id!==learning.lastPlan);
 choices.sort((a,b)=>b.weight-a.weight);plan.variant=choices[0].id;plan.reason=learning.lastWon===false?'Oldingi mag‘lubiyatdan keyin reja o‘zgardi':'Rollar va xarita nazorati';
 const base=plan.variant==='fast'?11:plan.variant==='late'?25:plan.variant==='split'?19:16;plan.executeAt=game.elapsed+base+game.random()*5;
 const spawn=game.map.spawns[crew[0].side==='T'?0:1],site=game.map.sites[plan.site];plan.approach=null;
 if(crew[0].side==='T'&&plan.variant==='split'&&tools.routePath){
  const route=tools.pathfind(game.map,spawn,site),middle=route.slice(Math.floor(route.length*.15),Math.floor(route.length*.8));
  const alt=tools.routePath(game.map,spawn,site,q=>middle.some(p=>dist(p,q)<1.5)?3:0);
  if(alt.length){const ranked=alt.map((p,i)=>({p,i,d:Math.min(99,...route.map(a=>dist(a,p)))})).filter(q=>q.i>alt.length*.2&&q.i<alt.length*.8).sort((a,b)=>b.d-a.d);if(ranked[0]?.d>1.2)plan.approach=point(ranked[0].p);}
 }
 return plan;
}
export function recordAdaptation(game,winner){
 if(!(game.tactics?.version>=4))return;
 for(let team=0;team<2;team++){
  const h=game.tactics.learning[team],plan=game.tactics.teams[team],i=variants.indexOf(plan.variant);if(i<0)continue;
  h.lastPlan=plan.variant;h.lastSite=plan.site;h.lastWon=team===winner;h.losses=team===winner?0:Math.min(20,h.losses+1);h.plays[i]++;if(team===winner)h.wins[i]++;
  if(team!==winner){for(const p of game.players.filter(p=>p.team===team&&!p.alive)){if(!h.danger.some(q=>dist(q,p)<2))h.danger.unshift(point(p));}h.danger=h.danger.slice(0,6);}
 }
}
export function routePenalty(p,now=0){const danger=p.brain?.avoid||[],blocked=p.brain?.blocked;if(!danger.length&&!(blocked?.until>now))return undefined;return q=>danger.some(a=>Math.abs(a.y-q.y)<1.5&&dist(a,q)<2.6)?2.6:blocked?.until>now&&Math.abs(blocked.y-q.y)<1.5&&dist(blocked,q)<1.2?6:0;}
export function validLearning(t){
 if(t.version<4)return true;
 return Array.isArray(t.learning)&&t.learning.length===2&&t.learning.every(h=>h&&[null,...variants].includes(h.lastPlan)&&[null,0,1].includes(h.lastSite)&&[null,true,false].includes(h.lastWon)&&Number.isInteger(h.losses)&&h.losses>=0&&h.losses<=20&&['plays','wins'].every(k=>Array.isArray(h[k])&&h[k].length===4&&h[k].every(v=>Number.isInteger(v)&&v>=0&&v<=1000))&&h.wins.every((v,i)=>v<=h.plays[i])&&Array.isArray(h.danger)&&h.danger.length<=6&&h.danger.every(p=>p&&['x','y','z'].every(k=>Number.isFinite(p[k]))));
}
export function checkMotion(game,p,tools){
 const b=p.brain,m=b.motion;if(!m||!p.goal||dist(p,p.goal)<.8||game.elapsed-m.activeAt>.25)return;
 if(Math.hypot(p.x-m.x,p.z-m.z)>.5){m.x=p.x;m.z=p.z;m.since=game.elapsed;m.repairs=0;return;}
 if(game.elapsed-m.since>1.7){
  let blocker=game.players.filter(q=>q.id!==p.id&&q.alive&&q.team===p.team&&Math.abs(q.y-p.y)<1&&dist(q,p)<1.2&&tools.clearLine(game.map,p,q,.2)&&(['anchor','control','postplant'].includes(q.brain?.state)||m.repairs>=2&&q.brain?.motion?.repairs>=1&&['execute','retake','rotate','spacing'].includes(q.brain?.state))&&q.targetId===null).sort((a,b)=>dist(a,p)-dist(b,p))[0];
  if(blocker&&!(blocker.brain.yieldUntil>game.elapsed)&&!(b.yieldUntil>game.elapsed)){
   const jam=m.repairs>=2&&blocker.brain.motion?.repairs>=1,rank=q=>game.bomb.carrier===q.id?-1:q.id,winner=jam&&rank(blocker)<rank(p)?blocker:p,yielder=winner===p?blocker:p;
   const obstacle=blocker;blocker=yielder;
   const points=game.map.nav?game.map.nav.rows.map(r=>({x:r[3][0],z:r[3][1],y:r[3][2]})).filter(q=>Math.abs(q.y-blocker.y)<.5&&dist(q,blocker)>.55&&dist(q,blocker)<(jam?3:1.8)):Array.from({length:12},(_,i)=>({x:blocker.x+Math.sin(i*Math.PI/6)*1.2,z:blocker.z+Math.cos(i*Math.PI/6)*1.2,y:blocker.y}));
   if(jam)for(const radius of [.7,1.3,2])for(let i=0;i<12;i++)points.push({x:blocker.x+Math.sin(i*Math.PI/6)*radius,z:blocker.z+Math.cos(i*Math.PI/6)*radius,y:blocker.y});
   const candidates=points.map(q=>game.map.reference?navStepLocation(game.map,blocker,q,blocker.goal||game.map.sites[game.tactics.teams[blocker.team].site]):q).filter(q=>q&&Math.abs(q.y-blocker.y)<.5);
   const choices=candidates.filter(q=>dist(q,winner)>dist(blocker,winner)+.3&&tools.clearLine(game.map,blocker,q,.2)&&!game.players.some(a=>a.id!==blocker.id&&a.alive&&Math.abs(a.y-q.y)<1&&dist(a,q)<.55));choices.sort((a,c)=>(dist(c,winner)-dist(c,blocker)*.5)-(dist(a,winner)-dist(a,blocker)*.5));
   if(choices[0]){blocker.brain.yieldPoint=point(choices[0]);blocker.brain.yieldUntil=game.elapsed+(jam?3:1.7);winner.brain.passUntil=game.elapsed+3;blocker.path=[];blocker.goal=null;}
   b.blocked={...point(obstacle),until:game.elapsed+4};
  }
  // If yielding and replanning still fail, walk back to a clear local floor
  // before trying the objective again. Never relocate or snap the agent.
  if(m.repairs>=3&&!(b.yieldUntil>game.elapsed)&&game.elapsed-(b.recoveryAt??-99)>7&&game.map.reference){
   const points=game.map.nav.rows.map(r=>({x:r[3][0],z:r[3][1],y:r[3][2]})).filter(q=>dist(q,p)>.7&&dist(q,p)<3&&Math.abs(q.y-p.y)<.45).map(q=>navStepLocation(game.map,p,q,p.goal)).filter(q=>q&&Math.abs(q.y-p.y)<.45&&tools.clearLine(game.map,p,q,.2)&&!game.players.some(a=>a.id!==p.id&&a.alive&&Math.abs(a.y-q.y)<1&&dist(a,q)<.7));
   const clearance=q=>Math.min(3,...game.players.filter(a=>a.id!==p.id&&a.alive).map(a=>dist(a,q)))-dist(q,p)*.15;
   points.sort((a,c)=>clearance(c)-clearance(a));if(points[0]){b.yieldPoint=point(points[0]);b.yieldUntil=game.elapsed+2.2;b.recoveryAt=game.elapsed;b.blocked={...point(p),until:game.elapsed+8};}
  }
  p.path=[];p.goal=null;p.repath=0;p.safeRoute=true;b.passUntil=game.elapsed+2;m.since=game.elapsed;m.repairs++;
 }
}
export function advanceControl(game,p,plan,tools){
 const b=p.brain;if(p.side!=='T'||game.elapsed>=plan.executeAt||game.elapsed-(b.lastAdvance||0)<(b.squadRole==='sniper'?4.5:2.5)||dist(p,b.staging)>.8)return;
 const target=b.routeVia&&!b.viaCleared?b.routeVia:game.map.sites[plan.site],route=tools.pathfind(game.map,p,target);let distance=0,from=p;
 for(const q of route){distance+=dist(from,q);if(distance>=1.1){if(!game.players.some(a=>a.id!==p.id&&a.team===p.team&&a.alive&&dist(a,q)<1.2)){b.staging=point(q);p.goal=null;p.path=[];}break;}from=q;}
 b.lastAdvance=game.elapsed;
}
