const limit=(n,a,b)=>Math.max(a,Math.min(b,n));
const point=p=>({x:p.x,z:p.z,y:p.y||0});
const middle=(a,b)=>({x:(a.x+b.x)/2,z:(a.z+b.z)/2,y:((a.y||0)+(b.y||0))/2});
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);

// Stable story selection: shots may expire every 120ms, camera shots must not.
export function createObserverDirector(){
 let focus=null,lastSwitch=-Infinity,lastRound=null;
 return {sample(game,time){
  if(lastRound!==game.round){focus=null;lastSwitch=-Infinity;lastRound=game.round;}
  const live=game.players.filter(p=>p.alive),candidates=[];
  const bomb=game.bomb;
  if(bomb?.state==='planted')candidates.push({id:'bomb',kind:'c4',priority:bomb.timer<12?110:65,...point(bomb),span:8});
  if(bomb?.progress>0&&game.players[bomb.actor]?.alive)candidates.push({id:'objective-'+bomb.actor,kind:'objective',priority:120,...point(game.players[bomb.actor]),span:7});
  for(const e of game.effects||[])if(e.kind==='c4'&&e.age<5)candidates.push({id:'explosion',kind:'c4',priority:130,...point(e),span:18});
  for(const a of live)for(const b of live)if(a.id<b.id&&a.team!==b.team){
   const d=distance(a,b);if(d>24)continue;
   const shooting=(game.shots||[]).some(s=>distance(s,a)<2||distance(s,b)<2),tracking=a.targetId===b.id||b.targetId===a.id;if(!shooting&&!tracking&&d>7)continue;
   candidates.push({id:`contact-${a.id}-${b.id}`,kind:'combat',priority:(shooting?90:50)-d*.7,...middle(a,b),span:limit(d*.42+4.5,6.5,11),actorId:a.id,otherId:b.id,axis:Math.atan2(b.x-a.x,b.z-a.z)});
  }
  if(!candidates.length&&live.length){
   const p=live.find(p=>p.side==='T')||live[0];
   candidates.push({id:'advance-'+p.id,kind:'advance',priority:10,...point(p),span:8,actorId:p.id,axis:p.angle});
  }
  candidates.sort((a,b)=>b.priority-a.priority||a.id.localeCompare(b.id));
  const best=candidates[0],same=focus&&candidates.find(c=>c.id===focus.id);
  if(best&&(!focus||(time-lastSwitch>=4.5&&best.id!==focus.id)||(best.kind==='combat'&&focus.kind==='advance'||best.priority>=110&&best.priority>(focus.priority||0)+15))){focus=best;lastSwitch=time;}
  else if(same)focus=same;
  // During a held shot continue tracking its actor even if a fleeting contact ends.
  else if(focus?.actorId!==undefined){const p=game.players[focus.actorId];if(p?.alive)focus={...focus,...point(p),axis:p.angle};}
  return focus?{...focus}:null;
 }};
}

// A fixed floor boundary is deliberate; actor.y + a margin sliced the whole map.
export function observerClipHeight(map,level,actor){
 const hasLower=Number.isFinite(map.lowerClip);
 return hasLower&&(level==='lower'||(level==='auto'&&Number.isFinite(actor?.y)&&actor.y<map.lowerClip-.05))?map.lowerClip:1000;
}

export function observerAngles(mode,time,playerId=0,reducedMotion=false){
 if(mode==='static')return{tilt:24*Math.PI/180,yaw:.16};
 if(reducedMotion)return{tilt:31*Math.PI/180,yaw:.25};
 return mode==='player'
  ?{tilt:(31+2*Math.sin(time*.11))*Math.PI/180,yaw:.35+.35*Math.sin(time*.055+playerId*.3)}
  :{tilt:(30+3*Math.sin(time*.09))*Math.PI/180,yaw:.5*Math.sin(time*.045)+.15};
}

// Match the frustum to an angled, rotated map rather than its unprojected axes.
export function overviewFrame(view,aspect,tilt,yaw){
 const width=view.maxX-view.minX,depth=view.maxZ-view.minZ;
 const horizontal=width*Math.abs(Math.cos(yaw))+depth*Math.abs(Math.sin(yaw));
 const vertical=(width*Math.abs(Math.sin(yaw))+depth*Math.abs(Math.cos(yaw)))*Math.cos(tilt)+4;
 return Math.max(vertical/2,horizontal/(2*Math.max(.4,aspect)))*1.09+1;
}

export const GRAPHICS_QUALITY=['balanced','sharp','battery'];
export function observerResolution(quality,width,height,dpr,mobile){
 const q=GRAPHICS_QUALITY.includes(quality)?quality:'balanced';
 const cap=q==='battery'?1.25:q==='sharp'?2:1.75;
 const budget=q==='battery'?850000:q==='sharp'?(mobile?2200000:4000000):(mobile?1400000:2800000);
 return Math.max(.75,Math.min(dpr||1,cap,Math.sqrt(budget/(Math.max(1,width)*Math.max(1,height)))));
}
