import {navWalkLine} from './reference-nav.js';
export const captureMotion=game=>({round:game.round,players:game.players.map(p=>({x:p.x,y:p.y||0,z:p.z,angle:p.angle}))});
// Interpolate only the last authoritative simulation step. Never modify a save,
// smooth across a wall, or blend old-round positions into a new spawn.
export function presentAgents(game,previous,alpha=1){
 if(!previous||previous.round!==game.round)return game.players;
 const t=Math.max(0,Math.min(1,alpha));
 return game.players.map(p=>{const q=previous.players[p.id];if(!q||Math.hypot(p.x-q.x,p.z-q.z)>2||Math.abs((p.y||0)-q.y)>.8)return p;
  if(game.map.reference&&!navWalkLine(game.map,q,p))return p;
  return{...p,x:q.x+(p.x-q.x)*t,y:q.y+((p.y||0)-q.y)*t,z:q.z+(p.z-q.z)*t,angle:q.angle+Math.atan2(Math.sin(p.angle-q.angle),Math.cos(p.angle-q.angle))*t};
 });
}
