// Arena combat tuning; names/capacities follow CS2, not a copy of its engine.
const rows=[
// id, name, family, magazine, reserve, interval, damage, range, reload, $, side
['glock','Glock-18','pistol',20,120,.22,20,20,2.2,200,'T'],
['usp','USP-S','pistol',12,24,.28,25,23,2.2,200,'CT'],
['p2000','P2000','pistol',13,52,.24,24,23,2.2,200,'CT'],
['p250','P250','pistol',13,26,.23,27,21,2.2,300,'both'],
['dual','Dual Berettas','pistol',30,120,.15,22,20,3.8,300,'both'],
['fiveseven','Five-SeveN','pistol',20,100,.2,28,22,2.3,500,'CT'],
['tec9','Tec-9','pistol',18,90,.18,28,22,2.5,500,'T'],
['cz75','CZ75-Auto','pistol',12,12,.1,25,18,2.7,500,'both'],
['deagle','Desert Eagle','pistol',7,35,.46,51,25,2.2,700,'both'],
['r8','R8 Revolver','pistol',8,8,.75,66,26,2.3,600,'both'],
['mac10','MAC-10','smg',30,100,.075,24,20,2.6,1050,'T'],
['mp9','MP9','smg',30,120,.08,23,21,2.1,1250,'CT'],
['mp7','MP7','smg',30,120,.08,25,23,3.1,1500,'both'],
['mp5','MP5-SD','smg',30,120,.08,24,23,3,1500,'both'],
['ump45','UMP-45','smg',25,100,.09,30,21,3.5,1200,'both'],
['p90','P90','smg',50,100,.067,22,23,3.4,2350,'both'],
['bizon','PP-Bizon','smg',64,120,.08,21,20,2.4,1400,'both'],
['ak','AK-47','rifle',30,90,.115,34,30,2.4,2700,'T'],
['m4','M4A4','rifle',30,90,.105,31,29,2.3,2900,'CT'],
['m4a1s','M4A1-S','rifle',20,80,.105,33,31,3.1,2900,'CT'],
['galil','Galil AR','rifle',35,90,.09,29,28,3,1800,'T'],
['famas','FAMAS','rifle',25,90,.09,28,28,3.3,1950,'CT'],
['aug','AUG','rifle',30,90,.1,30,34,3.3,3300,'CT'],
['sg553','SG 553','rifle',30,90,.11,33,35,2.8,3000,'T'],
['ssg08','SSG 08','sniper',10,90,1.25,74,43,3.7,1700,'both'],
['awp','AWP','sniper',5,30,1.35,115,45,3.2,4750,'both'],
['scar20','SCAR-20','sniper',20,90,.3,70,42,3.1,5000,'CT'],
['g3sg1','G3SG1','sniper',20,90,.3,70,42,4.7,5000,'T'],
['nova','Nova','shotgun',8,32,.85,83,14,2.9,1050,'both'],
['xm1014','XM1014','shotgun',7,32,.35,64,13,3.2,2000,'both'],
['mag7','MAG-7','shotgun',5,32,.85,88,12,2.4,1300,'CT'],
['sawedoff','Sawed-Off','shotgun',7,32,.85,90,11,3.2,1100,'T'],
['m249','M249','heavy',100,200,.08,30,29,5.7,5200,'both'],
['negev','Negev','heavy',150,300,.075,28,28,5.7,1700,'both'],
['zeus','Zeus x27','special',1,0,1,125,2.2,0,200,'both'],
['knife','Pichoq','melee',0,0,.65,42,1.8,0,0,'both'],
];
export const WEAPON_FAMILIES=[['pistol','Pistoletlar'],['smg','Pulemyotchalar'],['rifle','Avtomatlar'],['sniper','Snayperlar'],['shotgun','Droboviklar'],['heavy','Pulemyotlar'],['special','Elektroshoker'],['melee','Pichoq']];
const profiles={pistol:{accuracy:.6,burst:1,pause:.17,recoil:.045},smg:{accuracy:.58,burst:5,pause:.38,recoil:.055},rifle:{accuracy:.65,burst:3,pause:.52,recoil:.075},sniper:{accuracy:.78,burst:1,pause:.35,recoil:.1},shotgun:{accuracy:.67,burst:1,pause:.2,recoil:.1},heavy:{accuracy:.51,burst:7,pause:.65,recoil:.075},special:{accuracy:.86,burst:1,pause:.2,recoil:0},melee:{accuracy:1,burst:1,pause:0,recoil:0}};
export const WEAPONS=Object.fromEntries(rows.map(([id,name,family,mag,reserve,rate,damage,range,reload,price,side])=>[id,{name,family,mag,reserve,rate,damage,range,reload,price,side,silenced:['usp','m4a1s','mp5'].includes(id),pellets:family==='shotgun'?6:1,profile:{...profiles[family],...(id==='m4'?{accuracy:.68,pause:.47,recoil:.065}:id==='awp'?{accuracy:.8}:id==='glock'?{accuracy:.57}:id==='usp'?{accuracy:.62,pause:.14,recoil:.035}:id==='deagle'?{accuracy:.62,pause:.36,recoil:.12}:id==='cz75'?{burst:3,pause:.3}:id==='r8'?{pause:.35,recoil:.12}:{})}}]));
export const availableWeapon=(id,side)=>!!WEAPONS[id]&&(WEAPONS[id].side==='both'||WEAPONS[id].side===side);
// Genuine source clips present in the compact agent packs; use the closest rig
// when a weapon-specific clip was not included, rather than freezing the arms.
export const weaponAnimation=id=>({m4:'m4a4',m4a1s:'m4a4',aug:'m4a4',famas:'m4a4',galil:'ak',sg553:'ak',scar20:'awp',g3sg1:'awp',ssg08:'awp',xm1014:'nova',mag7:'nova',sawedoff:'nova',m249:'ak',negev:'ak',r8:'deagle',p2000:'usp',p250:'usp',fiveseven:'usp',tec9:'glock',dual:'glock',cz75:'glock',zeus:'glock',mac10:'mp9',mp7:'mp9',mp5:'mp9',p90:'mp9',bizon:'mp9',ump45:'mp9'}[id]||id);
