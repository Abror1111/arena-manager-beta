import * as T from 'three';
export function makeEffectTextures(){
 const result={};
 for(const kind of ['smoke','flame','flare']){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const c=canvas.getContext('2d');
  if(kind==='flame'){
   const glow=c.createRadialGradient(64,89,1,64,80,58);glow.addColorStop(0,'#ffcc6755');glow.addColorStop(1,'#ff440000');c.fillStyle=glow;c.fillRect(0,0,128,128);
   const g=c.createLinearGradient(0,110,0,7);g.addColorStop(0,'#fffbcbee');g.addColorStop(.32,'#ffc147ed');g.addColorStop(.7,'#fa702dd0');g.addColorStop(1,'#ed4d1900');c.fillStyle=g;
   c.beginPath();c.moveTo(18,114);c.bezierCurveTo(2,79,48,63,43,37);c.quadraticCurveTo(57,70,65,8);c.bezierCurveTo(65,55,106,61,96,34);c.bezierCurveTo(124,85,120,108,104,119);c.closePath();c.fill();
  }else{
   const g=c.createRadialGradient(64,64,0,64,64,64);
   if(kind==='smoke'){g.addColorStop(0,'#ffffffef');g.addColorStop(.4,'#ffffffcf');g.addColorStop(.73,'#ffffff65');g.addColorStop(1,'#ffffff00');}
   else{g.addColorStop(0,'#ffffffff');g.addColorStop(.12,'#ffffe7ff');g.addColorStop(.34,'#fff2c58a');g.addColorStop(1,'#fff1c000');}
   c.fillStyle=g;c.fillRect(0,0,128,128);
   if(kind==='flare'){c.strokeStyle='#fffbdcab';c.lineWidth=1.5;for(let i=0;i<8;i++){const a=i*Math.PI/4;c.beginPath();c.moveTo(64+Math.cos(a)*3,64+Math.sin(a)*3);c.lineTo(64+Math.cos(a)*56,64+Math.sin(a)*56);c.stroke();}}
  }
  const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;result[kind]=texture;
 }
 return result;
}
