import {validateBundledAudio,loadBundledClip} from './bundled-audio.js';
import {runtimeAudio} from './runtime-audio.js';
import {audioKey} from './audio-pack-rules.js';
const DB='arena-original20-audio-v1';let pending;
function db(){return pending??=new Promise((resolve,reject)=>{const req=indexedDB.open(DB,1);req.onupgradeneeded=()=>req.result.createObjectStore('packs');req.onsuccess=()=>resolve(req.result);req.onerror=()=>{pending=null;reject(Error('Ovozlarni saqlash uchun qurilma xotirasi ochilmadi.'));};});}
export async function readAudioPack(){try{const d=await db();return await new Promise((resolve,reject)=>{const q=d.transaction('packs').objectStore('packs').get('active');q.onsuccess=()=>resolve(q.result||null);q.onerror=()=>reject(q.error);});}catch{return null;}}
export async function writeAudioPack(pack){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('packs','readwrite');t.objectStore('packs').put(pack,'active');t.oncomplete=resolve;t.onerror=()=>reject(Error('Ovozlarni saqlashga joy yetmadi. Oldingi to‘plam saqlandi.'));t.onabort=()=>reject(Error('Ovoz saqlash tugamadi.'));});}
export async function removeAudioPack(){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('packs','readwrite');t.objectStore('packs').delete('active');t.oncomplete=resolve;t.onerror=()=>reject(t.error);});}
export function importAudioPack(file){return new Promise(async(resolve,reject)=>{if(!file||file.size>180*1024**2||file.size<32)return reject(Error('180 MB gacha ARENA audio ZIP tanlang.'));let worker;const timeout=setTimeout(()=>{worker?.terminate();reject(Error('Audio tekshiruvi uzoq davom etdi. Qayta urinib ko‘ring.'));},120000);try{const bytes=await file.arrayBuffer();worker=new Worker(new URL('./audio-pack-worker.js',import.meta.url),{type:'module'});worker.onmessage=async({data})=>{clearTimeout(timeout);worker.terminate();if(!data.ok)return reject(Error(data.error));try{const Context=globalThis.OfflineAudioContext||globalThis.webkitOfflineAudioContext;if(!Context)throw Error('Bu qurilmada audio o‘qish mavjud emas.');const decoder=new Context(1,1,22050),usable=[];for(const clip of data.pack.clips){try{const buffer=await decoder.decodeAudioData(clip.bytes.slice(0));if(buffer.duration>0&&buffer.duration<=8&&buffer.numberOfChannels<=2)usable.push(clip);}catch{}}if(!usable.length)throw Error('Bu audio formatlari qurilmada o‘qilmadi yoki yozuvlar 8 soniyadan uzun.');data.pack.clips=usable;await writeAudioPack(data.pack);resolve(data.pack);}catch(e){reject(e);}};worker.onerror=()=>{clearTimeout(timeout);worker.terminate();reject(Error('Audio ZIP tekshiruvi ochilmadi.'));};worker.postMessage(bytes,[bytes]);}catch(e){clearTimeout(timeout);worker?.terminate();reject(e);}});}
export function createOriginalAudioBank(ctx,{manifest=runtimeAudio,load=loadBundledClip,readLocal=readAudioPack}={}){
 // Decode at the shipped effect rate, independent of a 48/96kHz output device.
 // Buffers keep their pitch when WebAudio resamples them during playback.
 const Offline=globalThis.OfflineAudioContext||globalThis.webkitOfflineAudioContext;let decoder=ctx;
 if(Offline)try{decoder=new Offline(1,1,32000);}catch{}
 const entries=validateBundledAudio(manifest).filter(e=>!e.key.startsWith('music:')),keys=new Set(entries.map(e=>e.key)),buffers=new Map(),failures=new Map(),controller=new AbortController();let promise,disposed=false,total=0,source='procedural',attempt=-Infinity,localRead=false,loading=false;
 async function decode(key,bytes,origin,format){
  const buffer=await decoder.decodeAudioData(bytes.slice(0));if(disposed)return false;
  if(buffer.duration<=0||buffer.duration>8||buffer.numberOfChannels>2)throw Error('Ovoz formati mos emas.');
  const cost=buffer.length*buffer.numberOfChannels*4,old=buffers.get(key);if(total-(old?.cost||0)+cost>24*1024**2)throw Error('Ovoz xotirasi chegarasi.');
  let peak=0;for(let ch=0;ch<buffer.numberOfChannels;ch++){const a=buffer.getChannelData(ch);for(let i=0;i<a.length;i++)peak=Math.max(peak,Math.abs(a[i]));}if(peak<.0005)throw Error('Ovoz yozuvi bo‘sh.');
  buffers.set(key,{buffer,cost,gain:Math.min(2.5,.75/peak),origin,format});total+=cost-(old?.cost||0);source=origin;failures.delete(key);return true;
 }
 async function entry(e){
  if(disposed||buffers.has(e.key))return;
  for(const asset of[e,e.fallback].filter(Boolean))try{const bytes=await load(asset,{signal:controller.signal});if(await decode(e.key,bytes,e.origin==='arena-original'?'arena-original':'cs2-bundled',asset.url.endsWith('.wav')?'pcm':'ogg'))return;}catch(error){if(!disposed)failures.set(e.key,error.message||'Ovoz yuklanmadi.');}
 }
 return{get ready(){return buffers.size>0;},get source(){return source;},get count(){return buffers.size;},get expected(){return entries.length;},get loaded(){return buffers.size;},get totalExpected(){return entries.length;},get totalLoaded(){return buffers.size;},get status(){return loading?'loading':!entries.length&&!buffers.size?'empty':entries.every(e=>buffers.has(e.key))?'ready':buffers.size?'partial':'error';},get errors(){return failures.size;},get formats(){return [...new Set([...buffers.values()].map(e=>e.format))];},hasKey:key=>keys.has(key),get:key=>buffers.get(key),prepare({force=false}={}){
  if(disposed)return Promise.resolve();if(promise)return promise;
  if(!force&&Date.now()-attempt<2000)return Promise.resolve();
  if(localRead&&entries.every(e=>buffers.has(e.key)))return Promise.resolve();
  loading=true;attempt=Date.now();promise=(async()=>{
   const todo=entries.filter(e=>!buffers.has(e.key));let cursor=0;await Promise.all(Array.from({length:Math.min(3,todo.length)},async()=>{while(cursor<todo.length&&!disposed)await entry(todo[cursor++]);}));
   if(disposed||localRead)return;localRead=true;const pack=await readLocal();if(disposed||!pack)return;
   for(const clip of pack.clips||[])try{if(clip.name&&audioKey(clip.name)!==clip.key)continue;await decode(clip.key,clip.bytes,'cs2-local','local');}catch{/* Invalid personal clips cannot replace a verified bundled recording. */}
  })().finally(()=>{loading=false;promise=null;});return promise;
 },dispose(){disposed=true;controller.abort();buffers.clear();failures.clear();total=0;}};
}
