import React from 'react';
import {createRoot} from 'react-dom/client';
import {Manager} from './Manager.jsx';
import './style.css';
import './career.css';
import './visual-polish.css';
import './app-responsive.css';
import './ui15.css';
import './club-economy.css';
class ErrorBoundary extends React.Component {
 state={error:false};
 static getDerivedStateFromError(){return {error:true};}
 render(){return this.state.error?<div className="fatal"><h1>ARENA qayta ochilishi kerak</h1><p>Saqlangan klubingiz qurilmada qoladi. Ilovani qayta oching yoki saqlangan zaxira faylidan tiklang.</p><button onClick={()=>location.reload()}>Qayta ochish</button></div>:this.props.children;}
}
createRoot(document.getElementById('root')).render(<ErrorBoundary><Manager/></ErrorBoundary>);
if(!window.ArenaAndroid&&'serviceWorker' in navigator){
 window.addEventListener('load',()=>navigator.serviceWorker.register(new URL('./service-worker.js',document.baseURI)).catch(()=>{}),{once:true});
}
