import {validateBundledAudio,loadBundledClip} from './bundled-audio.js';
import {runtimeAudio} from './runtime-audio.js';
export const AUDIO_SETTINGS_EVENT='arena:audio-settings';
export function readEffectsVolume(){try{const v=localStorage.getItem('arena-effects-volume-v1');return v===null?1:Math.min(1,Math.max(0,Number(v)||0));}catch{return 1;}}
export function saveEffectsVolume(value){const volume=Math.min(1,Math.max(0,Number(value)||0));try{localStorage.setItem('arena-effects-volume-v1',String(volume));}catch{}globalThis.dispatchEvent?.(new Event(AUDIO_SETTINGS_EVENT));return volume;}
export function readMusicVolume(){try{const v=localStorage.getItem('arena-music-volume-v1');return v===null?.18:Math.min(.5,Math.max(0,Number(v)||0));}catch{return .18;}}
export function saveMusicVolume(value){const volume=Math.min(.5,Math.max(0,Number(value)||0));try{localStorage.setItem('arena-music-volume-v1',String(volume));}catch{}globalThis.dispatchEvent?.(new Event(AUDIO_SETTINGS_EVENT));return volume;}
export function musicCue(game){
 if(game.outro>0)return null;
 if(game.phase==='roundend'||game.phase==='matchend')return game.result?.winner===0?'music:win':'music:loss';
 if(game.phase==='live'&&game.bomb?.state==='planted')return game.bomb.timer<=10?'music:countdown':'music:planted';
 if(game.phase==='live'&&game.clock<=10)return'music:countdown';
 if(game.phase==='live')return'music:match';
 return null;
}
// Verified compressed tracks stream from Blob URLs: no long PCM buffers in RAM.
// Verified CS2 cues and separately attributed original ARENA compositions.
export function createSoundtrack({manifest=runtimeAudio,load=loadBundledClip,createAudio=url=>new Audio(url),makeURL=(bytes,type)=>URL.createObjectURL(new Blob([bytes],{type})),revokeURL=url=>URL.revokeObjectURL(url),volume=readMusicVolume()}={}){
 const tracks=new Map(validateBundledAudio(manifest).filter(c=>c.key.startsWith('music:')).map(c=>[c.key,c]));
 let desired=null,current=null,retiring=null,sequence=0,disposed=false,unlocked=false,hidden=false,enabled=true,ducked=false,loading=null,played=0,lastCue=null;
 const release=item=>{if(!item)return;item.audio.pause();item.audio.removeAttribute('src');item.audio.load();revokeURL(item.url);};
 const level=()=>enabled&&!hidden?volume*(current?.key==='music:match'?.4:1)*(ducked?.35:1):0;
 function fade(){if(current)current.audio.volume=Math.min(level(),current.audio.volume+.012);if(retiring){retiring.audio.volume=Math.max(0,retiring.audio.volume-.025);if(retiring.audio.volume<=0){release(retiring);retiring=null;}}}
 const timer=tracks.size?setInterval(fade,40):null;
 async function start(){
  if(disposed||!unlocked||hidden||!enabled||!desired||!tracks.has(desired)||loading||current?.key===desired)return;
  const key=desired,ticket=sequence,controller=new AbortController();loading=controller;
  try{const bytes=await load(tracks.get(key),{signal:controller.signal});if(disposed||ticket!==sequence||hidden||!enabled)return;
   const entry=tracks.get(key),type=entry.url.endsWith('.mp3')?'audio/mpeg':entry.url.endsWith('.wav')?'audio/wav':'audio/ogg';const url=makeURL(bytes,type);let audio;try{audio=createAudio(url);}catch(e){revokeURL(url);throw e;}const item={url,audio,key};audio.loop=key==='music:menu'||key==='music:match';audio.volume=0;
   try{await audio.play();}catch{release(item);return;}
   if(disposed||ticket!==sequence||hidden||!enabled){release(item);return;}
   release(retiring);retiring=current;current=item;played++;lastCue=key;
   audio.onended=()=>{if(current===item){release(current);current=null;}};
  }catch{/* Missing or corrupt audio must never block gameplay. */}finally{if(loading===controller)loading=null;}
 }
 function setCue(key){if(key===desired)return;desired=key;sequence++;loading?.abort();loading=null;release(retiring);retiring=current;current=null;start();}
 return{setCue,setDucked(value){ducked=!!value;},unlock(){unlocked=true;if(current&&current.audio.paused&&!hidden&&enabled)current.audio.play().catch(()=>{});return start();},
  setVolume(value){volume=Math.min(.5,Math.max(0,Number(value)||0));if(current)current.audio.volume=Math.min(current.audio.volume,level());},
  setEnabled(value){enabled=!!value;if(!enabled){if(current){current.audio.volume=0;current.audio.pause();}if(retiring){release(retiring);retiring=null;}}else if(!hidden){if(current)current.audio.play().catch(()=>{});else start();}},
  setHidden(value){hidden=!!value;if(hidden){current?.audio.pause();release(retiring);retiring=null;}else if(enabled){if(current)current.audio.play().catch(()=>{});else start();}},
  get available(){return tracks.size;},get cue(){return current?.key||null;},get played(){return played;},get lastCue(){return lastCue;},
  dispose(){if(disposed)return;disposed=true;sequence++;loading?.abort();clearInterval(timer);release(current);release(retiring);current=retiring=null;}
 };
}
