export const HD_ASSET_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/a4858f4d1ab4715eb6d07cb5da9549ce8d4da677/source-hd/";
