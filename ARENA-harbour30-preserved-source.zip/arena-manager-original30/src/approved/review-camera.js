import districts from './surroundings-layouts.json' with {type:'json'};
import {exteriorHeight} from './map-terrain.js';
import {mapContextFrame,mapContextPlan} from './map-context-data.js';
import {MAP_ATMOSPHERES} from './map-atmosphere-profiles.js';
export const CAMERA_PRESETS={
 surroundings:{name:'Atrof-muhit',tilt:49,yaw:-.65,exclude:'dust2'},
 overview:{name:'Tepadagi',tilt:24,yaw:.063},
 details:{name:'Fasadlar va muhit',tilt:56,yaw:-.65,exclude:'dust2'},
 front:{name:'Old tomondan',tilt:52,yaw:.28},
 left:{name:'Yon tomondan',tilt:49,yaw:-.91},
 back:{name:'Orqa tomondan',tilt:50,yaw:2.85},
 facades:{name:'Fasadlar',tilt:52,yaw:.28,map:'dust2',focus:[-17,6,27],zoom:1.8},
 streets:{name:'Ko‘chalar',tilt:38,yaw:-.08,map:'dust2',focus:[-5,4,7],zoom:2.25},
 marked:{name:'Chekka binolar',tilt:70,yaw:Math.PI,map:'dust2',focus:[-5.5,6,0],zoom:1.05},
 water:{name:'Suv va sohil',tilt:58,yaw:1.15,map:'dust2',focus:[39,3,3],zoom:1.75},
 coast:{name:'Sohil tomoni',tilt:55,yaw:Math.PI/3,map:'dust2',focus:[0,5,-1],zoom:1.05}
};
export function cameraOffset(id='overview',radius=900,map=null){const p=CAMERA_PRESETS[id]||CAMERA_PRESETS.overview,t=p.tilt*Math.PI/180;let yaw=p.yaw;if(id==='details'&&map&&map.id!=='dust2'&&map.id!=='vertigo'){const index={riad:2,villa:1,temple:1,ruin:3,plant:2,warehouse:1,depot:0,park:3}[MAP_ATMOSPHERES[map.id].architecture];yaw=[-Math.PI/2,Math.PI/2,Math.PI,0][index%4]+.24;}return[Math.sin(yaw)*Math.sin(t)*radius,Math.cos(t)*radius,Math.cos(yaw)*Math.sin(t)*radius];}
export function cameraPose(id,map){
 const p=CAMERA_PRESETS[id]||CAMERA_PRESETS.overview,v=map.view;
 if(id==='surroundings'&&map.id!=='dust2'){const d=districts[map.id],p=d.kind==='jungle'?d.plants[0]:d.buildings[0];if(p){const x=p.x??p[0],z=p.z??p[1];return{target:[x,map.id==='vertigo'?4:exteriorHeight(mapContextPlan(map.id),MAP_ATMOSPHERES[map.id],x,z)+3,z],zoom:1.65};}}

 const target=map.id==='dust2'?[-5.5,6,0]:(mapContextFrame(map.id)?.target||[(v.minX+v.maxX)/2-map.width/2,2,(v.minZ+v.maxZ)/2-map.height/2]);
 if(id==='details'&&map.id!=='dust2'){const plan=mapContextPlan(map.id),indices={riad:2,villa:1,temple:1,ruin:3,plant:2,warehouse:1,depot:0,park:3},index=indices[MAP_ATMOSPHERES[map.id]?.architecture];if(index!==undefined){const a=plan.anchors[index];return{target:[a[0],exteriorHeight(plan,MAP_ATMOSPHERES[map.id],...a)+2.6,a[1]],zoom:map.id==='nuke'?4.4:3.1};}return{target:[-1.5,4,.5],zoom:1.6};}
 return{target:p.focus&&p.map===map.id?[...p.focus]:target,zoom:p.focus&&p.map===map.id?p.zoom:1};
}
