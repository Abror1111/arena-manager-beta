import {loadAsset as loadGameAsset} from '../asset-cache.js';
// Inspection, matches and the library use the same verified binary cache.
export function resolveApprovedEntry(entry){
 const base=new URL('./',globalThis.location?.href||'http://arena.test/');
 let path=entry.url;
 if(!/^https?:\/\//.test(path))path=path.startsWith(base.pathname)?path.slice(base.pathname.length):path.replace(/^\//,'');
 return {...entry,url:new URL(path,base).href};
}
export function loadAsset(entry,options){return loadGameAsset(resolveApprovedEntry(entry),options);}
