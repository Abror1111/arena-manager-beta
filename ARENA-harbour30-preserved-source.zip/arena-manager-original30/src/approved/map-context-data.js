import districts from './surroundings-layouts.json' with {type:'json'};
import p0 from './map-context-plans/mirage.json' with {type:'json'};
import p1 from './map-context-plans/vertigo.json' with {type:'json'};
import p2 from './map-context-plans/nuke.json' with {type:'json'};
import p3 from './map-context-plans/anubis.json' with {type:'json'};
import p4 from './map-context-plans/ancient.json' with {type:'json'};
import p5 from './map-context-plans/inferno.json' with {type:'json'};
import p6 from './map-context-plans/overpass.json' with {type:'json'};
import p7 from './map-context-plans/cache.json' with {type:'json'};
import p8 from './map-context-plans/train.json' with {type:'json'};
import p9 from './map-context-plans/ancient-night.json' with {type:'json'};
export const MAP_CONTEXT_PLANS={'./map-context-plans/mirage.json':p0,'./map-context-plans/vertigo.json':p1,'./map-context-plans/nuke.json':p2,'./map-context-plans/anubis.json':p3,'./map-context-plans/ancient.json':p4,'./map-context-plans/inferno.json':p5,'./map-context-plans/overpass.json':p6,'./map-context-plans/cache.json':p7,'./map-context-plans/train.json':p8,'./map-context-plans/ancient-night.json':p9};
export function mapContextPlan(id){return MAP_CONTEXT_PLANS['./map-context-plans/'+id+'.json'];}
export function mapContextFrame(id){return districts[id]?.coreFrame||null;}
export function mapLightingFrame(id){const p=mapContextPlan(id),d=districts[id];if(!p||!d)return null;const q=d.coreFrame;return{min:[q.min[0]-38,id==='vertigo'?-160:q.min[1]-6,q.min[2]-38],max:[q.max[0]+38,q.max[1]+14,q.max[2]+38]};}
