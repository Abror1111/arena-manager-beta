export const CONTEXT_ASSET_PREFIX="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/c54f138be493645c1fc2854ee46fb1a4d4883633/context/";
