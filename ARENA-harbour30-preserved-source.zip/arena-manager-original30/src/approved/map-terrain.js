import * as T from 'three';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
export function exteriorHeight(plan,profile,x,z){
 if(profile.architecture==='skyline')return plan.sourceBounds[1]-.5;
 const bounds=plan.navBounds,dx=Math.max(bounds[0]-x,x-bounds[2],0),dz=Math.max(bounds[1]-z,z-bounds[3],0),d=Math.hypot(dx,dz),outside=smooth(9,30,d);
 const relief=profile.weather==='sand'?1.2*Math.sin(x*.083+Math.sin(z*.035))*Math.sin(z*.062):profile.family==='temple'?2.1*Math.sin(x*.062)*Math.sin(z*.075):.8*Math.sin(x*.047+1)*Math.cos(z*.061);
 let h=plan.groundY+outside*(.7+relief);
 const grid=plan.structure?.groundGrid;if(grid){const count=grid.count,fx=clamp((x-grid.min)/grid.step,0,count-1),fz=clamp((z-grid.min)/grid.step,0,count-1),ix=Math.min(count-2,Math.floor(fx)),iz=Math.min(count-2,Math.floor(fz)),tx=fx-ix,tz=fz-iz,v=grid.values,g=T.MathUtils.lerp(T.MathUtils.lerp(v[iz*count+ix],v[iz*count+ix+1],tx),T.MathUtils.lerp(v[(iz+1)*count+ix],v[(iz+1)*count+ix+1],tx),tz),b=plan.sourceBounds,d=Math.hypot(Math.max(b[0]-x,x-b[3],0),Math.max(b[2]-z,z-b[5],0));h=g+smooth(6,28,d)*relief*.65;}
 // The restored Anubis Nile continues west of its export cut. Its bed must
 // remain below that water level, independently of the eastern coastline.
 if(plan.id==='anubis')h=T.MathUtils.lerp(h,-2.70,smooth(0,7,-25-x));
 if(plan.id==='overpass'){const center=plan.sourceBounds[3]+12+2.6*Math.sin(z*.053)+1.2*Math.sin(z*.137),distance=Math.abs(x-center);h=T.MathUtils.lerp(-3.8,h,smooth(3.8,6.2,distance));}
 if(profile.water&&profile.coast!==false){const shore=plan.sourceBounds[3]+8+2.6*Math.sin(z*.053)+1.2*Math.sin(z*.137),dist=x-shore;h=T.MathUtils.lerp(h,.6,smooth(-18,-7,dist));h=T.MathUtils.lerp(h,-3.6,smooth(-12,12,dist));}
 return h;
}
export function exteriorTerrain(plan,profile){const axis=[-1200,-700,-400,-220,-150];for(let x=-120;x<=120;x+=2)axis.push(x);axis.push(150,220,400,700,1200);const p=[],uv=[],ix=[],n=axis.length,f=plan.structure?.groundUV;for(const z of axis)for(const x of axis){p.push(x,exteriorHeight(plan,profile,x,z),z);uv.push(f?x*f[0][0]+z*f[1][0]+f[2][0]:x*.2,f?x*f[0][1]+z*f[1][1]+f[2][1]:z*.2);}for(let z=0;z<n-1;z++)for(let x=0;x<n-1;x++){const a=z*n+x;ix.push(a,a+n,a+1,a+1,a+n,a+n+1);}const g=surfaceGeometry(p,uv);g.setIndex(ix);g.computeVertexNormals();return g;}
function surfaceGeometry(p,uv){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setAttribute('uv1',g.attributes.uv.clone());g.computeVertexNormals();return g;}
