import {prepareApprovedCollision} from './approved-collision.js';
import {gunzipSync} from 'three/addons/libs/fflate.module.js';
import {hasCollision,registerCollision,registerDecorCollision,hasPreparedCollision} from './world-collision.js';
import {loadAsset} from './asset-cache.js';
import environment from './environment132-collisions.json' with {type:'json'};
const owners=new WeakMap();
async function readMesh(entry,signal){
 const {bytes}=await loadAsset(entry,{signal}),raw=gunzipSync(new Uint8Array(bytes));
 if(signal?.aborted)throw new DOMException('Aborted','AbortError');
 const view=new DataView(raw.buffer,raw.byteOffset,raw.byteLength),n=view.getUint32(4,true),t=view.getUint32(8,true);
 if(String.fromCharCode(...raw.subarray(0,4))!=='ACM1'||raw.byteLength!==12+n*12+t*12)throw Error('Xarita to‘qnashuv fayli buzilgan.');
 return{positions:new Float32Array(raw.buffer.slice(raw.byteOffset+12,raw.byteOffset+12+n*12)),indices:new Uint32Array(raw.buffer.slice(raw.byteOffset+12+n*12,raw.byteOffset+12+n*12+t*12))};
}
export async function prepareMapCollision(map,signal){
 if(map.approved)return prepareApprovedCollision(map,signal);
 if(!map.rebuilt)return;
 const entry=environment.maps[map.id];if(!entry||entry.baseSHA256!==map.assets.collision.sha256)throw Error('Xarita geometriyasi versiyasi mos emas.');
 map.environmentCollisionTriangles=entry.triangles;Object.defineProperty(map,'physicsRevision',{get:()=>hasPreparedCollision(map,132,entry.sha256)?132:131,configurable:true});
 if(!hasCollision(map)){const data=await readMesh(map.assets.collision,signal);registerCollision(map,data.positions,data.indices);}
 if(hasPreparedCollision(map,132,entry.sha256))return;
 const data=await readMesh(entry,signal);if(signal?.aborted)throw new DOMException('Aborted','AbortError');
 if(!owners.has(map.nav))owners.set(map.nav,{version:132,sha256:entry.sha256});
 registerDecorCollision(map,data.positions,data.indices,owners.get(map.nav),{trimBaseBelow:entry.trimBaseBelow});
}
