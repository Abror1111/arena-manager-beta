import{landmarkSolids30,landmarkBallistics30}from'./harbour-landmarks30.js';
import{stairGuards29}from'./stair-guards29.js';
import{verticalSolid29,frameProfiles29}from'./vertical-solids29.js';
import{CHOKE_WALLS26,DOORS26,leafSegments26,segmentSolid26}from'./chokepoints26.js';import{BRIDGE26,groundFloor26}from'./route-levels26.js';
import{terrainHeight25}from'./coastal-elevation25.js';
import{ShapeUtils,Vector2}from'three';
import{SITES30,SPAWNS30,OUTLINE30,DISTRICTS30,ROUTES30,INTERIORS30,COVERS30,PALMS30,LANDMARK_WALLS30,BRIDGE_COLUMNS30}from'./harbour-plan30.js';
export const WIDTH=120,DEPTH=120,SCALE=1.2;
export const toWorld=([x,z])=>({x:(x-50)*SCALE,z:(z-50)*SCALE});
export const toGame=([x,z])=>({x:x*SCALE,z:z*SCALE});
export const OUTLINE=OUTLINE30,DISTRICTS=DISTRICTS30,SITES=SITES30,SPAWNS=SPAWNS30,ROUTES=ROUTES30,INTERIORS=INTERIORS30,LANDMARK_WALLS=LANDMARK_WALLS30,COVERS_PLAN=COVERS30,PALMS_PLAN=PALMS30;
export const coastalHeight24=terrainHeight25;
export function insidePlan(p,poly=OUTLINE){let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside}return inside}
function collider(p,y,h,id){const pts=p.map(toWorld),minX=Math.min(...pts.map(v=>v.x)),maxX=Math.max(...pts.map(v=>v.x)),minZ=Math.min(...pts.map(v=>v.z)),maxZ=Math.max(...pts.map(v=>v.z)),x=(minX+maxX)/2,z=(minZ+maxZ)/2;let polygon=pts.map(p=>({x:p.x-x,z:p.z-z}));const area=polygon.reduce((s,a,i)=>{const b=polygon[(i+1)%polygon.length];return s+a.x*b.z-b.x*a.z},0);if(area<0)polygon.reverse();return{x,z,w:maxX-minX,d:maxZ-minZ,y,h,id,polygon}}
export function coastalSolids24(){const rows=[...landmarkSolids30()];const triangulate=(p,y,h,id)=>{const v=p.map(([x,z])=>new Vector2(x,z));for(const tri of ShapeUtils.triangulateShape(v,[]))rows.push(collider(tri.map(i=>p[i]),y,h,id))};
 const outer=[[0,0],[100,0],[100,100],[0,100]],vertices=[...outer,...OUTLINE],tris=ShapeUtils.triangulateShape(outer.map(p=>new Vector2(...p)),[OUTLINE.map(p=>new Vector2(...p))]);for(const tri of tris)rows.push(collider(tri.map(i=>vertices[i]),-1.5,14,'boundary'));
 for(const d of DISTRICTS){const base=Math.min(...d.p.map(p=>{const w=toWorld(p);return coastalHeight24(w.x,w.z)}));triangulate(d.p,base-.2,d.h+Math.max(...d.p.map(p=>{const q=toWorld(p);return coastalHeight24(q.x,q.z)}))-base,d.id)}
 for(const[ax,az,bx,bz,h]of LANDMARK_WALLS){const a=toWorld([ax,az]),b=toWorld([bx,bz]),x=(a.x+b.x)/2,z=(a.z+b.z)/2;rows.push({x,z,w:Math.max(.32,Math.abs(b.x-a.x)),d:Math.max(.32,Math.abs(b.z-a.z)),y:coastalHeight24(x,z),h,id:'landmark-wall'})}
 for(const [propId29,[x,z,w]]of COVERS_PLAN.entries()){const q=toWorld([x,z]);rows.push({...q,w:w*SCALE,d:w*SCALE,y:coastalHeight24(q.x,q.z),h:w*SCALE,id:'cover',propId29})}for(const[px,pz]of BRIDGE_COLUMNS30){const q=toWorld([px,pz]);rows.push({...q,w:.28,d:.28,y:groundFloor26(q.x,q.z),h:4.6-.25-groundFloor26(q.x,q.z),id:'bridge-column'})}
 rows.push(...stairGuards29().solids);for(const r of [...CHOKE_WALLS26,...DOORS26.flatMap(leafSegments26)])rows.push(segmentSolid26(r,groundFloor26));return rows}
export function roofSolids24(){const arches=DOORS26.flatMap(d=>{const a=toWorld(d.p),b={x:a.x+Math.cos(d.yaw),z:a.z-Math.sin(d.yaw)},base=groundFloor26(a.x,a.z);return frameProfiles29(d).map((profile,i)=>verticalSolid29(a,b,profile,base,.32,d.id+'-frame-'+i))});const copings=DISTRICTS.flatMap(d=>{const heights=d.p.map(p=>{const q=toWorld(p);return coastalHeight24(q.x,q.z)}),top=Math.max(...heights)+d.h-.2;return d.p.map((a,i)=>{const b=d.p[(i+1)%d.p.length];return segmentSolid26({id:d.id+'-coping-'+i,a,b,h:.48,width:.3},()=>top)})});return [...landmarkBallistics30(),...arches,...copings,...BRIDGE26.map(r=>({x:((r.x0+r.x1)/2-50)*SCALE,z:((r.z0+r.z1)/2-50)*SCALE,w:(r.x1-r.x0)*SCALE,d:(r.z1-r.z0)*SCALE,y:r.y-.25,h:.25,id:'short-bridge'})),...INTERIORS.flatMap(d=>{const v=d.p.map(p=>new Vector2(...p));return ShapeUtils.triangulateShape(v,[]).map(tri=>{const row=collider(tri.map(i=>d.p[i]),d.h,.2,d.id);return row})})]}
