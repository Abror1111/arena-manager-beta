export function careerExperience(p){return Math.round(Math.min(100,(p.matches||0)*1.5+Math.sqrt(p.xp||0)*1.2));}
export const experienceBonus=p=>Math.round((careerExperience(p)-35)*.06);
export function experienceTier(p){const n=careerExperience(p);return n<22?'Yangi iste’dod':n<65?'Rivojlanayotgan':'Tajribali';}
export function recruitProgress(rating,index){const rookie=index%3===0,matches=rookie?0:12+(index%4)*17;return{matches,xp:rookie?0:matches*26,potential:rookie?90+index%6:Math.min(99,rating+5)};}
