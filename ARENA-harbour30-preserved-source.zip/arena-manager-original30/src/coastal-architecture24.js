import{buildHarbourLandmarks30}from'./harbour-landmarks30.js';import{BRIDGE_COLUMNS30,ROADS30}from'./harbour-plan30.js';
import{stairGuards29}from'./stair-guards29.js';
import{leafProfile29}from'./vertical-solids29.js';
import{DOORS26,CHOKE_WALLS26,leafSegments26}from'./chokepoints26.js';import{BRIDGE26}from'./route-levels26.js';
import*as T from'three';
import{DISTRICTS,OUTLINE,INTERIORS,ROUTES,toWorld,coastalHeight24,insidePlan,SCALE,LANDMARK_WALLS,SITES}from'./coastal-layout24.js';
// Shared outlines produce every exterior wall, roof edge and navigation solid.
export function buildCoastalArchitecture24(k){const{world,materials:m,mesh,box,cyl,beam,facade,arch,sitePaint,building,OUTSKIRTS,palm,PALMS,crate,COVERS}=k;
 const shape=p=>new T.Shape(p.map(q=>{const w=toWorld(q);return new T.Vector2(w.x,-w.z)}));
 function sheet(p,y,ma,roof=false){const g=new T.ShapeGeometry(shape(p),8);g.rotateX(-Math.PI/2);const o=mesh(g,ma,world,0,y,0);if(roof)o.userData.observerRoof=true;return o}
 function edge(a,b,base,h,ma,thickness=.28){const p=toWorld(a),q=toWorld(b),dx=q.x-p.x,dz=q.z-p.z,l=Math.hypot(dx,dz),o=box(world,ma,(p.x+q.x)/2,base+h/2,(p.z+q.z)/2,l+.1,h,thickness);o.rotation.y=-Math.atan2(dz,dx);return o}
 for(const d of DISTRICTS){const pts=d.p.map(toWorld),base=Math.min(...pts.map(p=>coastalHeight24(p.x,p.z)))-.2,top=Math.max(...pts.map(p=>coastalHeight24(p.x,p.z)))+d.h-.2,roof=new T.Group();roof.userData.observerRoof=true;world.add(roof);sheet(d.p,base,m.stone);sheet(d.p,top,m.paving,true);
  let signed=d.p.reduce((s,a,i)=>{const b=d.p[(i+1)%d.p.length];return s+a[0]*b[1]-b[0]*a[1]},0);
  for(let i=0;i<d.p.length;i++){const a=d.p[i],b=d.p[(i+1)%d.p.length],p=pts[i],q=pts[(i+1)%pts.length],dx=q.x-p.x,dz=q.z-p.z,l=Math.hypot(dx,dz);edge(a,b,base,top-base,m[d.color]);edge(a,b,base,.48,m.stone,.38);
   const face=new T.Group();face.position.set((p.x+q.x)/2,Math.max(base,coastalHeight24((p.x+q.x)/2,(p.z+q.z)/2)),(p.z+q.z)/2);face.rotation.y=-Math.atan2(dz,dx)+(signed>0?Math.PI:0);world.add(face);if(l>1.8)facade(face,l-.3,top-face.position.y,.28,d.style);
   // Closed coping and projecting cornice follow each irregular return.
   for(const[yy,hh,dd,ma]of[[top+.2,.4,.24,m[d.color]],[top+.43,.09,.42,m.trim],[top-.3,.16,.42,m.trim]]){const o=box(roof,ma,(p.x+q.x)/2,yy,(p.z+q.z)/2,l+.15,hh,dd);o.rotation.y=-Math.atan2(dz,dx)}
   cyl(world,m.trim,p.x,(base+top)/2,p.z,.14,top-base,8);
  }
  if(['signal-house','west-cistern'].includes(d.id)){const x=pts.reduce((n,p)=>n+p.x,0)/pts.length,z=pts.reduce((n,p)=>n+p.z,0)/pts.length;cyl(roof,m.stone,x,top+.18,z,1.85,.36,16);cyl(roof,m.cream,x,top+1.1,z,1.5,1.8,16);for(let j=0;j<12;j++){const a=j*Math.PI/6,xx=x+Math.cos(a)*1.51,zz=z+Math.sin(a)*1.51;box(roof,m.tile,xx,top+1.12,zz,.2,.7,.14)}const cap=mesh(new T.SphereGeometry(1.55,24,12,0,Math.PI*2,0,Math.PI/2),m.dome,roof,x,top+2.0,z);cyl(roof,m.brass,x,top+3.65,z,.045,.65,8)}
  // Rooftop service volumes are confined to their actual roof polygon.
  const xs=pts.map(p=>p.x),zs=pts.map(p=>p.z);let count=0;
  for(let x=Math.min(...xs)+2;x<Math.max(...xs)-2&&count<5;x+=5.5)for(let z=Math.min(...zs)+2;z<Math.max(...zs)-2&&count<5;z+=7){const plan=[x/SCALE+50,z/SCALE+50];if(!insidePlan(plan,d.p)||![[1,1],[-1,1],[1,-1],[-1,-1]].every(([a,b])=>insidePlan([plan[0]+a,plan[1]+b],d.p)))continue;count++;box(roof,m.cream,x,top+.65,z,1.7,1.3,2);box(roof,m.trim,x,top+1.34,z,1.9,.1,2.2);box(roof,m.wood,x,top+.55,z+1.02,.6,1.1,.05);if(count%2){cyl(roof,m.iron,x+1.1,top+.63,z,.55,1.2,12);for(const yy of[.15,1.1])cyl(roof,m.trim,x+1.1,top+yy,z,.58,.09,12)}else{const dish=mesh(new T.SphereGeometry(.65,12,8,0,Math.PI*2,0,Math.PI*.43),m.cream,roof,x,top+1.7,z,-.65);cyl(roof,m.iron,x,top+.7,z,.04,1.4,6);beam(roof,m.iron,new T.Vector3(x,top+1.1,z),new T.Vector3(x,top+2,z+.4),.025)}}
 }
 // Enclosing retaining walls hug the map outline; no rectangular empty apron.
 for(let i=0;i<OUTLINE.length;i++){const a=OUTLINE[i],b=OUTLINE[(i+1)%OUTLINE.length],p=toWorld(a),q=toWorld(b),length=Math.hypot(q.x-p.x,q.z-p.z),n=Math.ceil(length/1.5);for(let j=0;j<n;j++){const aa=[a[0]+(b[0]-a[0])*j/n,a[1]+(b[1]-a[1])*j/n],bb=[a[0]+(b[0]-a[0])*(j+1)/n,a[1]+(b[1]-a[1])*(j+1)/n],w=toWorld(aa),v=toWorld(bb),base=Math.min(coastalHeight24(w.x,w.z),coastalHeight24(v.x,v.z))-.12;edge(aa,bb,base,3.8,m.sand,.35);edge(aa,bb,base+3.8,.1,m.trim,.48)}}
 for(const r of INTERIORS){sheet(r.p,r.h,m.stone,true);const pts=r.p.map(toWorld);for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length];beam(world,m.wood,new T.Vector3(a.x,r.h-.12,a.z),new T.Vector3(b.x,r.h-.12,b.z),.09)}
  const minX=Math.min(...pts.map(p=>p.x)),maxX=Math.max(...pts.map(p=>p.x)),z=pts.reduce((s,p)=>s+p.z,0)/pts.length;for(let x=minX+1;x<maxX;x+=3){box(world,m.glass,x,r.h-.22,z,.35,.12,.35);box(world,m.iron,x,r.h-.1,z,.5,.06,.5)}}
 for(const a of OUTSKIRTS)building(...a.slice(0,6),m[a[6]]);
 for(const a of PALMS)palm(...a);world.userData.authoredProps29=[];for(const [id,a]of COVERS.entries()){const g=crate(...a),pivot=new T.Group(),size=a[2];pivot.userData.dynamicProp29=true;pivot.position.copy(g.position);pivot.position.y+=size/2;world.add(pivot);pivot.add(g);g.position.set(0,-size/2,0);const mats=new Map();g.traverse(o=>{if(!o.isMesh)return;let ma=mats.get(o.material);if(!ma){ma=o.material.clone();mats.set(o.material,ma);m['crate29-'+id+'-'+mats.size]=ma}o.material=ma});world.userData.authoredProps29.push({id,pivot,g,size,mats:[...mats.values()],body:g.children[0],parts:g.children.slice(1).map(mesh=>({mesh,p:mesh.position.clone(),r:mesh.rotation.clone()}))})}
 for(const site of SITES){const q=toWorld(site.p);sitePaint(q.x,q.z,site.label,site.label==='A'?'#ce7040':'#d4974c')}
 for(const[ax,az,bx,bz,h]of LANDMARK_WALLS){const a=toWorld([ax,az]),b=toWorld([bx,bz]),base=coastalHeight24((a.x+b.x)/2,(a.z+b.z)/2);edge([ax,az],[bx,bz],base,h,m.sand,.32);edge([ax,az],[bx,bz],base+h,.1,m.trim,.46)}
 // Each double door sits in an enclosed choke, with collision-matched adjoining walls.
 for(const r of CHOKE_WALLS26){const a=toWorld(r.a),b=toWorld(r.b),base=Math.min(coastalHeight24(a.x,a.z),coastalHeight24(b.x,b.z))-.04,h=(r.top??Math.max(coastalHeight24(a.x,a.z),coastalHeight24(b.x,b.z))+r.h)-base;edge(r.a,r.b,base,h,m.sand,.32);edge(r.a,r.b,base+h,.1,m.trim,.46)}
 for(const d of DOORS26){const q=toWorld(d.p),base=coastalHeight24(q.x,q.z),g=new T.Group();g.position.set(q.x,base,q.z);g.rotation.y=d.yaw;world.add(g);arch(g,m.trim,0,0,-.16,d.width+.44,d.h,.32,.22);for(const side of[-1,1]){const hinge=new T.Group();hinge.position.x=side*d.width/2;hinge.rotation.y=side*1.18;g.add(hinge);const profile=leafProfile29(d),shape=new T.Shape(profile.map(([u,y])=>new T.Vector2(-side*u,y))),geo=new T.ExtrudeGeometry(shape,{depth:.12,bevelEnabled:false});mesh(geo,m.wood,hinge,0,0,-.06);const w=d.width/2-.04;for(const y of[.45,1.45,2.25])box(hinge,m.iron,-side*w/2,y,.09,w,.1,.04);for(let i=0;i<6;i++){const u=.1+i*(w-.2)/5,top=d.h-(d.width+.44)/2+Math.sqrt(Math.max(0,(d.width/2)**2-(d.width/2-u)**2))-.1;box(hinge,m.woodLight,-side*u,(top+.12)/2,.075,.025,top-.12,.025)}mesh(new T.TorusGeometry(.13,.025,6,16),m.brass,hinge,-side*w*.72,1.25,.14);for(const y of[.45,2.15])cyl(hinge,m.iron,0,y,0,.055,.32,8)}}
 // Original port viaduct: straight cargo crossing with four grounded supports.
 for(const r of BRIDGE26){const o=box(world,m.stone,((r.x0+r.x1)/2-50)*SCALE,r.y-.125,((r.z0+r.z1)/2-50)*SCALE,(r.x1-r.x0)*SCALE,.25,(r.z1-r.z0)*SCALE);o.name='cargo-viaduct30';for(const pz of[r.z0,r.z1]){const a=toWorld([r.x0,pz]),b=toWorld([r.x1,pz]);beam(world,m.iron,new T.Vector3(a.x,r.y+.9,a.z),new T.Vector3(b.x,r.y+.9,b.z),.045);for(let x=a.x;x<=b.x;x+=.7)cyl(world,m.iron,x,r.y+.45,a.z,.03,.9,6)}}
 for(const[px,pz]of BRIDGE_COLUMNS30){const q=toWorld([px,pz]),base=coastalHeight24(q.x,q.z),h=4.35-base;box(world,m.stone,q.x,base+h/2,q.z,.28,h,.28);box(world,m.trim,q.x,4.22,q.z,.46,.22,.46)}
 const guards=stairGuards29();for(const r of guards.profiles){const sh=new T.Shape(r.profile.map(p=>new T.Vector2(...p))),geo=new T.ExtrudeGeometry(sh,{depth:r.thickness,bevelEnabled:false});geo.translate(0,0,-r.thickness/2);mesh(geo,m.iron,world,r.a.x,r.base,r.a.z,0,-Math.atan2(r.b.z-r.a.z,r.b.x-r.a.x),0)}for(const p of guards.posts)box(world,m.iron,p.x,p.y+p.h/2,p.z,p.w,p.h,p.d);
 buildHarbourLandmarks30(k);
}
export function addCoastalRoads24({mesh,world,materials:m}){
 const areas=ROADS30;
 for(const area of areas){const v=area.map(p=>new T.Vector2(...p)),verts=[],uv=[];
  for(const tri of T.ShapeUtils.triangulateShape(v,[])){const[a,b,c]=tri.map(i=>toWorld(area[i])),n=Math.ceil(Math.max(Math.hypot(a.x-b.x,a.z-b.z),Math.hypot(c.x-b.x,c.z-b.z),Math.hypot(a.x-c.x,a.z-c.z))/1.8),point=(u,v)=>({x:a.x+(b.x-a.x)*u+(c.x-a.x)*v,z:a.z+(b.z-a.z)*u+(c.z-a.z)*v}),emit=(p,q,r)=>{for(const w of[p,q,r]){verts.push(w.x,coastalHeight24(w.x,w.z)+.018,w.z);uv.push(w.x*.25,w.z*.25)}};
   for(let i=0;i<n;i++)for(let j=0;j<n-i;j++){emit(point(i/n,j/n),point((i+1)/n,j/n),point(i/n,(j+1)/n));if(i+j<n-1)emit(point((i+1)/n,j/n),point((i+1)/n,(j+1)/n),point(i/n,(j+1)/n))}}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(verts,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.computeVertexNormals();const ma=m.asphaltRoad.clone();ma.side=T.DoubleSide;mesh(g,ma,world).castShadow=false}
}
