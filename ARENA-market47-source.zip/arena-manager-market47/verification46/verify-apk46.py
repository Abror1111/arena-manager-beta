from pathlib import Path
import json,hashlib,zipfile,subprocess,os
p=Path('/dev/shm/arena-manager-career46');log=Path('/dev/shm/arena-career46-tests');apk=p/'androidGame46/app/build/outputs/apk/debug/app-debug.apk';meta=json.loads((log/'apk46.json').read_text());assets=json.loads((log/'android-assets46.json').read_text())
with zipfile.ZipFile(apk)as z:
 assert z.testzip()is None
 for name,m in assets['assets'].items():
  b=z.read('assets/public/'+name);assert len(b)==m['bytes']and hashlib.sha256(b).hexdigest()==m['sha256'],name
meta.update(bytes=apk.stat().st_size,sha256=hashlib.sha256(apk.read_bytes()).hexdigest(),nativeDirectoryEntryResolved=True)
env=dict(os.environ,JAVA_HOME='/workspace/.arena-tools/java/jdk-21.0.12.1');tools=Path('/workspace/.arena-tools/android-sdk/build-tools/35.0.0')
(log/'apk-signature.log').write_bytes(subprocess.check_output([str(tools/'apksigner'),'verify','--print-certs',str(apk)],env=env));(log/'apk-manifest.log').write_bytes(subprocess.check_output([str(tools/'aapt'),'dump','badging',str(apk)]));assert json.loads((log/'apk-browser46.json').read_text())['result']=='passed';(log/'apk46.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
