from pathlib import Path
import os,subprocess,urllib.parse
p=Path('/dev/shm/arena-manager-commerce45/android45');(p/'local.properties').write_text('sdk.dir=/workspace/.arena-tools/android-sdk\n')
env=dict(os.environ,JAVA_HOME='/workspace/.arena-tools/java/jdk-21.0.12.1',ANDROID_HOME='/workspace/.arena-tools/android-sdk',GRADLE_USER_HOME='/dev/shm/arena-gradle45/cache')
args=['/dev/shm/arena-gradle45/gradle-8.11.1/bin/gradle','--no-daemon',':commerce:assembleDebug']
proxy=urllib.parse.urlparse(os.environ.get('HTTPS_PROXY',''))
if proxy.hostname:
 for proto in ['http','https']:args+=['-D'+proto+'.proxyHost='+proxy.hostname,'-D'+proto+'.proxyPort='+str(proxy.port or 80)]
if Path('/etc/ssl/certs/java/cacerts').exists():args+=['-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts']
subprocess.run(args,cwd=p,env=env,check=True)
