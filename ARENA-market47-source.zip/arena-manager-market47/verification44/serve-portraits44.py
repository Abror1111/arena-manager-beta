from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote,urlsplit
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  path=unquote(urlsplit(path).path);prefix='/arena-manager-beta/remix31/'
  if path.startswith(prefix):
   version=Path('/dev/shm/arena-portraits44-tests/version.txt').read_text().strip();root=Path('/dev/shm/arena-manager-academy43-web')if version=='43'else Path('/dev/shm/arena-manager-portraits44-web');return str(root/path[len(prefix):])
  if path.startswith('/arena-manager-beta/'):return str(Path('/dev/shm/arena-pages32')/path[len('/arena-manager-beta/'):])
  return '/dev/shm/no-such-file'
ThreadingHTTPServer(('0.0.0.0',8255),H).serve_forever()
