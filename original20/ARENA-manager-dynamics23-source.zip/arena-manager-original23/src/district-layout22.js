import{cornerTreatment,footprintPoints}from'./footprints23.js';
// Independently authored tactical coastal town, in world metres.
export const WIDTH=120,DEPTH=88;
export const BUILDINGS=[
 [-51,-32,12,16,7,1,'sand'],[-26,-36,12,10,6,0,'cream'],[-8,-36,18,10,8.8,1,'sand'],[11,-37,10,8,6,3,'cream'],[28,-38,18,6,5.2,4,'sand'],[52,-31,10,18,8,1,'cream'],
 [-26,-20,16,12,6,3,'sand'],[-8,-21,14,12,8,1,'cream'],[9,-22,12,10,5.5,3,'sand'],[-29,-7,12,10,6,0,'sand'],[-18,4,12,12,7,1,'cream'],[-2,-8,8,6,5,4,'sand'],[9,4,12,14,8,0,'cream'],[23,4,8,12,6,3,'sand'],
 [40,8,14,10,6,1,'sand'],[53,10,10,14,8,0,'cream'],[48,24,12,10,6,3,'sand'],[52,36,12,10,7,1,'cream'],
 [-48,32,14,16,8,4,'sand'],[-29,35,18,12,6,1,'cream'],[-7,35,14,10,7,0,'sand'],[11,35,12,12,6,2,'peach'],[25,38,10,8,4.5,3,'cream'],[-15,21,12,10,5.5,5,'sand'],
 [-35,-23,4,4,4,3,'sand'],[-17,-12,4,4,4,0,'cream'],[17,13,6,6,4,3,'sand'],[-29,26,6,4,4,4,'sand'],[28,-8,6,5,4,3,'cream'],[46,-16,8,8,6.8,4,'sand'],[-50,12,8,10,5,3,'cream'],[18,25,6,6,4,3,'sand'],[34,19,8,6,4,0,'cream'],[-6,14,6,5,3.8,5,'sand'],[-7,7,6,8,4.5,0,'cream'],[-41,11,6,8,10,4,'sand'],[46,-22,3.6,3.6,10.5,4,'sand'],[-50,18,8,5,4,0,'cream']
];
export const OUTSKIRTS=[[-48,-53,14,12,8,1,'cream'],[-26,-54,15,10,6,0,'sand'],[-3,-55,18,12,9,1,'sand'],[22,-53,18,10,7,0,'cream'],[48,-54,14,12,8,4,'sand'],[69,-31,14,16,8,1,'cream'],[70,-5,16,18,7,3,'sand'],[69,23,14,16,8,1,'cream'],[48,55,16,12,7,0,'sand'],[23,56,16,12,9,1,'cream'],[-3,56,18,12,7,0,'sand'],[-29,55,16,12,8,1,'cream'],[-51,54,12,12,7,4,'sand']];
export const ROOM={x:0,z:21,w:14,d:12,h:5};
// Tunnel floors form an L, with actual entry/exit door openings.
export const TUNNEL_FLOORS=[{x:-43,z:-13,w:6,d:20},{x:-40,z:1,w:12,d:8}];
export const TUNNEL_WALLS=[[-46,-9,.35,28],[-40,-13,.35,20],[-45.5,-23,1,.35],[-40.5,-23,1,.35],[-37,-3,6,.35],[-34,-2,.35,2],[-34,4,.35,2],[-40,5,12,.35]];
export const ROOM_WALLS=[[7,16.5,.32,3],[7,25.5,.32,3],[-7,16.5,.32,3],[-7,25.5,.32,3],[-4.35,15,5.3,.32],[4.35,15,5.3,.32],[0,27,14,.32]];
// Top-level A and B yard walls leave three independent entrances each.
export const SITE_WALLS=[
 [26.5,-24,5,.35,3.4],[41,-24,12,.35,3.4],[24,-20.5,.35,7,3.4],[24,-10.5,.35,1,3.4],[47,-17,.35,14,3.4],[30.5,-10,13,.35,3.4],[46,-10,2,.35,3.4],
 [-36.5,13,3,.32,1.65],[-26.5,13,5,.32,1.65],[-38,19,.32,12,1.65],[-24,15,.32,4,1.65],[-24,23,.32,4,1.65],[-36,25,4,.32,1.65],[-26,25,4,.32,1.65]
];
export const PERIMETER_WALLS=[[-58,0,2,86,3.4],[59,0,.5,86,3.4],[0,-42,118,1.3,4],[0,43,118,.8,3.4]];
export const MID_WALLS=[[-5.5,-3,7,.5,4.8],[5,-3,6,.5,4.8]];
export const COVERS=[[-40,-30,1.2],[-29,-29,1.4],[23,-31,1.6],[29,-20,1.3],[40,-13,1.6],[-35,21,1.4],[-26,15,1.4],[-30,9,1.1],[3,-12,1.3],[-10,0,1.1],[24,18,1.3],[10,27,1.2],[-44,-6,1]];
export const PALMS=[[-61,-32,8],[-61,-8,7],[-61,19,8],[-58,38,7],[-32,-33,7],[20,-33,7],[38,-29,7],[52,-11,7],[30,11,7],[20,29,7],[-23,12,7],[-40,29,8],[-13,30,7],[6,12,7],[56,28,7],[-63,46,7]];
export const LAMPS=[[-37,-25],[-18,-29],[17,-30],[40,-6],[31,25],[-23,28],[-30,8],[-10,-2]];
export const MARKET_STALLS=[[-2,21],[3,23],[-22,31],[18,-12]];
const within=(x,z,x0,x1,z0,z1)=>x>=x0&&x<=x1&&z>=z0&&z<=z1;
export function districtHeight22(x,z){
 if(within(x,z,24,47,-24,-10))return 2.45;
 if(within(x,z,16,24,-17,-11))return .05+Math.min(16,Math.floor((x-16)*2)+1)*.15;
 if(within(x,z,37,45,-10,2))return Math.max(.05,2.45-Math.floor((z+10)*2+1)*.1);
 if(within(x,z,29,35,-32,-24))return .05+(z+32)*.3;
 if(within(x,z,-38,-24,13,25))return .65;
 if(within(x,z,-35,-29,9,13))return .05+Math.min(4,Math.floor(z-9)+1)*.15;
 if(within(x,z,-24,-20,17,21))return Math.max(.05,.65-(Math.floor(x+24)+1)*.15);
 if(within(x,z,-34,-28,25,28))return Math.max(.05,.65-(Math.floor(z-25)+1)*.2);
 if(within(x,z,-45,-41,-25,-21))return .05-(z+25)/4*.8;
 if(within(x,z,-34,-30,-1,3))return -.75+(x+34)/4*.8;
 if(TUNNEL_FLOORS.some(r=>within(x,z,r.x-r.w/2,r.x+r.w/2,r.z-r.d/2,r.z+r.d/2)))return -.75;
 return .05;
}
export function districtSolids22(){const rows=BUILDINGS.map(([x,z,w,d,h])=>{const base=districtHeight22(x,z),low=Math.min(base,...[-1,1].flatMap(a=>[-1,1].map(b=>districtHeight22(x+a*w/2,z+b*d/2))));const t=cornerTreatment(x,z);return{x,z,w,d,y:low,h:h+base-low+.6,...(t?{polygon:footprintPoints(w,d,t.radius,t.kind)}:{})}});
 for(const[x,z,w,d]of TUNNEL_WALLS)rows.push({x,z,w,d,y:-.75,h:4.65});for(const[x,z,w,d]of ROOM_WALLS)rows.push({x,z,w,d,h:5});for(const[x,z,w,d,h]of[...SITE_WALLS,...MID_WALLS,...PERIMETER_WALLS])rows.push({x,z,w,d,h});for(const[x,z,w]of COVERS)rows.push({x,z,w,d:w,h:w,y:districtHeight22(x,z)});for(const[x,z]of PALMS)rows.push({x,z,w:.4,d:.4,h:6});
 for(const x of[-4,4])for(const z of[17,25])rows.push({x,z,w:.4,d:.4,h:4});for(const[x,z]of LAMPS)rows.push({x,z,w:.16,d:.16,h:4});
 for(const x of[29,35])for(let z=-31.5;z<-24;z+=1)rows.push({x,z,w:.11,d:.11,h:1,y:districtHeight22(x,z)});
 // Small market furniture stays out of the room's walk-through central lane.
 for(const[x,z]of MARKET_STALLS)rows.push({x,z,w:2.4,d:1.5,h:1.2});return rows;
}
export const TACTICAL_ROUTES=[{id:'A LONG',points:[[-38,-32],[-38,-28],[20,-30],[32,-31],[32,-23],[35,-18]]},{id:'A SHORT',points:[[-38,-32],[-37,-13],[-20,-9],[-10,-4],[0,-2],[0,-4],[5,-4],[18,-14],[25,-14],[35,-18]]},{id:'B TUNNEL',points:[[-38,-32],[-43,-26],[-43,-18],[-43,1],[-32,1],[-27,8],[-32,10],[-32,17],[-30,19]]},{id:'B MID',points:[[-38,-32],[-37,-13],[-20,-9],[-10,-4],[-12,11.2],[-24,11.5],[-27,11],[-32,12],[-30,19]]},{id:'CT A',points:[[34,31],[28,26],[29,1],[41,1],[41,-11],[35,-18]]},{id:'CT B',points:[[34,31],[25,29],[14,21],[8,21],[-6,21],[-8,28],[-22,28],[-22,19],[-30,19]]}];
