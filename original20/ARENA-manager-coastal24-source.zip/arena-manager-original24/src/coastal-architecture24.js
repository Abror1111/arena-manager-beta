import*as T from'three';
import{DISTRICTS,OUTLINE,INTERIORS,ROUTES,toWorld,coastalHeight24,insidePlan,SCALE,LANDMARK_WALLS}from'./coastal-layout24.js';
// Shared outlines produce every exterior wall, roof edge and navigation solid.
export function buildCoastalArchitecture24(k){const{world,materials:m,mesh,box,cyl,beam,facade,arch,sitePaint,building,OUTSKIRTS,palm,PALMS,crate,COVERS}=k;
 const shape=p=>new T.Shape(p.map(q=>{const w=toWorld(q);return new T.Vector2(w.x,-w.z)}));
 function sheet(p,y,ma,roof=false){const g=new T.ShapeGeometry(shape(p),8);g.rotateX(-Math.PI/2);const o=mesh(g,ma,world,0,y,0);if(roof)o.userData.observerRoof=true;return o}
 function edge(a,b,base,h,ma,thickness=.28){const p=toWorld(a),q=toWorld(b),dx=q.x-p.x,dz=q.z-p.z,l=Math.hypot(dx,dz),o=box(world,ma,(p.x+q.x)/2,base+h/2,(p.z+q.z)/2,l+.1,h,thickness);o.rotation.y=-Math.atan2(dz,dx);return o}
 for(const d of DISTRICTS){const pts=d.p.map(toWorld),base=Math.min(...pts.map(p=>coastalHeight24(p.x,p.z)))-.2,top=base+d.h,roof=new T.Group();roof.userData.observerRoof=true;world.add(roof);sheet(d.p,base,m.stone);sheet(d.p,top,m.paving,true);
  let signed=d.p.reduce((s,a,i)=>{const b=d.p[(i+1)%d.p.length];return s+a[0]*b[1]-b[0]*a[1]},0);
  for(let i=0;i<d.p.length;i++){const a=d.p[i],b=d.p[(i+1)%d.p.length],p=pts[i],q=pts[(i+1)%pts.length],dx=q.x-p.x,dz=q.z-p.z,l=Math.hypot(dx,dz);edge(a,b,base,d.h,m[d.color]);edge(a,b,base,.48,m.stone,.38);
   const face=new T.Group();face.position.set((p.x+q.x)/2,Math.max(base,coastalHeight24((p.x+q.x)/2,(p.z+q.z)/2)),(p.z+q.z)/2);face.rotation.y=-Math.atan2(dz,dx)+(signed>0?Math.PI:0);world.add(face);if(l>1.8)facade(face,l-.3,top-face.position.y,0,d.style);
   // Closed coping and projecting cornice follow each irregular return.
   for(const[yy,hh,dd,ma]of[[top+.2,.4,.24,m[d.color]],[top+.43,.09,.42,m.trim],[top-.3,.16,.42,m.trim]]){const o=box(roof,ma,(p.x+q.x)/2,yy,(p.z+q.z)/2,l+.15,hh,dd);o.rotation.y=-Math.atan2(dz,dx)}
   cyl(world,m.trim,p.x,base+d.h/2,p.z,.14,d.h,8);
  }
  // Rooftop service volumes are confined to their actual roof polygon.
  const xs=pts.map(p=>p.x),zs=pts.map(p=>p.z);let count=0;
  for(let x=Math.min(...xs)+2;x<Math.max(...xs)-2&&count<5;x+=5.5)for(let z=Math.min(...zs)+2;z<Math.max(...zs)-2&&count<5;z+=7){const plan=[x/SCALE+50,z/SCALE+50];if(!insidePlan(plan,d.p)||![[1,1],[-1,1],[1,-1],[-1,-1]].every(([a,b])=>insidePlan([plan[0]+a,plan[1]+b],d.p)))continue;count++;box(roof,m.cream,x,top+.65,z,1.7,1.3,2);box(roof,m.trim,x,top+1.34,z,1.9,.1,2.2);box(roof,m.wood,x,top+.55,z+1.02,.6,1.1,.05);if(count%2){cyl(roof,m.iron,x+1.1,top+.63,z,.55,1.2,12);for(const yy of[.15,1.1])cyl(roof,m.trim,x+1.1,top+yy,z,.58,.09,12)}else{const dish=mesh(new T.SphereGeometry(.65,12,8,0,Math.PI*2,0,Math.PI*.43),m.cream,roof,x,top+1.7,z,-.65);cyl(roof,m.iron,x,top+.7,z,.04,1.4,6);beam(roof,m.iron,new T.Vector3(x,top+1.1,z),new T.Vector3(x,top+2,z+.4),.025)}}
 }
 // Enclosing retaining walls hug the map outline; no rectangular empty apron.
 for(let i=0;i<OUTLINE.length;i++){const a=OUTLINE[i],b=OUTLINE[(i+1)%OUTLINE.length],p=toWorld(a),q=toWorld(b),length=Math.hypot(q.x-p.x,q.z-p.z),n=Math.ceil(length/1.5);for(let j=0;j<n;j++){const aa=[a[0]+(b[0]-a[0])*j/n,a[1]+(b[1]-a[1])*j/n],bb=[a[0]+(b[0]-a[0])*(j+1)/n,a[1]+(b[1]-a[1])*(j+1)/n],w=toWorld(aa),v=toWorld(bb),base=Math.min(coastalHeight24(w.x,w.z),coastalHeight24(v.x,v.z))-.12;edge(aa,bb,base,3.8,m.sand,.35);edge(aa,bb,base+3.8,.1,m.trim,.48)}}
 for(const r of INTERIORS){sheet(r.p,r.h,m.stone,true);const pts=r.p.map(toWorld);for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length];beam(world,m.wood,new T.Vector3(a.x,r.h-.12,a.z),new T.Vector3(b.x,r.h-.12,b.z),.09)}
  const minX=Math.min(...pts.map(p=>p.x)),maxX=Math.max(...pts.map(p=>p.x)),z=pts.reduce((s,p)=>s+p.z,0)/pts.length;for(let x=minX+1;x<maxX;x+=3){box(world,m.glass,x,r.h-.22,z,.35,.12,.35);box(world,m.iron,x,r.h-.1,z,.5,.06,.5)}}
 for(const a of OUTSKIRTS)building(...a.slice(0,6),m[a[6]]);
 for(const a of PALMS)palm(...a);for(const a of COVERS)crate(...a);
 sitePaint(...Object.values(toWorld([80,17])),'A','#ce7040');sitePaint(...Object.values(toWorld([20,12.5])),'B','#d4974c');
 for(const[ax,az,bx,bz,h]of LANDMARK_WALLS){const a=toWorld([ax,az]),b=toWorld([bx,bz]),base=coastalHeight24((a.x+b.x)/2,(a.z+b.z)/2);edge([ax,az],[bx,bz],base,h,m.sand,.32);edge([ax,az],[bx,bz],base+h,.1,m.trim,.46)}
 // Double-door landmarks distinguish the Mid and Long choke points.
 for(const [p,angle]of[[[46,36],0],[[70,57],Math.PI/2]]){const q=toWorld(p),g=new T.Group();g.position.set(q.x,coastalHeight24(q.x,q.z),q.z);g.rotation.y=angle;world.add(g);arch(g,m.trim,0,0,0,4.5,4.4,.22,.22);for(const side of[-1,1]){const hinge=new T.Group();hinge.position.x=side*2.1;hinge.rotation.y=side*1.25;g.add(hinge);box(hinge,m.wood,-side*.9,1.65,0,1.8,3.3,.12);for(const y of[.5,2.8])box(hinge,m.iron,-side*.9,y,.09,1.8,.1,.04)}}
 // A sheltered tunnel entry arch and B's crenellated skyline are visible overhead.
 const bp=toWorld([16,58]);arch(world,m.trim,bp.x,coastalHeight24(bp.x,bp.z),bp.z,5,4.7,.4,.28);
 const fort=toWorld([12,8]);for(const dx of[-2,2]){cyl(world,m.sand,fort.x+dx,3.6,fort.z,1.05,7.2,12);for(let i=0;i<8;i++){const a=i*Math.PI/4;box(world,m.trim,fort.x+dx+Math.cos(a)*.95,7.25,fort.z+Math.sin(a)*.95,.35,.55,.35)}}
}
export function addCoastalRoads24({mesh,world,materials:m}){
 const areas=[[[83,24],[90,24],[90,65],[84,65],[84,54],[72,54],[69,57],[68,55],[71,51],[83,51]],[[44,34],[49,34],[49,61],[44,61]],[[26,18],[43,18],[45,22],[58,22],[58,26],[45,26],[42,24],[26,24]]];
 for(const area of areas){const v=area.map(p=>new T.Vector2(...p)),verts=[],uv=[];
  for(const tri of T.ShapeUtils.triangulateShape(v,[])){const[a,b,c]=tri.map(i=>toWorld(area[i])),n=Math.ceil(Math.max(Math.hypot(a.x-b.x,a.z-b.z),Math.hypot(c.x-b.x,c.z-b.z),Math.hypot(a.x-c.x,a.z-c.z))/1.8),point=(u,v)=>({x:a.x+(b.x-a.x)*u+(c.x-a.x)*v,z:a.z+(b.z-a.z)*u+(c.z-a.z)*v}),emit=(p,q,r)=>{for(const w of[p,q,r]){verts.push(w.x,coastalHeight24(w.x,w.z)+.018,w.z);uv.push(w.x*.25,w.z*.25)}};
   for(let i=0;i<n;i++)for(let j=0;j<n-i;j++){emit(point(i/n,j/n),point((i+1)/n,j/n),point(i/n,(j+1)/n));if(i+j<n-1)emit(point((i+1)/n,j/n),point((i+1)/n,(j+1)/n),point(i/n,(j+1)/n))}}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(verts,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.computeVertexNormals();const ma=m.asphaltRoad.clone();ma.side=T.DoubleSide;mesh(g,ma,world).castShadow=false}
}
