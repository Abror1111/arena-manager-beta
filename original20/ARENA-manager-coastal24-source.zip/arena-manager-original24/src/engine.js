import{containsFootprint,sweepSolid}from'./footprints23.js';
import{districtPath}from'./district-path20.js';
import {routePenalty} from './adaptive-play.js';
import {collisionRay,collisionBlocks,hasCollision} from './world-collision.js';
import {launchGrenade,advanceGrenade,validGrenade} from './grenade-physics.js';
import {sideAt,winTarget} from './match-rules.js';
import {ensureEconomy,validEconomy,buyTeam,awardRound,killReward} from './match-economy.js';
import {crowdStep,learnRound} from './squad-tactics.js';
import {fireAt,smokeBlocks} from './effect-model.js';
import {resetTactics,makeTeamPlan,validTactics,tacticalAI,tacticalShot,tacticalDeath} from './tactical-ai.js';
import {navBlocked,navVisible,navWalkLine,navPath,navLocation,navStepLocation} from './reference-nav.js';
export const VERSION='1.32';
import {WEAPONS,availableWeapon} from './weapons.js';
export {WEAPONS} from './weapons.js';
import {impactMapProps,tickMapProps,validPropStates} from './map-prop-physics.js';
export {MAPS,makeMap,heightAt} from './maps.js';
import {MAPS,ALL_MAPS,makeMap,heightAt} from './maps.js';
export const STRATEGIES=[{id:'balanced',name:'Muvozanat',description:'Xaritani nazorat qilish, so‘ng A yoki B.'},{id:'a',name:'A hujumi',description:'A nuqtasiga tayyorlanish va kelishilgan hujum.'},{id:'b',name:'B hujumi',description:'B nuqtasiga guruh bo‘lib kirish.'},{id:'hold',name:'Pozitsiya',description:'Shoshilmasdan himoya va qarshi hujum.'}];
const names=[['ACE','NOVA','SHADOW','REX','ECHO'],['FROST','VIPER','GHOST','BLAZE','STORM']];
export const dist=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const targetPoint=(x,z)=>({x,z});
export function blocked(map,x,z,margin=.55){if(map.reference)return navBlocked(map,x,z);return x<1||x>(map.width||60)-1||z<1||z>(map.height||40)-1||map.blocks.some(b=>containsFootprint(b,x,z,margin));}
export function clearLine(map,a,b,margin=0){
 if(map.original23&&margin===0){const start={x:a.x,y:(a.y??heightAt(map,a.x,a.z))+1.23,z:a.z},end={x:b.x,y:(b.y??heightAt(map,b.x,b.z))+1.23,z:b.z};return ![...map.blocks,...(map.ballisticSolids||[])].some(r=>sweepSolid(r,start,end,0,true))}
 if(map.reference){if(margin>0)return navWalkLine(map,a,b);if(!navVisible(map,a,b))return false;const eye=(map.playerScale||1)*1.23;return (!map.rebuilt&&!hasCollision(map))||(hasCollision(map)&&!collisionBlocks(map,{x:a.x,y:(a.y||0)+eye,z:a.z},{x:b.x,y:(b.y||0)+eye,z:b.z}));}
 const length=dist(a,b),steps=Math.max(1,Math.ceil(length*3));
 let previousHeight=heightAt(map,a.x,a.z);for(let i=1;i<=steps;i++){const t=i/steps,x=a.x+(b.x-a.x)*t,z=a.z+(b.z-a.z)*t,h=heightAt(map,x,z);if(map.original22&&margin>0&&Math.abs(h-previousHeight)>.36)return false;previousHeight=h;const rayY=(a.y??heightAt(map,a.x,a.z))+1.23+((b.y??heightAt(map,b.x,b.z))-(a.y??heightAt(map,a.x,a.z)))*t;if(map.blocks.some(r=>containsFootprint(r,x,z,margin)&&(!map.original22||margin>0||rayY>(r.y||0)&&rayY<(r.y||0)+r.h)))return false;}return true;
}
export function pathfind(map,a,b){
 if(map.original20)return districtPath(map,a,b,{blocked,clearLine});
 if(map.reference)return navPath(map,a,b);
 const valid=p=>!blocked(map,p.x,p.z);let goal={x:clamp(b.x,1,59),z:clamp(b.z,1,39)};
 if(!valid(goal)){let found=null;for(let radius=1;radius<10&&!found;radius++)for(let k=0;k<16;k++){const p={x:goal.x+Math.cos(k*Math.PI/8)*radius,z:goal.z+Math.sin(k*Math.PI/8)*radius};if(valid(p)){found=p;break;}}if(!found)return[];goal=found;}
 if(clearLine(map,a,goal,.6))return[goal];
 const cell=p=>({x:clamp(Math.floor(p.x/2),0,29),z:clamp(Math.floor(p.z/2),0,19)}),start=cell(a),end=cell(goal),key=p=>p.z*30+p.x;
 const center=p=>({x:p.x*2+1,z:p.z*2+1}),open=[start],came=new Map(),cost=new Map([[key(start),0]]),done=new Set();let last=null;
 for(let loops=0;open.length&&loops<650;loops++){
  open.sort((p,q)=>(cost.get(key(p))+Math.abs(p.x-end.x)+Math.abs(p.z-end.z))-(cost.get(key(q))+Math.abs(q.x-end.x)+Math.abs(q.z-end.z)));
  const p=open.shift(),k=key(p);if(done.has(k))continue;done.add(k);if(k===key(end)){last=p;break;}
  for(const [dx,dz]of[[1,0],[-1,0],[0,1],[0,-1]]){const n={x:p.x+dx,z:p.z+dz},nk=key(n);if(n.x<0||n.x>=30||n.z<0||n.z>=20||!valid(center(n))||done.has(nk))continue;const c=cost.get(k)+1;if(c<(cost.get(nk)??Infinity)){cost.set(nk,c);came.set(nk,p);open.push(n);}}
 }
 if(!last)return[];const points=[goal];while(key(last)!==key(start)){points.unshift(center(last));last=came.get(key(last));if(!last)return[];}
 const result=[];let origin=a;while(points.length){let i=points.length-1;while(i>0&&!clearLine(map,origin,points[i],.58))i--;origin=points[i];result.push(origin);points.splice(0,i+1);}return result;
}
function seeded(seed){let s=seed>>>0||1;const random=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)/4294967296;};random.getState=()=>s>>>0;return random;}
export class Match{
 constructor(options={}){this.combatVersion=2;this.soundSeq=0;this.soundEvents=[];this.outro=0;this.training=options.practice===true;this.propStates={};this.aiVersion=2;this.random=seeded(options.seed||Date.now());this.map=makeMap(options.map,options.mapRevision);this.map.getPropStates=()=>this.propStates;this.strategy=options.strategy||'balanced';this.enemyStrategy=options.enemyStrategy||'balanced';this.initialSide=options.side||'T';this.rating=options.rating||80;this.teamNames=options.teamNames||['UZB FIVE','IRON FIVE'];this.score=[0,0];this.round=0;this.players=Array.from({length:10},(_,i)=>({id:i,team:i<5?0:1,name:names[i<5?0:1][i%5],skill:(i<5?this.rating:78)+Math.round(this.random()*14-7),money:800,kills:0,deaths:0,weapon:null,alive:false,role:['Kapitan','Rifler','Snayper','Entry','Support'][i%5],experienceXP:0,experienceMatches:20}));for(const p of this.players){const source=(p.team===0?options.ownSquad:options.enemySquad)?.[p.id%5];if(source){p.profileId=source.id;p.name=source.name;p.role=source.role;p.skill=source.skill;p.aim=source.aim;p.reaction=source.reaction;p.utilitySkill=source.utility;p.tacticalSkill=source.tactics;p.experienceXP=source.xp||0;p.experienceMatches=source.matches||0;}}this.log=[];this.shots=[];this.effects=[];this.crates=[];this.selected=null;this.phase='ready';this.startRound();}
 snapshot(){const {random,map,...state}=this;return {schema:2,mapId:map.id,mapRevision:map.revision||'prototype',randomState:random.getState(),state:JSON.parse(JSON.stringify(state))};}
 static restore(value){
  const raw=JSON.parse(JSON.stringify(value));const fail=()=>{throw Error('Saqlangan jang ma’lumoti yaroqsiz.');};
  if(!raw||![1,2].includes(raw.schema)||!ALL_MAPS.some(m=>m.id===raw.mapId)||!Number.isInteger(raw.randomState)||raw.randomState<=0||raw.randomState>4294967295)fail();if(raw.schema===2&&!['prototype','cs2-2000933','arena-original-126','arena-rebuilt-131','arena-reviewed-14','arena-original20','arena-original21','arena-original22','arena-original23','arena-original24'].includes(raw.mapRevision))fail();const migrating=['arena-original-126','cs2-2000933','arena-original20','arena-original21','arena-original22','arena-original23'].includes(raw.mapRevision);if(migrating&&!MAPS.some(m=>m.id===raw.mapId))fail();const restoredMap=makeMap(raw.mapId,raw.schema===1?'prototype':raw.mapRevision);const s=raw.state;
  if(!s||!['freeze','live','roundend','matchend'].includes(s.phase)||!Number.isInteger(s.round)||s.round<1||s.round>1000||!Array.isArray(s.players)||s.players.length!==10||!Array.isArray(s.score)||s.score.length!==2||s.score.some(n=>!Number.isInteger(n)||n<0||n>1000))fail();
  for(let i=0;i<10;i++){const p=s.players[i];if(!p||p.id!==i||p.team!==(i<5?0:1)||typeof p.name!=='string'||p.name.length>24||!WEAPONS[p.weapon]||typeof p.alive!=='boolean'||!Number.isFinite(p.hp)||p.hp<0||p.hp>100||!Number.isFinite(p.x)||p.x<0||p.x>(raw.mapRevision==='arena-original-126'?44:restoredMap.width)||!Number.isFinite(p.z)||p.z<0||p.z>(raw.mapRevision==='arena-original-126'?38:restoredMap.height)||!Number.isFinite(p.skill)||!Array.isArray(p.path)||p.path.length>100)fail();for(const key of ['ammo','reserve','money','kills','deaths'])if(!Number.isInteger(p[key])||p[key]<0||p[key]>1000000)fail();if(!p.grenades||['he','smoke','flash','fire'].some(k=>!Number.isInteger(p.grenades[k])||p.grenades[k]<0||p.grenades[k]>1))fail();}
  if(!Array.isArray(s.effects)||s.effects.length>500||!Array.isArray(s.crates)||![0,6].includes(s.crates.length)||!Array.isArray(s.shots)||s.shots.length>200||!s.bomb||!['carried','dropped','planted','defused','exploded'].includes(s.bomb.state)||!Number.isFinite(s.clock)||!Number.isFinite(s.elapsed)||!Number.isFinite(s.freeze)||!['T','CT'].includes(s.initialSide)||!['a','b','balanced','hold'].includes(s.strategy)||!Array.isArray(s.teamNames)||s.teamNames.length!==2||s.teamNames.some(n=>typeof n!=='string'||n.length<1||n.length>24))fail();
  if(s.aiVersion!==undefined&&(s.aiVersion!==2||!validTactics(s)))fail();if(s.tactics!==undefined&&s.aiVersion!==2)fail();
  if(s.combatVersion!==undefined&&![1,2].includes(s.combatVersion))fail();if(s.outro!==undefined&&(!Number.isFinite(s.outro)||s.outro<0||s.outro>5))fail();if(s.soundSeq!==undefined&&(!Number.isInteger(s.soundSeq)||s.soundSeq<0))fail();if(s.soundEvents!==undefined&&(!Array.isArray(s.soundEvents)||s.soundEvents.length>64||s.soundEvents.some(e=>!e||!Number.isInteger(e.seq)||typeof e.kind!=='string'||e.kind.length>24||!['x','y','z'].every(k=>Number.isFinite(e[k])))))fail();
  if(s.economy!==undefined&&!validEconomy(s.economy))fail();for(const p of s.players){for(const k of ['experienceXP','experienceMatches','purchaseSpent','roundIncome'])if(p[k]!==undefined&&(!Number.isFinite(p[k])||p[k]<0||p[k]>100000000))fail();if(p.helmet!==undefined&&typeof p.helmet!=='boolean')fail();}
  if(s.training!==undefined&&typeof s.training!=='boolean')fail();if(s.propStates!==undefined&&!(raw.mapRevision==='arena-original-126'?validDiscardedOriginalProps(s.propStates):raw.mapRevision==='cs2-2000933'?validLegacyProps(s.propStates):validPropStates(raw.mapRevision==='arena-rebuilt-131'?{...restoredMap,props:restoredMap.legacyProps}:restoredMap,s.propStates)))fail();
  if(s.careerToken!==undefined&&(typeof s.careerToken!=='string'||s.careerToken.length>60||!/^s[0-9]+-m[0-9]+-[0-9]+$/.test(s.careerToken)))fail();
  const allowed=['careerToken','combatVersion','soundSeq','soundEvents','outro','economy','training','propStates','aiVersion','tactics','enemyStrategy','strategy','initialSide','rating','teamNames','score','round','players','log','shots','effects','crates','selected','phase','elapsed','clock','freeze','bomb','result'];if(Object.keys(s).some(k=>!allowed.includes(k)))fail();
  if(!Array.isArray(s.log)||s.log.length>5||s.log.some(n=>!n||typeof n.text!=='string'||!Number.isFinite(n.time)))fail();
  const point=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.z);for(const p of s.players){for(const key of ['armor','y','angle','cooldown','reload','blind','throwCD','walk','plant'])if(!Number.isFinite(p[key]))fail();if(!['T','CT'].includes(p.side)||typeof p.moving!=='boolean'||p.path.some(q=>!point(q))||(p.goal!==null&&!point(p.goal)))fail();}
  for(const e of s.effects)if(!point(e)||!Number.isFinite(e.age)||!Number.isFinite(e.life)||!['grenade','he','smoke','flash','fire','c4','debris','scorch'].includes(e.kind))fail();for(const e of s.effects)if(!validGrenade(e))fail();for(const e of s.effects)if(e.team!==undefined&&e.team!==null&&![0,1].includes(e.team))fail();for(const e of s.effects)if(e.extinguished!==undefined&&typeof e.extinguished!=='boolean')fail();for(const shot of s.shots)if(!point(shot)||!Number.isFinite(shot.tx)||!Number.isFinite(shot.tz)||!Number.isFinite(shot.age))fail();for(const crate of s.crates)if(!point(crate)||typeof crate.alive!=='boolean')fail();
  if(!Number.isFinite(s.bomb.timer)||!Number.isFinite(s.bomb.progress)||!point(s.bomb)||!['carried','dropped','planted','defused','exploded'].includes(s.bomb.state))fail();if(['roundend','matchend'].includes(s.phase)&&(!s.result||![0,1].includes(s.result.winner)||typeof s.result.reason!=='string'))fail();
  const match=Object.create(Match.prototype);Object.assign(match,{combatVersion:1,soundSeq:0,soundEvents:[],outro:0,training:false,propStates:{}},s);if(restoredMap.reference)match.crates=[];if(raw.mapRevision==='arena-rebuilt-131')match.propStates={};match.map=restoredMap;match.map.getPropStates=()=>match.propStates;match.random=seeded(raw.randomState);if(migrating){const funds=match.players.map(p=>({money:p.money,purchaseSpent:p.purchaseSpent,roundIncome:p.roundIncome}));match.effects=[];match.shots=[];match.propStates={};match.soundEvents=[];if(['freeze','live'].includes(match.phase)){match.round--;match.outro=0;match.startRound();match.players.forEach((p,i)=>{Object.assign(p,funds[i]);p.y=heightAt(restoredMap,p.x,p.z,p.y);});match.note('Sahil kengaytirildi: hisob va mablag‘ saqlanib, joriy raund qayta boshlandi.');}else{for(const p of match.players){Object.assign(p,restoredMap.spawnPoints[p.side==='T'?0:1][p.id%5]);p.y=heightAt(restoredMap,p.x,p.z,p.y);p.path=[];p.goal=null;p.moving=false;}}}if(!migrating&&raw.mapRevision==='arena-original22'){for(const p of match.players){p.y=heightAt(restoredMap,p.x,p.z);p.path=[];p.goal=null;p.repath=0;for(const q of p.brain?.archWaypoints||[])q.y=heightAt(restoredMap,q.x,q.z)}if(['planted','dropped','defused'].includes(match.bomb.state))match.bomb.y=heightAt(restoredMap,match.bomb.x,match.bomb.z)}return match;
 }

 side(team){return sideAt(this.initialSide,team,this.round);}
 setBuyPolicy(policy){if(!['auto','eco','force','full'].includes(policy)||this.phase==='matchend')return false;ensureEconomy(this).policy[0]=policy;return true;}
 emit(kind,data={}){this.soundSeq=(this.soundSeq||0)+1;this.soundEvents??=[];this.soundEvents.push({seq:this.soundSeq,kind,x:0,y:0,z:0,...data});if(this.soundEvents.length>64)this.soundEvents.shift();}
 note(text){this.log.unshift({text,time:this.elapsed});this.log.length=Math.min(this.log.length,5);}
 startRound(){if(this.phase==='matchend'||this.outro>0)return;this.combatVersion=2;
  const oldEquipment=this.players.map(p=>({alive:p.alive,weapon:p.weapon,armor:p.armor||0,helmet:!!p.helmet,kit:!!p.kit,grenades:{he:0,smoke:0,flash:0,fire:0,...p.grenades}}));
  this.round++;this.elapsed=0;this.clock=115;this.phase='freeze';this.freeze=this.combatVersion>=2?3:5;this.outro=0;this.bomb={state:'carried',carrier:null,x:0,z:0,timer:40,progress:0,actor:null};this.effects=[];this.shots=[];this.result=null;this.propStates={};this.crates=this.map.reference?[]:(this.map.originalCrates||[{x:11,z:10},{x:16,z:7},{x:45,z:28},{x:49,z:32},{x:22,z:16},{x:38,z:24}]).map(c=>({...c,h:1.4,alive:true}));
  const reset=this.round===1||this.round===13||(this.round>=25&&(this.round-25)%3===0);ensureEconomy(this);
  for(const p of this.players){if(reset)p.money=this.round>=25?10000:800;p.side=this.side(p.team);p.hp=100;p.alive=true;p.blind=0;p.reload=0;p.cooldown=this.random()*.8;p.angle=0;p.path=[];p.goal=null;p.repath=0;p.safeRoute=false;p.walk=0;p.moving=false;p.plant=0;p.throwCD=2.5+(100-(p.utilitySkill??p.skill))*.04+this.random()*3;p.targetId=null;p.acquire=0;
   const spawn=this.map.spawns[p.side==='T'?0:1],pos=this.map.spawnPoints?.[p.side==='T'?0:1]?.[p.id%5];p.x=pos?.x??spawn.x+(p.id%5-2)*1.1;p.z=pos?.z??spawn.z+(p.team===0?.4:-.4);p.y=pos?.y??heightAt(this.map,p.x,p.z);
  }
  buyTeam(this,0,oldEquipment,reset);buyTeam(this,1,oldEquipment,reset);
  this.bomb.carrier=(this.players.find(p=>p.side==='T'&&p.role==='Support')||this.players.find(p=>p.side==='T'&&p.id%5===1)).id;this.aiVersion=2;this.combatVersion=2;resetTactics(this,AI_TOOLS);this.note(`Raund ${this.round} · ${this.side(0)} · ${this.strategyName()}`);this.emit('roundStart');
 }
 equip(id,weapon){const p=this.players[id],gun=WEAPONS[weapon];if(!p?.alive||p.team!==0||!gun)return false;if(!this.training&&(this.phase!=='freeze'||!availableWeapon(weapon,p.side)||p.money<gun.price))return false;if(!this.training){p.money-=gun.price;p.purchaseSpent=(p.purchaseSpent||0)+gun.price;ensureEconomy(this).spent[p.team]+=gun.price;}p.weapon=weapon;p.ammo=gun.mag;p.reserve=gun.reserve;p.reload=0;p.cooldown=0;if(p.brain){p.brain.burstLeft=0;p.brain.burstPause=0;}return true;}
 strategyName(){return STRATEGIES.find(s=>s.id===this.strategy)?.name||'Muvozanat';}
 command(strategy){if(!STRATEGIES.some(s=>s.id===strategy))return;this.strategy=strategy;for(const p of this.players.filter(p=>p.team===0)){p.path=[];p.goal=null;p.repath=0;}if(this.aiVersion>=2){this.tactics.teams[0]=makeTeamPlan(this,0,AI_TOOLS);if(strategy!=='hold')this.tactics.teams[0].executeAt=this.elapsed+6;}this.note(`Buyruq: ${this.strategyName()}`);}
 alive(team){return this.players.filter(p=>p.team===team&&p.alive).length;}
 endRound(winner,reason){if(!['live','freeze'].includes(this.phase))return;this.score[winner]++;learnRound(this,winner);awardRound(this,winner,reason);this.phase='roundend';this.result={winner,reason};this.outro=this.combatVersion>=2&&this.bomb.state==='exploded'?5:0;for(const p of this.players){p.moving=false;p.path=[];p.goal=null;p.targetId=null;}if(!this.outro)this.emit('roundEnd',{winner});this.note(`${this.teamNames[winner]} · ${reason}`);if(Math.max(...this.score)>=winTarget(this.score)&&Math.abs(this.score[0]-this.score[1])>=2)this.phase='matchend';}
 kill(victim,killer,source){if(!victim.alive)return;if(this.aiVersion>=2)tacticalDeath(this,victim,killer,source);victim.hp=0;victim.alive=false;victim.moving=false;this.emit('death',{x:victim.x,y:victim.y,z:victim.z,owner:victim.id});victim.deaths++;if(killer){if(killer.team===victim.team){killer.money=Math.max(0,killer.money-300);this.note(`${killer.name} · sherigiga zarar`);}else{killer.kills++;killer.money=Math.min(16000,killer.money+killReward(source||killer.weapon));this.note(`${killer.name} › ${victim.name} · ${WEAPONS[source||killer.weapon]?.name||source||'Granata'}`);}}if(this.bomb.carrier===victim.id&&this.bomb.state==='carried'){this.bomb.carrier=null;this.bomb.state='dropped';this.bomb.x=victim.x;this.bomb.z=victim.z;this.bomb.y=victim.y;}}
 hurt(p,damage,killer,source){if(!p.alive)return;const absorbed=p.armor?Math.min(p.armor,damage*.28):0;p.armor=Math.max(0,p.armor-absorbed);p.hp=Math.max(0,p.hp-(damage-absorbed));if(damage>4)this.emit('hit',{x:p.x,y:p.y,z:p.z,owner:p.id});if(p.hp<=0)this.kill(p,killer,source);}
 obscured(a,b){return smokeBlocks(this.effects,a,b);}
 shoot(p,target){if(this.aiVersion>=2)return tacticalShot(this,p,target,AI_TOOLS);const gun=WEAPONS[p.weapon];if(p.cooldown>0||p.reload>0)return;if(p.weapon==='knife'){if(dist(p,target)<1.8){this.hurt(target,42,p);p.cooldown=gun.rate;}return;}
  if(p.ammo<=0){if(p.reserve){p.reload=gun.reload;return;}p.weapon='knife';return;}p.ammo--;p.cooldown=gun.rate;const length=dist(p,target),accuracy=clamp(.44+((p.aim??p.skill)-70)*.009-length*.006-(p.blind>0?.7:0),.05,.92);const hit=this.random()<accuracy;this.shots.push({x:p.x,z:p.z,tx:target.x+(hit?0:(this.random()-.5)*3),tz:target.z+(hit?0:(this.random()-.5)*3),age:0,y:p.y,ty:target.y,team:p.team,weapon:p.weapon});if(hit)this.hurt(target,gun.damage*(this.random()<.08?2.7:1),p);p.angle=Math.atan2(target.x-p.x,target.z-p.z);
 }
 utility(id,kind,target){if(this.aiVersion>=2&&this.phase!=='live')return false;const p=this.players[id];if(!p?.alive||!p.grenades[kind]||!['freeze','live'].includes(this.phase))return false;let aim=target;if(!aim){const enemy=this.aiVersion>=2?(p.brain?.memory&&this.elapsed-p.brain.memory.at<8?p.brain.memory:this.tactics.teams[p.team].contact):this.players.filter(q=>q.team!==p.team&&q.alive).sort((a,b)=>dist(a,p)-dist(b,p))[0];aim=enemy&&dist(enemy,p)<24?enemy:{x:p.x+Math.sin(p.angle)*9,z:p.z+Math.cos(p.angle)*9};}const error=(100-(p.utilitySkill??p.skill))*.035;aim={...aim,x:aim.x+(this.random()-.5)*error,z:aim.z+(this.random()-.5)*error};const d=dist(p,aim),scale=Math.min(1,18/Math.max(d,1));this.effects.push({kind:'grenade',type:kind,x:p.x,z:p.z,sx:p.x,sz:p.z,tx:clamp(p.x+(aim.x-p.x)*scale,1,(this.map.width||60)-1),tz:clamp(p.z+(aim.z-p.z)*scale,1,(this.map.height||40)-1),y:p.y,ty:aim.y??p.y,team:p.team,age:0,life:this.aiVersion>=2?Math.min(2.1,.75+d/16):1.1,owner:id,...(this.combatVersion>=2?launchGrenade(this.map,p,{x:p.x+(aim.x-p.x)*scale,z:p.z+(aim.z-p.z)*scale,y:aim.y??p.y},kind):{})});this.emit('throw',{owner:id,x:p.x,y:p.y,z:p.z,type:kind});p.grenades[kind]--;p.throwCD=7;this.note(`${p.name} · ${kind==='he'?'HE':kind==='smoke'?'Tutun':kind==='flash'?'Flash':'Molotov'}`);return true;}
 explode(kind,x,z,owner,y){const p=this.players[owner];y=y??p?.y??heightAt(this.map,x,z);impactMapProps(this,kind,x,z,y,clearLine);this.effects.push({kind,x,z,y,team:p?.team??null,age:0,life:kind==='smoke'?18:kind==='fire'?7:kind==='c4'?(this.combatVersion>=2?5:3):kind==='he'?1.6:.65,owner});
  this.emit(kind,{x,y,z,owner:owner??null});
  if(['he','c4','fire'].includes(kind)){const marks=this.effects.filter(e=>e.kind==='scorch');if(marks.length>=24)this.effects.splice(this.effects.indexOf(marks[0]),1);this.effects.push({kind:'scorch',x,z,y,age:kind==='fire'?-1:0,life:kind==='fire'?35:22,owner});}
  if(kind==='smoke'){for(const fire of this.effects)if(fire.kind==='fire'&&Math.hypot(fire.x-x,fire.z-z)<3.2&&Math.abs((fire.y||0)-y)<1.2){fire.extinguished=true;fire.life=Math.min(fire.life,fire.age+.45);}for(const state of Object.values(this.propStates))if(Math.hypot(state.x-x,state.z-z)<3.5&&Math.abs(state.y-y)<2)state.heat=0;}
  if(kind==='he'||kind==='c4'){const radius=kind==='c4'?27:this.aiVersion>=2?4.8*(this.map.playerScale||1):7;for(const target of this.players){if(!target.alive)continue;const d=dist(target,{x,z});if(d<radius){const cover=clearLine(this.map,{x,z,y},target)?1:.3;this.hurt(target,(1-d/radius)*(kind==='c4'?420:this.aiVersion>=2?(target.armor>0?70:98):110)*cover,p,kind);}}for(const c of this.crates)if(c.alive&&dist(c,{x,z})<(kind==='c4'?25:8)){c.alive=false;for(let n=0;n<5;n++)this.effects.push({kind:'debris',x:c.x,z:c.z,y:.6,vx:(this.random()-.5)*10,vz:(this.random()-.5)*10,vy:4+this.random()*5,age:0,life:3});}}
  if(kind==='flash')for(const q of this.players)if(q.alive&&dist(q,{x,z})<16&&clearLine(this.map,q,{x,z,y}))q.blind=Math.max(q.blind,this.aiVersion>=2?clamp((4-dist(q,{x,z})*.22)*(.25+.75*Math.max(0,Math.cos(Math.atan2(x-q.x,z-q.z)-q.angle))),0,4):clamp(4-dist(q,{x,z})*.17,0,4));
 }
 move(p,goal,dt,speed=3.1,spacing=false){if(p.brain?.motion){const m=p.brain.motion;if(this.elapsed-m.activeAt>.25){m.x=p.x;m.z=p.z;m.since=this.elapsed;m.repairs=0;}m.activeAt=this.elapsed;}p.repath-=dt;if(!p.goal||dist(p.goal,goal)>2||(this.map.reference&&Math.abs((p.goal.y??p.y)-(goal.y??p.y))>.6)||(!this.map.reference&&p.repath<=0)||(this.map.reference&&!p.path.length&&p.repath<=0)){p.path=this.map.reference?navPath(this.map,p,goal,!p.safeRoute,spacing&&this.tactics?.version>=4?routePenalty(p,this.elapsed):undefined):pathfind(this.map,p,goal);p.goal={...goal};p.repath=1.3;}
  if(spacing&&p.brain?.yieldPoint&&p.brain.yieldUntil>this.elapsed&&dist(goal,p.brain.yieldPoint)<.01&&clearLine(this.map,p,goal,.2))p.path=[{...goal}];
  if(this.map.reference){
   // Consume the whole time budget across short nav edges. Taking one edge per
   // frame caused stop/start movement and frame-rate-dependent walking speed.
   let budget=Math.max(0,speed*dt),travel=0;
   for(let loops=0;budget>1e-6&&p.path.length&&loops<48;loops++){
    const next=p.path[0],d=dist(p,next),dy=(next.y??p.y)-p.y;
    if(d<.12&&Math.abs(dy)<.15&&p.path.length>1&&navWalkLine(this.map,p,p.path[1])){p.path.shift();continue;}
    if(d<.008){if(Math.abs(dy)>.4){const step=Math.min(budget,Math.abs(dy));p.y+=Math.sign(dy)*step;budget-=step;travel+=step;continue;}p.path.shift();continue;}
    const step=Math.min(d,budget,.15),dx=next.x-p.x,dz=next.z-p.z,t=step/d;let nx=p.x+dx*t,nz=p.z+dz*t,steered=false;
    if(spacing&&this.tactics?.version>=3){const avoid=crowdStep(this,p,dx/d,dz/d,step,next,AI_TOOLS);if(!avoid)break;nx=avoid.x;nz=avoid.z;steered=avoid.steered;}
    const actual=Math.hypot(nx-p.x,nz-p.z),location=navStepLocation(this.map,p,{x:nx,z:nz,y:p.y+dy*t},p.goal);
    if(!location||Math.abs(location.y-p.y)>2.5){p.path=[];p.repath=0;p.safeRoute=true;break;}
    p.angle=Math.atan2(nx-p.x,nz-p.z);p.x=nx;p.z=nz;p.y=location.y;budget-=step;travel+=actual;
    if(dist(p,next)<.008)p.path.shift();if(steered)budget=0;
   }
   p.moving=travel>1e-5;if(p.moving)p.walk+=travel*3;
   return;
  }
  if(this.map.original20){const d=p.path.length?dist(p,p.path.at(-1)):0,wanted=speed*Math.min(1,d/.9);p.locomotionSpeed??=0;p.locomotionSpeed+=clamp(wanted-p.locomotionSpeed,-dt*9,dt*5.5);speed=p.locomotionSpeed;}let next=p.path[0];if(!next)return;if(dist(p,next)<.25){p.path.shift();next=p.path[0];if(!next)return;}let dx=next.x-p.x,dz=next.z-p.z,d=Math.hypot(dx,dz);const step=Math.min(d,speed*dt);let nx=p.x+dx/d*step,nz=p.z+dz/d*step;if(spacing&&this.tactics?.version>=3){const avoid=crowdStep(this,p,dx/d,dz/d,step,next,AI_TOOLS);if(!avoid)return;nx=avoid.x;nz=avoid.z;}
  if(!blocked(this.map,nx,nz,.4)&&(!this.map.original22||Math.abs(heightAt(this.map,nx,nz)-p.y)<.36)){p.x=nx;p.z=nz;p.angle=Math.atan2(dx,dz);p.moving=true;p.walk+=dt*9;p.y=heightAt(this.map,p.x,p.z);}else{p.repath=0;p.path=[];}
 }
 ai(p,dt){if(this.aiVersion>=2)return tacticalAI(this,p,dt,AI_TOOLS);p.moving=false;p.cooldown=Math.max(0,p.cooldown-dt);p.blind=Math.max(0,p.blind-dt);p.throwCD-=dt;if(p.reload>0){p.reload-=dt;if(p.reload<=0){const n=Math.min(WEAPONS[p.weapon].mag-p.ammo,p.reserve);p.ammo+=n;p.reserve-=n;}}
  const enemies=this.players.filter(q=>q.team!==p.team&&q.alive),gun=WEAPONS[p.weapon];let visible=enemies.filter(q=>dist(p,q)<gun.range&&clearLine(this.map,p,q)&&!this.obscured(p,q)).sort((a,b)=>dist(a,p)-dist(b,p));const enemy=visible[0];
  if(enemy&&p.throwCD<=0&&this.elapsed>4){const kind=p.grenades.smoke&&dist(enemy,p)>15?'smoke':p.grenades.he?'he':p.grenades.flash?'flash':p.grenades.fire?'fire':null;if(kind)this.utility(p.id,kind,enemy);}
  if(enemy){if(p.targetId!==enemy.id){p.targetId=enemy.id;p.acquire=clamp((108-(p.reaction??p.skill))/100,.1,.75);}p.acquire=Math.max(0,p.acquire-dt);}else{p.targetId=null;p.acquire=0;}
  if(enemy&&p.blind<1){if(p.acquire<=0)this.shoot(p,enemy);p.angle=Math.atan2(enemy.x-p.x,enemy.z-p.z);if(p.weapon==='knife')this.move(p,enemy,dt,4.3);if(this.bomb.state!=='planted'&&!(p.side==='T'&&this.bomb.carrier===p.id))return;}
  const bomb=this.bomb;if(bomb.state==='planted'){
   const d=dist(p,bomb);const save=bomb.timer<(p.side==='T'?5:8)&&(p.side==='T'||d>12||this.alive(p.team)<2);
   if(save){this.move(p,this.map.spawns[p.side==='T'?0:1],dt,3.7);return;}
   if(p.side==='CT'){if(d<1.6&&(!this.map.reference||Math.abs(p.y-(bomb.y??p.y))<.65)&&!enemy&&p.blind<.5){if(bomb.actor===null||bomb.actor===p.id){if(bomb.actor===null){bomb.actor=p.id;bomb.progress=0;}bomb.progress+=dt;if(bomb.progress>=(p.kit?5:10)){bomb.state='defused';this.endRound(p.team,'C4 zararsizlantirildi');}}}else this.move(p,bomb,dt);}
   else if(d>6)this.move(p,{x:bomb.x+(p.id%2?3:-3),z:bomb.z+(p.id%3-1)*3,y:bomb.y},dt,2.8);
   return;
  }
  if(p.side==='T'&&bomb.state==='dropped'){if(dist(p,bomb)<1.6){bomb.state='carried';bomb.carrier=p.id;}else{this.move(p,bomb,dt);return;}}
  const strat=p.team===0?this.strategy:(this.enemyStrategy||'balanced'),siteIndex=strat==='b'?1:strat==='a'?0:(this.round%2?0:1),site=this.map.sites[siteIndex];
  if(p.side==='T'){
   const carrier=bomb.carrier===p.id;if(carrier&&dist(p,site)<2&&(!this.map.reference||Math.abs(p.y-site.y)<.65)){p.plant+=dt;bomb.progress=p.plant;bomb.x=p.x;bomb.z=p.z;bomb.y=p.y;bomb.actor=p.id;if(p.plant>=3.2){bomb.state='planted';bomb.carrier=null;p.plant=0;bomb.timer=40;bomb.progress=0;bomb.actor=null;this.note(`C4 qo‘yildi · ${site.label}`);}}else{p.plant=0;let goal=site;if(!carrier&&p.id%5>2&&strat==='balanced'&&this.elapsed<25)goal=this.map.staging||this.map.areas?.find(a=>a.name==='MID')||{x:35,z:26};if(strat==='hold'&&this.elapsed<14)goal={x:this.map.spawns[0].x,z:this.map.spawns[0].z-4,y:this.map.spawns[0].y};this.move(p,goal,dt,p.blind>0?1.6:3.1);}
  }else{let siteCT=this.map.sites[strat==='a'?0:strat==='b'?1:p.id%5<3?0:1];if(this.elapsed>45-clamp((p.tacticalSkill??p.skill)-60,0,40)*.3||this.alive(p.team)<3)siteCT=site;if(dist(p,siteCT)>3.5||(this.map.reference&&Math.abs(p.y-siteCT.y)>.65))this.move(p,{...siteCT,x:siteCT.x+(p.id%3-1)*(this.map.reference?1:2),z:siteCT.z+(this.map.reference?1:3)},dt);else if(this.elapsed>15&&!enemy){const threat=this.players.find(q=>q.alive&&q.side==='T');if(threat&&this.elapsed>55)this.move(p,threat,dt,2.7);}}
 }
 tick(dt){dt=clamp(dt,0,.1);for(const s of this.shots)s.age+=dt;this.shots=this.shots.filter(s=>s.age<.12);
  const pending=[];for(const e of this.effects){e.age+=dt;if(e.kind==='grenade'){const before=e.bounces||0,impact=advanceGrenade(this.map,e,dt);if(e.bounces>before)this.emit('bounce',{x:e.gx,y:e.gy,z:e.gz,type:e.type});if(e.age>=e.life||impact){pending.push(e);e.age=e.life;}}if(e.kind==='debris'){e.vy-=dt*12;e.x+=e.vx*dt;e.z+=e.vz*dt;e.y=Math.max(.1,e.y+e.vy*dt);if(e.y===.1){e.vx*=.92;e.vz*=.92;e.vy=Math.abs(e.vy)*.25;}}}
  this.effects=this.effects.filter(e=>e.age<e.life);for(const e of pending){let y=e.physics===1?e.gy:e.ty;if(e.type==='fire'&&e.physics===1){const floor=collisionRay(this.map,{x:e.gx,y:e.gy+.12,z:e.gz},{x:e.gx,y:e.gy-12,z:e.gz});y=floor&&floor.ny>.5?floor.y:heightAt(this.map,e.gx,e.gz,e.y);}this.explode(e.type,e.physics===1?e.gx:e.tx,e.physics===1?e.gz:e.tz,e.owner,y);}
  tickMapProps(this,dt);
  if(this.phase!=='live')for(const p of this.players)p.moving=false;
  if(this.outro>0){this.outro=Math.max(0,this.outro-dt);if(this.outro<=1e-6){this.outro=0;this.emit('roundEnd',{winner:this.result?.winner});}return;}
  if(this.phase==='freeze'){this.freeze-=dt;if(this.freeze<=0)this.phase='live';return;}
  if(this.phase!=='live')return;this.elapsed+=dt;this.clock-=dt;
  for(const e of this.effects)if(e.kind==='fire')for(const p of this.players)if(p.alive&&fireAt(this.map,e,p))this.hurt(p,dt*24,this.players[e.owner],'fire');
  if(this.aiVersion>=2){const offset=Math.floor(this.elapsed*30)%10;for(let i=0;i<10;i++){const p=this.players[(i+offset)%10];if(p.alive)this.ai(p,dt);}}else for(const p of this.players)if(p.alive)this.ai(p,dt);
  if(this.map.original20)for(const p of this.players)if(!p.moving)p.locomotionSpeed=Math.max(0,(p.locomotionSpeed||0)-dt*9);
  if(this.aiVersion>=2&&this.bomb.actor!==null&&this.bomb.state==='carried'&&this.players[this.bomb.actor]?.brain?.state!=='plant'){this.players[this.bomb.actor].plant=0;this.bomb.progress=0;this.bomb.actor=null;}
  if(this.bomb.state==='planted'){
   this.bomb.carrier=null;for(const q of this.players)q.plant=0;
   if(this.bomb.actor!==null){const q=this.players[this.bomb.actor];if(!q?.alive||dist(q,this.bomb)>1.7||(this.aiVersion>=2&&q.brain?.state!=='defuse')){this.bomb.actor=null;this.bomb.progress=0;}}
   const rate=this.bomb.timer<5?5:this.bomb.timer<10?3:1,pulse=Math.floor(this.bomb.timer*rate);if(pulse!==this.bomb.lastBeep){this.bomb.lastBeep=pulse;this.emit('c4beep',{x:this.bomb.x,y:this.bomb.y||0,z:this.bomb.z});}this.bomb.timer-=dt;if(this.bomb.timer<=0){this.explode('c4',this.bomb.x,this.bomb.z,null,this.bomb.y);this.bomb.state='exploded';const t=this.players.find(p=>p.side==='T');this.endRound(t.team,'C4 portladi');}
  }
  if(this.phase!=='live')return;
  const t=this.players.filter(p=>p.side==='T'&&p.alive),ct=this.players.filter(p=>p.side==='CT'&&p.alive);
  if(!ct.length)this.endRound(this.players.find(p=>p.side==='T').team,'Himoyachilar yo‘q qilindi');else if(!t.length&&this.bomb.state!=='planted')this.endRound(this.players.find(p=>p.side==='CT').team,'Hujumchilar yo‘q qilindi');else if(this.clock<=0&&this.bomb.state!=='planted')this.endRound(this.players.find(p=>p.side==='CT').team,'Vaqt tugadi');
 }
}
function pointSegment(p,a,b){const dx=b.x-a.x,dz=b.z-a.z,t=clamp(((p.x-a.x)*dx+(p.z-a.z)*dz)/(dx*dx+dz*dz||1),0,1);return Math.hypot(p.x-a.x-dx*t,p.z-a.z-dz*t);}

const AI_TOOLS={routePath:(map,a,b,penalty)=>map.reference?navPath(map,a,b,true,penalty):pathfind(map,a,b),WEAPONS,clearLine,pathfind,dist,clamp,heightAt,blocked};

function validDiscardedOriginalProps(states){
 if(!states||typeof states!=='object'||Array.isArray(states)||Object.keys(states).length>6)return false;
 for(const [id,s]of Object.entries(states)){
  if(!/^[0-5]$/.test(id)||!s||Object.keys(s).sort().join(',')!=='age,broken,burn,heat,rx,ry,rz,settled,vx,vy,vz,x,y,z')return false;
  if(typeof s.broken!=='boolean'||typeof s.settled!=='boolean')return false;
  for(const k of ['x','y','z','vx','vy','vz','rx','ry','rz','burn','heat','age'])if(!Number.isFinite(s[k]))return false;
  if(s.burn<0||s.burn>1||s.heat<0||s.heat>7||s.age<0||s.age>10000||s.x<-30||s.x>74||s.z<-30||s.z>68||Math.abs(s.y)>40||Math.hypot(s.vx,s.vy,s.vz)>100)return false;
 }
 return true;
}

function validLegacyProps(states){if(!states||typeof states!=='object'||Array.isArray(states)||Object.keys(states).length>64)return false;for(const [id,s]of Object.entries(states)){if(!/^\d{1,6}$/.test(id)||!s||Object.keys(s).sort().join(',')!=='age,broken,burn,heat,rx,ry,rz,settled,vx,vy,vz,x,y,z')return false;if(typeof s.broken!=='boolean'||typeof s.settled!=='boolean')return false;for(const key of ['x','y','z','vx','vy','vz','rx','ry','rz','burn','heat','age'])if(!Number.isFinite(s[key]))return false;if(s.burn<0||s.burn>1||s.heat<0||s.heat>7||s.age<0||s.age>10000||Math.abs(s.x)>150||Math.abs(s.z)>150||Math.abs(s.y)>100||Math.hypot(s.vx,s.vy,s.vz)>100)return false;}return true;}
