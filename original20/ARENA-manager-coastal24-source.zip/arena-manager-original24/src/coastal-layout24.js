import{ShapeUtils,Vector2}from'three';
// Hand-authored plan guided by the reference radar's landmark arrangement.
// Plan coordinates are percentages; rendering and physics share these outlines.
export const WIDTH=120,DEPTH=120,SCALE=1.2;
export const toWorld=([x,z])=>({x:(x-50)*SCALE,z:(z-50)*SCALE});
export const toGame=([x,z])=>({x:x*SCALE,z:z*SCALE});
export const OUTLINE=[[8,2],[13,2],[13,8],[21,8],[25,11],[31,11],[31,15],[47,15],[47,20],[55,20],[56,15],[60,15],[60,10],[77,10],[77,3],[90,3],[90,10],[91,10],[91,21],[95,21],[95,31],[92,33],[91,46],[95,48],[95,67],[83,67],[83,55],[75,55],[75,67],[72,68],[72,82],[66,82],[66,94],[59,94],[59,98],[47,98],[47,96],[15,96],[15,95],[5,95],[5,86],[9,82],[9,58],[16,56],[16,50],[13,50],[13,49],[6,49],[6,40],[9,40],[9,32],[6,32],[6,18],[8,17]];
export const DISTRICTS=[
 {id:'west-upper',h:8.4,style:4,color:'sand',p:[[1,2],[7.2,2],[7.2,17],[5.2,18],[5.2,32],[1,32]]},
 {id:'b-back',h:8,style:0,color:'sand',p:[[14,1],[29,1],[29,10],[25,10],[21,7],[14,7]]},
 {id:'b-courtyard-flank',h:6.2,style:1,color:'cream',p:[[27,1],[47,1],[47,14],[32,14],[32,10],[27,10]]},
 {id:'north-mid',h:7.6,style:0,color:'sand',p:[[48,1],[59,1],[59,14],[55,14],[54,19],[48,19]]},
 {id:'a-back',h:7.4,style:1,color:'cream',p:[[61,1],[76,1],[76,9],[61,9]]},
 {id:'a-east',h:9.2,style:0,color:'cream',p:[[92,2],[99,2],[99,46],[92,45],[93,34],[96,32],[96,20],[92,20]]},
 {id:'b-tunnel-mid-block',h:7.2,style:0,color:'sand',p:[[26,27],[41,27],[41,35],[43,36],[43,37],[27,37],[27,42],[19,42],[19,39],[13,39],[13,33],[15,33],[15,37],[20,37],[25,31]]},
 {id:'upper-to-lower-tunnel',h:8.2,style:1,color:'sand',p:[[21,51],[27,51],[33,48],[33,44],[42,44],[42,53],[37,53],[37,61],[38,68],[42,69],[42,85],[35,85],[35,74],[30,74],[29,76],[25,76],[24,73],[21,73]]},
 {id:'t-spawn-island',h:6.5,style:0,color:'cream',p:[[49,68],[55,68],[56,70],[56,80],[55,81],[49,81],[48,79],[48,70]]},
 {id:'mid-short-block',h:5.4,style:3,color:'sand',p:[[50,29],[59,29],[59,35],[51,35],[51,37],[50,37]]},
 {id:'long-short-quarter',h:8.6,style:1,color:'cream',p:[[67,28],[81,28],[81,44],[74,44],[64,47],[64,61],[54,61],[53,59],[53,45],[63,42],[67,40]]},
 {id:'long-door-house',h:6.4,style:3,color:'sand',p:[[76,56],[82,56],[82,67],[76,67],[76,61],[74,60],[74,58]]},
 {id:'west-tunnel-outside',h:6.6,style:0,color:'cream',p:[[1,41],[5,41],[5,50],[12,50],[12,51],[15,51],[15,55],[8,57],[8,81],[4,85],[1,85]]},
 {id:'south-tunnel-flank',h:7.7,style:4,color:'sand',p:[[1,96],[14,96],[14,97],[46,97],[46,99],[1,99]]},
 {id:'south-east-quarter',h:7.8,style:0,color:'cream',p:[[73,69],[82,69],[82,68],[99,68],[99,99],[60,99],[60,95],[67,95],[67,83],[73,83]]}
];
export const SITES=[{label:'A',p:[80,17]},{label:'B',p:[20,12.5]}];
export const SPAWNS=[[38,91],[56,23]];
export const ROUTES=[
 {id:'A LONG',p:[[38,91],[56,91],[62,84],[66,77],[66,70],[69,66],[69,57],[73,53],[85,53],[86,43],[86,31],[86,23],[80,17]]},
 {id:'A SHORT',p:[[38,91],[44.5,90],[45,83],[45,70],[42,65],[47,60],[47,48],[47,41],[55,40],[62,39],[63,31],[63,25],[70,23],[77,21.5],[80,17]]},
 {id:'B TUNNEL',p:[[38,91],[26,91],[19,84],[18,78],[15,72],[15,63],[17,57],[17,52],[14,47],[11,44],[11,35],[17,27],[20,20],[20,12.5]]},
 {id:'B MID',p:[[38,91],[44.5,90],[45,83],[45,70],[42,65],[47,60],[47,48],[47,41],[46,34],[45,27],[38,23],[29,22],[24,22],[20,12.5]]},
 {id:'CT A',p:[[56,23],[60,24],[63,24],[73,24],[80,17]]},
 {id:'CT B',p:[[56,23],[48,24],[43,22],[34,22],[27,22],[23,19],[20,12.5]]}
];
export const INTERIORS=[{id:'upper-b',p:[[9.5,60],[24,60],[26,70],[24,73],[9.5,73]],h:5},{id:'upper-b-exit',p:[[7,41],[17,41],[17,48],[7,48]],h:4.5},{id:'lower-b',p:[[29,39],[43,39],[43,43],[29,43]],h:4.1}];
export const LANDMARK_WALLS=[[16.5,8,21.5,8,2.6],[16.5,8,16.5,17,2.6],[25,12,25,21,2.6],[77,13,83,13,1],[83,13,83,21,1],[60.5,28,60.5,35,1.1]];
export const COVERS_PLAN=[[19,17,1.4],[23,13,1.3],[15,26,1.2],[77,16,1.6],[79,20,1.5],[83,16,1.1],[89,29,1.7],[87,50,1.3],[68,77,1.7],[12,45,1],[30,89,1.4],[47.5,36,1]];
export const PALMS_PLAN=[[2,31,7],[3,52,8],[3,78,7],[12,99,8],[35,100,7],[57,100,8],[99,45,8],[98,72,7],[87,7,7],[12,13,6]];
const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};
export function coastalHeight24(x,z){const px=x/SCALE+50,pz=z/SCALE+50;return .05+Math.max(1.3*smooth(68,85,pz),.6*(1-smooth(25,34,px))*(1-smooth(30,38,pz)),.9*(1-smooth(28,35,px))*smooth(34,42,pz)*(1-smooth(74,83,pz)),2.4*smooth(61,77,px)*(1-smooth(25,47,pz)),1.45*smooth(54,61,px)*(1-smooth(33,44,pz)))}
export function insidePlan(p,poly=OUTLINE){let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside}return inside}
function collider(p,y,h,id){const pts=p.map(toWorld),minX=Math.min(...pts.map(v=>v.x)),maxX=Math.max(...pts.map(v=>v.x)),minZ=Math.min(...pts.map(v=>v.z)),maxZ=Math.max(...pts.map(v=>v.z)),x=(minX+maxX)/2,z=(minZ+maxZ)/2;let polygon=pts.map(p=>({x:p.x-x,z:p.z-z}));const area=polygon.reduce((s,a,i)=>{const b=polygon[(i+1)%polygon.length];return s+a.x*b.z-b.x*a.z},0);if(area<0)polygon.reverse();return{x,z,w:maxX-minX,d:maxZ-minZ,y,h,id,polygon}}
export function coastalSolids24(){const rows=[];const triangulate=(p,y,h,id)=>{const v=p.map(([x,z])=>new Vector2(x,z));for(const tri of ShapeUtils.triangulateShape(v,[]))rows.push(collider(tri.map(i=>p[i]),y,h,id))};
 const outer=[[0,0],[100,0],[100,100],[0,100]],vertices=[...outer,...OUTLINE],tris=ShapeUtils.triangulateShape(outer.map(p=>new Vector2(...p)),[OUTLINE.map(p=>new Vector2(...p))]);for(const tri of tris)rows.push(collider(tri.map(i=>vertices[i]),-1.5,14,'boundary'));
 for(const d of DISTRICTS){const base=Math.min(...d.p.map(p=>{const w=toWorld(p);return coastalHeight24(w.x,w.z)}));triangulate(d.p,base-.2,d.h+.45,d.id)}
 for(const[ax,az,bx,bz,h]of LANDMARK_WALLS){const a=toWorld([ax,az]),b=toWorld([bx,bz]),x=(a.x+b.x)/2,z=(a.z+b.z)/2;rows.push({x,z,w:Math.max(.32,Math.abs(b.x-a.x)),d:Math.max(.32,Math.abs(b.z-a.z)),y:coastalHeight24(x,z),h,id:'landmark-wall'})}
 for(const[x,z,w]of COVERS_PLAN){const q=toWorld([x,z]);rows.push({...q,w:w*SCALE,d:w*SCALE,y:coastalHeight24(q.x,q.z),h:w*SCALE,id:'cover'})}return rows}
export function roofSolids24(){return INTERIORS.flatMap(d=>{const v=d.p.map(p=>new Vector2(...p));return ShapeUtils.triangulateShape(v,[]).map(tri=>{const row=collider(tri.map(i=>d.p[i]),d.h,.2,d.id);return row})})}
