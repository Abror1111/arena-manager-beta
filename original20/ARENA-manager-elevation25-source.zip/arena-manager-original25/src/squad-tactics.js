import {grenadePosition} from './grenade-physics.js';
import {chooseAdaptation,recordAdaptation,validLearning} from './adaptive-play.js';
import {navLocation,navStepLocation,navWalkLine,navUseful} from './reference-nav.js';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z),sameFloor=(a,b)=>Math.abs((a.y||0)-(b.y||0))<1.2;
const point=p=>({x:p.x,z:p.z,y:p.y||0}),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const grids=new WeakMap();
const ROLES=['captain','rifler','sniper','entry','support'];
export const INTENT_LABELS={setup:'Tayyorlanish',control:'Xarita nazorati',execute:'Kelishilgan hujum',anchor:'Pozitsiyani ushlash',rotate:'Yordamga o‘tish',engage:'Otishma',cover:'Panaga o‘tish',reload:'O‘q almashtirish',postplant:'C4 himoyasi',retake:'Nuqtani qaytarish',defuse:'Zararsizlantirish',plant:'C4 qo‘yish',save:'Qurolni saqlash',turn:'Flashdan burilish',evade:'Granatadan qochish',spacing:'Sherikka yo‘l berish',peek:'Burchakdan tekshirish'};
export const experienceOf=p=>Math.round(clamp((p.experienceMatches||0)*2+Math.sqrt(p.experienceXP||0)*1.4+Math.max(0,(p.tacticalSkill??p.skill)-50)*.6,0,100));
export function roleOf(p){return ({Kapitan:'captain',Rifler:'rifler',Snayper:'sniper',Entry:'entry',Support:'support'})[p.role]||ROLES[p.id%5];}
export function candidatePoints(map,center,radius,tools){
 const found=[];
 if(map.nav){let grid=grids.get(map.nav);if(!grid){grid=new Map();for(const row of map.nav.rows){const [x,z,y]=row[3];if(!navUseful(map,{x,z,y}))continue;const key=`${Math.floor(x/4)},${Math.floor(z/4)}`;if(!grid.has(key))grid.set(key,[]);grid.get(key).push({x,z,y});}grids.set(map.nav,grid);}for(let x=Math.floor((center.x-radius)/4);x<=Math.floor((center.x+radius)/4);x++)for(let z=Math.floor((center.z-radius)/4);z<=Math.floor((center.z+radius)/4);z++)for(const q of grid.get(`${x},${z}`)||[])if(distance(q,center)<=radius&&sameFloor(q,center))found.push(q);}
 else for(let x=center.x-radius;x<=center.x+radius;x+=1.3)for(let z=center.z-radius;z<=center.z+radius;z+=1.3)if(Math.hypot(x-center.x,z-center.z)<=radius&&!tools.blocked(map,x,z,.4))found.push({x,z,y:tools.heightAt(map,x,z)});
 return found;
}
export function spreadPosition(game,center,p,reserved,tools,radius=6){
 const heading=(p.id%5)*Math.PI*2/5,desired=p.weapon==='awp'?Math.min(radius-1,5):3.3;
 const score=q=>{const nearest=Math.min(8,...reserved.filter(r=>sameFloor(r,q)).map(r=>distance(r,q))),a=Math.atan2(q.x-center.x,q.z-center.z),diff=Math.abs(Math.atan2(Math.sin(a-heading),Math.cos(a-heading)));return Math.min(nearest,3)*4-Math.abs(distance(q,center)-desired)*.9-diff*.55;};
 const choices=candidatePoints(game.map,center,radius,tools).filter(q=>distance(q,center)>1.1);const ranked=choices.map(q=>({q,score:score(q)})).sort((a,b)=>b.score-a.score).map(r=>r.q);
 for(const q of ranked.slice(0,4))if(tools.pathfind(game.map,p,q).length){reserved.push(q);return point(q);}
 const q=point(center);reserved.push(q);return q;
}
function routePoint(game,p,target,fraction,tools){const path=tools.pathfind(game.map,p,target);if(!path.length)return point(p);let from=p,total=0;for(const q of path){total+=distance(from,q);from=q;}let n=0;from=p;for(const q of path){const d=distance(from,q);if(d&&n+d>=total*fraction){const t=(total*fraction-n)/d,x=from.x+(q.x-from.x)*t,z=from.z+(q.z-from.z)*t,y=(from.y||0)+((q.y||0)-(from.y||0))*t;return{x,z,y:tools.heightAt(game.map,x,z,y)};}n+=d;from=q;}return point(path.at(-1));}
export function configureSquad(game,team,plan,tools){
 const crew=game.players.filter(p=>p.team===team),stages=[],anchors=[[],[]],main=game.map.sites[plan.site],strategy=team===0?game.strategy:game.enemyStrategy;
 for(const p of [...crew].sort((a,b)=>(roleOf(a)==='entry'?-1:0)-(roleOf(b)==='entry'?-1:0)||a.id-b.id)){
  const b=p.brain,role=roleOf(p),lane=role==='sniper'||role==='captain'?1:0,defendSite=strategy==='a'?0:strategy==='b'?1:role==='support'||role==='rifler'?1:0;
  const routeTarget=lane&&plan.approach?plan.approach:lane?(game.map.staging||game.map.sites[1-plan.site]):main;
  const staging=routePoint(game,p,routeTarget,lane?.38:.45,tools);
  b.squadRole=role;b.lane=lane;b.defendSite=defendSite;b.entryDelay=({entry:0,rifler:.85,captain:1.3,support:1.8,sniper:2.5})[role];b.experience=experienceOf(p);b.evade=null;b.evadeUntil=0;b.hazardKey='';b.waitTime=0;b.passUntil=0;
  b.staging=spreadPosition(game,staging,p,stages,tools,4.8);
  b.anchor=spreadPosition(game,p.side==='CT'?game.map.sites[defendSite]:main,p,anchors[p.side==='CT'?defendSite:plan.site],tools,6.5);b.postPlant=null;if(game.tactics.version>=4){b.motion={x:p.x,z:p.z,since:0,activeAt:-99,repairs:0};b.avoid=game.tactics.learning[team].danger.map(point);b.routeVia=p.side==='T'&&lane&&plan.approach?point(plan.approach):null;b.viaCleared=!b.routeVia;b.lastAdvance=(p.id%5)?-(p.id%5)*.6:0;}
  if(game.map.original22){const name=p.side==='CT'?(defendSite===0?'CT A':'CT B'):plan.site===0?(lane?'A SHORT':'A LONG'):(lane?'B MID':'B TUNNEL'),route=game.map.tacticalRoutes.find(r=>r.id===name);b.archRoute=name;b.archWaypoints=route.points.slice(1).map(q=>({...q,y:tools.heightAt(game.map,q.x,q.z)}));b.archIndex=0;if(game.elapsed>1){let nearest=Infinity;for(let i=0;i<b.archWaypoints.length;i++){const d=distance(p,b.archWaypoints[i]);if(d<nearest){nearest=d;b.archIndex=i}}}b.routeVia=null;b.viaCleared=true;}

 }
}
export function teamDefuser(game){
 const actor=game.players[game.bomb.actor];if(actor?.alive&&actor.side==='CT'&&sameFloor(actor,game.bomb)&&distance(actor,game.bomb)<1.7&&game.bomb.progress>0)return actor;
 return game.players.filter(p=>p.alive&&p.side==='CT').sort((a,b)=>(distance(a,game.bomb)/2.9+Math.abs((a.y||0)-(game.bomb.y||0))*3+(a.kit?5:10))-(distance(b,game.bomb)/2.9+Math.abs((b.y||0)-(game.bomb.y||0))*3+(b.kit?5:10))||a.id-b.id)[0];
}
export function defuseETA(game){const actor=game.players[game.bomb.actor];if(actor?.alive&&actor.side==='CT'&&distance(actor,game.bomb)<1.7&&game.bomb.state==='planted')return Math.max(0,(actor.kit?5:10)-game.bomb.progress);const p=teamDefuser(game);return p?distance(p,game.bomb)/2.9*1.15+(p.kit?5:10):Infinity;}
export function prepareSquadPlan(game,team,plan,tools){
 const history=game.tactics.history[team],strategy=team===0?game.strategy:game.enemyStrategy;
 if(strategy==='balanced'&&history.attempts[0]+history.attempts[1]>=2){const scores=[0,1].map(i=>(history.wins[i]+1)/(history.attempts[i]+2));if(Math.abs(scores[0]-scores[1])>.12&&game.random()<.8)plan.site=scores[0]>scores[1]?0:1;}
 if(game.tactics.version>=4)chooseAdaptation(game,team,plan,tools);configureSquad(game,team,plan,tools);return plan;
}
export function learnRound(game,winner){if(!(game.tactics?.version>=3))return;recordAdaptation(game,winner);for(let team=0;team<2;team++){if(game.side(team)!=='T')continue;const h=game.tactics.history[team],site=game.tactics.teams[team].site;h.attempts[site]++;if(team===winner)h.wins[site]++;}}
export function validSquadExtras(state){
 const t=state.tactics;if(t.version===undefined)return true;if(![3,4].includes(t.version)||!validLearning(t)||!Array.isArray(t.history)||t.history.length!==2)return false;
 const numbers=(a,n)=>Array.isArray(a)&&a.length===n&&a.every(v=>Number.isInteger(v)&&v>=0&&v<=1000);
 for(const h of t.history)if(!h||!numbers(h.attempts,2)||!numbers(h.wins,2)||h.wins.some((v,i)=>v>h.attempts[i])||!Number.isInteger(h.fragLosses)||h.fragLosses<0||h.fragLosses>1000)return false;
 for(const p of state.players){const b=p.brain;if(b.archWaypoints!==undefined&&(!Array.isArray(b.archWaypoints)||b.archWaypoints.length>24||b.archWaypoints.some(q=>!q||!['x','y','z'].every(k=>Number.isFinite(q[k])&&Math.abs(q[k])<10000))||typeof b.archRoute!=='string'||b.archRoute.length>24||!Number.isInteger(b.archIndex)||b.archIndex<0||b.archIndex>b.archWaypoints.length))return false;if(t.version>=4){const m=b.motion;if(!m||!['x','z','since','activeAt','repairs'].every(k=>Number.isFinite(m[k]))||!Number.isInteger(m.repairs)||m.repairs<0||m.repairs>1000||!Array.isArray(b.avoid)||b.avoid.length>6||b.avoid.some(q=>!q||!['x','y','z'].every(k=>Number.isFinite(q[k])))||typeof b.viaCleared!=='boolean'||!Number.isFinite(b.lastAdvance))return false;for(const k of ['routeVia','yieldPoint'])if(b[k]!==undefined&&b[k]!==null&&(!b[k]||!['x','y','z'].every(n=>Number.isFinite(b[k][n]))))return false;if(b.recoveryAt!==undefined&&!Number.isFinite(b.recoveryAt))return false;if(b.yieldUntil!==undefined&&!Number.isFinite(b.yieldUntil))return false;if(b.blocked!==undefined&&(!b.blocked||!['x','y','z','until'].every(k=>Number.isFinite(b.blocked[k]))))return false;}if(!ROLES.includes(b.squadRole)||![0,1].includes(b.lane)||![0,1].includes(b.defendSite)||!['entryDelay','experience','evadeUntil','waitTime','passUntil'].every(k=>Number.isFinite(b[k]))||b.experience<0||b.experience>100||typeof b.hazardKey!=='string'||b.hazardKey.length>120)return false;if(b.evade!==null&&(!b.evade||!['x','y','z'].every(k=>Number.isFinite(b.evade[k]))))return false;}
 return true;
}
export function grenadeHazard(game,p,tools){
 const experience=p.brain.experience,react=.42-experience*.0025;let danger=null;
 for(const e of game.effects){
  if(e.kind==='fire'&&!e.extinguished&&sameFloor(p,e)&&distance(p,e)<3.1){danger={...point(e),radius:3.2,key:`fire:${e.x}:${e.z}`,urgency:1};break;}
  if(e.kind!=='grenade'||!['he','fire'].includes(e.type)||e.age<react||Math.abs((e.ty??e.y??0)-p.y)>1.2)continue;
  const current=grenadePosition(e,game.map.playerScale||1);
  const friendly=game.players[e.owner]?.team===p.team;
  if(!friendly&&(distance(p,current)>14||!tools.clearLine(game.map,p,current)||game.obscured(p,current)))continue;
  const radius=e.type==='he'?4.8*(game.map.playerScale||1)+.55:3.3,impact=e.physics===1?{x:e.gx+e.vx*Math.min(.5,e.life-e.age),z:e.gz+e.vz*Math.min(.5,e.life-e.age),y:e.ty??e.y??0}:{x:e.tx,z:e.tz,y:e.ty??e.y??0};
  if(distance(p,impact)>radius+1||!tools.clearLine(game.map,p,impact))continue;
  danger={...impact,radius,key:`${e.owner}:${e.type}:${e.tx.toFixed(2)}:${e.tz.toFixed(2)}`,urgency:e.life-e.age};break;
 }
 if(danger&&(p.brain.hazardKey!==danger.key||p.brain.evadeUntil<=game.elapsed)){
  const choices=candidatePoints(game.map,p,Math.max(5,danger.radius+1.5),tools).filter(q=>distance(q,p)>.7&&distance(q,danger)>distance(p,danger)+.5&&tools.clearLine(game.map,p,q,.2));
  const score=q=>distance(q,danger)*2-distance(p,q)-game.players.filter(a=>a.id!==p.id&&a.alive&&a.team===p.team&&sameFloor(a,q)).reduce((n,a)=>n+Math.max(0,2-distance(a,q))*2,0);
  choices.sort((a,b)=>score(b)-score(a));if(choices[0]){p.brain.evade=point(choices[0]);p.brain.hazardKey=danger.key;p.brain.evadeUntil=game.elapsed+Math.max(.8,Math.min(2.4,danger.urgency+.45));p.path=[];p.goal=null;}
 }
 return !!(p.brain.evade&&p.brain.evadeUntil>game.elapsed);
}
// Local steering modifies only the next nav-safe step; it never pushes or teleports.
export function crowdStep(game,p,dx,dz,length,goal,tools){
 const peers=game.players.filter(q=>q.id!==p.id&&q.alive&&sameFloor(p,q)&&distance(p,q)<3&&(!game.map.reference||navWalkLine(game.map,p,q))),hard=Math.max(.38,(game.map.playerScale||1)*.65);
 if(!peers.length)return{x:p.x+dx*length,z:p.z+dz*length,steered:false};
 const desired=(game.elapsed<p.brain.passUntil ? .85 : Math.max(1.6,3.6*(game.map.playerScale||1)))+Math.min(.5,(game.tactics.history[p.team].fragLosses||0)*.05);
 const forward={x:p.x+dx*length,z:p.z+dz*length};if(!peers.some(q=>distance(forward,q)<desired&&distance(forward,q)<distance(p,q)))return{...forward,steered:false};
 const overlapping=peers.some(q=>distance(p,q)<hard*.99),turns=overlapping?[0,.55,-.55,1.05,-1.05,1.45,-1.45,1.9,-1.9]:[0,.45,-.45,.9,-.9,1.35,-1.35];const candidates=[];for(const turn of turns){
  const c=Math.cos(turn),s=Math.sin(turn),vx=dx*c-dz*s,vz=dx*s+dz*c,heading=p.id%2?1:-1;
  let step=length;if(turn===0)for(const q of peers){const ahead=(q.x-p.x)*dx+(q.z-p.z)*dz,lateral=Math.abs((q.x-p.x)*dz-(q.z-p.z)*dx);if(ahead>0&&lateral<hard*1.7)step=Math.min(step,length*clamp((distance(p,q)-hard)/(desired-hard),.04,1));}
  const q={x:p.x+vx*step,z:p.z+vz*step,y:p.y};if(peers.some(a=>distance(q,a)<hard&&distance(q,a)<distance(p,a)-.0001))continue;
  if(game.map.reference){const loc=navStepLocation(game.map,p,q,p.goal||goal);if(!loc||Math.abs(loc.y-p.y)>.6||turn!==0&&!navWalkLine(game.map,p,loc))continue;q.y=loc.y;}else if(tools.blocked(game.map,q.x,q.z,.4)||!tools.clearLine(game.map,p,q,.25))continue;
  const crowd=peers.reduce((n,a)=>n+Math.max(0,desired-distance(q,a))**2,0),score=(distance(p,goal)-distance(q,goal))*3-crowd*.7-Math.abs(turn)*.008+(turn*heading)*.001;
  candidates.push({...q,score,steered:turn!==0||step<length*.95});
 }
 candidates.sort((a,b)=>b.score-a.score);const q=candidates[0];if(!q||distance(q,p)<length*.15){p.brain.waitTime+=length/3;if(p.brain.waitTime>1.2){p.brain.passUntil=game.elapsed+1;p.brain.waitTime=0;}}else p.brain.waitTime=0;return q;
}
