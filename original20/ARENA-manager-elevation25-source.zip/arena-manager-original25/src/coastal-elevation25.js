// One metre-based floor definition for drawing, walking, IK and projectile impact.
export const SCALE25=1.2,GROUND25=.05;
export const STAIRS25=[
 {id:'short-south',axis:'z',start:41,end:35,x0:60,x1:66,z0:35,z1:41,low:.05,high:2.6,steps:17},
 {id:'ct-short',axis:'x',start:57,end:61.5,x0:57,x1:61.5,z0:21,z1:26,low:.05,high:2.6,steps:17},
 {id:'a-short',axis:'x',start:71,end:77,x0:71,x1:77,z0:18,z1:26,low:2.6,high:4.25,steps:11},
 {id:'upper-to-lower',axis:'x',start:25,end:33,x0:25,x1:33,z0:38,z1:47.5,low:1.8,high:-.85,steps:17},
 {id:'lower-mid',axis:'x',start:40,end:46,x0:40,x1:46,z0:38.5,z1:43.5,low:-.85,high:.05,steps:6}
];
const within=(x,z,r)=>x>=r.x0&&x<=r.x1&&z>=r.z0&&z<=r.z1;
const lerp=(a,b,t)=>a+(b-a)*Math.max(0,Math.min(1,t));
export function stairAt25(x,z){return STAIRS25.find(r=>within(x,z,r))||null}
export function terrainHeight25(x,z){if(Math.abs(x)>60||Math.abs(z)>60)return GROUND25;const px=x/1.2+50,pz=z/1.2+50,stair=stairAt25(px,pz);if(stair){const t=((stair.axis==='x'?px:pz)-stair.start)/(stair.end-stair.start),n=Math.max(0,Math.min(stair.steps,Math.floor(t*stair.steps+1e-8)));return stair.low+(stair.high-stair.low)*n/stair.steps}
 if(px>=33&&px<=40&&pz>=38.5&&pz<=43.5)return -.85;
 if(px>=77&&px<=91&&pz<=24)return 4.25;
 if(px>=83&&px<=91&&pz>24&&pz<=46)return lerp(4.25,.05,(pz-24)/22);
 if(px>=61.5&&px<=77&&pz>=10&&pz<=35)return 2.6;
 if(px<=26&&pz<=34)return 1.05;
 if(px>26&&px<=35&&pz<=30)return lerp(1.05,.05,(px-26)/9);
 if(px<=26&&pz>34&&pz<42)return lerp(1.05,1.8,(pz-34)/8);
 if(px<=28&&pz>=42&&pz<=74)return 1.8;
 if(px<=28&&pz>74&&pz<=85)return lerp(1.8,1.35,(pz-74)/11);
 if(pz>=85)return 1.35;
 if(pz>68)return lerp(.05,1.35,(pz-68)/17);
 return GROUND25;
}
export function terrainNormal25(x,z){const e=.012,dx=(terrainHeight25(x+e,z)-terrainHeight25(x-e,z))/(e*2),dz=(terrainHeight25(x,z+e)-terrainHeight25(x,z-e))/(e*2),steep=Math.hypot(dx,dz)>2,ny=steep?0:1,l=Math.hypot(dx,ny,dz)||1;return{nx:-dx/l,ny:ny/l,nz:-dz/l}}
export function terrainSweep25(a,b,pad=.07){if(Math.min(a.y,b.y)>4.25+pad)return null;const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,n=Math.max(1,Math.ceil(Math.hypot(dx,dy,dz)/(pad===0?.3:.08))),signed=t=>a.y+dy*t-terrainHeight25(a.x+dx*t,a.z+dz*t)-pad;let prev=0,side=signed(0);if(side<-.04)return null;for(let i=1;i<=n;i++){const t=i/n,next=signed(t);if(next<=0&&side>=0){let lo=prev,hi=t;for(let k=0;k<15;k++){const mid=(lo+hi)/2;if(signed(mid)>0)lo=mid;else hi=mid}const u=(lo+hi)/2,x=a.x+dx*u,z=a.z+dz*u,normal=terrainNormal25(x,z);return{x,y:a.y+dy*u,z,t:u,...normal}}prev=t;side=next}return null}
export const ROAD_AREAS25=[[[83,24],[90,24],[90,65],[84,65],[84,54],[72,54],[69,57],[68,55],[71,51],[83,51]],[[44,34],[49,34],[49,61],[44,61]],[[26,18],[43,18],[45,22],[56,22],[56,26],[45,26],[42,24],[26,24]]];
export function terrainAxes25(){const xs=new Set(),zs=new Set();for(let i=0;i<=120;i++){xs.add(i-60);zs.add(i-60)}for(const v of[25,26,28,33,35,40,46,57,60,61.5,66,71,77,83,91])xs.add((v-50)*1.2);for(const v of[10,18,21,24,26,30,34,35,38,38.5,41,42,43.5,46,47.5,68,74,85])zs.add((v-50)*1.2);for(const r of STAIRS25)for(let i=0;i<=r.steps;i++)(r.axis==='x'?xs:zs).add((r.start+(r.end-r.start)*i/r.steps-50)*1.2);const clean=s=>[...s].sort((a,b)=>a-b).filter((x,i,a)=>!i||x-a[i-1]>.00001);return{x:clean(xs),z:clean(zs)}}
