import {collisionRay,hasCollision} from './world-collision.js';
import {navLocation,navWalkLine} from './reference-nav.js';
const gravity=7.8;
export function grenadePosition(e,scale=1){if(e.physics===1)return{x:e.gx,y:e.gy,z:e.gz};const t=Math.min(1,e.age/e.life);return{x:e.sx+(e.tx-e.sx)*t,z:e.sz+(e.tz-e.sz)*t,y:(e.y||0)+1.1*scale+((e.ty??e.y??0)-(e.y||0))*t+Math.sin(t*Math.PI)*(1.8+Math.hypot(e.tx-e.sx,e.tz-e.sz)*.06)};}
export function launchGrenade(map,p,target,type){
 const d=Math.hypot(target.x-p.x,target.z-p.z),duration=Math.min(1.65,.65+d/18),height=(map.playerScale||1)*1.2;
 return {physics:1,gx:p.x,gy:p.y+height,gz:p.z,vx:(target.x-p.x)/duration,vy:((target.y??p.y)-p.y-height)/duration+gravity*duration/2,vz:(target.z-p.z)/duration,bounces:0,grounded:false,trail:[],life:type==='fire'?2.8:type==='smoke'?2.4:type==='flash'?1.65:1.8};
}
function fallbackHit(map,a,b){
 if(!map.reference){
  let best=null;
  for(const r of map.blocks){
   let lo=0,hi=1,normal=null;for(const [axis,min,max,n]of [['x',r.x-r.w/2-.06,r.x+r.w/2+.06,'x'],['z',r.z-r.d/2-.06,r.z+r.d/2+.06,'z'],['y',r.y||0,(r.y||0)+r.h+.06,'y']]){const delta=b[axis]-a[axis];if(Math.abs(delta)<1e-8){if(a[axis]<min||a[axis]>max){lo=2;break;}continue;}let t1=(min-a[axis])/delta,t2=(max-a[axis])/delta,sgn=-Math.sign(delta);if(t1>t2)[t1,t2]=[t2,t1];if(t1>lo){lo=t1;normal={[n]:sgn};}hi=Math.min(hi,t2);}
   if(normal&&lo<=hi&&lo>=0&&lo<=1&&(!best||lo<best.t))best={x:a.x+(b.x-a.x)*lo,y:a.y+(b.y-a.y)*lo,z:a.z+(b.z-a.z)*lo,nx:normal.x||0,ny:normal.y||0,nz:normal.z||0,t:lo};
  }
  if(best)return best;
 }else{
  const start=navLocation(map,a),end=navLocation(map,b);if(start&&(!end||!navWalkLine(map,start,end))&&Math.min(a.y,b.y)<start.y+2.2){const x=navLocation(map,{x:b.x,z:a.z,y:a.y}),z=navLocation(map,{x:a.x,z:b.z,y:a.y});return{x:a.x,y:a.y,z:a.z,nx:!x?-Math.sign(b.x-a.x):0,ny:0,nz:x||!z?-Math.sign(b.z-a.z):0,t:0};}
 }
 const floor=map.reference?navLocation(map,b):{y:0};if(floor&&b.y<floor.y+.07&&a.y>=floor.y+.04){const t=(a.y-floor.y-.07)/Math.max(.00001,a.y-b.y);return{x:a.x+(b.x-a.x)*t,y:floor.y+.07,z:a.z+(b.z-a.z)*t,nx:0,ny:1,nz:0,t};}return null;
}
export function advanceGrenade(map,e,dt){
 if(e.physics!==1)return false;let impact=false;
 for(let left=dt;left>1e-7;){const step=Math.min(left,1/90);left-=step;if(e.grounded)continue;
  const a={x:e.gx,y:e.gy,z:e.gz};e.vy-=gravity*step;const b={x:e.gx+e.vx*step,y:e.gy+e.vy*step,z:e.gz+e.vz*step};
  const hit=hasCollision(map)?collisionRay(map,a,b,{ignoreStart:.001}):fallbackHit(map,a,b);
  if(hit){
   e.gx=hit.x+hit.nx*.035;e.gy=hit.y+hit.ny*.035;e.gz=hit.z+hit.nz*.035;
   const dot=e.vx*hit.nx+e.vy*hit.ny+e.vz*hit.nz,restitution=hit.ny>.6?.34:.58;
   e.vx=(e.vx-(1+restitution)*dot*hit.nx)*.83;e.vy=(e.vy-(1+restitution)*dot*hit.ny)*.83;e.vz=(e.vz-(1+restitution)*dot*hit.nz)*.83;e.bounces++;
   if(e.type==='fire'&&hit.ny>.55){impact=true;e.grounded=true;break;}
   if((hit.ny>.6&&Math.hypot(e.vx,e.vz)<.65&&Math.abs(e.vy)<.75)||e.bounces>=12){e.grounded=true;e.vx=e.vy=e.vz=0;}
  }else{e.gx=b.x;e.gy=b.y;e.gz=b.z;}
  e.gx=Math.max(.1,Math.min(map.width-.1,e.gx));e.gz=Math.max(.1,Math.min(map.height-.1,e.gz));
  if(e.gy< -20){e.grounded=true;impact=e.type==='fire';}
 }
 e.x=e.gx;e.z=e.gz;
 if(!e.trail.length||Math.hypot(e.gx-e.trail.at(-1).x,e.gy-e.trail.at(-1).y,e.gz-e.trail.at(-1).z)>.3){e.trail.push({x:e.gx,y:e.gy,z:e.gz});if(e.trail.length>12)e.trail.shift();}
 return impact;
}
export function validGrenade(e){if(e.physics===undefined)return true;return e.physics===1&&['gx','gy','gz','vx','vy','vz'].every(k=>Number.isFinite(e[k])&&Math.abs(e[k])<10000)&&Number.isInteger(e.bounces)&&e.bounces>=0&&e.bounces<=30&&typeof e.grounded==='boolean'&&Array.isArray(e.trail)&&e.trail.length<=12&&e.trail.every(p=>p&&['x','y','z'].every(k=>Number.isFinite(p[k])));}
