// Independently authored district data; no exported radar/nav/scene inputs.
export const Z_SCALE=40/52;
export const DISTRICT_SCALE=1.4;
export const PASSAGES=[{x:-2,z:-13,length:11,width:3.6,height:3.4}];
export const BARRIERS=[[15,-1,.35,5.5,1.6],[-11,6,3.3,.35,1.45]];
export const BUILDINGS=[[-23,-20,10,8,4.6,3,'sand'],[-9,-21,10,7,8.6,1,'cream'],[6,-21,12,8,4.2,4,'peach'],[22,-19,9,10,5.2,3,'cream'],[-23,-6,8,12,4.9,4,'sand'],[22,-3,9,12,6,0,'sand'],[-23,15,10,11,7,1,'cream'],[-8,21,12,7,6,2,'sand'],[9,20,14,9,7,5,'peach'],[23,17,8,9,3.8,4,'cream'],[1,0,4.7,6.4,3.6,5,'peach'],[19,-10,3.5,4.2,3.4,3,'sand'],[-19,20,4.2,4.8,4.2,0,'sand'],[20,22,5.2,4.5,3.6,4,'peach'],[-17,-15,3.4,5.6,3.3,3,'sand'],[-17,0,3.4,4.8,3.2,0,'cream'],[20,6.8,5,4.6,3.8,1,'sand'],[5,13.4,6,3.2,3.4,3,'cream'],[-8,13.8,4.5,4.6,3.5,0,'peach'],[11,-16.5,5,3.4,3.3,4,'sand']];
export const PALMS=[[-29,-14,7],[-28,7,7],[-28,22,6],[-16,17,7],[16,12,6],[15,-13,7],[27,7,6],[-17,-16,6],[-3,13,6],[-35,-22,7],[-34,27,7]];
export const MARKETS=[[-12,10],[9,-10],[14,10]];
export const COVERS=[[-15,8],[9,4],[-2,-15],[15,3]];
export function districtHeight(x,z){
 if(x>=5.4&&x<=11&&z>=2&&z<8)return 1.13;
 if(x>=5.4&&x<=11&&z>=8&&z<11.6)return Math.max(.05,1.13-(Math.floor((z-8)/.6)+1)*.18);
 if(x>=11&&x<14&&z>=3.5&&z<=6)return Math.max(.05,1.13-(Math.floor((x-11)/.5)+1)*.18);
 return x>-11.5&&x<5.5&&z>-6&&z<8?.315:.05;
}
export const TERRACE_WALLS=[[5.15,5,.25,6.4,1.43],[8.1,1.8,6.2,.25,1.43],[11.15,2.65,.25,1.6,1.43],[11.15,7.2,.25,1.6,1.43]];
export function districtSolids(){
 const rows=[...BARRIERS.map(([x,z,w,d,h])=>({x,z,w,d,h})),...PASSAGES.flatMap(p=>[-1,1].map(side=>({x:p.x,z:p.z+side*p.width/2,w:p.length,d:.25,h:p.height}))),...BUILDINGS.map(([x,z,w,d,h])=>({x,z,w,d,h})),{x:-13,z:-9,w:4.4,d:4.4,h:10},{x:-4,z:1,w:4.7,d:4.7,h:2},...MARKETS.map(([x,z])=>({x,z,w:3.8,d:2.6,h:3})),...TERRACE_WALLS.map(([x,z,w,d,h])=>({x,z,w,d,h}))];
 for(const [x,z]of COVERS)for(const [dx,w]of [[0,1.3],[1.5,.95]])rows.push({x:x+dx,z,w,d:w,h:w,y:districtHeight(x+dx,z)});
 for(const [x,z]of [[-19,1],[17,-7],[-13,15],[2,-16]])rows.push({x,z,w:.9,d:.9,h:1});
 for(const [x,z]of [[-17,-1],[15,8],[2,15],[-16,13]]){rows.push({x,z,w:1.9,d:.8,h:1.2});rows.push({x:x+2,z,w:1.5,d:.65,h:.7})}
 for(const [x,z]of PALMS)if(Math.abs(x)<29&&Math.abs(z)<26)rows.push({x,z,w:.4,d:.4,h:6});
 for(const x of [-6,-3.5,-1,1.5,4])rows.push({x,z:-9,w:.48,d:.48,h:3.2});
 return rows;
}
