import*as T from'three';import{mergeGeometries}from'three/addons/utils/BufferGeometryUtils.js';import{BUILDINGS,PALMS,MARKETS,COVERS,TERRACE_WALLS,PASSAGES,BARRIERS,DISTRICT_SCALE,districtHeight}from'./district-layout.js';
import{createGull}from'./district-birds21.js';import{addDistrictRoof}from'./district-roofs21.js';
export function addOriginalWorld(scene,map,renderer){const world=new T.Group();world.scale.set(DISTRICT_SCALE,1,DISTRICT_SCALE*0.7692307692307693);scene.add(world);const materials={},geos={box:new T.BoxGeometry(1,1,1),sphere:new T.SphereGeometry(1,12,10)},obstacles=[],clouds=[],birds=[],sceneStats={buildings:0,materialTextures:0},foliageReveal={focus:{value:new T.Vector3()},enabled:{value:0}};let water,seed=1831029;const clamp=T.MathUtils.clamp;function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}const range=(a,b)=>a+(b-a)*random();function groundHeight(x,z){return districtHeight(x,z)}
function texture(kind,color){
 const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d');g.fillStyle=color;g.fillRect(0,0,512,512);
 for(let i=0;i<16000;i++){const v=random()>.5?255:0;g.fillStyle=`rgba(${v},${v},${v},${range(.015,.075)})`;const s=range(.5,2.8);g.fillRect(random()*512,random()*512,s,s)}
 if(kind==='plaster'){
  for(let i=0;i<130;i++){g.fillStyle=`rgba(86,67,43,${range(.015,.065)})`;g.beginPath();g.ellipse(random()*512,random()*512,range(5,35),range(3,16),0,0,7);g.fill()}
  for(let i=0;i<18;i++){let x=random()*512,y=random()*512;g.strokeStyle='#3b302313';g.lineWidth=range(.5,1.4);g.beginPath();g.moveTo(x,y);for(let j=0;j<5;j++){x+=range(-9,9);y+=range(3,12);g.lineTo(x,y)}g.stroke()}
 }else if(kind==='stone'||kind==='paving'){
  const h=kind==='stone'?64:85,w=kind==='stone'?128:85;
  for(let r=0;r<512/h;r++)for(let col=-1;col<512/w+1;col++){let x=col*w+(r%2)*w*.5;g.fillStyle=`rgba(${random()>.5?'255,249,231':'74,64,50'},${range(.025,.13)})`;g.fillRect(x+2,r*h+2,w-4,h-4);g.strokeStyle='#4c4c3a29';g.lineWidth=2;g.strokeRect(x+1,r*h+1,w-2,h-2);g.strokeStyle='#fff8d635';g.strokeRect(x+3,r*h+3,w-6,h-6)}
 }else if(kind==='roof'){
  for(let y=0;y<512;y+=25)for(let x=-30;x<512;x+=50){const xx=x+(Math.floor(y/25)%2)*25;g.fillStyle=`rgba(75,30,15,${range(.1,.3)})`;g.fillRect(xx,y,48,23);const grad=g.createLinearGradient(xx,y,xx+48,y);grad.addColorStop(0,'#ea9c6722');grad.addColorStop(.5,'#ffd2a155');grad.addColorStop(1,'#52241066');g.fillStyle=grad;g.fillRect(xx+2,y+1,45,20)}
 }else if(kind==='wood'){
  for(let x=0;x<512;x+=45){g.strokeStyle='#20150c70';g.lineWidth=3;g.beginPath();g.moveTo(x,0);g.lineTo(x,512);g.stroke();for(let j=0;j<30;j++){g.strokeStyle='#d9aa6920';g.lineWidth=range(.5,2);g.beginPath();g.moveTo(x+random()*43,0);g.bezierCurveTo(x+range(0,45),170,x+range(0,45),330,x+range(0,45),512);g.stroke()}}
 }else if(kind==='tile'){
  g.fillStyle='#123e42';g.fillRect(0,0,512,512);for(let y=0;y<512;y+=64)for(let x=0;x<512;x+=64){g.strokeStyle='#d5c298';g.lineWidth=2;g.strokeRect(x+2,y+2,60,60);g.save();g.translate(x+32,y+32);g.rotate(Math.PI/4);g.strokeStyle='#7baba3';g.strokeRect(-16,-16,32,32);g.fillStyle='#d4ba7d';g.fillRect(-4,-4,8,8);g.restore()}
 }
 const tex=new T.CanvasTexture(c);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);tex.repeat.set(kind==='tile'?1:2,kind==='tile'?1:2);sceneStats.materialTextures++;return tex;
}
function mat(name,color,kind='plaster',extra={}){return materials[name]=new T.MeshStandardMaterial({color:0xffffff,map:texture(kind,color),roughness:.88,...extra})}
function solid(name,color,extra={}){return materials[name]=new T.MeshStandardMaterial({color,roughness:.72,...extra})}
function mesh(geo,ma,parent=world,x=0,y=0,z=0,rx=0,ry=0,rz=0){const m=new T.Mesh(geo,ma);m.position.set(x,y,z);m.rotation.set(rx,ry,rz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function box(parent,ma,x,y,z,w,h,d){const m=mesh(geos.box,ma,parent,x,y,z);m.scale.set(w,h,d);return m}
function capsule(parent,ma,x,y,z,w,h,d){const m=mesh(geos.capsule,ma,parent,x,y,z);m.scale.set(w*.5,h/3,d*.5);return m}
function cyl(parent,ma,x,y,z,r,h,segments=12,rTop=r){return mesh(new T.CylinderGeometry(rTop,r,h,segments),ma,parent,x,y,z)}
function sphere(parent,ma,x,y,z,r,sx=1,sy=1,sz=1){const m=mesh(geos.sphere,ma,parent,x,y,z);m.scale.set(r*sx,r*sy,r*sz);return m}
function beam(parent,ma,a,b,r=.05){const v=new T.Vector3().subVectors(b,a),m=mesh(new T.CylinderGeometry(r,r,v.length(),7),ma,parent);m.position.copy(a).add(b).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return m}
function archShape(w,h,border=.2){const sh=new T.Shape();sh.moveTo(-w/2,0);sh.lineTo(w/2,0);sh.lineTo(w/2,h-w*.5);sh.absarc(0,h-w*.5,w*.5,0,Math.PI,false);sh.lineTo(-w/2,0);if(border){const r=w/2-border,hole=new T.Path();hole.moveTo(-r,.02);hole.lineTo(-r,h-w*.5);hole.absarc(0,h-w*.5,r,Math.PI,0,true);hole.lineTo(r,.02);hole.closePath();sh.holes.push(hole)}return sh}
function arch(parent,ma,x,y,z,w,h,depth=.13,border=.17){return mesh(new T.ExtrudeGeometry(archShape(w,h,border),{depth,bevelEnabled:false,curveSegments:12}),ma,parent,x,y,z)}
function addObstacle(x,z,w,d,h=5){obstacles.push({minX:x-w/2-.45,maxX:x+w/2+.45,minZ:z-d/2-.45,maxZ:z+d/2+.45,h})}

function windowDetail(parent,x,y,z,w=1,h=1.5,fancy=false){
 box(parent,materials.dark,x,y+h/2,z,w,h,.045);box(parent,materials.wood,x-w*.27,y+h*.48,z+.045,w*.42,h*.88,.08);box(parent,materials.wood,x+w*.27,y+h*.48,z+.045,w*.42,h*.88,.08);
 for(const dx of [-1,1])box(parent,materials.trim,x+dx*(w/2+.07),y+h/2,z+.05,.11,h+.22,.13);
 box(parent,materials.trim,x,y+h+.055,z+.06,w+.25,.12,.18);box(parent,materials.trim,x,y-.03,z+.13,w+.35,.17,.37);
 for(let i=1;i<6;i++)box(parent,materials.woodLight,x,y+i*h/6,z+.11,w*.92,.025,.035);
 if(fancy){arch(parent,materials.trim,x,y-.05,z+.13,w+.4,h+.55,.12,.12);box(parent,materials.tile,x,y-.3,z+.15,w+.45,.24,.12)}
}
function facade(parent,width,height,depth,style=0){
 if(style===3){const wide=Math.min(width-1.2,4.4);box(parent,materials.dark,0,1.3,depth/2+.03,wide,2.6,.045);for(const side of[-1,1])box(parent,materials.wood,side*wide*.25,1.2,depth/2+.09,wide*.48,2.4,.08);arch(parent,materials.trim,0,0,depth/2+.15,wide+.4,3.1,.18,.18);for(let i=0;i<6;i++)box(parent,materials.iron,-wide*.42+i*wide*.168,1.2,depth/2+.14,.035,2.3,.04);box(parent,materials.tile,0,3.3,depth/2+.1,Math.min(width-.5,5),.24,.08);return}
 if(style===4){arch(parent,materials.trim,0,0,depth/2+.1,1.8,2.7,.22,.22);box(parent,materials.wood,0,1.1,depth/2+.08,1.2,2.2,.07);for(const side of[-1,1]){box(parent,materials.trim,side*(width*.35),height*.55,depth/2+.04,.5,1.4,.12);box(parent,materials.dark,side*(width*.35),height*.55,depth/2+.12,.15,.9,.04)}for(let y=.7;y<height-.4;y+=.65)box(parent,materials.stone,0,y,depth/2+.015,width,.045,.03);return}
 if(style===5){for(let i=0;i<7;i++){const w=(width-.6)/7;box(parent,i%2?materials.cloth:materials.canvas,-width/2+.3+w*(i+.5),2.65,depth/2+.62,w,.06,1.2);box(parent,i%2?materials.cloth:materials.canvas,-width/2+.3+w*(i+.5),2.44,depth/2+1.2,w,.4,.04)}}
 // Local +Z faces outward; all four facades are actually built.
 const floors=Math.max(1,Math.floor((height-2.5)/2.75)+1);
 for(let f=0;f<floors;f++){
  let yy=f*2.75+1.05;const count=Math.floor(width/2.4);
  for(let i=0;i<count;i++){const xx=(i-(count-1)/2)*2.35;if(f===0&&i===Math.floor(count/2)&&style!==2){box(parent,materials.dark,xx,1.1,depth/2+.025,1.25,2.2,.08);arch(parent,materials.trim,xx,.02,depth/2+.12,1.65,2.75,.15,.2);box(parent,materials.wood,xx,1.03,depth/2+.08,1.05,2.05,.06);for(let k=0;k<5;k++)box(parent,materials.woodLight,xx-.42+k*.21,1.02,depth/2+.13,.025,2,.015);sphere(parent,materials.brass,xx+.31,1.03,depth/2+.2,.055)}else windowDetail(parent,xx,yy,depth/2+.04,style===2?1.25:.9,style===2?1.35:1.45,style===1&&f===floors-1)}
  if(f>0){box(parent,materials.trim,0,f*2.75+.3,depth/2+.15,width+.18,.15,.28);if(style===1){const ww=Math.min(width-1,5);box(parent,materials.trim,0,f*2.75+.52,depth/2+.65,ww,.2,1.25);for(let i=0;i<Math.ceil(ww/.22);i++)box(parent,materials.iron,-ww/2+i*.22,f*2.75+1.05,depth/2+1.15,.035,1,.035);box(parent,materials.iron,0,f*2.75+1.5,depth/2+1.15,ww,.045,.045)}}
 }
 box(parent,materials.trim,0,height-.18,depth/2+.08,width+.15,.2,.25);box(parent,materials.tile,0,.45,depth/2+.04,width,.24,.045);
 for(const xx of [-width/2+.13,width/2-.13]){box(parent,materials.trim,xx,height/2,depth/2+.09,.23,height,.16);for(let y=.5;y<height;y+=.6)box(parent,materials.stone,xx,y,depth/2+.16,.31,.24,.14)}
}
function building(x,z,w,d,h,style=0,color=materials.sand){
 sceneStats.buildings++;const g=new T.Group();world.add(g);g.position.set(x,0,z);addObstacle(x,z,w,d,h);
 // Four walls, floor and solid ceiling; never a single floating facade.
 box(g,materials.stone,0,.18,0,w+.36,.36,d+.36);box(g,color,0,h/2,-d/2+.13,w,h,.26);box(g,color,0,h/2,d/2-.13,w,h,.26);box(g,color,-w/2+.13,h/2,0,.26,h,d);box(g,color,w/2-.13,h/2,0,.26,h,d);
 box(g,materials.paving,0,h-.15,0,w,.3,d);
 for(let j=0;j<4;j++){const f=new T.Group();g.add(f);f.rotation.y=j*Math.PI/2;facade(f,j%2?d:w,h,j%2?w:d,style)}
 addDistrictRoof(g,{w,d,h,style,m:materials});
 return g;
}
function palm(x,z,h=6){
 const g=new T.Group();world.add(g);g.position.set(x,0,z);
 const curve=new T.CatmullRomCurve3([new T.Vector3(),new T.Vector3(.12,h*.35,.1),new T.Vector3(.4,h*.72,.1),new T.Vector3(.7,h,0)]);mesh(new T.TubeGeometry(curve,12,.18,7,false),materials.trunk,g);
 for(let i=0;i<11;i++){const y=i*h/11;const m=mesh(new T.TorusGeometry(.19-y*.006,.025,4,8),materials.trunkLight,g,.7*(y/h)**2,y,0,Math.PI/2);}
 for(let j=0;j<9;j++){
  const a=j*Math.PI*2/9,verts=[],idx=[];for(let k=0;k<=12;k++){const s=k/12,r=s*3.6,yy=h+Math.sin(s*Math.PI)*.9-s*s*1.4,w=Math.sin(s*Math.PI)*.43;const cx=.7+Math.cos(a)*r,cz=Math.sin(a)*r;verts.push(cx+Math.sin(a)*w,yy,cz-Math.cos(a)*w,cx-Math.sin(a)*w,yy,cz+Math.cos(a)*w);if(k<12){let q=k*2;idx.push(q,q+1,q+2,q+1,q+3,q+2)}}
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(verts,3));geo.setIndex(idx);geo.computeVertexNormals();mesh(geo,j%2?materials.leaf:materials.foliage,g);
  for(let k=2;k<10;k++){const s=k/12,r=s*3.6;for(const side of [-1,1]){const a1=new T.Vector3(.7+Math.cos(a)*r,h+Math.sin(s*Math.PI)*.9-s*s*1.4,Math.sin(a)*r),a2=a1.clone().add(new T.Vector3(Math.cos(a)*.25+Math.sin(a)*side*.5,-.1,Math.sin(a)*.25-Math.cos(a)*side*.5));beam(g,materials.leaf,a1,a2,.018)}}
 }
 cyl(g,materials.stone,0,.05,0,1.05,.1,16);return g;
}
function crate(x,z,w=1.2){const g=new T.Group();world.add(g);g.position.set(x,groundHeight(x,z),z);box(g,materials.wood,0,w/2,0,w,w,w);for(const y of [.13,w-.13]){box(g,materials.woodLight,0,y,w/2+.025,w,.14,.06);box(g,materials.woodLight,0,y,-w/2-.025,w,.14,.06)}for(const xx of [-w/2+.1,w/2-.1])box(g,materials.woodLight,xx,w/2,w/2+.06,.14,w,.09);const diagonal=box(g,materials.woodLight,0,w/2,w/2+.08,.1,w*1.15,.07);diagonal.rotation.z=-.7;addObstacle(x,z,w,w,w);return g}
function lamp(x,z,h=3.7){cyl(world,materials.iron,x,h/2,z,.055,h,8);box(world,materials.iron,x,h,z,.55,.07,.55);box(world,materials.glass,x,h-.3,z,.3,.5,.3);for(const dx of [-.18,.18])for(const dz of [-.18,.18])box(world,materials.iron,x+dx,h-.3,z+dz,.035,.55,.035);mesh(new T.ConeGeometry(.48,.25,4),materials.brass,world,x,h+.15,z,0,Math.PI/4);}
function market(x,z){const g=new T.Group();world.add(g);g.position.set(x,0,z);for(const xx of [-1.7,1.7])for(const zz of [-1.15,1.15])cyl(g,materials.wood,xx,1.5,zz,.055,3,7);for(let i=0;i<9;i++){const m=box(g,i%2?materials.cloth:materials.canvas,-1.6+i*.4,2.9,0,.4,.08,2.75);m.rotation.x=.13;box(g,i%2?materials.cloth:materials.canvas,-1.6+i*.4,2.6,1.35,.4,.42,.07)}box(g,materials.wood,0,.9,.2,3.2,.15,1.6);for(let i=0;i<7;i++){box(g,materials.woodLight,-1.2+i*.4,1.1,.2,.35,.24,.7);for(let j=0;j<5;j++)sphere(g,i%2?materials.fruit:materials.flower,-1.2+i*.4+range(-.12,.12),1.25,.2+range(-.2,.2),.08)}addObstacle(x,z,3.8,2.6,3);}
function makeTerrain(){
 const geo=new T.PlaneGeometry(220,220,100,100);geo.rotateX(-Math.PI/2);const p=geo.attributes.position;for(let i=0;i<p.count;i++){let x=p.getX(i),z=p.getZ(i),height=-.12;if(x<-32)height=-.12-(-x-32)*.18;else if(Math.abs(x)>35||Math.abs(z)>31)height=-.15+Math.sin(x*.09+z*.04)*Math.cos(z*.12)*.55;p.setY(i,height)}geo.computeVertexNormals();mesh(geo,materials.sandGround,world);
 box(world,materials.paving,0,-.01,0,58,.12,52);
 // Dusty street surfaces separate long lane, mid and market from the raised plaza.
 for(const points of[[[-18,-23],[-14.9,-23],[-14.9,19],[-18,19]],[[11.8,-18],[17.2,-18],[17.2,18],[12,18]],[[ -18,-15.1],[17.3,-15.1],[17.3,-11.1],[-18,-11.1]]]){const shape=new T.Shape();shape.moveTo(points[0][0],-points[0][1]);for(const p of points.slice(1))shape.lineTo(p[0],-p[1]);shape.closePath();const geo=new T.ShapeGeometry(shape);geo.rotateX(-Math.PI/2);mesh(geo,materials.street,world,0,.056,0)}
box(world,materials.stone,-29,.16,0,.7,.5,52);
 for(let i=0;i<23;i++){box(world,materials.stone,-30.1,.13,-25+i*2.2,1.4,.3,1.9)}
 // Slightly raised central square with layered edging, mosaic and inlaid paths.
 box(world,materials.stone,-3,.12,1,17,.2,14);box(world,materials.paving,-3,.24,1,16.7,.12,13.7);
 for(const z of [-5.55,7.55])box(world,materials.tile,-3,.31,z,16.7,.025,.45);
 for(const x of [-11.15,5.15])box(world,materials.tile,x,.31,1,.45,.025,13.2);
 for(let i=0;i<16;i++)for(let j=0;j<12;j++)if((i+j)%2===0)box(world,materials.inlay,-10.5+i,.311,-4.5+j,.3,.012,.3);
 for(const [x,z]of [[-28,-23],[-28,23],[25,24],[25,-24]]){box(world,materials.iron,x,.015,z,1,.025,.55);for(let k=0;k<6;k++)box(world,materials.trim,x-.4+k*.16,.04,z,.04,.03,.5)}
}
function makeWater(){
 const geo=new T.PlaneGeometry(160,240,1,1);geo.rotateX(-Math.PI/2);
 water=mesh(geo,new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uTime:{value:0},uSun:{value:new T.Vector3(-.6,.8,-.4)},uOpacity:{value:.94}},vertexShader:`varying vec3 vWorld;void main(){vec4 w=modelMatrix*vec4(position,1.);vWorld=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,fragmentShader:`precision highp float;uniform float uTime;uniform vec3 uSun;uniform float uOpacity;varying vec3 vWorld;
 float wave(vec2 p){return sin(p.x*.9+p.y*.55+uTime*1.15)*.11+sin(p.x*.31-p.y*.7+uTime*.8)*.08+sin(p.x*1.7+p.y*.4-uTime*.7)*.04;}
 void main(){vec2 p=vWorld.xz/1.4;float w=wave(p),wx=wave(p+vec2(.12,0.)),wz=wave(p+vec2(0.,.12));vec3 n=normalize(vec3((w-wx)*2.2,1.,(w-wz)*2.2));vec3 v=normalize(cameraPosition-vWorld);float fres=pow(1.-max(dot(n,v),0.),3.);float depth=smoothstep(-32.,-51.,p.x);vec3 col=mix(vec3(.32,.67,.64),vec3(.055,.29,.37),depth);col=mix(col,vec3(.73,.82,.77),fres*.65);vec3 h=normalize(v+uSun);float spec=pow(max(dot(n,h),0.),140.);col+=spec*vec3(1.,.87,.61)*.36;float stripe=sin(p.x*.85+sin(p.y*.17)*.5+uTime*1.5);float shore=(1.-smoothstep(-35.,-31.2,p.x))*smoothstep(-40.,-32.,p.x);float foam=smoothstep(.84,1.,stripe)*shore;col=mix(col,vec3(.85,.9,.78),foam*.64);col+=pow(max(w+.05,0.),3.)*.07;gl_FragColor=vec4(col,uOpacity);}`}),world,-99,-.14,0);water.receiveShadow=false;water.castShadow=false;water.renderOrder=1;
 for(let i=0;i<30;i++){const x=range(-45,-32),z=range(-45,45);sphere(world,materials.rock,x,-.48,z,range(.5,1.5),1,range(.45,.9),1.3)}
}
function makeFountain(){
 const x=-4,z=1;for(const [r,h,y]of [[2.3,.22,.38],[2.1,.4,.55],[1.85,.15,.72]])cyl(world,materials.trim,x,y,z,r,h,32);
 cyl(world,materials.tile,x,.79,z,1.75,.03,32);const pool=cyl(world,materials.poolWater,x,.83,z,1.7,.03,32);pool.castShadow=false;
 cyl(world,materials.trim,x,1.25,z,.22,.9,12);cyl(world,materials.trim,x,1.65,z,.95,.18,24);cyl(world,materials.brass,x,1.9,z,.12,.5,12);sphere(world,materials.brass,x,2.2,z,.18);
 for(let i=0;i<8;i++){const a=i*Math.PI/4;const curve=new T.CatmullRomCurve3([new T.Vector3(x,2.05,z),new T.Vector3(x+Math.cos(a)*.5,2.3,z+Math.sin(a)*.5),new T.Vector3(x+Math.cos(a)*1.2,.9,z+Math.sin(a)*1.2)]);const m=mesh(new T.TubeGeometry(curve,12,.018,5),materials.poolWater,world);m.castShadow=false}
 addObstacle(x,z,4.7,4.7,2);
}
function makeLandmark(){
 // Open colonnade, independent silhouette and spatial composition.
 const g=new T.Group();world.add(g);g.position.set(-1,0,-9);
 for(const x of [-5,-2.5,0,2.5,5]){cyl(g,materials.stone,x,1.6,0,.23,3.2,12);cyl(g,materials.trim,x,.22,0,.35,.3,12);cyl(g,materials.trim,x,3.15,0,.36,.3,12);}
 for(let i=0;i<4;i++)arch(g,materials.trim,-3.75+i*2.5,1.6,0,2.5,2,.5,.2);
 box(g,materials.sand,0,3.8,.25,10.5,.55,.85);box(g,materials.tile,0,3.72,.72,10.5,.28,.03);box(g,materials.trim,0,4.14,.25,10.9,.18,1);
 const tower=building(-13,-9,4.4,4.4,10,1,materials.peach);
 const dome=mesh(new T.SphereGeometry(2.0,24,14,0,Math.PI*2,0,Math.PI/2),materials.dome,tower,0,11.15,0);cyl(tower,materials.tile,0,11.1,0,2,.25,24);cyl(tower,materials.brass,0,13.3,0,.045,.65,8);sphere(tower,materials.brass,0,13.65,0,.14);
 for(let i=0;i<4;i++){const a=i*Math.PI/2;box(tower,materials.cream,Math.sin(a)*1.6,10.8,Math.cos(a)*1.6,.35,.8,.35)}
}
function makeSet(){
 makeTerrain();makeWater();
 const defs=BUILDINGS;
 for(const [x,z,w,d,h,st,co]of defs)building(x,z,w,d,h,st,materials[co]);
 makeLandmark();makeFountain();
 for(const [x,z,h]of PALMS)palm(x,z,h);
 for(const [x,z]of COVERS){crate(x,z,1.3);crate(x+1.5,z,.95)}
 for(const [x,z]of MARKETS)market(x,z);
 addTerrace();
 for(const [x,z,w,d,h]of BARRIERS){box(world,materials.sand,x,h/2,z,w,h,d);box(world,materials.trim,x,h+.05,z,w+.12,.1,d+.12)}
 for(const p of PASSAGES){const g=new T.Group();world.add(g);g.position.set(p.x,0,p.z);for(const side of[-1,1]){box(g,materials.sand,0,p.height/2,side*p.width/2,p.length,p.height,.25);box(g,materials.trim,0,.22,side*(p.width/2-.15),p.length,.35,.16)}box(g,materials.stone,0,p.height+.08,0,p.length,.2,p.width+.3);for(const x of[-p.length/2,p.length/2]){const portal=new T.Group();portal.position.x=x;portal.rotation.y=Math.PI/2;g.add(portal);arch(portal,materials.trim,0,0,0,p.width-.25,p.height-.1,.3,.2)}for(let x=-p.length/2+1;x<p.length/2;x+=2){const rib=new T.Group();rib.position.x=x;rib.rotation.y=Math.PI/2;g.add(rib);arch(rib,materials.stone,0,0,0,p.width-.25,p.height-.1,.15,.12)}}
 for(const [x,z]of [[-17,4],[-16,-14],[14,-15],[15,14],[-10,15],[3,13],[16,4],[-27,-25]])lamp(x,z);
 // Quayside steps, bollards, small original mooring boat and rope details.
 for(let i=0;i<5;i++)box(world,materials.stone,-30.1-i*.65,-.08-i*.09,11,1,.2,5);
 for(let z=-23;z<24;z+=5)cyl(world,materials.iron,-30.3,.36,z,.13,.55,8);
 const boat=new T.Group();world.add(boat);boat.position.set(-35,-.05,12);const hull=new T.Shape();hull.moveTo(-.8,-2.5);hull.quadraticCurveTo(-1.5,0,0,3.1);hull.quadraticCurveTo(1.5,0,.8,-2.5);hull.closePath();const hg=new T.ExtrudeGeometry(hull,{depth:.5,bevelEnabled:true,bevelSize:.14,bevelThickness:.14,bevelSegments:2});hg.rotateX(-Math.PI/2);mesh(hg,materials.boat,boat);box(boat,materials.wood,0,.5,0,1.5,.15,2.7);for(let i=0;i<3;i++)box(boat,materials.trim,0,.65,-1+i,1.5,.1,.25);beam(world,materials.rope,new T.Vector3(-34.3,.5,10),new T.Vector3(-30.3,.6,9),.025);
 // Planter beds, ceramic urns, sacks, street seating and pipes enrich close views.
 for(const [x,z]of [[-17,-1],[15,8],[2,15],[-16,13]]){box(world,materials.trim,x,.32,z,1.9,.55,.8);for(let j=0;j<8;j++)sphere(world,j%3?materials.foliage:materials.flower,x+range(-.8,.8),.9+range(0,.3),z+range(-.25,.25),.34);box(world,materials.wood,x+2,.6,z,1.5,.15,.65);for(const dx of [-.5,.5])box(world,materials.iron,x+2+dx,.3,z,.12,.6,.5)}
 for(const [x,z]of [[-19,1],[17,-7],[-13,15],[2,-16]]){const points=[new T.Vector2(0,0),new T.Vector2(.3,0),new T.Vector2(.5,.35),new T.Vector2(.46,.75),new T.Vector2(.22,.95),new T.Vector2(.2,1.1)];mesh(new T.LatheGeometry(points,14),materials.terracotta,world,x,0,z);cyl(world,materials.dark,x,1.08,z,.15,.04,14);addObstacle(x,z,.9,.9,1)}
 // Site inlays are authored geometry, not imported radar imagery.
 for(const [x,z,letter,co]of [[6,5,'A','#da9e57'],[-13,-3,'B','#69a9b3']]){
  const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.strokeStyle=co;g.lineWidth=6;g.strokeRect(12,12,232,232);g.fillStyle=co;g.font='bold 160px sans-serif';g.textAlign='center';g.fillText(letter,128,185);const tx=new T.CanvasTexture(c);tx.colorSpace=T.SRGBColorSpace;const ma=new T.MeshBasicMaterial({map:tx,transparent:true,opacity:.65,depthWrite:false});mesh(new T.PlaneGeometry(3.7,3.7),ma,world,x,groundHeight(x,z)+.012,z,-Math.PI/2);}
 makeAtmosphere();bakeStatic();
}
function addTerrace(){
 box(world,materials.stone,8.2,.59,5,5.6,1.08,6);box(world,materials.paving,8.2,1.137,5,5.6,.025,6);
 for(let i=0;i<6;i++){const h=1.08-(i+1)*.18;if(h>0){box(world,materials.stone,8.2,.05+h/2,8.3+i*.6,5.6,h,.6);box(world,materials.trim,8.2,.05+h+.008,8.56+i*.6,5.6,.018,.07);box(world,materials.stone,11.25+i*.5,.05+h/2,4.75,.5,h,2.5);box(world,materials.trim,11.46+i*.5,.05+h+.008,4.75,.06,.018,2.5)}}
 for(const [x,z,w,d,h]of TERRACE_WALLS){box(world,materials.sand,x,h/2,z,w,h,d);box(world,materials.trim,x,h+.045,z,w+.12,.09,d+.12);addObstacle(x,z,w,d,h)}
}
function smoothRoute(start,path){const result=[];let from=start,index=0;while(index<path.length){let far=path.length-1;while(far>index&&!lineClear(from,path[far]))far--;result.push(path[far]);from=path[far];index=far+1}return result}
function bakeStatic(){
 world.updateMatrixWorld(true);const bins=new Map(),remove=[];
 world.traverse(o=>{if(!o.isMesh||o===water||o.material.transparent||Array.isArray(o.material))return;const key=o.material.uuid;let geo=o.geometry.clone();geo.applyMatrix4(o.matrixWorld);if(!geo.attributes.uv)geo.setAttribute('uv',new T.BufferAttribute(new Float32Array(geo.attributes.position.count*2),2));if(o.material.map){const p=geo.attributes.position,n=geo.attributes.normal,uv=geo.attributes.uv;for(let i=0;i<p.count;i++){if(Math.abs(n.getY(i))>.6)uv.setXY(i,p.getX(i)*.25,p.getZ(i)*.25);else uv.setXY(i,(Math.abs(n.getX(i))>.6?p.getZ(i):p.getX(i))*.25,p.getY(i)*.25)}}if(geo.index)geo=geo.toNonIndexed();geo.deleteAttribute('uv1');if(!geo.attributes.uv){geo.setAttribute('uv',new T.BufferAttribute(new Float32Array(geo.attributes.position.count*2),2))}if(!bins.has(key))bins.set(key,{material:o.material,geos:[]});bins.get(key).geos.push(geo);remove.push(o)});
 for(const o of remove)o.parent.remove(o);
 for(const {material,geos:gs}of bins.values()){const geo=mergeGeometries(gs,false);if(!geo)throw Error('Geometry merge failed');const m=new T.Mesh(geo,material);m.castShadow=true;m.receiveShadow=true;scene.add(m);gs.forEach(g=>g.dispose())}
 sceneStats.staticBatches=bins.size;
}
function makeAtmosphere(){
 const cloudMat=new T.MeshBasicMaterial({color:0xfff3d7,transparent:true,opacity:.08,depthWrite:false});
 for(let i=0;i<12;i++){const g=new T.Group();scene.add(g);g.position.set(range(-110,110),range(28,40),range(-135,-95));for(let j=0;j<4;j++){const m=sphere(g,cloudMat,j*4,range(-1,1),range(-2,2),range(3,6),1.8,.3,1);m.castShadow=false}clouds.push(g)}
 for(let i=0;i<9;i++){const gull=createGull(i);scene.add(gull.root);birds.push({...gull,angle:range(0,7),r:range(17,29),height:range(10,17),speed:range(.04,.08)})}
}
function enableCanopyReveal(){
 for(const material of [materials.foliage,materials.leaf]){
  material.transparent=true;material.depthWrite=false;
  material.onBeforeCompile=shader=>{shader.uniforms.uOperatorFocus=foliageReveal.focus;shader.uniforms.uOperatorReveal=foliageReveal.enabled;shader.vertexShader='varying vec3 vCanopyWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\nvCanopyWorld=(modelMatrix*vec4(transformed,1.0)).xyz;');shader.fragmentShader='uniform vec3 uOperatorFocus;uniform float uOperatorReveal;varying vec3 vCanopyWorld;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <alphatest_fragment>',`vec3 sight=uOperatorFocus-cameraPosition;float sightLength=max(dot(sight,sight),0.001);float along=dot(vCanopyWorld-cameraPosition,sight)/sightLength;float nearSight=length(vCanopyWorld-cameraPosition-sight*clamp(along,0.0,1.0));float reveal=(1.0-smoothstep(0.6,1.6,nearSight))*step(0.0,along)*step(along,0.99)*uOperatorReveal;diffuseColor.a*=1.0-reveal*0.9;\n#include <alphatest_fragment>`)};
  material.customProgramCacheKey=()=> 'arena-original-canopy-reveal-19';material.needsUpdate=true;
 }
}


 mat('sand','#ccad7f');mat('cream','#e6d7b8');mat('peach','#c59779');mat('trim','#e4d9bf','stone');mat('stone','#b2a48b','stone');mat('paving','#bdad91','paving');mat('sandGround','#c6b28b');mat('street','#9f9985','stone');mat('tile','#18474b','tile');mat('roof','#b65d39','roof');mat('wood','#6e5540','wood');mat('woodLight','#a58b5d','wood');mat('trunk','#756245','wood');
 solid('trunkLight',0x927b50);solid('foliage',0x516d41,{side:T.DoubleSide});solid('leaf',0x7c914d,{side:T.DoubleSide});solid('flower',0xb28c73);solid('fruit',0xd99543);solid('iron',0x354345,{metalness:.55,roughness:.4});solid('dark',0x253b3a);solid('brass',0xbda365,{metalness:.7,roughness:.35});solid('terracotta',0xa96c46);solid('ceramic',0xc4b59a);solid('cloth',0x2e6a68);solid('canvas',0xd7c393);solid('glass',0xf1c489,{emissive:0xeab878,emissiveIntensity:.3});solid('dome',0x547e76,{metalness:.35,roughness:.4});solid('inlay',0x71847a);solid('rock',0x918b72);solid('boat',0x365b60);solid('rope',0xa29776);solid('poolWater',0x519d9c,{metalness:.3,roughness:.17,transparent:true,opacity:.8});

makeSet();enableCanopyReveal();
// Focused observer cutaway: retain the district, reveal only the sight corridor
// between camera and selected actor so rooftops cannot cover the animation.
for(const material of Object.values(materials)){
 if(material.transparent||!material.isMeshStandardMaterial)continue;
 material.onBeforeCompile=shader=>{shader.uniforms.uActorFocus=foliageReveal.focus;shader.uniforms.uActorReveal=foliageReveal.enabled;shader.vertexShader='varying vec3 vDistrictWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\nvDistrictWorld=(modelMatrix*vec4(transformed,1.0)).xyz;');shader.fragmentShader='uniform vec3 uActorFocus;uniform float uActorReveal;varying vec3 vDistrictWorld;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <alphatest_fragment>',`vec3 sight=uActorFocus-cameraPosition;float along=dot(vDistrictWorld-cameraPosition,sight)/max(dot(sight,sight),0.001);float gap=length(vDistrictWorld-cameraPosition-sight*clamp(along,0.0,1.0));if(uActorReveal>0.5&&along>0.0&&along<0.99&&gap<1.35&&vDistrictWorld.y>uActorFocus.y-0.75)discard;\n#include <alphatest_fragment>`)};
 material.customProgramCacheKey=()=> 'arena-original-focused-cutaway20';material.needsUpdate=true;
}
let disposed=false;return{ready:true,progress:1,error:null,clipHeight:1000,sourceHash:'arena-original-district21',sourceTriangles:0,sourceCaptures:0,cacheMode:'original-procedural',districtCount:sceneStats.buildings,gullCount:birds.length,gullAnatomy:birds[0]?.anatomy,roofStyle:'parapet-coping,gable-tiles,ridge-caps,gutters,roof-access',wallSolids:sceneStats.buildings,seamlessGround:true,groundSource:'arena-original-district21',environment:{weather:'coastal-desert',districtBuildings:sceneStats.buildings},setRoofMode(){},setLevel(level,actor){foliageReveal.enabled.value=actor?1:0;if(actor)foliageReveal.focus.value.set(actor.x-map.width/2,(actor.y||0)+1.1,actor.z-map.height/2)},updateProps(){},invalidate(){},render(camera,now){if(disposed)return;const t=now/1000;water.material.uniforms.uTime.value=t;for(const b of birds){const a=b.angle+t*b.speed;b.root.position.set((-19+Math.cos(a)*b.r)*DISTRICT_SCALE,b.height+Math.sin(a*2),Math.sin(a)*b.r*0.7692307692307693*DISTRICT_SCALE);b.root.rotation.y=-a;b.pose(t)}for(let i=0;i<clouds.length;i++)clouds[i].position.x=((clouds[i].userData.originX??=clouds[i].position.x)+t*(.12+i*.008)+120)%240-120;renderer.render(scene,camera)},dispose(){disposed=true}}}
