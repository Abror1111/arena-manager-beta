import * as T from 'three';
import {mergeStaticMeshes} from './mesh-utils.js';
// Original geometry recreations; UI silhouettes separately use genuine CS2 SVGs.
export function createEquipment(kind='c4',{incendiary=false}={}){
 const root=new T.Group();root.name='equipment-'+kind;const materials=[],geometries=[],textures=[];
 const mat=(color,extra={})=>{const m=new T.MeshStandardMaterial({color,roughness:.65,...extra});materials.push(m);return m;};
 const dark=mat('#252b2b'),steel=mat('#a4aba5',{metalness:.72,roughness:.32}),olive=mat('#65734a'),tan=mat('#b8a87c'),red=mat('#ad3028');
 const add=(geo,m,x=0,y=0,z=0)=>{geometries.push(geo);const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;root.add(o);return o;};
 const box=(x,y,z,w,h,d,m)=>add(new T.BoxGeometry(w,h,d),m,x,y,z);
 const cyl=(x,y,z,r,h,m,r2=r)=>add(new T.CylinderGeometry(r2,r,h,12),m,x,y,z);
 const ring=(x,y,z,r)=>{const o=add(new T.TorusGeometry(r,.006,4,14),steel,x,y,z);return o;};
 let led=null,lcd=null,context=null,lastText='',lastBlink=false;
 if(kind==='c4'){
  for(const x of[-.145,.145])for(const z of[-.115,.115])box(x,.08,z,.26,.14,.205,tan);
  for(const z of[-.11,.11])box(0,.085,z,.555,.155,.035,dark);
  box(0,.17,0,.235,.095,.3,dark);box(0,.221,-.085,.2,.008,.09,steel);
  const canvas=globalThis.document?.createElement('canvas');if(canvas){canvas.width=256;canvas.height=96;context=canvas.getContext('2d');if(context){lcd=new T.CanvasTexture(canvas);lcd.colorSpace=T.SRGBColorSpace;textures.push(lcd);}}
  const screenMat=mat('#ffffff',{map:lcd,emissive:'#527c35',emissiveMap:lcd,emissiveIntensity:.65,roughness:.3});const screen=add(new T.PlaneGeometry(.175,.065),screenMat,0,.227,-.085);screen.rotation.x=-Math.PI/2;
  const keyMat=mat('#b8b9a7'),enterMat=mat('#ad594b');for(let row=0;row<4;row++)for(let col=0;col<3;col++)box((col-1)*.051,.224,.005+row*.043,.039,.018,.03,row===3&&col===2?enterMat:keyMat);
  for(const [color,x,z]of[['#bd3535',-.09,-.18],['#dfc846',.03,-.19],['#47798e',.1,-.17]]){
   const points=[new T.Vector3(x,.17,z),new T.Vector3(x-.06,.27,z-.06),new T.Vector3(x+.1,.28,z-.09),new T.Vector3(.15,.12,-.11)];add(new T.TubeGeometry(new T.CatmullRomCurve3(points),12,.008,4,false),mat(color));
  }
  box(.244,.095,0,.028,.085,.35,dark);box(-.244,.095,0,.028,.085,.35,dark);
  const ledMat=new T.MeshBasicMaterial({color:'#ff352a'});materials.push(ledMat);led=add(new T.SphereGeometry(.018,8,6),ledMat,.09,.23,-.085);
 }else if(kind==='he'){
  const body=add(new T.SphereGeometry(.092,12,9),olive);body.scale.y=1.22;
  for(const y of[-.055,0,.055]){const band=add(new T.TorusGeometry(Math.sqrt(.092**2-(y*.7)**2),.006,3,12),dark,0,y,0);band.rotation.x=Math.PI/2;}
  cyl(0,.115,0,.042,.04,dark);box(.045,.11,0,.025,.12,.03,steel);ring(-.045,.14,0,.035);
 }else if(kind==='fire'&&!incendiary){
  const glass=mat('#5a6131',{roughness:.25,metalness:.08});cyl(0,-.01,0,.068,.24,glass);cyl(0,.14,0,.032,.075,glass,.02);cyl(0,.205,0,.021,.08,glass);box(0,-.025,.068,.091,.115,.003,tan);const cloth=box(.016,.25,0,.028,.1,.027,mat('#c3b48c'));cloth.rotation.z=-.4;
 }else{
  const flash=kind==='flash',fire=kind==='fire',bodyMat=mat(flash?'#a9b0a7':fire?'#a3633c':'#719073',{metalness:.35,roughness:.42});cyl(0,0,0,.066,.245,bodyMat);cyl(0,.14,0,.064,.042,dark);cyl(0,-.13,0,.066,.026,dark);
  for(const y of[-.08,.075])cyl(0,y,0,.068,.024,flash?dark:fire?red:tan);
  if(flash)for(const y of[-.04,.018])for(let a=0;a<8;a++){const hole=box(Math.sin(a*Math.PI/4)*.065,y,Math.cos(a*Math.PI/4)*.065,.012,.018,.008,dark);hole.rotation.y=a*Math.PI/4;}
  else box(0,0,.067,.06,.085,.003,mat('#d5cba7'));
  box(.049,.12,0,.02,.13,.035,steel);ring(-.05,.16,0,.031);
 }
 if(led)root.remove(led);mergeStaticMeshes(root,true);if(led)root.add(led);
 function update(timer=40,active=false,progress=0,defused=false){const text=defused?'SAFE':active?Math.max(0,timer).toFixed(1).padStart(4,'0'):progress>0?'ARMING':'7355608';if(context&&text!==lastText){lastText=text;context.fillStyle='#263823';context.fillRect(0,0,256,96);context.fillStyle='#b8cf85';context.font='bold 45px monospace';context.textAlign='center';context.fillText(text,128,64);lcd.needsUpdate=true;}if(led){const blink=active&&(Math.floor(timer*(timer<10?6:2))%2===0);if(blink!==lastBlink){led.visible=blink;lastBlink=blink;}}}
 update();if(led)led.visible=false;
 return{root,update,dispose(){root.removeFromParent();const gs=new Set(geometries),ms=new Set(materials);root.traverse(o=>{if(o.geometry)gs.add(o.geometry);if(o.material)ms.add(o.material);});gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());}};
}
