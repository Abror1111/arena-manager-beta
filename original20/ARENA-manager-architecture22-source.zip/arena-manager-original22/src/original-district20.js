import*as T from'three';import{mergeGeometries}from'three/addons/utils/BufferGeometryUtils.js';import{WIDTH,DEPTH,BUILDINGS,OUTSKIRTS,ROOM,TUNNEL_FLOORS,TUNNEL_WALLS,ROOM_WALLS,SITE_WALLS,MID_WALLS,PERIMETER_WALLS,COVERS,PALMS,LAMPS,MARKET_STALLS,districtHeight22}from'./district-layout22.js';
import{createGull}from'./district-birds21.js';import{addDistrictRoof}from'./district-roofs21.js';
export function addOriginalWorld(scene,map,renderer){const world=new T.Group();world.scale.set(1,1,1);scene.add(world);const materials={},geos={box:new T.BoxGeometry(1,1,1),sphere:new T.SphereGeometry(1,12,10)},obstacles=[],clouds=[],birds=[],sceneStats={buildings:0,materialTextures:0},foliageReveal={focus:{value:new T.Vector3()},enabled:{value:0}};const roofMeshes=[];let roofMode='original';let water,seed=1831029;const clamp=T.MathUtils.clamp;function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}const range=(a,b)=>a+(b-a)*random();function groundHeight(x,z){return districtHeight22(x,z)}
function texture(kind,color){
 const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d');g.fillStyle=color;g.fillRect(0,0,512,512);
 for(let i=0;i<16000;i++){const v=random()>.5?255:0;g.fillStyle=`rgba(${v},${v},${v},${range(.015,.075)})`;const s=range(.5,2.8);g.fillRect(random()*512,random()*512,s,s)}
 if(kind==='plaster'){
  for(let i=0;i<130;i++){g.fillStyle=`rgba(86,67,43,${range(.015,.065)})`;g.beginPath();g.ellipse(random()*512,random()*512,range(5,35),range(3,16),0,0,7);g.fill()}
  for(let i=0;i<18;i++){let x=random()*512,y=random()*512;g.strokeStyle='#3b302313';g.lineWidth=range(.5,1.4);g.beginPath();g.moveTo(x,y);for(let j=0;j<5;j++){x+=range(-9,9);y+=range(3,12);g.lineTo(x,y)}g.stroke()}
 }else if(kind==='stone'||kind==='paving'){
  const h=kind==='stone'?64:85,w=kind==='stone'?128:85;
  for(let r=0;r<512/h;r++)for(let col=-1;col<512/w+1;col++){let x=col*w+(r%2)*w*.5;g.fillStyle=`rgba(${random()>.5?'255,249,231':'74,64,50'},${range(.025,.13)})`;g.fillRect(x+2,r*h+2,w-4,h-4);g.strokeStyle='#4c4c3a29';g.lineWidth=2;g.strokeRect(x+1,r*h+1,w-2,h-2);g.strokeStyle='#fff8d635';g.strokeRect(x+3,r*h+3,w-6,h-6)}
 }else if(kind==='asphalt'){for(let j=0;j<45;j++){g.strokeStyle='#302a2110';g.lineWidth=range(.4,1.1);let x=random()*512,y=random()*512;g.beginPath();g.moveTo(x,y);for(let k=0;k<5;k++){x+=range(-9,9);y+=range(3,13);g.lineTo(x,y)}g.stroke()}
 }else if(kind==='roof'){
  for(let y=0;y<512;y+=25)for(let x=-30;x<512;x+=50){const xx=x+(Math.floor(y/25)%2)*25;g.fillStyle=`rgba(75,30,15,${range(.1,.3)})`;g.fillRect(xx,y,48,23);const grad=g.createLinearGradient(xx,y,xx+48,y);grad.addColorStop(0,'#ea9c6722');grad.addColorStop(.5,'#ffd2a155');grad.addColorStop(1,'#52241066');g.fillStyle=grad;g.fillRect(xx+2,y+1,45,20)}
 }else if(kind==='wood'){
  for(let x=0;x<512;x+=45){g.strokeStyle='#20150c70';g.lineWidth=3;g.beginPath();g.moveTo(x,0);g.lineTo(x,512);g.stroke();for(let j=0;j<30;j++){g.strokeStyle='#d9aa6920';g.lineWidth=range(.5,2);g.beginPath();g.moveTo(x+random()*43,0);g.bezierCurveTo(x+range(0,45),170,x+range(0,45),330,x+range(0,45),512);g.stroke()}}
 }else if(kind==='tile'){
  g.fillStyle='#123e42';g.fillRect(0,0,512,512);for(let y=0;y<512;y+=64)for(let x=0;x<512;x+=64){g.strokeStyle='#d5c298';g.lineWidth=2;g.strokeRect(x+2,y+2,60,60);g.save();g.translate(x+32,y+32);g.rotate(Math.PI/4);g.strokeStyle='#7baba3';g.strokeRect(-16,-16,32,32);g.fillStyle='#d4ba7d';g.fillRect(-4,-4,8,8);g.restore()}
 }
 const tex=new T.CanvasTexture(c);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);tex.repeat.set(kind==='tile'?1:2,kind==='tile'?1:2);sceneStats.materialTextures++;return tex;
}
function mat(name,color,kind='plaster',extra={}){return materials[name]=new T.MeshStandardMaterial({color:0xffffff,map:texture(kind,color),roughness:.88,...extra})}
function solid(name,color,extra={}){return materials[name]=new T.MeshStandardMaterial({color,roughness:.72,...extra})}
function mesh(geo,ma,parent=world,x=0,y=0,z=0,rx=0,ry=0,rz=0){const m=new T.Mesh(geo,ma);m.position.set(x,y,z);m.rotation.set(rx,ry,rz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function box(parent,ma,x,y,z,w,h,d){const m=mesh(geos.box,ma,parent,x,y,z);m.scale.set(w,h,d);return m}
function capsule(parent,ma,x,y,z,w,h,d){const m=mesh(geos.capsule,ma,parent,x,y,z);m.scale.set(w*.5,h/3,d*.5);return m}
function cyl(parent,ma,x,y,z,r,h,segments=12,rTop=r){return mesh(new T.CylinderGeometry(rTop,r,h,segments),ma,parent,x,y,z)}
function sphere(parent,ma,x,y,z,r,sx=1,sy=1,sz=1){const m=mesh(geos.sphere,ma,parent,x,y,z);m.scale.set(r*sx,r*sy,r*sz);return m}
function beam(parent,ma,a,b,r=.05){const v=new T.Vector3().subVectors(b,a),m=mesh(new T.CylinderGeometry(r,r,v.length(),7),ma,parent);m.position.copy(a).add(b).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return m}
function archShape(w,h,border=.2){const sh=new T.Shape();sh.moveTo(-w/2,0);sh.lineTo(w/2,0);sh.lineTo(w/2,h-w*.5);sh.absarc(0,h-w*.5,w*.5,0,Math.PI,false);sh.lineTo(-w/2,0);if(border){const r=w/2-border,hole=new T.Path();hole.moveTo(-r,.02);hole.lineTo(-r,h-w*.5);hole.absarc(0,h-w*.5,r,Math.PI,0,true);hole.lineTo(r,.02);hole.closePath();sh.holes.push(hole)}return sh}
function arch(parent,ma,x,y,z,w,h,depth=.13,border=.17){return mesh(new T.ExtrudeGeometry(archShape(w,h,border),{depth,bevelEnabled:false,curveSegments:12}),ma,parent,x,y,z)}
function addObstacle(x,z,w,d,h=5){obstacles.push({minX:x-w/2-.45,maxX:x+w/2+.45,minZ:z-d/2-.45,maxZ:z+d/2+.45,h})}

function windowDetail(parent,x,y,z,w=1,h=1.5,fancy=false){
 box(parent,materials.dark,x,y+h/2,z,w,h,.045);box(parent,materials.wood,x-w*.27,y+h*.48,z+.045,w*.42,h*.88,.08);box(parent,materials.wood,x+w*.27,y+h*.48,z+.045,w*.42,h*.88,.08);
 for(const dx of [-1,1])box(parent,materials.trim,x+dx*(w/2+.07),y+h/2,z+.05,.11,h+.22,.13);
 box(parent,materials.trim,x,y+h+.055,z+.06,w+.25,.12,.18);box(parent,materials.trim,x,y-.03,z+.13,w+.35,.17,.37);
 for(let i=1;i<6;i++)box(parent,materials.woodLight,x,y+i*h/6,z+.11,w*.92,.025,.035);
 if(fancy){arch(parent,materials.trim,x,y-.05,z+.13,w+.4,h+.55,.12,.12);box(parent,materials.tile,x,y-.3,z+.15,w+.45,.24,.12)}
}
function facade(parent,width,height,depth,style=0){
 if(style===3){const wide=Math.min(width-1.2,4.4);box(parent,materials.dark,0,1.3,depth/2+.03,wide,2.6,.045);for(const side of[-1,1])box(parent,materials.wood,side*wide*.25,1.2,depth/2+.09,wide*.48,2.4,.08);arch(parent,materials.trim,0,0,depth/2+.15,wide+.4,3.1,.18,.18);for(let i=0;i<6;i++)box(parent,materials.iron,-wide*.42+i*wide*.168,1.2,depth/2+.14,.035,2.3,.04);box(parent,materials.tile,0,3.3,depth/2+.1,Math.min(width-.5,5),.24,.08);return}
 if(style===4){arch(parent,materials.trim,0,0,depth/2+.1,1.8,2.7,.22,.22);box(parent,materials.wood,0,1.1,depth/2+.08,1.2,2.2,.07);for(const side of[-1,1]){box(parent,materials.trim,side*(width*.35),height*.55,depth/2+.04,.5,1.4,.12);box(parent,materials.dark,side*(width*.35),height*.55,depth/2+.12,.15,.9,.04)}for(let y=.7;y<height-.4;y+=.65)box(parent,materials.stone,0,y,depth/2+.015,width,.045,.03);return}
 if(style===5){for(let i=0;i<7;i++){const w=(width-.6)/7;box(parent,i%2?materials.cloth:materials.canvas,-width/2+.3+w*(i+.5),2.65,depth/2+.62,w,.06,1.2);box(parent,i%2?materials.cloth:materials.canvas,-width/2+.3+w*(i+.5),2.44,depth/2+1.2,w,.4,.04)}}
 // Local +Z faces outward; all four facades are actually built.
 const floors=Math.max(1,Math.floor((height-2.5)/2.75)+1);
 for(let f=0;f<floors;f++){
  let yy=f*2.75+1.05;const count=Math.floor(width/2.4);
  for(let i=0;i<count;i++){const xx=(i-(count-1)/2)*2.35;if(f===0&&i===Math.floor(count/2)&&style!==2){box(parent,materials.dark,xx,1.1,depth/2+.025,1.25,2.2,.08);arch(parent,materials.trim,xx,.02,depth/2+.12,1.65,2.75,.15,.2);box(parent,materials.wood,xx,1.03,depth/2+.08,1.05,2.05,.06);for(let k=0;k<5;k++)box(parent,materials.woodLight,xx-.42+k*.21,1.02,depth/2+.13,.025,2,.015);sphere(parent,materials.brass,xx+.31,1.03,depth/2+.2,.055)}else windowDetail(parent,xx,yy,depth/2+.04,style===2?1.25:.9,style===2?1.35:1.45,style===1&&f===floors-1)}
  if(f>0){box(parent,materials.trim,0,f*2.75+.3,depth/2+.15,width+.18,.15,.28);if(style===1){const ww=Math.min(width-1,5);box(parent,materials.trim,0,f*2.75+.52,depth/2+.65,ww,.2,1.25);for(let i=0;i<Math.ceil(ww/.22);i++)box(parent,materials.iron,-ww/2+i*.22,f*2.75+1.05,depth/2+1.15,.035,1,.035);box(parent,materials.iron,0,f*2.75+1.5,depth/2+1.15,ww,.045,.045)}}
 }
 box(parent,materials.trim,0,height-.18,depth/2+.08,width+.15,.2,.25);box(parent,materials.tile,0,.45,depth/2+.04,width,.24,.045);
 for(const xx of [-width/2+.13,width/2-.13]){box(parent,materials.trim,xx,height/2,depth/2+.09,.23,height,.16);for(let y=.5;y<height;y+=.6)box(parent,materials.stone,xx,y,depth/2+.16,.31,.24,.14)}
}
function building(x,z,w,d,h,style=0,color=materials.sand){
 sceneStats.buildings++;const g=new T.Group();world.add(g);const base=groundHeight(x,z),low=Math.min(base,...[-1,1].flatMap(a=>[-1,1].map(b=>groundHeight(x+a*w/2,z+b*d/2))));g.position.set(x,base,z);if(base>low+.01)box(g,materials.stone,0,-(base-low)/2,0,w+.1,base-low+.08,d+.1);addObstacle(x,z,w,d,h);
 // Four walls, floor and solid ceiling; never a single floating facade.
 box(g,materials.stone,0,.18,0,w+.36,.36,d+.36);box(g,color,0,h/2,-d/2+.13,w,h,.26);box(g,color,0,h/2,d/2-.13,w,h,.26);box(g,color,-w/2+.13,h/2,0,.26,h,d);box(g,color,w/2-.13,h/2,0,.26,h,d);
 box(g,materials.paving,0,h-.15,0,w,.3,d).userData.observerRoof=true;
 for(let j=0;j<4;j++){const f=new T.Group();g.add(f);f.rotation.y=j*Math.PI/2;facade(f,j%2?d:w,h,j%2?w:d,style)}
 addDistrictRoof(g,{w,d,h,style,m:materials});
 return g;
}
function palm(x,z,h=6){
 const g=new T.Group();world.add(g);g.position.set(x,groundHeight(x,z),z);
 const curve=new T.CatmullRomCurve3([new T.Vector3(),new T.Vector3(.12,h*.35,.1),new T.Vector3(.4,h*.72,.1),new T.Vector3(.7,h,0)]);mesh(new T.TubeGeometry(curve,12,.18,7,false),materials.trunk,g);
 for(let i=0;i<11;i++){const y=i*h/11;const m=mesh(new T.TorusGeometry(.19-y*.006,.025,4,8),materials.trunkLight,g,.7*(y/h)**2,y,0,Math.PI/2);}
 for(let j=0;j<9;j++){
  const a=j*Math.PI*2/9,verts=[],idx=[];for(let k=0;k<=12;k++){const s=k/12,r=s*3.6,yy=h+Math.sin(s*Math.PI)*.9-s*s*1.4,w=Math.sin(s*Math.PI)*.43;const cx=.7+Math.cos(a)*r,cz=Math.sin(a)*r;verts.push(cx+Math.sin(a)*w,yy,cz-Math.cos(a)*w,cx-Math.sin(a)*w,yy,cz+Math.cos(a)*w);if(k<12){let q=k*2;idx.push(q,q+1,q+2,q+1,q+3,q+2)}}
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(verts,3));geo.setIndex(idx);geo.computeVertexNormals();mesh(geo,j%2?materials.leaf:materials.foliage,g);
  for(let k=2;k<10;k++){const s=k/12,r=s*3.6;for(const side of [-1,1]){const a1=new T.Vector3(.7+Math.cos(a)*r,h+Math.sin(s*Math.PI)*.9-s*s*1.4,Math.sin(a)*r),a2=a1.clone().add(new T.Vector3(Math.cos(a)*.25+Math.sin(a)*side*.5,-.1,Math.sin(a)*.25-Math.cos(a)*side*.5));beam(g,materials.leaf,a1,a2,.018)}}
 }
 cyl(g,materials.stone,0,.05,0,1.05,.1,16);return g;
}
function crate(x,z,w=1.2){const g=new T.Group();world.add(g);g.position.set(x,groundHeight(x,z),z);box(g,materials.wood,0,w/2,0,w,w,w);for(const y of [.13,w-.13]){box(g,materials.woodLight,0,y,w/2+.025,w,.14,.06);box(g,materials.woodLight,0,y,-w/2-.025,w,.14,.06)}for(const xx of [-w/2+.1,w/2-.1])box(g,materials.woodLight,xx,w/2,w/2+.06,.14,w,.09);const diagonal=box(g,materials.woodLight,0,w/2,w/2+.08,.1,w*1.15,.07);diagonal.rotation.z=-.7;addObstacle(x,z,w,w,w);return g}
function lamp(x,z,h=3.7){cyl(world,materials.iron,x,h/2,z,.055,h,8);box(world,materials.iron,x,h,z,.55,.07,.55);box(world,materials.glass,x,h-.3,z,.3,.5,.3);for(const dx of [-.18,.18])for(const dz of [-.18,.18])box(world,materials.iron,x+dx,h-.3,z+dz,.035,.55,.035);mesh(new T.ConeGeometry(.48,.25,4),materials.brass,world,x,h+.15,z,0,Math.PI/4);}
function market(x,z){const g=new T.Group();world.add(g);g.position.set(x,0,z);for(const xx of [-1.7,1.7])for(const zz of [-1.15,1.15])cyl(g,materials.wood,xx,1.5,zz,.055,3,7);for(let i=0;i<9;i++){const m=box(g,i%2?materials.cloth:materials.canvas,-1.6+i*.4,2.9,0,.4,.08,2.75);m.rotation.x=.13;box(g,i%2?materials.cloth:materials.canvas,-1.6+i*.4,2.6,1.35,.4,.42,.07)}box(g,materials.wood,0,.9,.2,3.2,.15,1.6);for(let i=0;i<7;i++){box(g,materials.woodLight,-1.2+i*.4,1.1,.2,.35,.24,.7);for(let j=0;j<5;j++)sphere(g,i%2?materials.fruit:materials.flower,-1.2+i*.4+range(-.12,.12),1.25,.2+range(-.2,.2),.08)}addObstacle(x,z,3.8,2.6,3);}
function makeTerrain(){
 const outer=new T.PlaneGeometry(340,300,100,90);outer.rotateX(-Math.PI/2);const a=outer.attributes.position;for(let i=0;i<a.count;i++){const x=a.getX(i),z=a.getZ(i);a.setY(i,x<-65?.05-(-x-65)*.16:Math.abs(x)<60&&Math.abs(z)<44?-.07:.05+Math.max(0,Math.abs(z)-55)*.012)}outer.computeVertexNormals();mesh(outer,materials.sandGround,world);
 const geo=new T.PlaneGeometry(WIDTH,DEPTH,WIDTH,DEPTH);geo.rotateX(-Math.PI/2);const p=geo.attributes.position,colors=[];for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i),h=Math.min(...[-.001,.001].flatMap(dx=>[-.001,.001].map(dz=>groundHeight(x+dx,z+dz))));p.setY(i,h-.018);const street=(x>-40&&x<42&&z>-34&&z<-28)||(x>-40&&x<43&&z>27&&z<32)||(x>27&&x<33&&z>0&&z<30),c=new T.Color(h<-.1?'#8b897b':street?'#858a87':'#cbb68f');colors.push(c.r,c.g,c.b)}geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));geo.computeVertexNormals();const ma=new T.MeshStandardMaterial({map:texture('asphalt','#ffffff'),roughness:.96,vertexColors:true});materials.playfield=ma;mesh(geo,ma,world);materials.asphaltRoad=new T.MeshStandardMaterial({map:texture('asphalt','#626967'),roughness:.97});for(const[x,z,w,d]of[[3,-31,74,4],[1.5,28.5,81,4],[30,14,3,28],[4,-13,30,3]])box(world,materials.asphaltRoad,x,.04,z,w,.016,d);
 // Continuous quay and retained stone edge connect the town to the shore.
 box(world,materials.stone,-62,-.13,0,4,.3,96);for(let z=-45;z<=45;z+=2.4){box(world,materials.trim,-64,.13,z,.6,.38,2.2);cyl(world,materials.iron,-63,.43,z,.09,.6,8)}
 for(const z of[-27.3,26.7])for(let x=-40;x<43;x+=1.5)box(world,materials.trim,x,.09,z,1.4,.12,.2);
}
function makeWater(){
 const geo=new T.PlaneGeometry(180,300,1,1);geo.rotateX(-Math.PI/2);
 water=mesh(geo,new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uTime:{value:0},uSun:{value:new T.Vector3(-.6,.8,-.4)},uOpacity:{value:.94}},vertexShader:`varying vec3 vWorld;void main(){vec4 w=modelMatrix*vec4(position,1.);vWorld=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,fragmentShader:`precision highp float;uniform float uTime;uniform vec3 uSun;uniform float uOpacity;varying vec3 vWorld;
 float wave(vec2 p){return sin(p.x*.9+p.y*.55+uTime*1.15)*.11+sin(p.x*.31-p.y*.7+uTime*.8)*.08+sin(p.x*1.7+p.y*.4-uTime*.7)*.04;}
 void main(){vec2 p=vWorld.xz;float w=wave(p),wx=wave(p+vec2(.12,0.)),wz=wave(p+vec2(0.,.12));vec3 n=normalize(vec3((w-wx)*2.2,1.,(w-wz)*2.2));vec3 v=normalize(cameraPosition-vWorld);float fres=pow(1.-max(dot(n,v),0.),3.);float depth=1.-smoothstep(-90.,-67.,p.x);vec3 col=mix(vec3(.32,.67,.64),vec3(.055,.29,.37),depth);col=mix(col,vec3(.73,.82,.77),fres*.65);vec3 h=normalize(v+uSun);float spec=pow(max(dot(n,h),0.),140.);col+=spec*vec3(1.,.87,.61)*.36;float stripe=sin(p.x*.85+sin(p.y*.17)*.5+uTime*1.5);float shore=(1.-smoothstep(-71.,-66.,p.x))*smoothstep(-78.,-67.,p.x);float foam=smoothstep(.84,1.,stripe)*shore;col=mix(col,vec3(.85,.9,.78),foam*.64);col+=pow(max(w+.05,0.),3.)*.07;gl_FragColor=vec4(col,uOpacity);}`}),world,-158,-.14,0);water.receiveShadow=false;water.castShadow=false;water.renderOrder=1;
 for(let i=0;i<30;i++){const x=range(-79,-67),z=range(-58,58);sphere(world,materials.rock,x,-.48,z,range(.5,1.5),1,range(.45,.9),1.3)}
}
function wall(x,z,w,d,h,base=0,ma=materials.sand){box(world,ma,x,base+h/2,z,w,h,d);box(world,materials.trim,x,base+h+.045,z,w+.14,.09,d+.14);for(let y=.45;y<h;y+=.85)box(world,materials.stone,x,base+y,z,w+.025,.035,d+.025)}
function stairRun(x,z,w,d,top){if(top<=.05)return;box(world,materials.stone,x,(top-.05)/2+.05,z,w,top-.05,d);box(world,materials.trim,x,top+.008,z,w,.016,d)}
function raisedSites(){
 box(world,materials.stone,35.5,1.2,-17,23,2.5,14);box(world,materials.paving,35.5,2.455,-17,22.9,.01,13.9);
 for(let i=0;i<16;i++){stairRun(16+i*.5+.25,-14,.5,6,.05+(i+1)*.15);stairRun(32,-32+i*.5+.25,6,.5,.05+(i+1)*.15)}for(let i=0;i<24;i++)stairRun(41,-10+i*.5+.25,8,.5,Math.max(.05,2.45-(i+1)*.1));
 box(world,materials.stone,-31,.3,19,14,.7,12);box(world,materials.paving,-31,.655,19,13.9,.01,11.9);for(let i=0;i<4;i++){stairRun(-32,9+i+.5,6,1,.05+(i+1)*.15);stairRun(-24+i+.5,19,1,4,.65-(i+1)*.15)}for(let i=0;i<3;i++)stairRun(-31,25+i+.5,6,1,.65-(i+1)*.2);
 for(const[x,z,w,d,h]of SITE_WALLS)wall(x,z,w,d,h);
}
function portal(x,z,w,h,y=0,rotate=0){const g=new T.Group();g.position.set(x,y,z);g.rotation.y=rotate;world.add(g);arch(g,materials.trim,0,0,0,w,h,.32,.22);return g}
function interiorRooms(){
 for(const[x,z,w,d]of TUNNEL_WALLS)wall(x,z,w,d,4.65,-.75,materials.stone);
 for(const r of TUNNEL_FLOORS){box(world,materials.stone,r.x,3.92,r.z,r.w+.25,.26,r.d+.25).userData.observerRoof=true;for(let z=r.z-r.d/2+2;z<r.z+r.d/2;z+=4)if(r.d>10)portal(r.x,z,r.w-.35,4.2,-.75);}
 portal(-43,-23,4,4.2,-.6);portal(-34,1,4,4.2,-.75,Math.PI/2);
 // Vent grilles and lamps show the tunnel's interior geometry in observer cutaway.
 for(const z of[-19,-11,-5]){box(world,materials.iron,-45.77,2,z,.07,.75,1.2);for(let i=0;i<6;i++)box(world,materials.trim,-45.71,1.7+i*.1,z,.04,.035,1.12);box(world,materials.glass,-40.2,2.75,z,.12,.24,.5)}
 for(const[x,z,w,d]of ROOM_WALLS)wall(x,z,w,d,ROOM.h,0,materials.cream);box(world,materials.paving,ROOM.x,.052,ROOM.z,ROOM.w-.3,.008,ROOM.d-.3);const roofGroup=new T.Group();roofGroup.position.set(ROOM.x,0,ROOM.z);world.add(roofGroup);addDistrictRoof(roofGroup,{w:ROOM.w,d:ROOM.d,h:ROOM.h,style:2,m:materials});box(roofGroup,materials.wood,0,ROOM.h-.06,0,ROOM.w,.12,ROOM.d).userData.observerRoof=true;
 for(const x of[-4,0,4])windowDetail(roofGroup,x,1.1,ROOM.d/2+.025,1.2,1.45,true);for(const x of[-7,7])portal(x,21,5.8,4.3,0,Math.PI/2);portal(0,15,3.4,4.1);for(const x of[-4,4])for(const z of[17,25]){cyl(world,materials.stone,x,2,z,.17,4,12);box(world,materials.wood,x,4.2,21,.25,.25,11)}
 for(const[x,z,w,d,h]of MID_WALLS)wall(x,z,w,d,h);for(const x of[-2.8,2.8]){cyl(world,materials.sand,x,3.7,-3,.62,7.4,14);for(const y of[.5,3.4,6.8])cyl(world,materials.trim,x,y,-3,.7,.18,14);mesh(new T.ConeGeometry(.76,.7,8),materials.dome,world,x,7.75,-3)}const gate=portal(0,-3,4,4.6);for(const side of[-1,1]){const hinge=new T.Group();hinge.position.set(side*2,0,0);hinge.rotation.y=side*Math.PI*.47;gate.add(hinge);box(hinge,materials.wood,side*-.9,1.7,0,1.8,3.4,.16);for(const y of[.5,2.8])box(hinge,materials.iron,side*-.9,y,.1,1.8,.12,.04)}
}
function sitePaint(x,z,letter,color){const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.strokeStyle=color;g.lineWidth=8;g.strokeRect(12,12,232,232);g.fillStyle=color;g.font='bold 170px sans-serif';g.textAlign='center';g.fillText(letter,128,186);const tx=new T.CanvasTexture(c);tx.colorSpace=T.SRGBColorSpace;mesh(new T.PlaneGeometry(5,5),new T.MeshBasicMaterial({map:tx,transparent:true,opacity:.72,depthWrite:false}),world,x,groundHeight(x,z)+.025,z,-Math.PI/2)}
function makeSet(){
 makeTerrain();makeWater();raisedSites();for(const[x,z,w,d,h]of PERIMETER_WALLS)wall(x,z,w,d,h);for(const[x,z,w,d,h,style,color]of[...BUILDINGS,...OUTSKIRTS])building(x,z,w,d,h,style,materials[color]);interiorRooms();
 for(const[x,z,h]of PALMS)palm(x,z,h);for(const[x,z,w]of COVERS)crate(x,z,w);for(const[x,z]of MARKET_STALLS){const g=new T.Group();g.position.set(x,groundHeight(x,z),z);world.add(g);box(g,materials.wood,0,.8,0,2.4,.15,1.5);for(const side of[-1,1])for(const zz of[-.5,.5])box(g,materials.woodLight,side, .4,zz,.1,.8,.1);for(let j=0;j<6;j++)sphere(g,j%2?materials.fruit:materials.flower,-.9+j*.36,1.03,0,.16)}
 for(const[x,z]of LAMPS)lamp(x,z,4);
 sitePaint(35,-18,'A','#cc6d38');sitePaint(-30,19,'B','#d58c47');
 // Tower cupola and arches give B its own silhouette rather than repeated houses.
 const dome=mesh(new T.SphereGeometry(2.6,24,14,0,Math.PI*2,0,Math.PI/2),materials.dome,world,-41,11.1,11);cyl(world,materials.tile,-41,11.1,11,2.6,.24,24);cyl(world,materials.brass,-41,14,11,.045,.7,8);
 makeAtmosphere();bakeStatic();
}

function smoothRoute(start,path){const result=[];let from=start,index=0;while(index<path.length){let far=path.length-1;while(far>index&&!lineClear(from,path[far]))far--;result.push(path[far]);from=path[far];index=far+1}return result}
function bakeStatic(){
 world.updateMatrixWorld(true);const bins=new Map(),remove=[];
 world.traverse(o=>{if(!o.isMesh||o===water||o.material.transparent||Array.isArray(o.material))return;let ancestor=o,isRoof=false;while(ancestor&&ancestor!==world){isRoof||=!!ancestor.userData.observerRoof;ancestor=ancestor.parent}const key=o.material.uuid+(isRoof?':roof':':wall');let geo=o.geometry.clone();geo.applyMatrix4(o.matrixWorld);if(!geo.attributes.uv)geo.setAttribute('uv',new T.BufferAttribute(new Float32Array(geo.attributes.position.count*2),2));if(o.material.map){const p=geo.attributes.position,n=geo.attributes.normal,uv=geo.attributes.uv;for(let i=0;i<p.count;i++){if(Math.abs(n.getY(i))>.6)uv.setXY(i,p.getX(i)*.25,p.getZ(i)*.25);else uv.setXY(i,(Math.abs(n.getX(i))>.6?p.getZ(i):p.getX(i))*.25,p.getY(i)*.25)}}if(geo.index)geo=geo.toNonIndexed();geo.deleteAttribute('uv1');if(!geo.attributes.uv){geo.setAttribute('uv',new T.BufferAttribute(new Float32Array(geo.attributes.position.count*2),2))}if(!bins.has(key))bins.set(key,{material:o.material,geos:[],isRoof});bins.get(key).geos.push(geo);remove.push(o)});
 for(const o of remove)o.parent.remove(o);
 for(const {material,geos:gs,isRoof}of bins.values()){const geo=mergeGeometries(gs,false);if(!geo)throw Error('Geometry merge failed');const m=new T.Mesh(geo,material);m.castShadow=true;m.receiveShadow=true;scene.add(m);if(isRoof)roofMeshes.push(m);gs.forEach(g=>g.dispose())}
 sceneStats.staticBatches=bins.size;
}
function makeAtmosphere(){
 const cloudMat=new T.MeshBasicMaterial({color:0xfff3d7,transparent:true,opacity:.08,depthWrite:false});
 for(let i=0;i<12;i++){const g=new T.Group();scene.add(g);g.position.set(range(-110,110),range(28,40),range(-135,-95));for(let j=0;j<4;j++){const m=sphere(g,cloudMat,j*4,range(-1,1),range(-2,2),range(3,6),1.8,.3,1);m.castShadow=false}clouds.push(g)}
 for(let i=0;i<9;i++){const gull=createGull(i);scene.add(gull.root);birds.push({...gull,angle:range(0,7),r:range(17,29),height:range(10,17),speed:range(.04,.08)})}
}
function enableCanopyReveal(){
 for(const material of [materials.foliage,materials.leaf]){
  material.transparent=true;material.depthWrite=false;
  material.onBeforeCompile=shader=>{shader.uniforms.uOperatorFocus=foliageReveal.focus;shader.uniforms.uOperatorReveal=foliageReveal.enabled;shader.vertexShader='varying vec3 vCanopyWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\nvCanopyWorld=(modelMatrix*vec4(transformed,1.0)).xyz;');shader.fragmentShader='uniform vec3 uOperatorFocus;uniform float uOperatorReveal;varying vec3 vCanopyWorld;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <alphatest_fragment>',`vec3 sight=uOperatorFocus-cameraPosition;float sightLength=max(dot(sight,sight),0.001);float along=dot(vCanopyWorld-cameraPosition,sight)/sightLength;float nearSight=length(vCanopyWorld-cameraPosition-sight*clamp(along,0.0,1.0));float reveal=(1.0-smoothstep(0.6,1.6,nearSight))*step(0.0,along)*step(along,0.99)*uOperatorReveal;diffuseColor.a*=1.0-reveal*0.9;\n#include <alphatest_fragment>`)};
  material.customProgramCacheKey=()=> 'arena-original-canopy-reveal-19';material.needsUpdate=true;
 }
}


 mat('sand','#ccad7f');mat('cream','#e6d7b8');mat('peach','#c59779');mat('trim','#e4d9bf','stone');mat('stone','#b2a48b','stone');mat('paving','#bdad91','paving');mat('sandGround','#c6b28b');mat('street','#9f9985','stone');mat('tile','#18474b','tile');mat('roof','#b65d39','roof');mat('wood','#6e5540','wood');mat('woodLight','#a58b5d','wood');mat('trunk','#756245','wood');
 solid('trunkLight',0x927b50);solid('foliage',0x516d41,{side:T.DoubleSide});solid('leaf',0x7c914d,{side:T.DoubleSide});solid('flower',0xb28c73);solid('fruit',0xd99543);solid('iron',0x354345,{metalness:.55,roughness:.4});solid('dark',0x253b3a);solid('brass',0xbda365,{metalness:.7,roughness:.35});solid('terracotta',0xa96c46);solid('ceramic',0xc4b59a);solid('cloth',0x2e6a68);solid('canvas',0xd7c393);solid('glass',0xf1c489,{emissive:0xeab878,emissiveIntensity:.3});solid('dome',0x547e76,{metalness:.35,roughness:.4});solid('inlay',0x71847a);solid('rock',0x918b72);solid('boat',0x365b60);solid('rope',0xa29776);solid('poolWater',0x519d9c,{metalness:.3,roughness:.17,transparent:true,opacity:.8});

makeSet();enableCanopyReveal();
// Focused observer cutaway: retain the district, reveal only the sight corridor
// between camera and selected actor so rooftops cannot cover the animation.
for(const material of Object.values(materials)){
 if(material.transparent||!material.isMeshStandardMaterial)continue;
 material.onBeforeCompile=shader=>{shader.uniforms.uActorFocus=foliageReveal.focus;shader.uniforms.uActorReveal=foliageReveal.enabled;shader.vertexShader='varying vec3 vDistrictWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\nvDistrictWorld=(modelMatrix*vec4(transformed,1.0)).xyz;');shader.fragmentShader='uniform vec3 uActorFocus;uniform float uActorReveal;varying vec3 vDistrictWorld;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <alphatest_fragment>',`vec3 sight=uActorFocus-cameraPosition;float along=dot(vDistrictWorld-cameraPosition,sight)/max(dot(sight,sight),0.001);float gap=length(vDistrictWorld-cameraPosition-sight*clamp(along,0.0,1.0));if(uActorReveal>0.5&&along>0.0&&along<0.99&&gap<1.35&&vDistrictWorld.y>uActorFocus.y-0.75)discard;\n#include <alphatest_fragment>`)};
 material.customProgramCacheKey=()=> 'arena-original-focused-cutaway20';material.needsUpdate=true;
}
let disposed=false;return{ready:true,progress:1,error:null,clipHeight:1000,sourceHash:'arena-original-district22',sourceTriangles:0,sourceCaptures:0,cacheMode:'original-procedural',get roofMode(){return roofMode},districtCount:sceneStats.buildings,playableBuildings:BUILDINGS.length,contextBuildings:OUTSKIRTS.length,interiorSpaces:3,heightRange:[-.75,2.45],gullCount:birds.length,gullAnatomy:birds[0]?.anatomy,roofStyle:'parapet-coping,gable-tiles,ridge-caps,gutters,roof-access',wallSolids:sceneStats.buildings,seamlessGround:true,groundSource:'arena-original-district22',environment:{weather:'coastal-desert',districtBuildings:sceneStats.buildings},setRoofMode(value){if(value===roofMode)return;roofMode=value;for(const m of roofMeshes)m.visible=value!=='routes';renderer.shadowMap.needsUpdate=true},setLevel(level,actor){foliageReveal.enabled.value=actor?1:0;if(actor)foliageReveal.focus.value.set(actor.x-map.width/2,(actor.y||0)+1.1,actor.z-map.height/2)},updateProps(){},invalidate(){},render(camera,now){if(disposed)return;const t=now/1000;water.material.uniforms.uTime.value=t;for(const b of birds){const a=b.angle+t*b.speed;b.root.position.set(-65+Math.cos(a)*b.r,b.height+Math.sin(a*2),Math.sin(a)*b.r*1.7);b.root.rotation.y=-a;b.pose(t)}for(let i=0;i<clouds.length;i++)clouds[i].position.x=((clouds[i].userData.originX??=clouds[i].position.x)+t*(.12+i*.008)+120)%240-120;renderer.render(scene,camera)},dispose(){disposed=true}}}
