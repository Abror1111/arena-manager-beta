# ARENA Manager1.54 — New Game

Add New Game on the opening screen and in Settings. A native confirmation names the current club and explains that roster, balances, season and pending match will reset. Cancel, Escape and closing the dialog do not change the club. Cancel receives initial focus.

Confirmed restart creates a validated empty club with12000coins, zero progress and mandatory tutorial step0; it preserves graphics quality and leaves global audio preferences and asset caches intact. An importable previous-club snapshot is stored before replacing the primary save. A storage failure leaves the current club/UI unchanged. Primary and normal fallback point to the fresh game after a successful reset.

Offer current backup export in the confirmation and last pre-restart backup export in Settings. Normal new-game progress never overwrites that dedicated snapshot; a subsequent confirmed restart replaces it with the immediately preceding club. Optional Help replay uses its own memory storage.

Compact opening actions and static confirmation layout fit narrow phones, landscape, Fold/tablet and desktop; enlarged fonts remain inside their boxes. A one-frame coach refresh after mounting avoids missing the first tutorial target when the confirmation closes.

Web-only release; the1.52Android APK remains unchanged. Simulation, maps, artwork, audio and ordinary economy are preserved; engine display version changes to1.54. Source and verification include current tests and prior release history; no new Android signing certificate is issued.

Build: `node --test tests/*.test.mjs`; `ARENA_MANAGER_OUT=/tmp/arena54-web npm run build`; `python pack-web31.py /tmp/arena54-web`. runtime54.json pins the exact immutable SHA-verified compressed runtime. Serve at /arena-manager-beta/remix31/ with shared root assets. verification54 contains current restart/storage/viewport tests; prior verification directories preserve full history. Previous source: https://github.com/Abror1111/arena-manager-beta/tree/arena-required53-source .
