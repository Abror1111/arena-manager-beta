from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote,urlsplit
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  path=unquote(urlsplit(path).path);prefix='/arena-manager-beta/remix31/'
  if path.startswith(prefix):return str(Path('/dev/shm/arena-manager-newgame54-web')/path[len(prefix):])
  if path.startswith('/arena-manager-beta/'):return str(Path('/dev/shm/arena-pages53')/path[len('/arena-manager-beta/'):])
  return '/dev/shm/no-such-file'
ThreadingHTTPServer(('0.0.0.0',8280),H).serve_forever()
