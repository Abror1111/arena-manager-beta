from pathlib import Path
import json,hashlib,zipfile,subprocess,os
p=Path('/dev/shm/arena-manager-mobile52');log=Path('/dev/shm/arena-mobile52-tests');apk=p/'androidGame52/app/build/outputs/apk/debug/app-debug.apk';meta={'result':'passed','applicationId':'uz.arena.manager.preview','versionCode':152,'versionName':'1.52-beta','orientation':'fullUser','physicalDeviceInstalled':False};assets=json.loads((log/'android-assets52.json').read_text())
with zipfile.ZipFile(apk)as z:
 assert z.testzip()is None
 for name,m in assets['assets'].items():
  b=z.read('assets/public/'+name);assert len(b)==m['bytes']and hashlib.sha256(b).hexdigest()==m['sha256'],name
meta.update(bundledAssetHashesVerified=len(assets["assets"]),bytes=apk.stat().st_size,sha256=hashlib.sha256(apk.read_bytes()).hexdigest(),nativeDirectoryEntryResolved=True)
env=dict(os.environ,JAVA_HOME='/workspace/.arena-tools/java/jdk-21.0.12.1');tools=Path('/workspace/.arena-tools/android-sdk/build-tools/35.0.0')
(log/'apk-signature.log').write_bytes(subprocess.check_output([str(tools/'apksigner'),'verify','--print-certs',str(apk)],env=env));(log/'apk-manifest.log').write_bytes(subprocess.check_output([str(tools/'aapt'),'dump','badging',str(apk)]));(log/'apk52.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
