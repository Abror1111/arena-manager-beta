# ARENA Android preview1.52

Same applicationId uz.arena.manager.preview, versionCode152, minSdk26/target35; fullUser orientation and adjustResize. Private signing key is excluded. Existing preview certificate is required to install over an older preview. Export a backup in Settings first.

Restore web dependencies and build/pack the exact source. Adapt verification52/prepare-android52.py and build-game52.py paths to a local Android SDK35, JDK21 and Gradle8.11.1. Preparation bundles Sandrift3D, all11simulation/collision data, original UI artwork, Manrope+OFL, audio and runtime52.json immutable runtime with native remote aliases52. Other3Dworlds download/cache on demand. Gradle uses the previewKey52 project property for a local keystore path; never distribute it.

Verification includes ZIP CRC, packaged asset hashes, apksigner, aapt and offline Chromium using actual extracted APK assets. Physical APK installation and device FPS are not claimed. No live billing/ads.
