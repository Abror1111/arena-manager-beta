package uz.arena.preview;

import android.app.Activity;
import android.os.*;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import android.graphics.Color;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public final class MainActivity extends Activity {
 private WebView web;
 private JSONObject aliases;
 private String pendingBackup;
 private ValueCallback<Uri[]> fileCallback;
 private static final int SAVE=701,OPEN=702,FILE=703;
 private static final String ROOT="https://arena.local/";
 private static final String REMOTE="https://raw.githubusercontent.com/Abror1111/arena-manager-beta/fd35f9ae327ca3477f6d55c6acf3b07cc3e95df4/";
 private final String CSP="default-src 'self' data: blob: https://raw.githubusercontent.com; script-src 'self' blob: 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://raw.githubusercontent.com; connect-src 'self' blob: https://raw.githubusercontent.com; media-src 'self' blob: data:; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-src 'none'";
 private boolean owned(){return web!=null&&web.getUrl()!=null&&web.getUrl().startsWith(ROOT);}
 public final class Shell {
  @JavascriptInterface public void saveBackup(String text){if(text==null||text.length()>1000000)return;runOnUiThread(()->{if(!owned())return;pendingBackup=text;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"arena-career-1.52.json");try{startActivityForResult(i,SAVE);}catch(Exception e){pendingBackup=null;status("Zaxira oynasi ochilmadi.");}});}
  @JavascriptInterface public void openBackup(){runOnUiThread(()->{if(!owned())return;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");try{startActivityForResult(i,OPEN);}catch(Exception e){status("Fayl tanlash oynasi ochilmadi.");}});}
 }
 private void status(String s){if(web!=null)web.evaluateJavascript("window.dispatchEvent(new CustomEvent('arena:backup-status',{detail:"+JSONObject.quote(s)+"}))",null);}
 @Override public void onCreate(Bundle b){
  super.onCreate(b);getWindow().setStatusBarColor(Color.TRANSPARENT);getWindow().setNavigationBarColor(Color.BLACK);
  try(InputStream in=getAssets().open("public/remote-aliases52.json")){aliases=new JSONObject(new String(read(in,1000000),StandardCharsets.UTF_8));}catch(Exception e){aliases=new JSONObject();}
  web=new WebView(this);web.setBackgroundColor(Color.rgb(12,20,28));WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setMediaPlaybackRequiresUserGesture(true);android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.addJavascriptInterface(new Shell(),"ArenaShell");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return !"https".equals(r.getUrl().getScheme())||!"arena.local".equals(r.getUrl().getHost());}
   @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){return route(r.getUrl());}
   @Override public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())status("O‘yinni qayta oching yoki ilovani yangilang.");}
  });
  ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient(){@Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest r){return route(r.getUrl());}});
  web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/x-zip-compressed","application/octet-stream"});try{startActivityForResult(i,FILE);}catch(Exception e){fileCallback.onReceiveValue(null);fileCallback=null;}return true;}});
  setContentView(web);web.setOnApplyWindowInsetsListener((v,insets)->{int l=0,r=0;if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null){l=insets.getDisplayCutout().getSafeInsetLeft();r=insets.getDisplayCutout().getSafeInsetRight();}web.setPadding(l,0,r,0);return insets;});
  if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,()->web.evaluateJavascript("window.dispatchEvent(new Event('arena:back'))",null));
  web.loadUrl(ROOT+"arena-manager-beta/remix31/?v=52");
 }
 private String mime(String path){if(path.endsWith(".html"))return"text/html";if(path.endsWith(".js"))return"application/javascript";if(path.endsWith(".css"))return"text/css";if(path.endsWith(".json"))return"application/json";if(path.endsWith(".webp"))return"image/webp";if(path.endsWith(".jpg"))return"image/jpeg";if(path.endsWith(".png"))return"image/png";if(path.endsWith(".svg"))return"image/svg+xml";if(path.endsWith(".mp3"))return"audio/mpeg";if(path.endsWith(".wav"))return"audio/wav";if(path.endsWith(".webm"))return"video/webm";if(path.endsWith(".glb"))return"model/gltf-binary";return"application/octet-stream";}
 private WebResourceResponse response(String path,InputStream input){Map<String,String> h=new HashMap<>();h.put("Cache-Control","no-store");h.put("Content-Security-Policy",CSP);h.put("Access-Control-Allow-Origin","*");return new WebResourceResponse(mime(path),"UTF-8",200,"OK",h,input);}
 private WebResourceResponse route(Uri uri){
  if(!"https".equals(uri.getScheme()))return error(403);
  String clean=uri.buildUpon().clearQuery().fragment(null).build().toString();
  if("raw.githubusercontent.com".equals(uri.getHost())){
   String file=aliases.optString(clean,"");if(!file.isEmpty())try{return response(file,getAssets().open("public/"+file));}catch(Exception ignored){}
   return uri.getPath()!=null&&uri.getPath().startsWith("/Abror1111/arena-manager-beta/")?null:error(403);
  }
  if(!"arena.local".equals(uri.getHost()))return error(403);
  String path=uri.getPath();if(path==null||path.equals("/"))path="/arena-manager-beta/remix31/index.html";if(path.endsWith("/"))path+="index.html";if(path.contains("..")||path.indexOf('\\')>=0)return error(403);
  try{return response(path,getAssets().open("public"+path));}catch(Exception ignored){}
  String prefix="/arena-manager-beta/";if(!path.startsWith(prefix))return error(404);String rel=path.substring(prefix.length());
  if(!(rel.startsWith("visuals/")||rel.startsWith("cs2/")||rel.startsWith("approved14/")||rel.startsWith("materials/")||rel.startsWith("environment132/")||rel.startsWith("rebuilt131/")))return error(404);
  try{URLConnection c=new URL(REMOTE+rel).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(60000);return response(path,c.getInputStream());}catch(Exception e){return error(503);}
 }
 private WebResourceResponse error(int code){return new WebResourceResponse("text/plain","UTF-8",code,code==403?"Forbidden":code==503?"Unavailable":"Not Found",new HashMap<>(),new ByteArrayInputStream(new byte[0]));}
 private static byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>max)throw new IOException("File too large");out.write(b,0,n);}return out.toByteArray();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==FILE){if(fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);fileCallback=null;}return;}if(result!=RESULT_OK||data==null||data.getData()==null){pendingBackup=null;return;}try{if(request==SAVE&&pendingBackup!=null){try(OutputStream o=getContentResolver().openOutputStream(data.getData(),"wt")){if(o==null)throw new IOException();o.write(pendingBackup.getBytes(StandardCharsets.UTF_8));}pendingBackup=null;status("Zaxira saqlandi.");}else if(request==OPEN){try(InputStream in=getContentResolver().openInputStream(data.getData())){if(in==null)throw new IOException();String text=new String(read(in,1000000),StandardCharsets.UTF_8);web.evaluateJavascript("window.dispatchEvent(new CustomEvent('arena:import',{detail:"+JSONObject.quote(text)+"}))",null);}}}catch(Exception e){pendingBackup=null;status("Fayl o‘qilmadi yoki saqlanmadi. 1 MB gacha JSON tanlang.");}}
 @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused){if(Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();if(c!=null){c.hide(WindowInsets.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}}else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}}
 @Override protected void onPause(){if(web!=null){web.evaluateJavascript("window.dispatchEvent(new Event('arena:pause'))",null);web.onPause();}super.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('arena:back'))",null);}
 @Override protected void onDestroy(){if(fileCallback!=null)fileCallback.onReceiveValue(null);if(web!=null){web.removeJavascriptInterface("ArenaShell");web.destroy();web=null;}super.onDestroy();}
}
