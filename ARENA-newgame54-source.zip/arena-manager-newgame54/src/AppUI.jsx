import React,{useEffect,useId,useRef} from 'react';
import {AdaptiveDeck,card} from './AdaptiveDeck.jsx';

const paths={menu:'M4 6h16M4 12h16M4 18h16',close:'m6 6 12 12M6 18 18 6',arrow:'m9 5 7 7-7 7',camera:'M4 6h4l2-2h4l2 2h4v14H4ZM8 13a4 4 0 1 0 8 0 4 4 0 0 0-8 0',people:'M8 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-3a6 6 0 0 1 12 0v3M16 4a4 4 0 0 1 0 8M18 15a5 5 0 0 1 4 5',settings:'M4 7h16M4 17h16M8 4v6m8 4v6',play:'m8 4 12 8-12 8V4Z',pause:'M8 4v16M16 4v16',home:'m3 10 9-7 9 7v11h-6v-7H9v7H3V10Z',shield:'M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6L12 2Z',map:'m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2V5Zm6-2v16m6-14v16',check:'m5 12 4 4L19 6',back:'m15 5-7 7 7 7',sun:'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM12 1v2m0 18v2M1 12h2m18 0h2M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2'};
export function AppIcon({name,size=20}){return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]||paths.settings}/></svg>;}

export function useGameViewport(){
 useEffect(()=>{const v=window.visualViewport;let baseHeight=Math.round(v?.height||innerHeight),baseWidth=innerWidth;const update=()=>{const h=Math.round(v?.height||innerHeight),typing=/^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName||'');if(innerWidth!==baseWidth){baseWidth=innerWidth;baseHeight=h}baseHeight=Math.max(baseHeight,h);document.documentElement.style.setProperty('--app-vh',h+'px');document.documentElement.style.setProperty('--app-vtop',Math.round(v?.offsetTop||0)+'px');document.documentElement.dataset.keyboard=String((typing||document.documentElement.dataset.keyboard==='true')&&(h<innerHeight-120||h<baseHeight-120));};update();for(const e of ['resize','scroll'])v?.addEventListener(e,update);for(const e of ['resize','focusin','focusout'])window.addEventListener(e,update);return()=>{for(const e of ['resize','scroll'])v?.removeEventListener(e,update);for(const e of ['resize','focusin','focusout'])window.removeEventListener(e,update);document.documentElement.style.removeProperty('--app-vh');document.documentElement.style.removeProperty('--app-vtop');delete document.documentElement.dataset.keyboard;};},[]);
}

export function GameDialog({title,eyebrow='ARENA / MANAGER',onClose,children,className=''}){
 const ref=useRef(),titleId=useId(),drag=useRef(null);
 useEffect(()=>{const d=ref.current,previous=document.activeElement;d.showModal();(d.querySelector('[data-autofocus]')||d.querySelector('h2'))?.focus({preventScroll:true});return()=>{d.close();if(previous?.isConnected&&previous.getClientRects().length)previous.focus({preventScroll:true});};},[]);
 const trap=e=>{if(e.key!=='Tab')return;const items=[...ref.current.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),a[href],summary,[tabindex]:not([tabindex="-1"])')].filter(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'),first=items[0],last=items.at(-1);if(!first){e.preventDefault();return;}if(e.shiftKey&&(document.activeElement===first||!items.includes(document.activeElement))){e.preventDefault();last.focus();}else if(!e.shiftKey&&(document.activeElement===last||!items.includes(document.activeElement))){e.preventDefault();first.focus();}};
 const end=e=>{if(drag.current===null)return;const delta=e.clientY-drag.current;drag.current=null;ref.current.style.removeProperty('--dialog-drag');if(delta>100)onClose();};
 return <dialog ref={ref} className={'game-dialog '+className} aria-modal="true" aria-labelledby={titleId} onKeyDown={trap} onCancel={e=>{e.preventDefault();onClose();}} onClick={e=>{if(e.target===e.currentTarget)onClose();}}><section className="game-sheet"><header className="game-sheet-heading" onPointerDown={e=>{if(e.button>0||e.target.closest('button'))return;drag.current=e.clientY;e.currentTarget.setPointerCapture(e.pointerId);}} onPointerMove={e=>{if(drag.current!==null)ref.current.style.setProperty('--dialog-drag',Math.max(0,e.clientY-drag.current)+'px');}} onPointerUp={end} onPointerCancel={()=>{drag.current=null;ref.current?.style.removeProperty('--dialog-drag');}}><span className="sheet-handle" aria-hidden="true"/><div><span className="eyebrow">{eyebrow}</span><h2 id={titleId} tabIndex="-1">{title}</h2></div><button className="app-icon-button" aria-label="Panelni yopish" onClick={onClose}><AppIcon name="close"/></button></header><div className="game-sheet-body">{className.includes('navigation-dialog')||className.includes('battle-roster-dialog')||className.includes('new-game-dialog54')?<div className="static-panel52">{children}</div>:className.includes('arsenal-dialog')?<div className="shop-scroll" data-vertical-scroll="shop">{children}</div>:<AdaptiveDeck label={title} items={dialogCards(children)}/>}</div></section></dialog>;
}

// Semantic blocks keep every command reachable in a short, horizontal sheet.
function dialogCards(children){
 const result=[];
 function add(node,context=''){
  React.Children.forEach(node,n=>{
   if(n===null||n===false)return;
   if(!React.isValidElement(n)){if(String(n).trim())result.push(card('dialog-'+result.length,'',<p>{n}</p>));return;}
   const cls=n.props.className||'';
   if(n.type===React.Fragment||(n.type==='div'&&React.Children.toArray(n.props.children).some(c=>React.isValidElement(c)&&(c.props.className||'').split(' ').includes('command-row')))||['purchase-summary','commands','outcome','roster-columns','roster-team','menu-grid','audio-pack-settings','audio-sliders','explorer-dialog-actions','camera-choice-grid','command-row','settings-actions'].some(x=>cls.split(' ').includes(x))||n.type==='ul'){
    add(n.props.children,cls);return;
   }
   if(n.type==='details'){add(n.props.children,cls);return;}
   if(n.type==='summary'){result.push(card('dialog-'+result.length,'',<h3>{n.props.children}</h3>));return;}
   if((n.type==='p'||n.type==='small'||n.type==='li')&&typeof n.props.children==='string'&&n.props.children.length>220){
    const words=n.props.children.split(' ');let text='';for(const word of words){if((text+' '+word).length>190){result.push(card('dialog-'+result.length,'',<p>{text}</p>));text='';}text+=(text?' ':'')+word;}if(text)result.push(card('dialog-'+result.length,'',<p>{text}</p>));return;
   }
   result.push(card('dialog-'+result.length,'',<div className={'dialog-block '+context}>{n}</div>));
  });
 }
 add(children);return result;
}
