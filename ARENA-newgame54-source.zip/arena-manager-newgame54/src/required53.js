import{ensureGuide52,guideBattleReady52,hasGuideAction52}from'./guide-state52.js';
const battle=['battle-pause','battle-auto','battle-player','battle-order','battle-speed','battle-play'];
export function requiredTutorial53(c){return !!c.tutorial?.required53&&!c.tutorial.complete}
export function ensureRequired53(state){if(!state.tutorial||state.tutorial.complete)return state;if(state.tutorial.required53&&state.tutorial.guide52&&!state.tutorial.guide52.paused)return state;const c=structuredClone(ensureGuide52(state)),t=c.tutorial,g=t.guide52,first=!t.required53;t.required53=true;g.paused=false;
 // Real completed work from an older guide remains completed; migration never spends or grants funds.
 if(first&&t.step===3&&c.finance.stats.training>0)for(const k of['training-player','training-skill'])if(!g.actions.includes(k))g.actions.push(k);
 if(first&&t.step===8&&c.history.some(h=>h.type==='practice'&&!h.forfeit))for(const k of battle)if(!g.actions.includes(k))g.actions.push(k);
 return c}
export function assertRequiredStep53(c){if(!requiredTutorial53(c))return;const s=c.tutorial.step,okay=s===2?hasGuideAction52(c,'roster'):s===3?['training-player','training-skill'].every(k=>hasGuideAction52(c,k)):s===4?hasGuideAction52(c,'rest'):s===5?['map','strategy'].every(k=>hasGuideAction52(c,k)):s===8?guideBattleReady52(c):true;if(!okay)throw Error('Avval ko‘rsatilgan boshqaruvlarni amalda sinang. Qo‘llanma to‘liq tugagach klub ochiladi.')}
export function validateRequired53(t){return t?.required53===undefined||typeof t.required53==='boolean'}
