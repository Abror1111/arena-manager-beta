import*as C from'./career.js';
import{ensureRequired53}from'./required53.js';
import{ensureGuide52}from'./guide-state52.js';
export const RESTART_BACKUP54=C.SAVE_KEY+'-before-newgame54';
export function restartBackup54(storage){try{const text=storage.getItem(RESTART_BACKUP54);if(!text)return null;return{text,career:C.importCareer(text)}}catch{return null}}
export function startNewGame54(storage,previous,{demo=false}={}){C.validateCareer(previous);let next=demo?ensureGuide52(C.createNewCareer()):ensureRequired53(C.createNewCareer());next.settings.quality=previous.settings.quality;C.validateCareer(next);const data=JSON.stringify(next);
 // Preserve an importable snapshot before replacing the current club; storage failure must not reset the UI.
 try{storage.setItem(RESTART_BACKUP54,C.exportCareer(previous));storage.setItem(C.SAVE_KEY,data)}catch{throw Error('Yangi o‘yin saqlanmadi. Joriy klub o‘zgartirilmadi. Joy bo‘shating yoki avval zaxira fayl oling.')}
 let fallbackSaved=true;try{storage.setItem(C.BACKUP_KEY,data)}catch{fallbackSaved=false}
 return{career:next,fallbackSaved}}
