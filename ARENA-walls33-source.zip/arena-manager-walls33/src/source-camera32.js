import{createCinematicCamera}from'./cinematic-camera23.js';
// Work in metres internally so source-map scale never doubles the pan speed.
export function createSourceCamera32(scale=1){const spring=createCinematicCamera(),s=scale||1;const toMetres=p=>({...p,x:p.x/s,y:p.y/s,z:p.z/s,span:p.span/s});return{step(frame,dt){const f=toMetres(frame);f.minSpan=frame.minSpan===undefined?undefined:frame.minSpan/s;if(frame.seed)f.seed=toMetres(frame.seed);const q=spring.step(f,dt);return{...q,x:q.x*s,y:q.y*s,z:q.z*s,span:q.span*s,travel:q.travel*s,panSpeed:q.panSpeed*s}}}}
